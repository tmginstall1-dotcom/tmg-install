# Staff Android artifact-only handoff

Use the sanitized archive from the frozen candidate, not July `main` or its old
APK. No installed app update, production publication, release or notification
has been performed by this work.

1. Extract into the owner's isolated `codex/staff-operations-2026-10-20` branch.
   Preserve all archive paths, including `.github/workflows/build-android.yml`.
   Do not merge/push `main`. Check `android-build-inputs.sha256` before edits.
2. Run **Build Android APK & AAB**, selecting that isolated branch. Manual runs
   are artifact-only even if an older default-branch UI omits the new input.
   They build web assets without starting the server or running migrations.
3. Existing repository signing secrets must be present. Do not create, replace
   or export keys. CI refuses an unsigned manual upgrade.
4. Download `tmg-staff-release-apk` only after successful package/signer/version
   verification. Inspect its `android-build-proof.txt`.

Required package: `com.tmginstall.staff`.
Required signing certificate SHA256:
`bc68524e65ed0d6c147a4bf736b3a609708f73042f558c429128120a1174a484`.
Owner-inspected July APK: versionName `1.0.116`, versionCode `116`, SHA256
`e2589390188c878d3c91b3a1a871d6aced9e7e82bab15104b43a03b363b4b211`.
Another existing artifact uses versionCode `20260701`; the new CI code is
`20260701 + github.run_number`, and CI checks it is greater than `20260701`.

Web and background GPS use `https://tmginstall.com`. Existing location
permissions/purpose are unchanged; no exact-alarm permission is added. Native
service uses the same origin's session cookie and revalidates its open shift
before collecting on startup/restart. Missing/expired auth stops tracking and
requires sign-in. Job/site completion does not close attendance or stop shift GPS.
Clock-out/logout stops tracking. Pending captured points are bounded, retain
their capture timestamp and are acknowledged before removal; closed/wrong-shift
points cannot become off-duty server records. When revalidation cannot reach the
server, collection pauses rather than trusting an old active flag indefinitely.

Build tooling matches the already-declared Capacitor 8 requirements: Node 22,
Java 21, SDK 36, Gradle 8.14.3/AGP 8.13.0 and AndroidX template versions.
Minimum Android is API 24 (Android 7), as required by Capacitor 8. Target SDK
remains the existing 33 to avoid silently changing installed-app permission/
window behavior; this is not a Play Store submission or target-36 certification.
No npm dependencies or Android permission declarations have been changed.

The existing public Android Firebase config is included and package-checked.
It is not a private service-account credential. Missing config fails the build.
Available shared/development/production metadata reports the backend
`FIREBASE_SERVICE_ACCOUNT` credential absent: project pairing and real assignment
push delivery are **not verified**, and app packaging alone does not enable them.
Owner-managed backend setup/verification is separate; no notifications were sent.

## Mandatory device check before staff distribution

This environment has no configured Android SDK/signing secrets. Browser tests,
mocked native startup and the plain-Java lifecycle race check are not an Android
APK build or physical-device certification. CI must first compile and sign it.

On a synthetic staff account on an Android device, verify upgrade without
uninstalling, camera/gallery, precise location, visible foreground notification,
screen-off/Doze, resume/restart, airplane-mode recovery, call/maps/work-sheet,
clock-in through a job completion to clock-out, logout/session expiry and no
off-duty collection. Never use real customer/staff records for this check.
Android vendor battery restrictions and offline remote-clock-out awareness
cannot be certified in a browser.

Old APKs may retain previously cached financial data/copied customer bearer
links until upgraded/cleared. New server responses restrict live access, but
cannot remotely erase old offline copies. No customer links have been rotated.
Keep legitimate customer access intact.

The server/client release changes require the normal owner-controlled
publication and exact-release WhatsApp quotation activation procedure; do not
bypass or activate it in CI. Manual artifact builds do not publish a GitHub
release, call the production build-notification endpoint or change the database.
