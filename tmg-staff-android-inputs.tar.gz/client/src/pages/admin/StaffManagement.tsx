import { useState, useEffect, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useSearch, useLocation } from "wouter";
import { format, differenceInMinutes, startOfMonth, endOfMonth, startOfWeek, endOfWeek, parseISO } from "date-fns";
import {
 Plus, Trash2, Pencil, Check, X, Users, Clock, UserPlus, LogIn, LogOut,
 ChevronDown, ChevronUp, Calendar, FileText, Settings2, Loader2, AlertCircle, MapPin, Printer,
 ArrowRight, DollarSign, ChevronLeft, ChevronRight, Navigation2, MoveRight, CircleDot, CreditCard, AlertTriangle
} from "lucide-react";
import OfficialPayslip from "@/components/OfficialPayslip";
import { payslipLoanPresentation, staffLoanStatus } from "../../../../shared/payslipLoanPresentation";
import GpsMap from "@/components/GpsMap";
import {closedShiftTime,completedBreakMinutes,formatSingaporeAttendance} from "@/lib/attendanceTime";
import {singaporeInputValue,singaporeInputToIso,attendanceAmendmentDateError} from "../../../../shared/attendanceTime";
import {singaporeGpsDay,validGpsDay,loadGpsHistory,gpsElapsedSeconds} from "@/lib/gps-history";

const API_BASE = (import.meta.env.VITE_API_BASE as string) || "";

const TEAM_COLORS = ["#6366f1","#ec4899","#f59e0b","#10b981","#3b82f6","#ef4444","#8b5cf6","#14b8a6"];

function fmt(mins: number) {
 if (mins < 0) mins = 0;
 const h = Math.floor(mins / 60);
 const m = mins % 60;
 return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

function StatusBadge({ status }: { status: string }) {
 const map: Record<string, string> = {
 pending: "bg-amber-50 text-amber-700",
 approved: "bg-emerald-50 text-emerald-700",
 rejected: "bg-red-50 text-red-700",
 };
 return (
 <span className={`inline-flex items-center rounded-md px-2 py-0.5 text-[11px] font-semibold whitespace-nowrap ${map[status] || "bg-zinc-100 text-zinc-600"}`}>
 {status}
 </span>
 );
}

const LEAVE_TYPE_LABELS: Record<string, string> = {
 annual: "Annual Leave",
 medical: "Medical Leave",
 unpaid: "Unpaid Leave",
 other: "Other",
};

export default function StaffManagement() {
 const search = useSearch();
 const [, navigate] = useLocation();
 const params = new URLSearchParams(search);
 const tabParam = params.get("tab");
 const validTabs = ["teams", "payroll", "amendments", "leave", "payslips", "tracking"] as const;
 type TabKey = typeof validTabs[number];
 const [tab, setTab] = useState<TabKey>(
 validTabs.includes(tabParam as TabKey) ? (tabParam as TabKey) : "teams"
 );

 useEffect(() => {
 const p = new URLSearchParams(search);
 const t = p.get("tab");
 if (validTabs.includes(t as TabKey)) setTab(t as TabKey);
 }, [search]);

 const switchTab = (key: TabKey) => {
 setTab(key);
 navigate(`/admin/staff?tab=${key}`, { replace: true });
 };

 // Fetch pending counts for badge display
 const { data: pendingAmendments = [] } = useQuery<any[]>({
 queryKey: ["/api/admin/attendance/amendments"],
 select: (d) => d.filter((a: any) => a.status === "pending"),
 refetchInterval: 30_000,
 });
 const { data: pendingLeave = [] } = useQuery<any[]>({
 queryKey: ["/api/admin/leave", "pending"],
 queryFn: async () => {
 const res = await fetch(`${API_BASE}/api/admin/leave?status=pending`, { credentials: "include" });
 return res.json();
 },
 refetchInterval: 30_000,
 });

 const pendingAmendCount = (pendingAmendments as any[]).length;
 const pendingLeaveCount = (pendingLeave as any[]).length;

 const tabs = [
 { key: "teams" as const, label: "Teams & Staff", icon: Users, badge: 0 },
 { key: "payroll" as const, label: "Attendance", icon: Clock, badge: 0 },
 { key: "amendments" as const, label: "Amendments", icon: AlertCircle, badge: pendingAmendCount },
 { key: "leave" as const, label: "Leave", icon: Calendar, badge: pendingLeaveCount },
 { key: "payslips" as const, label: "Payslips", icon: FileText, badge: 0 },
 { key: "tracking" as const, label: "GPS Track", icon: Navigation2, badge: 0 },
 ];

 // Staff count for header display
 const { data: allStaffForHeader = [] } = useQuery<any[]>({ queryKey: ["/api/staff"] });

 return (
 <div className="min-h-screen pt-14 pb-16 lg:pl-56 bg-[#F5F4F0] overflow-x-hidden">

 {/* Light header */}
 <div className="bg-white border-b border-zinc-200 px-6 py-5">
 <p className="text-xs text-zinc-400 mb-1">Management → Staff & HR</p>
 <div className="flex items-center gap-3">
 <h1 className="text-xl font-semibold text-zinc-900">Staff & HR</h1>
 {(pendingAmendCount + pendingLeaveCount) > 0 && (
 <span className="inline-flex items-center rounded-md px-2 py-0.5 text-[11px] font-semibold bg-amber-50 text-amber-700">
 {pendingAmendCount + pendingLeaveCount} pending
 </span>
 )}
 </div>
 <p className="text-sm text-zinc-500 mt-0.5">{(allStaffForHeader as any[]).length} staff members</p>
 
 {/* Tab bar */}
 <div className="flex border-b border-zinc-200 overflow-x-auto scrollbar-none mt-5 -mb-5">
 {tabs.map(({ key, label, icon: Icon, badge }) => (
 <button key={key} onClick={() => switchTab(key)}
 className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium whitespace-nowrap cursor-pointer transition-colors border-b-2 ${
 tab === key
 ? "text-zinc-900 border-blue-600"
 : "text-zinc-500 border-transparent hover:text-zinc-900"
 }`}
 data-testid={`tab-${key}`}>
 <Icon className="w-4 h-4 shrink-0" />
 <span>{label}</span>
 {badge > 0 && (
 <span className="inline-flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white ml-1.5">
 {badge}
 </span>
 )}
 </button>
 ))}
 </div>
 </div>

 <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-6">
 {tab === "teams" && <TeamsTab />}
 {tab === "payroll" && <PayrollTab />}
 {tab === "amendments" && <AmendmentsTab />}
 {tab === "leave" && <LeaveTab />}
 {tab === "payslips" && <PayslipsTab />}
 {tab === "tracking" && <GpsTrackingTab />}
 </div>
 </div>
 );
}

// ─── Teams Tab ───────────────────────────────────────────────────────────────

function TeamsTab() {
 const qc = useQueryClient();
 const { toast } = useToast();
 const [newTeamName, setNewTeamName] = useState("");
 const [newTeamColor, setNewTeamColor] = useState(TEAM_COLORS[0]);
 const [addingTeam, setAddingTeam] = useState(false);
 const [newStaff, setNewStaff] = useState({ name: "", username: "", password: "" });
 const [addingStaff, setAddingStaff] = useState(false);
 const [paySettingsStaffId, setPaySettingsStaffId] = useState<number | null>(null);
 const [editStaffId, setEditStaffId] = useState<number | null>(null);

 const { data: teams = [] } = useQuery<any[]>({ queryKey: ["/api/teams"], refetchInterval: 30_000 });
 const { data: allStaff = [] } = useQuery<any[]>({ queryKey: ["/api/staff"], refetchInterval: 30_000 });

 const unassigned = allStaff.filter((s: any) => !s.teamId);

 const createTeamMut = useMutation({
 mutationFn: () => apiRequest("POST", "/api/teams", { name: newTeamName, color: newTeamColor }),
 onSuccess: () => { qc.invalidateQueries({ queryKey: ["/api/teams"] }); setNewTeamName(""); setAddingTeam(false); toast({ title: "Team created" }); },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 const deleteTeamMut = useMutation({
 mutationFn: (id: number) => apiRequest("DELETE", `/api/teams/${id}`),
 onSuccess: () => { qc.invalidateQueries({ queryKey: ["/api/teams"] }); qc.invalidateQueries({ queryKey: ["/api/staff"] }); toast({ title: "Team deleted" }); },
 });

 const assignMut = useMutation({
 mutationFn: ({ teamId, userId }: { teamId: number; userId: number }) =>
 apiRequest("POST", `/api/teams/${teamId}/assign`, { userId }),
 onSuccess: () => { qc.invalidateQueries({ queryKey: ["/api/teams"] }); qc.invalidateQueries({ queryKey: ["/api/staff"] }); },
 });

 const unassignMut = useMutation({
 mutationFn: (userId: number) => apiRequest("POST", `/api/staff/${userId}/unassign-team`, {}),
 onSuccess: () => { qc.invalidateQueries({ queryKey: ["/api/teams"] }); qc.invalidateQueries({ queryKey: ["/api/staff"] }); },
 });

 const createStaffMut = useMutation({
 mutationFn: () => apiRequest("POST", "/api/admin/staff", newStaff),
 onSuccess: () => {
 qc.invalidateQueries({ queryKey: ["/api/staff"] });
 setNewStaff({ name: "", username: "", password: "" });
 setAddingStaff(false);
 toast({ title: "Staff account created" });
 },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 const deleteStaffMut = useMutation({
 mutationFn: (id: number) => apiRequest("DELETE", `/api/admin/staff/${id}`),
 onSuccess: () => { qc.invalidateQueries({ queryKey: ["/api/staff"] }); qc.invalidateQueries({ queryKey: ["/api/teams"] }); toast({ title: "Staff removed" }); },
 });

 return (
 <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
 {/* Left: Staff Pool */}
 <div className="lg:col-span-1 space-y-6">
 <div className="bg-white border border-zinc-200 rounded-none overflow-hidden">
 <div className="px-5 py-4 border-b border-zinc-100 flex items-center justify-between">
 <h2 className="text-sm font-semibold text-zinc-900">All Staff</h2>
 <button onClick={() => setAddingStaff(true)}
 className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-xs font-medium transition-colors">
 <UserPlus className="w-3.5 h-3.5" /> Add
 </button>
 </div>

 <div className="p-0">
 {addingStaff && (
 <div className="m-4 p-4 bg-zinc-50 border border-zinc-200 rounded-lg space-y-3">
 <input value={newStaff.name} onChange={e => setNewStaff(s => ({ ...s, name: e.target.value }))}
 placeholder="Full name" className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" data-testid="input-staff-name" />
 <input value={newStaff.username} onChange={e => setNewStaff(s => ({ ...s, username: e.target.value }))}
 placeholder="Username" className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" data-testid="input-staff-username" />
 <input value={newStaff.password} onChange={e => setNewStaff(s => ({ ...s, password: e.target.value }))}
 type="password" placeholder="Password (min 6)" className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" data-testid="input-staff-password" />
 <div className="flex gap-2">
 <button onClick={() => createStaffMut.mutate()} disabled={createStaffMut.isPending}
 className="inline-flex flex-1 justify-center items-center gap-2 h-9 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-50" data-testid="button-create-staff">
 {createStaffMut.isPending ? "Creating..." : "Create Account"}
 </button>
 <button onClick={() => setAddingStaff(false)} className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50 text-sm font-medium transition-colors">Cancel</button>
 </div>
 </div>
 )}

 <div className="divide-y divide-zinc-100">
 {allStaff.map((s: any) => (
 <div key={s.id} className="p-4 hover:bg-zinc-50 transition-colors">
 <StaffRow staff={s} teams={teams}
 onAssign={(teamId: number) => assignMut.mutate({ teamId, userId: s.id })}
 onUnassign={() => unassignMut.mutate(s.id)}
 onDelete={() => { if (confirm(`Remove ${s.name}? This cannot be undone.`)) deleteStaffMut.mutate(s.id); }}
 onEdit={() => { setEditStaffId(editStaffId === s.id ? null : s.id); setPaySettingsStaffId(null); }}
 onPaySettings={() => { setPaySettingsStaffId(paySettingsStaffId === s.id ? null : s.id); setEditStaffId(null); }} />
 {editStaffId === s.id && <EditStaffForm staff={s} onClose={() => setEditStaffId(null)} />}
 {paySettingsStaffId === s.id && <PaySettingsForm staff={s} onClose={() => setPaySettingsStaffId(null)} />}
 </div>
 ))}
 {allStaff.length === 0 && (
 <p className="text-sm text-zinc-500 text-center py-6">No staff yet</p>
 )}
 </div>
 </div>
 </div>
 </div>

 {/* Right: Teams */}
 <div className="lg:col-span-2 space-y-6">
 <div className="flex items-center justify-between">
 <h2 className="text-sm font-semibold text-zinc-900">Teams</h2>
 <button onClick={() => setAddingTeam(true)}
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors"
 data-testid="button-add-team">
 <Plus className="w-4 h-4" /> New Team
 </button>
 </div>

 {addingTeam && (
 <div className="bg-white border border-zinc-200 rounded-none p-5 space-y-4">
 <input value={newTeamName} onChange={e => setNewTeamName(e.target.value)}
 placeholder="Team name (e.g. Team A)" autoFocus
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" data-testid="input-team-name" />
 <div className="flex gap-2 items-center">
 <span className="text-xs text-zinc-500 font-medium">Colour:</span>
 <div className="flex gap-1.5">
 {TEAM_COLORS.map(c => (
 <button key={c} onClick={() => setNewTeamColor(c)}
 className={`w-6 h-6 rounded-full transition-all ${newTeamColor === c ? "ring-2 ring-offset-2 ring-zinc-400 scale-110" : ""}`}
 style={{ background: c }} />
 ))}
 </div>
 </div>
 <div className="flex gap-2 pt-2">
 <button onClick={() => createTeamMut.mutate()} disabled={!newTeamName || createTeamMut.isPending}
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-50">
 <Check className="w-4 h-4" /> Create
 </button>
 <button onClick={() => setAddingTeam(false)} className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50 text-sm font-medium transition-colors">Cancel</button>
 </div>
 </div>
 )}

 {teams.length === 0 && !addingTeam && (
 <div className="text-center py-16 bg-white border border-dashed border-zinc-200 rounded-none">
 <Users className="w-10 h-10 text-zinc-300 mx-auto mb-3" />
 <p className="text-sm font-medium text-zinc-500">No teams yet</p>
 <p className="text-xs text-zinc-400 mt-1">Create a team to group staff together</p>
 </div>
 )}
 
 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
 {teams.map((team: any) => (
 <TeamCard key={team.id} team={team} allStaff={allStaff}
 onDelete={() => { if (confirm(`Delete ${team.name}? Members will become unassigned.`)) deleteTeamMut.mutate(team.id); }}
 onRemoveMember={(uid: number) => unassignMut.mutate(uid)}
 onAddMember={(uid: number) => assignMut.mutate({ teamId: team.id, userId: uid })} />
 ))}
 </div>
 </div>
 </div>
 );
}

function PaySettingsForm({ staff, onClose }: { staff: any; onClose: () => void }) {
 const qc = useQueryClient();
 const { toast } = useToast();
 const [form, setForm] = useState({
 monthlyRate: staff.monthlyRate || "0",
 hourlyRate: staff.hourlyRate || "0",
 overtimeRate: staff.overtimeRate || "0",
 absenceDeductionRate: staff.absenceDeductionRate || "0",
 annualLeaveEntitlement: staff.annualLeaveEntitlement ?? 14,
 });

 const mut = useMutation({
 mutationFn: () => apiRequest("PATCH", `/api/admin/pay-settings/${staff.id}`, {
 ...form,
 annualLeaveEntitlement: parseInt(String(form.annualLeaveEntitlement)),
 }),
 onSuccess: () => {
 qc.invalidateQueries({ queryKey: ["/api/staff"] });
 onClose();
 toast({ title: "Pay settings updated" });
 },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 const field = (label: string, hint: string, key: keyof typeof form, testId: string) => (
 <div className="space-y-1">
 <div className="flex items-baseline justify-between">
 <label className="text-xs font-medium text-zinc-700">{label}</label>
 <span className="text-[10px] text-zinc-500">{hint}</span>
 </div>
 <div className="relative">
 <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-medium text-zinc-500">S$</span>
 <input type="number" step="0.01" min="0" value={form[key]}
 onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
 className="h-9 w-full pl-8 pr-3 border border-zinc-300 rounded-lg text-sm bg-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid={testId} />
 </div>
 </div>
 );

 return (
 <div className="mx-0 mb-4 bg-white border border-zinc-200 rounded-none overflow-hidden mt-2 ">
 <div className="px-5 py-4 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50">
 <p className="text-sm font-semibold text-zinc-900">Pay Package: {staff.name}</p>
 <button onClick={onClose} className="p-1 text-zinc-400 hover:text-zinc-900 transition-colors"><X className="w-4 h-4" /></button>
 </div>

 <div className="p-5 space-y-5">
 <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
 {field("Monthly Salary", "SGD/mo", "monthlyRate", "input-monthly-rate")}
 {field("Hourly Rate", "first 8 hrs", "hourlyRate", "input-hourly-rate")}
 {field("Overtime Rate", "after 8 hrs", "overtimeRate", "input-overtime-rate")}
 </div>

 {/* Leave entitlement + absence deduction rate */}
 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
 <div className="space-y-1">
 <div className="flex items-baseline justify-between">
 <label className="text-xs font-medium text-zinc-700">Annual Leave</label>
 <span className="text-[10px] text-zinc-500">days/yr</span>
 </div>
 <input type="number" min="0" max="30" value={form.annualLeaveEntitlement}
 onChange={e => setForm(f => ({ ...f, annualLeaveEntitlement: parseInt(e.target.value) || 0 }))}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="input-leave-entitlement" />
 </div>
 {field("Absence Deduction", "per day, 0 = auto", "absenceDeductionRate", "input-absence-deduction-rate")}
 </div>
 <p className="text-[10px] text-zinc-500 -mt-3">
 Deducted for each day of unpaid leave or annual leave taken beyond the yearly entitlement. Leave at 0 to derive from salary (monthly ÷ 26).
 </p>

 <div className="flex gap-3 pt-4 border-t border-zinc-100 mt-6">
 <button onClick={() => mut.mutate()} disabled={mut.isPending}
 className="inline-flex items-center justify-center gap-2 h-9 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-50"
 data-testid="button-save-pay">
 {mut.isPending ? "Saving…" : "Save Pay Package"}
 </button>
 <button onClick={onClose} className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50 text-sm font-medium transition-colors">Cancel</button>
 </div>
 </div>
 </div>
 );
}

function StaffRow({ staff, teams, onAssign, onUnassign, onDelete, onPaySettings, onEdit }: any) {
 const team = teams.find((t: any) => t.id === staff.teamId);
 const monthly = parseFloat(staff.monthlyRate || "0");
 const hourly = parseFloat(staff.hourlyRate || "0");
 const hasPayConfig = monthly > 0 || hourly > 0;
 const missingDetails = !staff.phone && !staff.nricFin;
 const initial = staff.name.charAt(0).toUpperCase();

 return (
 <div className="px-5 py-4 border-b border-black/10 last:border-0 hover:bg-[#F5F4F0] transition-colors" data-testid={`staff-row-${staff.id}`}>
 <div className="flex items-start justify-between gap-4">
 <div className="flex items-start gap-3 min-w-0 flex-1">
 {/* Ink avatar — flat, square-ish to match Yeezy aesthetic */}
 <div className="w-11 h-11 rounded-none bg-[#0A0A0A] flex items-center justify-center text-base font-extrabold text-white shrink-0">
 {initial}
 </div>
 <div className="min-w-0 flex-1">
 <p className="text-[15px] font-bold text-[#0A0A0A] truncate leading-tight">{staff.name}</p>
 <div className="flex items-center gap-2 text-[11px] text-[#0A0A0A]/55 mt-0.5 font-medium">
 <span>@{staff.username}</span>
 {(staff.phone || staff.email) && (
 <>
 <span className="text-[#0A0A0A]/30">•</span>
 <span className="truncate">{[staff.phone, staff.email].filter(Boolean).join(" · ")}</span>
 </>
 )}
 </div>

 {/* Status pills row */}
 <div className="flex items-center gap-1.5 mt-2 flex-wrap">
 {team ? (
 <span className="inline-flex items-center rounded-none px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider whitespace-nowrap border"
 style={{ backgroundColor: team.color + "1A", color: team.color, borderColor: team.color + "44" }}>
 {team.name}
 </span>
 ) : (
 <span className="inline-flex items-center rounded-none px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider whitespace-nowrap bg-[#EBE9E2] text-[#0A0A0A] border border-black/15">
 Unassigned
 </span>
 )}
 {hasPayConfig ? (
 <span className="inline-flex items-center gap-1 rounded-none px-2 py-0.5 text-[10px] font-bold whitespace-nowrap bg-white text-[#0A0A0A] border border-black/15">
 <DollarSign className="w-3 h-3" />
 {monthly > 0 ? `S$${monthly.toFixed(0)}/mo` : `S$${hourly.toFixed(2)}/hr`}
 </span>
 ) : (
 <span className="inline-flex items-center rounded-none px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider whitespace-nowrap bg-[#FBEBEB] text-[#C1121F] border border-[#C1121F]/20">
 No pay set
 </span>
 )}
 {missingDetails && (
 <span className="inline-flex items-center gap-1 rounded-none px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider whitespace-nowrap bg-[#FBEBEB] text-[#C1121F] border border-[#C1121F]/20">
 <AlertCircle className="w-3 h-3" />
 Profile incomplete
 </span>
 )}
 </div>

 {/* Team assignment selector — dedicated row so it doesn't crowd the pills */}
 <div className="mt-2">
 <select onChange={e => { if (e.target.value === "__unassign__") onUnassign(); else if (e.target.value) onAssign(parseInt(e.target.value)); e.target.value = ""; }}
 className="h-7 pl-2 pr-7 text-[11px] font-semibold border border-black/15 rounded-none bg-white text-[#0A0A0A] outline-none focus:ring-1 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] max-w-[140px]"
 defaultValue=""
 data-testid={`select-assign-team-${staff.id}`}>
 <option value="" disabled>{staff.teamId ? "Move to team…" : "Assign to team…"}</option>
 {staff.teamId && <option value="__unassign__">— Remove from team</option>}
 {teams.filter((t: any) => t.id !== staff.teamId).map((t: any) => <option key={t.id} value={t.id}>{t.name}</option>)}
 </select>
 </div>
 </div>
 </div>

 {/* Action cluster — ink icons, flat rounded-none to match Yeezy */}
 <div className="flex items-center gap-0 shrink-0 border border-black/10 rounded-none bg-white">
 <button onClick={onEdit} title="Edit account"
 className="inline-flex items-center justify-center w-9 h-9 text-[#0A0A0A] hover:bg-[#0A0A0A] hover:text-white transition-colors"
 data-testid={`button-edit-staff-${staff.id}`}>
 <Pencil className="w-4 h-4" />
 </button>
 <div className="w-px h-5 bg-black/10" />
 <button onClick={onPaySettings} title="Pay settings"
 className="inline-flex items-center justify-center w-9 h-9 text-[#0A0A0A] hover:bg-[#0A0A0A] hover:text-white transition-colors"
 data-testid={`button-pay-settings-${staff.id}`}>
 <Settings2 className="w-4 h-4" />
 </button>
 <div className="w-px h-5 bg-black/10" />
 <button onClick={onDelete} title="Delete staff"
 className="inline-flex items-center justify-center w-9 h-9 text-[#0A0A0A] hover:bg-[#C1121F] hover:text-white transition-colors"
 data-testid={`button-delete-staff-${staff.id}`}>
 <Trash2 className="w-4 h-4" />
 </button>
 </div>
 </div>
 </div>
 );
}

function EditStaffForm({ staff, onClose }: { staff: any; onClose: () => void }) {
 const qc = useQueryClient();
 const { toast } = useToast();
 const [form, setForm] = useState({
 name: staff.name || "",
 username: staff.username || "",
 password: "",
 phone: staff.phone || "",
 email: staff.email || "",
 nricFin: staff.nricFin || "",
 startDate: staff.startDate || "",
 emergencyName: staff.emergencyName || "",
 emergencyPhone: staff.emergencyPhone || "",
 mustClockInAtFirstJob: !!staff.mustClockInAtFirstJob,
 canClockInAtVanPickup: !!staff.canClockInAtVanPickup,
 });

 const set = (key: keyof typeof form) => (e: any) => setForm(f => ({ ...f, [key]: e.target.value }));

 const mut = useMutation({
 mutationFn: () => {
 const payload: any = {
 name: form.name,
 username: form.username,
 phone: form.phone || null,
 email: form.email || null,
 nricFin: form.nricFin || null,
 startDate: form.startDate || null,
 emergencyName: form.emergencyName || null,
 emergencyPhone: form.emergencyPhone || null,
 mustClockInAtFirstJob: form.mustClockInAtFirstJob,
 canClockInAtVanPickup: form.canClockInAtVanPickup,
 };
 if (form.password) payload.password = form.password;
 return apiRequest("PATCH", `/api/admin/staff/${staff.id}`, payload);
 },
 onSuccess: () => {
 qc.invalidateQueries({ queryKey: ["/api/staff"] });
 onClose();
 toast({ title: "Staff profile updated" });
 },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 const sectionLabel = (text: string) => (
 <p className="text-xs font-semibold text-zinc-900 mt-5 mb-3 first:mt-0 pb-2 border-b border-zinc-100">{text}</p>
 );

 const field = (label: string, key: keyof typeof form, opts?: { type?: string; placeholder?: string; hint?: string }) => (
 <div className="space-y-1">
 <div className="flex items-baseline justify-between">
 <label className="text-xs font-medium text-zinc-700">{label}</label>
 {opts?.hint && <span className="text-[10px] text-zinc-500">{opts.hint}</span>}
 </div>
 <input
 type={opts?.type || "text"}
 value={form[key]}
 onChange={set(key)}
 placeholder={opts?.placeholder}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid={`input-edit-${key}-${staff.id}`}
 />
 </div>
 );

 return (
 <div className="mx-0 mb-4 bg-white border border-zinc-200 rounded-none overflow-hidden mt-2 ">
 <div className="px-5 py-4 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50">
 <p className="text-sm font-semibold text-zinc-900">Edit Profile: {staff.name}</p>
 <button onClick={onClose} className="p-1 text-zinc-400 hover:text-zinc-900 transition-colors"><X className="w-4 h-4" /></button>
 </div>

 <div className="p-5 space-y-4">
 {/* Account */}
 {sectionLabel("Account")}
 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
 {field("Full Name", "name")}
 {field("Username", "username")}
 </div>
 {field("New Password", "password", { type: "password", placeholder: "Leave blank to keep current", hint: "optional" })}

 {/* Contact */}
 {sectionLabel("Contact Details")}
 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
 {field("Phone", "phone", { placeholder: "+65 9xxx xxxx" })}
 {field("Email", "email", { type: "email", placeholder: "name@example.com" })}
 </div>

 {/* Employment */}
 {sectionLabel("Employment")}
 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
 {field("NRIC / FIN", "nricFin", { placeholder: "S1234567A" })}
 {field("Start Date", "startDate", { type: "date" })}
 </div>
 <label className="flex items-start gap-3 mt-1 cursor-pointer" data-testid={`toggle-firstjob-${staff.id}`}>
 <input
 type="checkbox"
 checked={form.mustClockInAtFirstJob}
 onChange={(e) => setForm(f => ({ ...f, mustClockInAtFirstJob: e.target.checked }))}
 className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-[#0A0A0A] focus:ring-[#0A0A0A]"
 />
 <span className="text-xs text-zinc-700 leading-snug">
 <span className="font-medium text-zinc-900">Legacy first-job override</span>
 <br />
 Kept for older records. The monthly review now decides loading mornings and direct-to-site days automatically from the work schedule.
 </span>
 </label>
 <label className="flex items-start gap-3 mt-1 cursor-pointer" data-testid={`toggle-driver-${staff.id}`}>
 <input
 type="checkbox"
 checked={form.canClockInAtVanPickup}
 onChange={(e) => setForm(f => ({ ...f, canClockInAtVanPickup: e.target.checked }))}
 className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-[#0A0A0A] focus:ring-[#0A0A0A]"
 />
 <span className="text-xs text-zinc-700 leading-snug">
 <span className="font-medium text-zinc-900">Driver — starts loading runs at Woodlands</span>
 <br />
 On the first work day after a gap, the expected route starts near Woodlands St 31 before IKEA Alexandra. Consecutive work days start directly at the first site.
 </span>
 </label>

 {/* Emergency */}
 {sectionLabel("Emergency Contact")}
 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
 {field("Contact Name", "emergencyName", { placeholder: "Full name" })}
 {field("Contact Phone", "emergencyPhone", { placeholder: "+65 9xxx xxxx" })}
 </div>

 <div className="flex gap-3 pt-4 border-t border-zinc-100 mt-6">
 <button
 onClick={() => mut.mutate()}
 disabled={mut.isPending || !form.name || !form.username}
 className="inline-flex items-center justify-center gap-2 h-9 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-50"
 data-testid={`button-save-staff-${staff.id}`}
 >
 {mut.isPending ? "Saving..." : "Save Profile"}
 </button>
 <button onClick={onClose} className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50 text-sm font-medium transition-colors">
 Cancel
 </button>
 </div>
 </div>
 </div>
 );
}

function TeamCard({ team, allStaff, onDelete, onRemoveMember, onAddMember }: any) {
 const [editingName, setEditingName] = useState(false);
 const [name, setName] = useState(team.name);
 const qc = useQueryClient();
 const { toast } = useToast();

 const updateMut = useMutation({
 mutationFn: () => apiRequest("PATCH", `/api/teams/${team.id}`, { name }),
 onSuccess: () => { qc.invalidateQueries({ queryKey: ["/api/teams"] }); setEditingName(false); toast({ title: "Team renamed" }); },
 });

 const nonMembers = allStaff.filter((s: any) => s.teamId !== team.id);

 return (
 <div className="bg-card border overflow-hidden" style={{ borderColor: team.color + "44" }}>
 <div className="px-4 py-3 flex items-center justify-between" style={{ background: team.color + "11" }}>
 <div className="flex items-center gap-2">
 <div className="w-3 h-3" style={{ background: team.color }} />
 {editingName ? (
 <div className="flex items-center gap-1">
 <input value={name} onChange={e => setName(e.target.value)} autoFocus
 className="h-7 px-2 text-sm border border-zinc-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors w-32" />
 <button onClick={() => updateMut.mutate()} className="p-1 text-emerald-600"><Check className="w-3.5 h-3.5" /></button>
 <button onClick={() => setEditingName(false)} className="p-1 text-zinc-400 hover:text-zinc-700 transition-colors"><X className="w-3.5 h-3.5" /></button>
 </div>
 ) : (
 <h3 className="font-semibold text-sm text-zinc-900">{team.name}</h3>
 )}
 <span className="text-xs text-zinc-400">({team.members?.length || 0} staff)</span>
 </div>
 <div className="flex items-center gap-1">
 <button onClick={() => setEditingName(true)} className="p-1.5 text-zinc-400 hover:text-zinc-700 transition-colors">
 <Pencil className="w-3.5 h-3.5" />
 </button>
 <button onClick={onDelete} className="p-1.5 text-zinc-400 hover:text-red-600 transition-colors">
 <Trash2 className="w-3.5 h-3.5" />
 </button>
 </div>
 </div>

 <div className="p-4">
 {team.members?.length === 0 ? (
 <p className="text-sm text-zinc-400 text-center py-4">No members yet — assign staff from the panel on the left</p>
 ) : (
 <div className="flex flex-wrap gap-2 mb-4">
 {team.members.map((m: any) => (
 <div key={m.id} className="flex items-center gap-2 px-3 py-1.5 border border-zinc-200 rounded-lg bg-white text-sm font-semibold">
 <span className="w-6 h-6 rounded-full flex items-center justify-center text-white text-[11px] font-bold shrink-0"
 style={{ background: team.color }}>{m.name.charAt(0)}</span>
 {m.name}
 <button onClick={() => onRemoveMember(m.id)}
 className="text-zinc-400 hover:text-red-600 transition-colors ml-0.5 p-0.5"
 data-testid={`button-remove-member-${m.id}`}>
 <X className="w-3.5 h-3.5" />
 </button>
 </div>
 ))}
 </div>
 )}

 {nonMembers.length > 0 && (
 <div>
 <p className="text-[11px] font-bold text-zinc-400 uppercase tracking-wide mb-2">Add member</p>
 <div className="flex flex-wrap gap-2">
 {nonMembers.map((s: any) => (
 <button key={s.id} onClick={() => onAddMember(s.id)}
 className="flex items-center gap-1.5 px-3 py-1.5 border border-zinc-200 rounded-lg text-[11px] font-semibold text-zinc-700 hover:bg-zinc-50 hover:border-zinc-300 transition-colors"
 data-testid={`button-add-member-${s.id}`}>
 <Plus className="w-3.5 h-3.5 text-zinc-400" /> {s.name}
 </button>
 ))}
 </div>
 </div>
 )}
 </div>
 </div>
 );
}

// ─── Attendance / Payroll Tab ──────────────────────────────────────────────────

// Staff initials avatar with deterministic color
const AVATAR_COLORS = ["#6366f1","#ec4899","#f59e0b","#10b981","#3b82f6","#ef4444","#8b5cf6","#14b8a6","#06b6d4","#84cc16"];
function staffColor(id: number) { return AVATAR_COLORS[id % AVATAR_COLORS.length]; }
function StaffAvatar({ user, size = 10 }: { user: any; size?: number }) {
 const initials = user?.name?.split(" ").map((w: string) => w[0]).slice(0, 2).join("").toUpperCase() || "?";
 return (
 <div style={{ backgroundColor: staffColor(user?.id ?? 0), width: size * 4, height: size * 4, fontSize: size * 1.5 }}
 className="rounded-full flex items-center justify-center text-white font-bold shrink-0">
 {initials}
 </div>
 );
}

function PayrollTab() {
 const [view, setView] = useState<"today" | "timesheets">("today");
 return (
 <div className="space-y-6">
 {/* Sub-tab switcher */}
 <div className="flex border-b border-zinc-200 w-full">
 {([["today","Today's Roster"],["timesheets","Timesheets"]] as const).map(([v,l]) => (
 <button key={v} onClick={() => setView(v)}
 className={`px-4 py-2.5 text-sm font-medium whitespace-nowrap cursor-pointer transition-colors border-b-2 ${view === v ? "text-zinc-900 border-blue-600" : "text-zinc-500 border-transparent hover:text-zinc-900"}`}
 data-testid={`tab-att-${v}`}>
 {l}
 </button>
 ))}
 </div>
 {view === "today" ? <TodayRoster /> : <TimesheetsView />}
 </div>
 );
}

// ─── Today's Roster ────────────────────────────────────────────────────────────

function TodayRoster() {
 const todayStr = format(new Date(), "yyyy-MM-dd");
 const [date, setDate] = useState(todayStr);
 const { data: staff = [] } = useQuery<any[]>({ queryKey: ["/api/staff"] });
 const isValidDate = /^\d{4}-\d{2}-\d{2}$/.test(date) && !isNaN(new Date(date).getTime());
 const isToday = date === todayStr;

 const { data: logs = [], isLoading } = useQuery<any[]>({
 queryKey: ["/api/admin/attendance", date, date, ""],
 queryFn: async () => {
 if (!isValidDate) return [];
 const params = new URLSearchParams({ from: date + "T00:00:00+08:00", to: date + "T23:59:59+08:00" });
 const res = await fetch(`${API_BASE}/api/admin/attendance?${params}`, { credentials: "include" });
 if (!res.ok) return [];
 const data = await res.json();
 return Array.isArray(data) ? data : [];
 },
 enabled: isValidDate,
 refetchInterval: 30000,
 });

 // Live GPS locations for currently clocked-in staff (today only, refresh every 30s)
 const { data: liveLocations = {} } = useQuery<Record<number, { lat: string; lng: string; recordedAt: string }>>({
 queryKey: ["/api/admin/live-locations"],
 queryFn: async () => {
 const res = await fetch(`${API_BASE}/api/admin/live-locations`, { credentials: "include" });
 if (!res.ok) return {};
 return res.json();
 },
 enabled: isToday,
 refetchInterval: 30000,
 });

 // Build roster: each staff member with their log for the day (if any)
 const roster = (staff as any[]).map((s: any) => {
 const log = (logs as any[]).find((l: any) => l.userId === s.id);
 return { staff: s, log: log || null };
 });

 const clockedIn = roster.filter(r => r.log && !r.log.clockOutAt);
 const clockedOut = roster.filter(r => r.log && r.log.clockOutAt);
 const notClockedIn = roster.filter(r => !r.log);

 return (
 <div className="space-y-6">
 {/* Date picker */}
 <div className="flex items-center gap-3 flex-wrap">
 <div className="flex items-center gap-2 bg-white border border-zinc-300 rounded-lg px-3 py-2 h-9 focus-within:ring-2 focus-within:ring-[#0A0A0A] focus-within:border-[#0A0A0A] transition-colors">
 <Calendar className="w-4 h-4 text-zinc-400" />
 <input type="date" value={date} onChange={e => setDate(e.target.value)}
 className="text-sm font-medium text-zinc-900 bg-transparent outline-none" data-testid="input-roster-date" />
 </div>
 {!isToday && (
 <button onClick={() => setDate(todayStr)}
 className="text-sm font-medium text-[#0A0A0A] hover:text-[#0A0A0A] hover:underline transition-colors">Back to Today</button>
 )}
 <span className="text-sm text-zinc-500 font-medium">
 {(() => { try { const d = new Date(date + "T12:00:00"); if (isNaN(d.getTime())) return ""; return (isToday ? "Today, " : "") + format(d, "EEEE, d MMMM yyyy"); } catch { return ""; } })()}
 </span>
 </div>

 {/* Stats cards */}
 <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
 <div className="bg-white border border-zinc-200 rounded-none p-5 ">
 <p className="text-sm font-medium text-zinc-500 mb-1">Clocked in</p>
 <p className="text-3xl font-semibold text-emerald-600">{clockedIn.length}</p>
 </div>
 <div className="bg-white border border-zinc-200 rounded-none p-5 ">
 <p className="text-sm font-medium text-zinc-500 mb-1">Not in</p>
 <p className="text-3xl font-semibold text-zinc-400">{notClockedIn.length}</p>
 </div>
 <div className="bg-white border border-zinc-200 rounded-none p-5 ">
 <p className="text-sm font-medium text-zinc-500 mb-1">Clocked out</p>
 <p className="text-3xl font-semibold text-zinc-900">{clockedOut.length}</p>
 </div>
 </div>

 {/* Staff roster list */}
 {isLoading ? (
 <div className="flex justify-center py-16">
 <div className="animate-spin w-6 h-6 border-2 border-zinc-200 border-t-zinc-900 rounded-full" />
 </div>
 ) : (
 <div className="bg-white border border-zinc-200 rounded-none overflow-hidden divide-y divide-zinc-100">
 {roster.length === 0 && (
 <div className="text-center py-16">
 <Users className="w-10 h-10 text-zinc-300 mx-auto mb-3" />
 <p className="text-sm font-medium text-zinc-500">No staff found.</p>
 </div>
 )}
 {/* Clocked In section */}
 {clockedIn.map(({ staff: s, log }) => (
 <RosterRow key={s.id} staff={s} log={log} status="in" liveLocation={liveLocations[s.id]} />
 ))}
 {/* Clocked Out section */}
 {clockedOut.map(({ staff: s, log }) => (
 <RosterRow key={s.id} staff={s} log={log} status="out" />
 ))}
 {/* Not Clocked In section */}
 {notClockedIn.map(({ staff: s }) => (
 <RosterRow key={s.id} staff={s} log={null} status="absent" />
 ))}
 </div>
 )}
 </div>
 );
}

// Module-level cache so all pill instances share results and avoid duplicate requests
const geocodeCache: Record<string, string> = {};

function useReverseGeocode(lat: string, lng: string) {
 const key = `${parseFloat(lat).toFixed(5)},${parseFloat(lng).toFixed(5)}`;
 const [address, setAddress] = useState<string>(geocodeCache[key] || "");

 useEffect(() => {
 if (geocodeCache[key]) { setAddress(geocodeCache[key]); return; }
 let cancelled = false;
 fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&zoom=17&addressdetails=1`, {
 headers: { "Accept-Language": "en" },
 })
 .then(r => r.json())
 .then(data => {
 if (cancelled) return;
 const a = data?.address;
 // Build a short readable label: road + suburb/district
 const parts = [
 a?.road || a?.pedestrian || a?.footway || a?.path,
 a?.suburb || a?.neighbourhood || a?.quarter || a?.city_district || a?.town || a?.village || a?.city,
 ].filter(Boolean);
 const result = parts.length ? parts.join(", ") : (data?.display_name?.split(",").slice(0, 2).join(",") || key);
 geocodeCache[key] = result;
 setAddress(result);
 })
 .catch(() => { if (!cancelled) setAddress(key); });
 return () => { cancelled = true; };
 }, [key]);

 return address;
}

function GpsLocationPill({ lat, lng, label, color }: { lat: string; lng: string; label: string; color: "green" | "red" }) {
 const address = useReverseGeocode(lat, lng);
 const mapsUrl = `https://maps.google.com/?q=${lat},${lng}`;
 const colorCls = color === "green"
 ? "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-400 dark:border-emerald-800"
 : "bg-red-50 text-red-600 border-red-200 dark:bg-red-950/30 dark:text-red-400 dark:border-red-900";
 return (
 <a href={mapsUrl} target="_blank" rel="noreferrer"
 className={`inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 border hover:opacity-80 transition-opacity ${colorCls}`}
 title={`${label}: ${parseFloat(lat).toFixed(6)}, ${parseFloat(lng).toFixed(6)} — Open in Google Maps`}>
 <MapPin className="w-2.5 h-2.5 shrink-0" />
 {label} · {address || `${parseFloat(lat).toFixed(4)}, ${parseFloat(lng).toFixed(4)}`}
 </a>
 );
}

function RosterRow({ staff, log, status, liveLocation }: {
 staff: any; log: any; status: "in" | "out" | "absent";
 liveLocation?: { lat: string; lng: string; recordedAt: string };
}) {
 const [mapOpen, setMapOpen] = useState<"in" | "out" | "live" | null>(null);
 const rawMins = log?.clockOutAt
 ? differenceInMinutes(new Date(log.clockOutAt), new Date(log.clockInAt))
 : null;
 const dedMins = Math.max(0, Number(log?.deductionMinutes || 0));
 const shiftTime=log?.clockOutAt?closedShiftTime(log):null;
 const breakMins = shiftTime?.breakMinutes??0;
 const mins = shiftTime?.netMinutes??null;

 const hasInGps = !!(log?.clockInLat && log?.clockInLng);
 const hasOutGps = !!(log?.clockOutLat && log?.clockOutLng);

 const activeGps = mapOpen === "out" && hasOutGps
 ? { lat: log.clockOutLat, lng: log.clockOutLng }
 : mapOpen === "in" && hasInGps
 ? { lat: log.clockInLat, lng: log.clockInLng }
 : mapOpen === "live" && liveLocation
 ? { lat: liveLocation.lat, lng: liveLocation.lng }
 : null;

 const osmSrc = activeGps
 ? `https://www.openstreetmap.org/export/embed.html?bbox=${+activeGps.lng - 0.003},${+activeGps.lat - 0.003},${+activeGps.lng + 0.003},${+activeGps.lat + 0.003}&layer=mapnik&marker=${activeGps.lat},${activeGps.lng}`
 : null;

 const liveMinutesAgo = liveLocation
 ? Math.floor((Date.now() - new Date(liveLocation.recordedAt).getTime()) / 60000)
 : null;

 return (
 <div className="px-4 py-3" data-testid={`roster-row-${staff.id}`}>
 {/* Main row */}
 <div className="flex items-center gap-3">
 <StaffAvatar user={staff} size={10} />
 <div className="flex-1 min-w-0">
 <p className="font-bold text-sm leading-tight">{staff.name}</p>
 <p className="text-xs font-mono text-zinc-400">@{staff.username}</p>

 {/* Status + GPS location pills inline */}
 {status === "in" && log && (
 <div className="mt-1 space-y-1">
 <div className="flex items-center gap-1.5">
 <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
 <span className="text-xs font-bold text-emerald-600">Clocked in · {formatSingaporeAttendance(log.clockInAt, "h:mm a")}</span>
 </div>
 {(() => {
 // Live break: an open break has a startAt but no endAt yet. The roster
 // refetches every 30s so this running counter self-updates on its own.
 // Completed breaks stay visible for the rest of the shift so admin can
 // always see WHEN each break was taken and for how long.
 const breaks = Array.isArray(log?.breaks) ? log.breaks : [];
 const open = breaks.find((b: any) => b?.startAt && !b?.endAt);
 const doneList = formatBreakTimes(breaks);
 const openPill = (() => {
 if (!open) return null;
 const ts = new Date(open.startAt).getTime();
 if (!Number.isFinite(ts)) return null;
 const brkMins = Math.max(0, Math.floor((Date.now() - ts) / 60000));
 return (
 <div className="flex items-center gap-1.5" data-testid={`status-onbreak-${staff.id}`}>
 <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse shrink-0" />
 <span className="text-xs font-bold text-amber-600">
 On break ☕ · {brkMins}m (since {format(new Date(ts), "h:mm a")})
 </span>
 </div>
 );
 })();
 if (!openPill && doneList.length === 0) return null;
 return (
 <>
 {openPill}
 {doneList.length > 0 && (
 <div className="text-[11px] font-bold text-amber-600" data-testid={`text-breaks-taken-${staff.id}`}>
 ☕ Break{doneList.length > 1 ? "s" : ""} taken · {doneList.join(", ")}
 </div>
 )}
 </>
 );
 })()}
 <div className="flex items-center gap-1.5 flex-wrap">
 {hasInGps && (
 <>
 <GpsLocationPill lat={log.clockInLat} lng={log.clockInLng} label="In" color="green" />
 <button onClick={() => setMapOpen(p => p === "in" ? null : "in")}
 className={`text-[10px] px-2 py-0.5 border rounded font-bold transition-colors ${mapOpen === "in" ? "bg-slate-700 text-white border-slate-700" : "border-zinc-300 text-zinc-500 hover:bg-zinc-100"}`}
 data-testid={`button-map-in-${staff.id}`}>
 {mapOpen === "in" ? "▲" : "Map ▾"}
 </button>
 </>
 )}
 {!hasInGps && <span className="text-[10px] text-amber-600 font-bold">⚠ No GPS at clock-in</span>}
 </div>
 {/* Live location */}
 {liveLocation && (
 <div className="flex items-center gap-1.5 flex-wrap">
 <div className="flex items-center gap-1 text-[11px] font-bold text-[#0A0A0A] bg-blue-50 border border-blue-200 rounded px-2 py-0.5">
 <Navigation2 className="w-2.5 h-2.5 animate-pulse shrink-0" />
 Live · {liveMinutesAgo === 0 ? "just now" : `${liveMinutesAgo}m ago`}
 </div>
 <GpsLocationPill lat={liveLocation.lat} lng={liveLocation.lng} label="Now" color="green" />
 <button onClick={() => setMapOpen(p => p === "live" ? null : "live")}
 className={`text-[10px] px-2 py-0.5 border rounded font-bold transition-colors ${mapOpen === "live" ? "bg-black text-white border-blue-700" : "border-zinc-300 text-zinc-500 hover:bg-zinc-100"}`}
 data-testid={`button-map-live-${staff.id}`}>
 {mapOpen === "live" ? "▲" : "Map ▾"}
 </button>
 </div>
 )}
 {!liveLocation && (
 <span className="text-[10px] text-slate-400 font-medium">No live GPS yet — updates every 30 s</span>
 )}
 </div>
 )}

 {status === "out" && log && (
 <div className="mt-1 space-y-1">
 <div className="flex items-center gap-1.5">
 <Clock className="w-3 h-3 text-zinc-400 shrink-0" />
 <span className="text-xs text-zinc-500">
 {formatSingaporeAttendance(log.clockInAt, "h:mm a")} – {formatSingaporeAttendance(log.clockOutAt, "h:mm a")}
 {mins !== null && <span className="font-bold text-zinc-900 ml-1">{fmt(mins)}</span>}
 </span>
 </div>
 {(() => {
 const doneList = formatBreakTimes(log?.breaks);
 if (doneList.length === 0) return null;
 return (
 <div className="text-[11px] font-bold text-amber-600" data-testid={`text-breaks-taken-out-${staff.id}`}>
 ☕ Break{doneList.length > 1 ? "s" : ""} taken · {doneList.join(", ")}
 </div>
 );
 })()}
 <div className="flex items-center gap-1.5 flex-wrap">
 {hasInGps && (
 <>
 <GpsLocationPill lat={log.clockInLat} lng={log.clockInLng} label="In" color="green" />
 <button onClick={() => setMapOpen(p => p === "in" ? null : "in")}
 className={`text-[10px] px-2 py-0.5 border rounded font-bold transition-colors ${mapOpen === "in" ? "bg-slate-700 text-white border-slate-700" : "border-zinc-300 text-zinc-500 hover:bg-zinc-100"}`}
 data-testid={`button-map-in-${staff.id}`}>
 {mapOpen === "in" ? "▲" : "Map ▾"}
 </button>
 </>
 )}
 {hasOutGps && (
 <>
 <GpsLocationPill lat={log.clockOutLat} lng={log.clockOutLng} label="Out" color="red" />
 <button onClick={() => setMapOpen(p => p === "out" ? null : "out")}
 className={`text-[10px] px-2 py-0.5 border rounded font-bold transition-colors ${mapOpen === "out" ? "bg-slate-700 text-white border-slate-700" : "border-zinc-300 text-zinc-500 hover:bg-zinc-100"}`}
 data-testid={`button-map-out-${staff.id}`}>
 {mapOpen === "out" ? "▲" : "Map ▾"}
 </button>
 </>
 )}
 {!hasInGps && !hasOutGps && <span className="text-[10px] text-amber-600 font-bold">⚠ No GPS recorded</span>}
 </div>
 </div>
 )}

 {status === "absent" && (
 <span className="text-xs text-zinc-400">Not clocked in</span>
 )}
 </div>
 </div>

 {/* Inline OSM map panel */}
 {mapOpen && osmSrc && (
 <div className="mt-3 overflow-hidden border border-zinc-200 rounded-none">
 {/* Header strip */}
 <div className={`flex items-center justify-between px-3 py-2 ${
 mapOpen === "in" ? "bg-emerald-500 text-white" : "bg-red-500 text-white"
 }`}>
 <div className="flex items-center gap-2 text-xs font-bold">
 <MapPin className="w-3.5 h-3.5" />
 {mapOpen === "in"
 ? `Clock-In · ${log?.clockInAt ? formatSingaporeAttendance(log.clockInAt, "h:mm a") : ""}`
 : `Clock-Out · ${log?.clockOutAt ? formatSingaporeAttendance(log.clockOutAt, "h:mm a") : ""}`}
 </div>
 <div className="flex items-center gap-2">
 <a href={`https://maps.google.com/?q=${activeGps!.lat},${activeGps!.lng}`}
 target="_blank" rel="noreferrer"
 className="text-[10px] font-bold underline opacity-90 hover:opacity-100">
 Open in Maps ↗
 </a>
 <button onClick={() => setMapOpen(null)} className="opacity-80 hover:opacity-100 ml-1">✕</button>
 </div>
 </div>
 {/* Map iframe */}
 <iframe
 src={osmSrc}
 title={`${staff.name} ${mapOpen === "in" ? "clock-in" : "clock-out"} location`}
 className="w-full"
 style={{ height: 240, border: "none" }}
 loading="lazy"
 />
 {/* Coords footer */}
 <div className="px-3 py-1.5 bg-zinc-100 text-[10px] font-mono text-zinc-500 flex items-center justify-between">
 <span>{parseFloat(activeGps!.lat).toFixed(6)}, {parseFloat(activeGps!.lng).toFixed(6)}</span>
 <a href={`https://maps.google.com/?q=${activeGps!.lat},${activeGps!.lng}`}
 target="_blank" rel="noreferrer"
 className="text-[#0A0A0A] font-sans text-[10px] font-bold hover:underline">
 Google Maps ↗
 </a>
 </div>
 </div>
 )}
 </div>
 );
}

// ─── Timesheets — helpers ───────────────────────────────────────────────────────

// Total minutes of completed (closed) breaks logged on a shift. Unpaid → deducted.
function sumBreakMinutes(breaks: any): number {
 return completedBreakMinutes(breaks);
}

// Human-readable list of COMPLETED breaks on a shift, e.g.
// "12:30–1:05 PM (35m)" — one entry per closed break, in the order taken.
function formatBreakTimes(breaks: any): string[] {
 if (!Array.isArray(breaks)) return [];
 return breaks
 .filter((b: any) => b?.startAt && b?.endAt)
 .map((b: any) => {
 const start = new Date(b.startAt);
 const end = new Date(b.endAt);
 if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime())) return null;
 const mins = Math.max(0, Math.round((end.getTime() - start.getTime()) / 60000));
 return `${formatSingaporeAttendance(start, "h:mm")}–${formatSingaporeAttendance(end, "h:mm a")} (${mins}m)`;
 })
 .filter(Boolean) as string[];
}

function calcOT(logs: any[]): { totalMins: number; regularMins: number; otMins: number; deductedMins: number } {
 let totalMins = 0, regularMins = 0, otMins = 0, deductedMins = 0;
 for (const l of logs) {
 if (!l.clockOutAt) continue;
 const time=closedShiftTime(l);
 const raw = time?.rawMinutes??0;
 if (raw <= 0) continue; // Skip invalid records (clock-out before clock-in) so they don't poison totals
 const mins = time!.netMinutes;
 const ded = raw-mins;
 deductedMins += Math.min(ded, raw);
 totalMins += mins;
 regularMins += Math.min(mins, 8 * 60);
 otMins += Math.max(0, mins - 8 * 60);
 }
 return { totalMins, regularMins, otMins, deductedMins };
}

// ─── Inline edit form for a single attendance log ──────────────────────────────

function EditLogForm({ log, queryKeys, onClose }: { log: any; queryKeys: any[]; onClose: () => void }) {
 const qc = useQueryClient();
 const { toast } = useToast();
 const toLocal = (d: string | null) => d ? singaporeInputValue(d) : "";
 const inputTimestamp=(value:string,original?:string|null)=>
   original&&value===toLocal(original)?original:singaporeInputToIso(value);
 const [inVal, setInVal] = useState(toLocal(log.clockInAt));
 const [outVal, setOutVal] = useState(toLocal(log.clockOutAt));
 const [notes, setNotes] = useState(log.notes || "");
 // Editable copy of the staff-logged breaks. Lets admin end a break the staff
 // forgot to close, fix times, add a missed break, or remove a bogus one.
 const [brks, setBrks] = useState<{ startAt: string; endAt: string }[]>(
 (Array.isArray(log.breaks) ? log.breaks : []).map((b: any) => ({
 startAt: toLocal(b?.startAt || null),
 endAt: toLocal(b?.endAt || null),
 })),
 );
 const setBrk = (i: number, field: "startAt" | "endAt", v: string) =>
 setBrks(prev => prev.map((b, idx) => idx === i ? { ...b, [field]: v } : b));
 const removeBrk = (i: number) => setBrks(prev => prev.filter((_, idx) => idx !== i));
 const addBrk = () => setBrks(prev => [...prev, { startAt: "", endAt: "" }]);

 const previewBreakMins = brks.reduce((s, b) => {
 if (!b.startAt || !b.endAt) return s;
 const d = differenceInMinutes(new Date(b.endAt), new Date(b.startAt));
 return s + Math.max(0, d);
 }, 0);
 const previewMins = inVal && outVal
 ? differenceInMinutes(new Date(outVal), new Date(inVal)) - previewBreakMins
 : null;
 // A break with no end on a shift that is already clocked out can only be a
 // mistake (an open break makes sense only while the staff is still in).
 const openBreakOnClosedShift = !!outVal && brks.some(b => b.startAt && !b.endAt);

 const saveMut = useMutation({
 mutationFn: () => apiRequest("PATCH", `/api/admin/attendance/${log.id}`, {
 clockInAt: inVal ? inputTimestamp(inVal,log.clockInAt) : undefined,
 clockOutAt: outVal ? inputTimestamp(outVal,log.clockOutAt) : null,
 notes,
 breaks: brks
 .filter(b => b.startAt) // a break with no start time is an empty row — drop it
 .map(b => {
 const original=(Array.isArray(log.breaks)?log.breaks:[]).find((saved:any)=>toLocal(saved.startAt)===b.startAt);
 return {startAt:inputTimestamp(b.startAt,original?.startAt),
 endAt:b.endAt?inputTimestamp(b.endAt,original?.endAt):null};
 }),
 }),
 onSuccess: () => {
 queryKeys.forEach(k => qc.invalidateQueries({ queryKey: k }));
 toast({ title: "Record updated" });
 onClose();
 },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 return (
 <tr className="border-t bg-zinc-50">
 <td colSpan={7} className="px-4 py-3">
 <div className="space-y-3">
 <p className="text-xs font-semibold text-[#0A0A0A] uppercase tracking-wider">Editing record #{log.id} · Singapore time (UTC+8)</p>
 <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
 <div>
 <label className="text-[11px] font-semibold text-zinc-500 mb-1 block flex items-center gap-1">
 <LogIn className="w-3 h-3 text-emerald-500" /> Clock In
 </label>
 <input type="datetime-local" value={inVal} onChange={e => setInVal(e.target.value)}
 className="w-full h-9 px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid={`input-edit-clockin-${log.id}`} />
 </div>
 <div>
 <label className="text-[11px] font-semibold text-zinc-500 mb-1 block flex items-center gap-1">
 <LogOut className="w-3 h-3 text-red-500" /> Clock Out
 <span className="ml-1 text-[10px] text-zinc-400 font-normal">(leave blank = still in)</span>
 </label>
 <input type="datetime-local" value={outVal} onChange={e => setOutVal(e.target.value)}
 className="w-full h-9 px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid={`input-edit-clockout-${log.id}`} />
 </div>
 </div>
 {/* Breaks — admin can end a forgotten break, fix times, add or remove */}
 <div>
 <label className="text-[11px] font-semibold text-zinc-500 mb-1 block">
 ☕ Breaks (unpaid) <span className="text-[10px] text-zinc-400 font-normal">— leave End blank only if the break is genuinely still running</span>
 </label>
 {brks.length === 0 && <p className="text-xs text-zinc-400 mb-1">No breaks logged on this shift.</p>}
 <div className="space-y-2">
 {brks.map((b, i) => {
 const mins = b.startAt && b.endAt
 ? differenceInMinutes(new Date(b.endAt), new Date(b.startAt))
 : null;
 return (
 <div key={i} className="flex flex-wrap items-center gap-2" data-testid={`row-edit-break-${log.id}-${i}`}>
 <input type="datetime-local" value={b.startAt} onChange={e => setBrk(i, "startAt", e.target.value)}
 className="h-9 px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid={`input-break-start-${log.id}-${i}`} />
 <span className="text-xs text-zinc-400">to</span>
 <input type="datetime-local" value={b.endAt} onChange={e => setBrk(i, "endAt", e.target.value)}
 className="h-9 px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid={`input-break-end-${log.id}-${i}`} />
 {mins !== null && (
 <span className={`text-[11px] font-bold ${mins > 0 ? "text-amber-600" : "text-red-600"}`}>
 {mins > 0 ? `${mins}m` : "end before start!"}
 </span>
 )}
 {b.startAt && !b.endAt && (
 <span className="text-[11px] font-bold text-red-600">still open — set an end time</span>
 )}
 <button onClick={() => removeBrk(i)} title="Remove this break"
 className="text-zinc-400 hover:text-red-600 transition-colors"
 data-testid={`button-remove-break-${log.id}-${i}`}>
 <X className="w-4 h-4" />
 </button>
 </div>
 );
 })}
 </div>
 <button onClick={addBrk}
 className="mt-2 inline-flex items-center gap-1 text-[11px] font-bold text-zinc-500 hover:text-zinc-900 border border-zinc-300 rounded px-2 py-1 transition-colors"
 data-testid={`button-add-break-${log.id}`}>
 <Plus className="w-3 h-3" /> Add break
 </button>
 </div>
 <div>
 <label className="text-[11px] font-semibold text-zinc-500 mb-1 block">Admin Notes</label>
 <input type="text" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Optional note…"
 className="w-full h-9 px-3 border border-zinc-300 rounded-lg text-sm bg-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid={`input-edit-notes-${log.id}`} />
 </div>
 {previewMins !== null && previewMins >= 0 && (
 <p className="text-xs text-zinc-500">
 Duration: <strong className="text-zinc-900">{fmt(previewMins)}</strong>
 {previewBreakMins > 0 && <span className="ml-1 text-amber-600 font-bold">(after −{fmt(previewBreakMins)} break)</span>}
 {previewMins > 8 * 60 && <span className="ml-2 text-amber-600 font-bold">({fmt(previewMins - 8 * 60)} OT)</span>}
 </p>
 )}
 {openBreakOnClosedShift && (
 <p className="text-xs font-bold text-red-600" data-testid={`text-open-break-blocked-${log.id}`}>
 This shift is clocked out — set an end time on every break (or remove it) before saving.
 </p>
 )}
 <div className="flex gap-2">
 <button onClick={() => saveMut.mutate()} disabled={saveMut.isPending || openBreakOnClosedShift}
 className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-60"
 data-testid={`button-save-log-${log.id}`}>
 {saveMut.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />}
 Save
 </button>
 <button onClick={onClose}
 className="inline-flex items-center h-8 px-3 rounded-lg border border-zinc-200 text-zinc-600 hover:bg-zinc-50 text-sm font-medium transition-colors"
 data-testid={`button-cancel-edit-${log.id}`}>
 Cancel
 </button>
 </div>
 </div>
 </td>
 </tr>
 );
}

// ─── Add record form ───────────────────────────────────────────────────────────

function AddRecordForm({
 staff, presetUserId, presetDate, queryKeys, onClose,
}: {
 staff: any[]; presetUserId?: number; presetDate?: string; queryKeys: any[]; onClose: () => void;
}) {
 const qc = useQueryClient();
 const { toast } = useToast();
 const defaultDate = presetDate || singaporeInputValue(new Date()).slice(0,10);
 const [userId, setUserId] = useState(String(presetUserId || (staff[0]?.id ?? "")));
 const [inVal, setInVal] = useState(defaultDate + "T08:00");
 const [outVal, setOutVal] = useState(defaultDate + "T17:00");
 const [notes, setNotes] = useState("");

 const previewMins = inVal && outVal
 ? differenceInMinutes(new Date(outVal), new Date(inVal))
 : null;

 const addMut = useMutation({
 mutationFn: () => apiRequest("POST", "/api/admin/attendance", {
 userId: parseInt(userId),
 clockInAt: singaporeInputToIso(inVal),
 clockOutAt: outVal ? singaporeInputToIso(outVal) : null,
 notes: notes || undefined,
 }),
 onSuccess: () => {
 queryKeys.forEach(k => qc.invalidateQueries({ queryKey: k }));
 toast({ title: "Record added ✓", description: staff.find((s:any) => String(s.id) === userId)?.name });
 onClose();
 },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 return (
 <div className="bg-white border border-zinc-200 rounded-none p-5 space-y-4"
 data-testid="add-record-form">
 <div className="flex items-center justify-between">
 <div className="flex items-center gap-2">
 <div className="w-7 h-7 rounded-lg bg-[#0A0A0A] flex items-center justify-center">
 <Plus className="w-4 h-4 text-white" />
 </div>
 <p className="font-semibold text-sm text-zinc-900">Add Attendance Record</p>
 </div>
 <button onClick={onClose} className="text-zinc-400 hover:text-zinc-700 transition-colors">
 <X className="w-4 h-4" />
 </button>
 </div>

 <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
 {/* Staff selector */}
 <div className="sm:col-span-2">
 <label className="block text-[11px] font-semibold text-zinc-500 mb-1">Staff Member</label>
 <select value={userId} onChange={e => setUserId(e.target.value)}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="select-add-staff">
 {staff.filter((s:any) => s.role === "staff").map((s:any) => (
 <option key={s.id} value={s.id}>{s.name} (@{s.username})</option>
 ))}
 </select>
 </div>

 {/* Clock In */}
 <div>
 <label className="block text-[11px] font-semibold text-zinc-500 mb-1 flex items-center gap-1">
 <LogIn className="w-3 h-3 text-emerald-500" /> Clock In
 </label>
 <input type="datetime-local" value={inVal} onChange={e => setInVal(e.target.value)}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="input-add-clockin" />
 </div>

 {/* Clock Out */}
 <div>
 <label className="block text-[11px] font-semibold text-zinc-500 mb-1 flex items-center gap-1">
 <LogOut className="w-3 h-3 text-red-500" /> Clock Out
 <span className="text-[10px] text-zinc-400 font-normal ml-1">(optional)</span>
 </label>
 <input type="datetime-local" value={outVal} onChange={e => setOutVal(e.target.value)}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="input-add-clockout" />
 </div>

 {/* Notes */}
 <div className="sm:col-span-2">
 <label className="block text-[11px] font-semibold text-zinc-500 mb-1">Notes / Reason</label>
 <input type="text" value={notes} onChange={e => setNotes(e.target.value)}
 placeholder="e.g. Staff forgot to clock in — manually added by admin"
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="input-add-notes" />
 </div>
 </div>

 {/* Duration preview */}
 {previewMins !== null && previewMins > 0 && (
 <p className="text-xs text-zinc-500">
 Duration: <strong className="text-zinc-900">{fmt(previewMins)}</strong>
 {previewMins > 8 * 60 && (
 <span className="ml-2 text-amber-600 font-bold">(+{fmt(previewMins - 8 * 60)} OT)</span>
 )}
 </p>
 )}
 {previewMins !== null && previewMins <= 0 && (
 <p className="text-xs text-red-500 font-bold">⚠ Clock Out must be after Clock In</p>
 )}

 <div className="flex gap-2">
 <button onClick={() => addMut.mutate()} disabled={addMut.isPending || !userId || !inVal || (previewMins !== null && previewMins <= 0)}
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-50"
 data-testid="button-save-add-record">
 {addMut.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
 Save Record
 </button>
 <button onClick={onClose}
 className="inline-flex items-center h-9 px-4 rounded-lg border border-zinc-200 text-zinc-600 hover:bg-zinc-50 text-sm font-medium transition-colors">
 Cancel
 </button>
 </div>
 </div>
 );
}

// ─── Bulk Deduct Modal ─────────────────────────────────────────────────────────

function BulkDeductModal({ staff, defaultUserId, defaultFrom, defaultTo, queryKeys, onClose }: {
 staff: any[]; defaultUserId?: number; defaultFrom: string; defaultTo: string; queryKeys: any[]; onClose: () => void;
}) {
 const qc = useQueryClient();
 const { toast } = useToast();
 const staffOnly = staff.filter((s: any) => s.role === "staff");
 const [userId, setUserId] = useState<string>(String(defaultUserId ?? staffOnly[0]?.id ?? ""));
 const [fromDate, setFromDate] = useState(defaultFrom);
 const [toDate, setToDate] = useState(defaultTo);
 const [minutesPerDay, setMinutesPerDay] = useState(30);
 const [reason, setReason] = useState("");
 const [mode, setMode] = useState<"set" | "add">("set");

 const mut = useMutation({
 mutationFn: () => apiRequest("POST", "/api/admin/attendance/bulk-deduct", {
 userId: parseInt(userId),
 fromDate,
 toDate,
 minutesPerDay,
 reason: reason.trim(),
 mode,
 }),
 onSuccess: async (res: any) => {
 const data = await res.json();
 queryKeys.forEach(k => qc.invalidateQueries({ queryKey: k }));
 toast({
 title: "Deduction applied",
 description: `${data.daysAffected ?? data.updated} working day(s) affected. Total deducted: ${fmt(data.totalMinutesDeducted)}.`,
 });
 onClose();
 },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 const staffName = staffOnly.find((s: any) => String(s.id) === userId)?.name || "—";

 return (
 <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" data-testid="modal-bulk-deduct">
 <div className="bg-white rounded-none max-w-lg w-full overflow-hidden">
 <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-100">
 <div className="flex items-center gap-2">
 <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center">
 <Clock className="w-4 h-4 text-white" />
 </div>
 <div>
 <p className="font-semibold text-zinc-900">Bulk Deduct Working Time</p>
 <p className="text-xs text-zinc-500">Subtract minutes from each working day in a date range</p>
 </div>
 </div>
 <button onClick={onClose} className="text-zinc-400 hover:text-zinc-700">
 <X className="w-5 h-5" />
 </button>
 </div>
 <div className="p-6 space-y-4">
 <div>
 <label className="block text-[11px] font-semibold text-zinc-500 mb-1">Staff Member</label>
 <select value={userId} onChange={e => setUserId(e.target.value)}
 className="h-10 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white"
 data-testid="select-bulk-deduct-staff">
 {staffOnly.map((s: any) => <option key={s.id} value={s.id}>{s.name} (@{s.username})</option>)}
 </select>
 </div>
 <div className="grid grid-cols-2 gap-3">
 <div>
 <label className="block text-[11px] font-semibold text-zinc-500 mb-1">From</label>
 <input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)}
 className="h-10 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white"
 data-testid="input-bulk-deduct-from" />
 </div>
 <div>
 <label className="block text-[11px] font-semibold text-zinc-500 mb-1">To</label>
 <input type="date" value={toDate} onChange={e => setToDate(e.target.value)}
 className="h-10 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white"
 data-testid="input-bulk-deduct-to" />
 </div>
 </div>
 <div className="grid grid-cols-2 gap-3">
 <div>
 <label className="block text-[11px] font-semibold text-zinc-500 mb-1">Minutes per working day</label>
 <div className="flex items-center gap-2">
 <input type="number" min={0} max={1440} value={minutesPerDay}
 onChange={e => setMinutesPerDay(Math.max(0, Math.min(1440, parseInt(e.target.value) || 0)))}
 className="h-10 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white"
 data-testid="input-bulk-deduct-minutes" />
 <span className="text-xs text-zinc-500 whitespace-nowrap">min/day</span>
 </div>
 <div className="flex gap-1 mt-1">
 {[15, 30, 45, 60].map(n => (
 <button key={n} onClick={() => setMinutesPerDay(n)}
 className={`text-[10px] px-2 py-0.5 rounded ${minutesPerDay === n ? "bg-zinc-900 text-white" : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200"}`}>
 {n}m
 </button>
 ))}
 </div>
 </div>
 <div>
 <label className="block text-[11px] font-semibold text-zinc-500 mb-1">Mode</label>
 <div className="flex border border-zinc-300 rounded-lg overflow-hidden h-10">
 <button onClick={() => setMode("set")}
 className={`flex-1 text-xs font-medium ${mode === "set" ? "bg-zinc-900 text-white" : "bg-white text-zinc-600 hover:bg-zinc-50"}`}
 data-testid="button-mode-set">
 Set (replace)
 </button>
 <button onClick={() => setMode("add")}
 className={`flex-1 text-xs font-medium ${mode === "add" ? "bg-zinc-900 text-white" : "bg-white text-zinc-600 hover:bg-zinc-50"}`}
 data-testid="button-mode-add">
 Add (stack)
 </button>
 </div>
 <p className="text-[10px] text-zinc-400 mt-1">
 {mode === "set" ? "Overwrites any existing deduction." : "Adds on top of existing deduction."}
 </p>
 </div>
 </div>
 <div>
 <label className="block text-[11px] font-semibold text-zinc-500 mb-1">Reason (required)</label>
 <input type="text" value={reason} onChange={e => setReason(e.target.value)}
 placeholder="e.g. Lunch break not included in clock — Apr 2026 review"
 className="h-10 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white"
 data-testid="input-bulk-deduct-reason" />
 </div>
 <div className="bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 text-xs text-amber-800">
 <strong>Preview:</strong> Will deduct <strong>{minutesPerDay} min</strong> from every working day for{" "}
 <strong>{staffName}</strong> between <strong>{fromDate}</strong> and <strong>{toDate}</strong>.
 Days without a clock-out will be skipped.
 </div>
 </div>
 <div className="flex justify-end gap-2 px-6 py-4 bg-zinc-50 border-t border-zinc-100">
 <button onClick={onClose}
 className="h-9 px-4 rounded-lg border border-zinc-200 text-zinc-600 hover:bg-zinc-100 text-sm font-medium">
 Cancel
 </button>
 <button onClick={() => mut.mutate()}
 disabled={mut.isPending || !userId || !reason.trim() || minutesPerDay <= 0}
 className="inline-flex items-center gap-1.5 h-9 px-4 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm font-medium disabled:opacity-50"
 data-testid="button-apply-bulk-deduct">
 {mut.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
 Apply Deduction
 </button>
 </div>
 </div>
 </div>
 );
}

// ─── Monthly Clock-In Review (payslip prep) ──────────────────────────────────────

function ReviewClockInsModal({ staff, defaultUserId, periodStart, periodEnd, onClose, onGenerate }: {
  staff: any[]; defaultUserId?: string; periodStart: string; periodEnd: string;
  onClose: () => void; onGenerate: (userId: string, start: string, end: string) => void;
}) {
  const qc = useQueryClient();
  const { toast } = useToast();
  const staffOnly = staff.filter((s: any) => s.role === "staff");
  const [userId, setUserId] = useState<string>(defaultUserId || String(staffOnly[0]?.id ?? ""));
  const [start, setStart] = useState(periodStart);
  const [end, setEnd] = useState(periodEnd);

  const { data, isLoading, isFetching } = useQuery<any>({
    queryKey: ["/api/admin/attendance/review", userId, start, end],
    enabled: !!userId,
    queryFn: async () => {
      const res = await fetch(
        `${API_BASE}/api/admin/attendance/review?userId=${userId}&start=${start}&end=${end}`,
        { credentials: "include" },
      );
      if (!res.ok) throw new Error((await res.json()).message || "Failed to load review");
      return res.json();
    },
  });

  // Editable per-day deduction (minutes + reason), seeded from existing/suggested.
  const [edits, setEdits] = useState<Record<string, { minutes: number; reason: string }>>({});
  useEffect(() => {
    if (!data?.days) return;
    const init: Record<string, { minutes: number; reason: string }> = {};
    for (const d of data.days) {
      // For flagged (off-site) days, pre-fill the GPS-estimated non-payable travel
      // time as a suggested deduction the admin can adjust; otherwise leave at 0.
      const minutes = d.existingDeduction > 0
        ? d.existingDeduction
        : (d.offSite ? (d.suggestedMinutes || 0) : 0);
      const reason = d.existingReason || d.suggestedReason || "";
      init[d.date] = { minutes, reason };
    }
    setEdits(init);
  }, [data]);

  const applyMut = useMutation({
    mutationFn: (p: { date: string; minutes: number; reason: string }) =>
      apiRequest("POST", "/api/admin/attendance/apply-review", {
        userId: parseInt(userId), date: p.date, minutes: p.minutes,
        reason: p.reason.trim() || undefined,
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/admin/attendance/review"] });
      qc.invalidateQueries({ queryKey: ["/api/admin/attendance"] });
      toast({ title: "Saved" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const days: any[] = data?.days || [];
  const flaggedCount = days.filter((d) => d.offSite).length;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-3 sm:p-4" data-testid="modal-review-clockins">
      <div className="bg-white rounded-none max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-100 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#0A0A0A] flex items-center justify-center">
              <Clock className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="font-semibold text-zinc-900">Review Clock-Ins</p>
              <p className="text-xs text-zinc-500">Check each day's time & location, apply deductions, then generate the payslip</p>
            </div>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-700"><X className="w-5 h-5" /></button>
        </div>

        {/* Controls */}
        <div className="px-5 py-3 border-b border-zinc-100 grid grid-cols-1 sm:grid-cols-3 gap-3 shrink-0">
          <div>
            <label className="block text-[11px] font-semibold text-zinc-500 mb-1">Staff Member</label>
            <select value={userId} onChange={e => setUserId(e.target.value)}
              className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white" data-testid="select-review-staff">
              {staffOnly.map((s: any) => <option key={s.id} value={s.id}>{s.name} (@{s.username})</option>)}
            </select>
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-zinc-500 mb-1">From</label>
            <input type="date" value={start} onChange={e => setStart(e.target.value)}
              className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white" data-testid="input-review-from" />
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-zinc-500 mb-1">To</label>
            <input type="date" value={end} onChange={e => setEnd(e.target.value)}
              className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white" data-testid="input-review-to" />
          </div>
        </div>

        {/* Summary line */}
        <div className="px-5 py-2 bg-zinc-50 border-b border-zinc-100 text-xs text-zinc-600 shrink-0">
          The first scheduled day after a gap is a <strong>loading morning</strong> at {data?.isDriver ? <><strong>{data?.vanLabel || "Woodlands St 31"}</strong>, then IKEA Alexandra</> : <strong>{data?.ikeaLabel || "IKEA Alexandra"}</strong>}. Consecutive scheduled days start at the <strong>first job site</strong>. A day without a schedule is left for manual review.
          {flaggedCount > 0 && <span className="ml-1 text-red-600 font-semibold">· {flaggedCount} off-site day(s)</span>}
        </div>

        {/* Days table */}
        <div className="flex-1 overflow-y-auto px-5 py-4">
          {isLoading ? (
            <div className="flex justify-center py-12"><Loader2 className="w-7 h-7 animate-spin text-zinc-400" /></div>
          ) : days.length === 0 ? (
            <div className="text-center py-12 text-sm text-zinc-400">No clock-in records for this staff in this period.</div>
          ) : (
            <div className="space-y-3">
              {days.map((d) => {
                const e = edits[d.date] || { minutes: 0, reason: "" };
                // A prefilled reason at 0 minutes is never persisted (no deduction to
                // attach it to), so it must not make the row look dirty. Reason only
                // counts as a change once there's an actual deduction.
                const changedFromServer =
                  e.minutes !== d.existingDeduction ||
                  (e.minutes > 0 && e.reason.trim() !== (d.existingReason || "").trim());
                return (
                  <div key={d.date} className={`border rounded-lg p-3 ${d.offSite ? "border-red-200 bg-red-50/40" : "border-zinc-200"}`} data-testid={`review-day-${d.date}`}>
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-zinc-900">{format(parseISO(d.date), "EEE d MMM")}</span>
                        {!d.closed && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-700">NO CLOCK-OUT</span>}
                        {d.offSite && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-red-600 text-white" data-testid={`badge-offsite-${d.date}`}>OFF-SITE</span>}
                        {d.matched === "ikea" && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-700">AT IKEA</span>}
                        {d.matched === "firstJob" && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-700">AT FIRST JOB</span>}
                        {d.matched === "vanPickup" && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-700">AT VAN</span>}
                         {d.expectedMode === "loadingMorning" && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-700">LOADING DAY</span>}
                         {d.expectedMode === "driverRoute" && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-700">DRIVER ROUTE</span>}
                         {d.driverReachedIkea === true && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-700">REACHED IKEA</span>}
                         {d.driverUnexpectedStop && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-red-100 text-red-700">ROUTE DEVIATION</span>}
                         {d.expectedMode === "directToSite" && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-violet-100 text-violet-700">DIRECT TO SITE</span>}
                         {d.expectedMode === "offDay" && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-zinc-100 text-zinc-600">NO SCHEDULE</span>}
                        {d.needsManualReview && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-700" data-testid={`badge-check-${d.date}`}>CHECK</span>}
                        {d.locationOk === null && !d.needsManualReview && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-zinc-100 text-zinc-500">NO GPS</span>}
                      </div>
                      <span className="text-xs text-zinc-500">Worked {fmt(d.grossMinutes)}{d.breakMinutes > 0 ? ` · break ${fmt(d.breakMinutes)}` : ""}</span>
                    </div>

                    {/* time + location */}
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-zinc-600 mb-1">
                      <span className="inline-flex items-center gap-1">
                        <LogIn className="w-3 h-3 text-emerald-500" />
                        {format(new Date(d.clockInAt), "h:mm a")}
                      </span>
                      {d.clockInLat && d.clockInLng && <GpsLocationPill lat={d.clockInLat} lng={d.clockInLng} label="In" color="green" />}
                      {d.closed && (
                        <span className="inline-flex items-center gap-1">
                          <LogOut className="w-3 h-3 text-red-500" />
                          {format(new Date(d.clockOutAt), "h:mm a")}
                        </span>
                      )}
                      {d.clockOutLat && d.clockOutLng && <GpsLocationPill lat={d.clockOutLat} lng={d.clockOutLng} label="Out" color="red" />}
                    </div>

                    {/* expected clock-in place + where they actually clocked in + distances */}
                    <div className="text-[11px] text-zinc-400 mb-2">
                      {(() => {
                        if (d.expectedMode === "offDay") return <>No scheduled work found — check this attendance manually</>;
                        if (d.expectedMode === "driverRoute") return <>Expected at Woodlands St 31 to begin the driver route to IKEA Alexandra</>;
                        if (d.expectedMode === "loadingMorning") return <>Expected at IKEA Alexandra for morning loading</>;
                        return d.firstJobRef
                          ? <>Expected at first job <span className="text-zinc-500 font-medium">{d.firstJobRef}</span>{d.firstJobAddress ? ` · ${d.firstJobAddress}` : ""}{!d.firstJobLocated && <span className="text-amber-600"> (job address couldn't be located)</span>}</>
                          : <>Expected at first job <span className="text-zinc-400">(schedule details unavailable)</span></>;
                      })()}
                      {d.clockInPlace && (
                        <span className="text-zinc-500"> · clocked in at <span className="font-medium text-zinc-600">{d.clockInPlace}</span></span>
                      )}
                       {d.driverUnexpectedStop && (
                         <span className="text-red-600"> · unexpected stop before IKEA: <span className="font-medium">{d.driverUnexpectedStop}</span></span>
                       )}
                      {d.offSite && (
                        <span className="text-red-500">
                          {" · "}{d.distJobM != null ? `~${d.distJobM}m from job, ` : ""}~{d.distIkeaM}m from IKEA{data?.isDriver && d.distVanM != null ? `, ~${d.distVanM}m from van` : ""}
                          {d.suggestedMinutes > 0 ? ` · ~${fmt(d.suggestedMinutes)} travel to deduct` : ""}
                        </span>
                      )}
                    </div>

                    {/* deduction editor */}
                    <div className="flex flex-wrap items-end gap-2">
                      <div>
                        <label className="block text-[10px] font-semibold text-zinc-500 mb-0.5">Deduct (min)</label>
                        <input type="number" min={0} max={Math.max(0, d.grossMinutes)} value={e.minutes}
                          disabled={!d.closed}
                          onChange={ev => setEdits(s => ({ ...s, [d.date]: { ...e, minutes: Math.max(0, Math.min(d.grossMinutes || 1440, parseInt(ev.target.value) || 0)) } }))}
                          className="h-9 w-24 px-2 border border-zinc-300 rounded-lg text-sm bg-white disabled:bg-zinc-100"
                          data-testid={`input-deduct-${d.date}`} />
                      </div>
                      <div className="flex-1 min-w-[180px]">
                        <label className="block text-[10px] font-semibold text-zinc-500 mb-0.5">Reason</label>
                        <input type="text" value={e.reason} disabled={!d.closed}
                          placeholder="e.g. Clocked in at van, not job site"
                          onChange={ev => setEdits(s => ({ ...s, [d.date]: { ...e, reason: ev.target.value } }))}
                          className="h-9 w-full px-2 border border-zinc-300 rounded-lg text-sm bg-white disabled:bg-zinc-100"
                          data-testid={`input-reason-${d.date}`} />
                      </div>
                      <button
                        onClick={() => applyMut.mutate({ date: d.date, minutes: e.minutes, reason: e.reason })}
                        disabled={!d.closed || applyMut.isPending || (e.minutes > 0 && !e.reason.trim()) || !changedFromServer}
                        className="inline-flex items-center gap-1.5 h-9 px-3 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-xs font-medium disabled:opacity-40"
                        data-testid={`button-save-${d.date}`}>
                        <Check className="w-3.5 h-3.5" /> Save
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 px-5 py-4 bg-zinc-50 border-t border-zinc-100 shrink-0">
          <p className="text-[11px] text-zinc-400">Save each day's deduction before generating. Reasons appear on the payslip for record.</p>
          <div className="flex gap-2">
            <button onClick={onClose} className="h-9 px-4 rounded-lg border border-zinc-200 text-zinc-600 hover:bg-zinc-100 text-sm font-medium">Close</button>
            <button onClick={() => onGenerate(userId, start, end)} disabled={!userId || isFetching}
              className="inline-flex items-center gap-1.5 h-9 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium disabled:opacity-50"
              data-testid="button-review-generate">
              <FileText className="w-4 h-4" /> Generate Payslip
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Timesheets View ────────────────────────────────────────────────────────────

function TimesheetsView() {
 const today = new Date(singaporeInputValue(new Date()));
 const [view, setView] = useState<"daily" | "period">("period");
 const [from, setFrom] = useState(format(startOfMonth(today), "yyyy-MM-dd"));
 const [to, setTo] = useState(format(endOfMonth(today), "yyyy-MM-dd"));
 const [dailyDate, setDailyDate] = useState(format(today, "yyyy-MM-dd"));
 const [filterUid, setFilterUid] = useState("");
 const [sortBy, setSortBy] = useState<"name" | "hours">("name");
 const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
 const [expandedId, setExpandedId] = useState<number | null>(null);
 const [editingId, setEditingId] = useState<number | null>(null);
 const [confirmDel, setConfirmDel] = useState<number | null>(null);
 const [showAddForm, setShowAddForm] = useState(false);
 const [addPresetUid, setAddPresetUid] = useState<number | undefined>();
 const [bulkDeductOpen, setBulkDeductOpen] = useState(false);
 const qc = useQueryClient();
 const { toast } = useToast();

 const { data: staff = [] } = useQuery<any[]>({ queryKey: ["/api/staff"] });

 // Period-view date validation
 const isValid = (d: string) => /^\d{4}-\d{2}-\d{2}$/.test(d) && !isNaN(new Date(d).getTime());

 // Shared fetcher
 const fetchLogs = async (f: string, t: string, uid: string) => {
 if (!isValid(f) || !isValid(t)) return [];
 const params = new URLSearchParams({ from: f + "T00:00:00+08:00", to: t + "T23:59:59+08:00" });
 if (uid) params.set("userId", uid);
 const res = await fetch(`${API_BASE}/api/admin/attendance?${params}`, { credentials: "include" });
 if (!res.ok) return [];
 const data = await res.json();
 return Array.isArray(data) ? data : [];
 };

 // Period logs
 const periodKey = ["/api/admin/attendance", from, to, filterUid];
 const { data: periodLogs = [], isLoading: periodLoading } = useQuery<any[]>({
 queryKey: periodKey,
 queryFn: () => fetchLogs(from, to, filterUid),
 enabled: view === "period",
 refetchInterval: 30_000,
 });

 // Daily logs
 const dailyKey = ["/api/admin/attendance", dailyDate, dailyDate, ""];
 const { data: dailyLogs = [], isLoading: dailyLoading } = useQuery<any[]>({
 queryKey: dailyKey,
 queryFn: () => fetchLogs(dailyDate, dailyDate, ""),
 enabled: view === "daily",
 refetchInterval: 30000,
 });

 const sharedQueryKeys = [periodKey, dailyKey];

 // Delete mutation
 const deleteMut = useMutation({
 mutationFn: (id: number) => apiRequest("DELETE", `/api/admin/attendance/${id}`),
 onSuccess: () => {
 sharedQueryKeys.forEach(k => qc.invalidateQueries({ queryKey: k }));
 toast({ title: "Record deleted" });
 setConfirmDel(null);
 },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 // Period view: build per-staff rows
 const buildStaffRows = (logs: any[]) => {
 const map: Record<number, any> = {};
 for (const log of logs) {
 if (log.user?.role !== "staff") continue;
 const uid = log.userId;
 if (!map[uid]) map[uid] = { user: log.user, logs: [] };
 map[uid].logs.push(log);
 }
 (staff as any[]).forEach((s: any) => {
 if (!map[s.id]) map[s.id] = { user: s, logs: [] };
 });
 let rows = Object.values(map).map((r: any) => ({ ...r, ...calcOT(r.logs), days: r.logs.filter((l: any) => l.clockOutAt).length }));
 rows.sort((a: any, b: any) => {
 const dir = sortDir === "asc" ? 1 : -1;
 if (sortBy === "hours") return dir * (a.totalMins - b.totalMins);
 return dir * a.user.name.localeCompare(b.user.name);
 });
 return rows;
 };

 const staffRows = buildStaffRows(periodLogs as any[]);
 const grandTotals = calcOT(staffRows.flatMap((r: any) => r.logs));

 const setPreset = (p: string) => {
 const t = new Date(singaporeInputValue(new Date()));
 if (p === "today") { setFrom(format(t, "yyyy-MM-dd")); setTo(format(t, "yyyy-MM-dd")); }
 if (p === "week") { setFrom(format(startOfWeek(t, { weekStartsOn: 1 }), "yyyy-MM-dd")); setTo(format(endOfWeek(t, { weekStartsOn: 1 }), "yyyy-MM-dd")); }
 if (p === "month") { setFrom(format(startOfMonth(t), "yyyy-MM-dd")); setTo(format(endOfMonth(t), "yyyy-MM-dd")); }
 if (p === "prevMonth") { const pm = new Date(t.getFullYear(), t.getMonth() - 1, 1); setFrom(format(startOfMonth(pm), "yyyy-MM-dd")); setTo(format(endOfMonth(pm), "yyyy-MM-dd")); }
 };

 // Shared log-row render (used by both views)
 const renderLogRow = (log: any, showDate = true) => {
 const mins = log.clockOutAt ? differenceInMinutes(new Date(log.clockOutAt), new Date(log.clockInAt)) : null;
 const otMins = mins !== null ? Math.max(0, mins - 8 * 60) : 0;
 const isEditing = editingId === log.id;
 const isDeleting = confirmDel === log.id;

 if (isEditing) return (
 <EditLogForm key={`edit-${log.id}`} log={log} queryKeys={sharedQueryKeys} onClose={() => setEditingId(null)} />
 );

 return (
 <tr key={log.id} className={`border-t transition-colors ${isDeleting ? "bg-red-50" : "hover:bg-zinc-50"}`}
 data-testid={`log-row-${log.id}`}>
 {showDate && (
 <td className="px-3 py-2.5 font-medium text-sm whitespace-nowrap">
 {formatSingaporeAttendance(log.clockInAt, "EEE, d MMM")}
 </td>
 )}
 <td className="px-3 py-2.5">
 <div className="flex items-center gap-1 text-sm">
 <LogIn className="w-3 h-3 text-emerald-500 shrink-0" />
 <span className="font-mono">{formatSingaporeAttendance(log.clockInAt, "HH:mm")}</span>
 </div>
 {log.clockInLat && log.clockInLng && (
 <div className="mt-0.5">
 <GpsLocationPill lat={log.clockInLat} lng={log.clockInLng} label="In" color="green" />
 </div>
 )}
 </td>
 <td className="px-3 py-2.5">
 {log.clockOutAt ? (
 <>
 <div className="flex items-center gap-1 text-sm">
 <LogOut className="w-3 h-3 text-red-500 shrink-0" />
 <span className="font-mono">{formatSingaporeAttendance(log.clockOutAt, "HH:mm")}</span>
 </div>
 {log.clockOutLat && log.clockOutLng && (
 <div className="mt-0.5">
 <GpsLocationPill lat={log.clockOutLat} lng={log.clockOutLng} label="Out" color="red" />
 </div>
 )}
 </>
 ) : (
 <span className="text-[11px] font-bold text-amber-600 bg-amber-50 dark:bg-amber-950/30 px-2 py-0.5">Still in</span>
 )}
 </td>
 <td className="px-3 py-2.5 text-right">
 {mins === null ? (
 <span className="text-zinc-400 text-sm">—</span>
 ) : mins <= 0 ? (
 <button
 onClick={() => setEditingId(log.id)}
 data-testid={`button-fix-invalid-${log.id}`}
 title="Clock-out is at or before clock-in. Click to fix."
 className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-red-50 hover:bg-red-100 text-red-700 text-[11px] font-bold border border-red-200 transition-colors">
 <AlertTriangle className="w-3 h-3" /> Fix dates
 </button>
 ) : (() => {
 const ded = Math.max(0, Number(log.deductionMinutes || 0));
 const time=closedShiftTime(log)!;
 const brk = time.breakMinutes;
 const netMins = time.netMinutes;
 const netOt = Math.max(0, netMins - 8 * 60);
 return (
 <div>
 <span className="font-bold text-sm text-zinc-900">{fmt(netMins)}</span>
 {netOt > 0 && <span className="ml-1 text-[10px] font-bold text-amber-600">+{fmt(netOt)} OT</span>}
 {brk > 0 && (
 <div className="text-[10px] font-bold text-amber-600 mt-0.5"
 title={`Breaks: ${formatBreakTimes(log.breaks).join(", ")}`}
 data-testid={`text-break-detail-${log.id}`}>
 −{fmt(brk)} break
 <div className="font-medium text-amber-500">{formatBreakTimes(log.breaks).join(", ")}</div>
 </div>
 )}
 {ded > 0 && (
 <div className="text-[10px] font-bold text-red-600 mt-0.5"
 title={log.deductionReason || "Admin deduction"}>
 −{fmt(ded)} deducted
 </div>
 )}
 </div>
 );
 })()}
 </td>
 {(log.notes || log.deductionReason) && (
 <td className="px-3 py-2.5 text-xs text-zinc-400 italic max-w-[120px] truncate"
 title={[log.notes, log.deductionReason && `Deduction: ${log.deductionReason}`].filter(Boolean).join(" · ")}>
 {log.notes || log.deductionReason}
 </td>
 )}
 {!log.notes && !log.deductionReason && <td className="px-3 py-2.5" />}
 <td className="px-3 py-2.5">
 {isDeleting ? (
 <div className="flex items-center gap-1.5">
 <span className="text-[11px] text-red-600 font-bold">Delete?</span>
 <button onClick={() => deleteMut.mutate(log.id)} disabled={deleteMut.isPending}
 className="text-[11px] font-bold text-white bg-red-500 px-2 py-0.5 rounded hover:bg-red-600"
 data-testid={`button-confirm-delete-${log.id}`}>
 {deleteMut.isPending ? "…" : "Yes"}
 </button>
 <button onClick={() => setConfirmDel(null)}
 className="text-[11px] font-bold border border-zinc-300 px-2 py-0.5 rounded hover:bg-zinc-100 text-zinc-600 transition-colors">
 No
 </button>
 </div>
 ) : (
 <div className="flex items-center gap-1">
 <button onClick={() => { setEditingId(log.id); setConfirmDel(null); }}
 className="p-1.5 rounded-lg hover:bg-zinc-100 text-zinc-400 hover:text-zinc-700 transition-colors"
 title="Edit" data-testid={`button-edit-log-${log.id}`}>
 <Pencil className="w-3.5 h-3.5" />
 </button>
 <button onClick={() => { setConfirmDel(log.id); setEditingId(null); }}
 className="p-1.5 rounded-lg hover:bg-red-50 text-zinc-400 hover:text-red-500 transition-colors"
 title="Delete" data-testid={`button-delete-log-${log.id}`}>
 <Trash2 className="w-3.5 h-3.5" />
 </button>
 </div>
 )}
 </td>
 </tr>
 );
 };

 const logTableHead = (showDate = true) => (
 <thead>
 <tr className="bg-zinc-50 border-b border-zinc-200">
 {showDate && <th className="text-left px-3 py-2.5 text-[11px] font-semibold text-zinc-500 uppercase tracking-wider">Date</th>}
 <th className="text-left px-3 py-2.5 text-[11px] font-semibold text-zinc-500 uppercase tracking-wider">Clock In</th>
 <th className="text-left px-3 py-2.5 text-[11px] font-semibold text-zinc-500 uppercase tracking-wider">Clock Out</th>
 <th className="text-right px-3 py-2.5 text-[11px] font-semibold text-zinc-500 uppercase tracking-wider">Hours</th>
 <th className="text-left px-3 py-2.5 text-[11px] font-semibold text-zinc-500 uppercase tracking-wider">Notes</th>
 <th className="px-3 py-2.5 text-[11px] font-semibold text-zinc-500 uppercase tracking-wider">Actions</th>
 </tr>
 </thead>
 );

 return (
 <div className="space-y-6">
 {/* ── Controls bar ─────────────────────────────────────────────── */}
 <div className="bg-white border border-zinc-200 rounded-none p-5 space-y-4">
 {/* View toggle */}
 <div className="flex items-center gap-3 flex-wrap">
 <div className="flex border border-zinc-200 rounded-lg overflow-hidden h-9">
 {(["daily","period"] as const).map(v => (
 <button key={v} onClick={() => setView(v)}
 className={`px-4 text-sm font-medium transition-colors ${view === v ? "bg-zinc-100 text-zinc-900" : "bg-white text-zinc-600 hover:bg-zinc-50"}`}
 data-testid={`button-view-${v}`}>
 {v === "daily" ? "Daily" : "Period"}
 </button>
 ))}
 </div>

 {/* Add Record button — always visible */}
 <button
 onClick={() => { setAddPresetUid(undefined); setShowAddForm(f => !f); }}
 className={`inline-flex items-center gap-2 h-9 px-4 rounded-lg text-sm font-medium transition-colors ${showAddForm ? "bg-zinc-900 text-white" : "bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50"}`}
 data-testid="button-open-add-record">
 <Plus className="w-4 h-4" />
 Add Record
 </button>

 {/* Bulk Deduct button — period view only */}
 {view === "period" && (
 <button
 onClick={() => setBulkDeductOpen(true)}
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-white border border-red-200 text-red-700 hover:bg-red-50 text-sm font-medium transition-colors"
 data-testid="button-open-bulk-deduct">
 <Clock className="w-4 h-4" />
 Bulk Deduct
 </button>
 )}

 {view === "period" && (
 <div className="flex gap-2 ml-auto flex-wrap">
 {[["today","Today"],["week","This Week"],["month","This Month"],["prevMonth","Last Month"]].map(([v,l]) => (
 <button key={v} onClick={() => setPreset(v)}
 className="h-8 px-3 rounded-md border border-zinc-200 bg-white text-xs font-medium text-zinc-600 hover:bg-zinc-50 transition-colors">
 {l}
 </button>
 ))}
 </div>
 )}
 </div>

 {/* Filters row */}
 <div className="flex flex-wrap gap-4 items-end">
 {view === "daily" ? (
 <div className="flex items-center gap-3">
 <button onClick={() => { const d = new Date(dailyDate); d.setDate(d.getDate()-1); setDailyDate(format(d,"yyyy-MM-dd")); }}
 className="w-9 h-9 rounded-lg border border-zinc-200 flex items-center justify-center text-zinc-500 hover:bg-zinc-50 transition-colors" title="Previous day">
 <ChevronDown className="w-4 h-4 rotate-90" />
 </button>
 <div>
 <label className="text-xs font-medium text-zinc-700 mb-1 block">Date</label>
 <input type="date" value={dailyDate} onChange={e => setDailyDate(e.target.value)}
 className="h-9 px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" data-testid="input-daily-date" />
 </div>
 <button onClick={() => { const d = new Date(dailyDate); d.setDate(d.getDate()+1); setDailyDate(format(d,"yyyy-MM-dd")); }}
 className="w-9 h-9 mt-[22px] rounded-lg border border-zinc-200 flex items-center justify-center text-zinc-500 hover:bg-zinc-50 transition-colors" title="Next day">
 <ChevronDown className="w-4 h-4 -rotate-90" />
 </button>
 <button onClick={() => setDailyDate(format(today, "yyyy-MM-dd"))}
 className="h-9 mt-[22px] px-3 rounded-lg border border-zinc-200 bg-white text-sm font-medium text-zinc-700 hover:bg-zinc-50 transition-colors">
 Today
 </button>
 </div>
 ) : (
 <div className="flex flex-wrap gap-4 items-end">
 <div>
 <label className="text-xs font-medium text-zinc-700 mb-1 block">From</label>
 <input type="date" value={from} onChange={e => setFrom(e.target.value)}
 className="h-9 px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" data-testid="input-from-date" />
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-700 mb-1 block">To</label>
 <input type="date" value={to} onChange={e => setTo(e.target.value)}
 className="h-9 px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" data-testid="input-to-date" />
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-700 mb-1 block">Staff</label>
 <select value={filterUid} onChange={e => setFilterUid(e.target.value)}
 className="h-9 px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors min-w-[150px]" data-testid="select-staff-filter">
 <option value="">All Staff</option>
 {(staff as any[]).map((s: any) => <option key={s.id} value={s.id}>{s.name}</option>)}
 </select>
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-700 mb-1 block">Sort By</label>
 <div className="flex gap-2 h-9">
 {[["name","Name"],["hours","Hours"]].map(([v,l]) => (
 <button key={v} onClick={() => { if (sortBy === v) setSortDir(d => d === "asc" ? "desc" : "asc"); else { setSortBy(v as any); setSortDir("asc"); } }}
 className={`inline-flex items-center gap-1.5 h-9 px-3 rounded-lg text-sm font-medium transition-colors ${sortBy === v ? "bg-zinc-900 text-white" : "bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50"}`}>
 {l} {sortBy === v ? (sortDir === "asc" ? "↑" : "↓") : ""}
 </button>
 ))}
 </div>
 </div>
 </div>
 )}
 </div>
 </div>

 {/* ── Add Record form (expanded inline) ───────────────────────── */}
 {showAddForm && (
 <AddRecordForm
 staff={staff as any[]}
 presetUserId={addPresetUid}
 presetDate={view === "daily" ? dailyDate : undefined}
 queryKeys={sharedQueryKeys}
 onClose={() => { setShowAddForm(false); setAddPresetUid(undefined); }}
 />
 )}

 {/* ── Bulk Deduct modal ───────────────────────────────────────── */}
 {bulkDeductOpen && (
 <BulkDeductModal
 staff={staff as any[]}
 defaultUserId={filterUid ? parseInt(filterUid) : undefined}
 defaultFrom={from}
 defaultTo={to}
 queryKeys={sharedQueryKeys}
 onClose={() => setBulkDeductOpen(false)}
 />
 )}

 {/* ── Stats ───────────────────────────────────────────────────── */}
 {view === "period" && (
 <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
 {[
 { label: "Total Hours (net)", val: fmt(grandTotals.totalMins), color: "text-zinc-900" },
 { label: "Regular", val: fmt(grandTotals.regularMins), color: "text-emerald-600" },
 { label: "Overtime", val: fmt(grandTotals.otMins), color: "text-amber-600" },
 { label: "Deducted", val: grandTotals.deductedMins > 0 ? `−${fmt(grandTotals.deductedMins)}` : "—", color: grandTotals.deductedMins > 0 ? "text-red-600" : "text-zinc-400" },
 ].map(c => (
 <div key={c.label} className="bg-white border border-zinc-200 rounded-none p-5 ">
 <p className="text-sm font-medium text-zinc-500 mb-1">{c.label}</p>
 <p className={`text-2xl font-semibold ${c.color}`}>{c.val}</p>
 </div>
 ))}
 </div>
 )}

 {/* ── Daily View ───────────────────────────────────────────────── */}
 {view === "daily" && (
 <div className="space-y-4">
 <div className="flex items-center justify-between">
 <h3 className="text-base font-semibold text-zinc-900">
 {isValid(dailyDate) ? (() => { try { return format(new Date(dailyDate + "T12:00:00"), "EEEE, d MMMM yyyy"); } catch { return dailyDate; } })() : "Select a date"}
 </h3>
 {dailyLoading && <div className="w-5 h-5 border-2 border-zinc-200 border-t-zinc-700 rounded-full animate-spin" />}
 </div>
 <div className="space-y-4">
 {(staff as any[]).filter((s:any)=>s.role==="staff").map((s: any) => {
 const sLogs = (dailyLogs as any[]).filter((l:any) => l.userId === s.id);
 const hasRecords = sLogs.length > 0;
 return (
 <div key={s.id} className={`bg-white border border-zinc-200 rounded-none overflow-hidden ${!hasRecords ? "opacity-75" : ""}`}
 data-testid={`daily-staff-${s.id}`}>
 <div className="flex items-center gap-3 px-5 py-4 border-b border-zinc-100 bg-zinc-50/50">
 <StaffAvatar user={s} size={10} />
 <div className="flex-1 min-w-0">
 <p className="font-semibold text-sm text-zinc-900">{s.name}</p>
 <p className="text-xs text-zinc-500">@{s.username}</p>
 </div>
 {hasRecords ? (
 <div className="flex items-center gap-3">
 <span className="text-sm font-semibold text-emerald-600">{fmt(calcOT(sLogs).totalMins)}</span>
 <button
 onClick={() => { setAddPresetUid(s.id); setShowAddForm(true); }}
 className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50 text-xs font-medium transition-colors"
 title={`Add record for ${s.name}`}
 data-testid={`button-quick-add-${s.id}`}>
 <Plus className="w-3.5 h-3.5" /> Add
 </button>
 </div>
 ) : (
 <button
 onClick={() => { setAddPresetUid(s.id); setShowAddForm(true); }}
 className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50 text-xs font-medium transition-colors"
 title={`Add record for ${s.name}`}
 data-testid={`button-add-${s.id}`}>
 <Plus className="w-3.5 h-3.5" /> Add Record
 </button>
 )}
 </div>
 {hasRecords && (
 <div className="overflow-x-auto">
 <table className="w-full">
 {logTableHead(false)}
 <tbody className="divide-y divide-zinc-100">
 {sLogs.map((log: any) => renderLogRow(log, false))}
 </tbody>
 </table>
 </div>
 )}
 </div>
 );
 })}
 </div>
 </div>
 )}

 {/* ── Period View ─────────────────────────────────────────────── */}
 {view === "period" && (
 periodLoading ? (
 <div className="flex justify-center py-16">
 <div className="w-6 h-6 border-2 border-zinc-200 border-t-zinc-700 rounded-full animate-spin" />
 </div>
 ) : (
 <div className="space-y-4">
 {staffRows.map((row: any) => (
 <div key={row.user?.id} className={`bg-white border border-zinc-200 rounded-none overflow-hidden ${row.days === 0 ? "opacity-75" : ""}`}
 data-testid={`period-staff-${row.user?.id}`}>
 {/* Staff header */}
 <button
 onClick={() => row.logs.length > 0 && setExpandedId(expandedId === row.user?.id ? null : row.user?.id)}
 className={`w-full px-5 py-4 flex items-center gap-4 transition-colors bg-zinc-50/50 hover:bg-zinc-50 border-b border-zinc-100 ${row.logs.length > 0 ? "cursor-pointer" : "cursor-default"}`}
 data-testid={`button-expand-staff-${row.user?.id}`}>
 <StaffAvatar user={row.user} size={10} />
 <div className="flex-1 min-w-0 text-left">
 <p className="font-semibold text-sm text-zinc-900">{row.user?.name}</p>
 <p className="text-xs text-zinc-500">@{row.user?.username}</p>
 <p className="text-xs mt-1">
 {row.days > 0
 ? <span className="inline-flex items-center rounded-md px-2 py-0.5 text-[11px] font-semibold bg-emerald-50 text-emerald-700">{row.days} day{row.days !== 1 ? "s" : ""} clocked</span>
 : <span className="inline-flex items-center rounded-md px-2 py-0.5 text-[11px] font-semibold bg-zinc-100 text-zinc-600">No records this period</span>}
 </p>
 </div>
 {/* Hour breakdown */}
 {row.totalMins > 0 && (
 <div className="text-right shrink-0 mr-4">
 <p className="font-semibold text-lg text-zinc-900">{fmt(row.totalMins)}</p>
 <div className="flex gap-2 justify-end mt-0.5">
 <span className="text-[11px] font-medium text-emerald-600">{fmt(row.regularMins)} reg</span>
 {row.otMins > 0 && <span className="text-[11px] font-medium text-amber-600">{fmt(row.otMins)} OT</span>}
 </div>
 <p className="text-[11px] text-zinc-500 mt-0.5">{row.days > 0 ? fmt(Math.round(row.totalMins / row.days)) + " avg/day" : ""}</p>
 </div>
 )}
 {row.logs.length > 0 && (
 <div className="w-8 h-8 rounded-full flex items-center justify-center bg-white border border-zinc-200 text-zinc-500 shrink-0">
 {expandedId === row.user?.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
 </div>
 )}
 </button>

 {/* Expanded log table */}
 {expandedId === row.user?.id && (
 <div className="overflow-x-auto">
 <table className="w-full min-w-[600px]">
 {logTableHead(true)}
 <tbody className="divide-y divide-zinc-100">
 {row.logs.map((log: any) => renderLogRow(log, true))}
 </tbody>
 </table>
 </div>
 )}
 </div>
 ))}
 </div>
 )
 )}
 </div>
 );
}

// ─── Amendments Tab ────────────────────────────────────────────────────────────


// Preset impact reasons for declining a time amendment. `chip` is the short
// label the admin taps; `full` is the plain-language sentence the STAFF sees so
// they understand the business impact (self-inflicted OT, P&L cost, reputation).
const REJECT_IMPACT_REASONS: { id: string; chip: string; full: string }[] = [
 { id: "late-first-job", chip: "Late first-job arrival (self-inflicted OT)", full: "The overtime came from arriving late to the first job, not from extra work that was assigned. Our rule is that the team must reach the first job location by 9:00am — clocking in at the van at 9:00am is not on time because the drive to the job comes after." },
 { id: "not-billable", chip: "Not billable — hits company P&L", full: "This overtime cannot be charged to the customer, so it becomes a direct cost to the company. Paying avoidable overtime reduces the profit on the job and hurts the company's bottom line (P&L)." },
 { id: "reputation", chip: "Delayed customer / reputation", full: "The late start pushed the job later and affected the customer's schedule. Late jobs risk bad reviews and lost repeat business, which damages the company's reputation." },
 { id: "not-approved", chip: "OT not pre-approved", full: "The overtime was not approved in advance. Extra hours need to be agreed with the office before the work, so they cannot be added after the fact." },
 { id: "mismatch", chip: "Doesn't match GPS / records", full: "The requested times do not match the GPS track and attendance records for that day." },
];

function AmendmentsTab() {
 const qc = useQueryClient();
 const { toast } = useToast();
 const { data: amendments = [], isLoading } = useQuery<any[]>({ queryKey: ["/api/admin/attendance/amendments"], refetchInterval: 30_000 });
 const [notes, setNotes] = useState<Record<number, string>>({});
 const [reasons, setReasons] = useState<Record<number, string[]>>({});

 const toggleReason = (id: number, rid: string) => setReasons(prev => {
 const cur = prev[id] || [];
 return { ...prev, [id]: cur.includes(rid) ? cur.filter(x => x !== rid) : [...cur, rid] };
 });

 // Build the full, staff-facing explanation from the checked impact reasons,
 // the GPS late-arrival evidence, and the admin's free-text note.
 const composeRejectReason = (a: any): string => {
 const picked = reasons[a.id] || [];
 const lines: string[] = [];
 for (const r of REJECT_IMPACT_REASONS) if (picked.includes(r.id)) lines.push("• " + r.full);
 const fa = a.firstJobArrival;
 if (fa?.lateFirstJob) {
 const at = new Date(fa.firstJobArrivalAt).toLocaleTimeString('en-SG', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'Asia/Singapore' });
 const late = fa.minutesLate;
 const lateStr = late >= 60 ? `${Math.floor(late / 60)}h ${late % 60}m` : `${late}m`;
 lines.push(`• GPS record: you reached the first job at ${at} — ${lateStr} after the ${fa.deadline} rule.`);
 }
 const note = (notes[a.id] || "").trim();
 if (note) lines.push(note);
 return lines.join("\n");
 };

 const reviewMut = useMutation({
 mutationFn: ({ id, status, adminNote }: { id: number; status: "approved" | "rejected"; adminNote?: string }) =>
 apiRequest("PATCH", `/api/admin/attendance/amendments/${id}`, { status, adminNote: adminNote ?? (notes[id] || "") }),
 onSuccess: () => {
 qc.invalidateQueries({ queryKey: ["/api/admin/attendance/amendments"] });
 qc.invalidateQueries({ queryKey: ["/api/admin/attendance"] });
 toast({ title: "Amendment reviewed" });
 },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 if (isLoading) return <div className="flex justify-center py-16"><div className="w-6 h-6 border-2 border-zinc-200 border-t-zinc-700 rounded-full animate-spin" /></div>;

 if (amendments.length === 0) {
 return (
 <div className="text-center py-16 bg-white border border-dashed border-zinc-200 rounded-none">
 <AlertCircle className="w-10 h-10 text-zinc-300 mx-auto mb-3" />
 <p className="text-sm font-medium text-zinc-500">No amendment requests</p>
 </div>
 );
 }

 return (
 <div className="space-y-4">
 {amendments.map((a: any) => (
 <div key={a.id} className="bg-white border border-zinc-200 rounded-none overflow-hidden">
 <div className="px-5 py-4 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50">
 <div>
 <div className="flex items-center gap-3 mb-1">
 <p className="font-semibold text-sm text-zinc-900">{a.user?.name}</p>
 <StatusBadge status={a.status} />
 </div>
 <p className="text-xs text-zinc-500">Submitted {format(new Date(a.createdAt), "d MMM yyyy HH:mm")}</p>
 </div>
 </div>
 <div className="p-5 space-y-4">
 {/* Before → After comparison */}
 <div className="grid grid-cols-[1fr_auto_1fr] gap-4 items-center">
 {/* Original */}
 <div className="bg-zinc-50 border border-zinc-200 rounded-lg p-3 space-y-2">
 <p className="text-[10px] font-semibold text-zinc-500 uppercase tracking-widest mb-1">Original</p>
 <div className="flex items-center gap-2 text-sm text-zinc-700">
 <LogIn className="w-4 h-4 text-emerald-500 shrink-0" />
 <span>{a.originalClockIn ? formatSingaporeAttendance(a.originalClockIn, "d MMM, HH:mm") : <span className="text-zinc-400">—</span>}</span>
 </div>
 <div className="flex items-center gap-2 text-sm text-zinc-700">
 <LogOut className="w-4 h-4 text-red-500 shrink-0" />
 <span>{a.originalClockOut ? formatSingaporeAttendance(a.originalClockOut, "d MMM, HH:mm") : <span className="text-zinc-400">—</span>}</span>
 </div>
 </div>
 {/* Arrow */}
 <div className="flex flex-col items-center justify-center">
 <ArrowRight className="w-5 h-5 text-zinc-400" />
 </div>
 {/* Requested */}
 <div className="bg-white border border-blue-200 rounded-lg p-3 space-y-2 ">
 <p className="text-[10px] font-semibold text-[#0A0A0A] uppercase tracking-widest mb-1">Requested</p>
 <div className="flex items-center gap-2 text-sm text-zinc-900 font-medium">
 <LogIn className="w-4 h-4 text-emerald-500 shrink-0" />
 <span>{a.requestedClockIn ? formatSingaporeAttendance(a.requestedClockIn, "d MMM, HH:mm") : <span className="text-zinc-400 font-normal">—</span>}</span>
 </div>
 <div className="flex items-center gap-2 text-sm text-zinc-900 font-medium">
 <LogOut className="w-4 h-4 text-red-500 shrink-0" />
 <span>{a.requestedClockOut ? formatSingaporeAttendance(a.requestedClockOut, "d MMM, HH:mm") : <span className="text-zinc-400 font-normal">—</span>}</span>
 </div>
 </div>
 </div>
  {a.status==="pending" && attendanceAmendmentDateError(
    {clockInAt:a.originalClockIn,clockOutAt:a.originalClockOut},
    {clockInAt:a.requestedClockIn,clockOutAt:a.requestedClockOut},
  ) && <p role="alert" className="text-sm text-red-700 bg-red-50 border border-red-200 p-3">
    {attendanceAmendmentDateError(
      {clockInAt:a.originalClockIn,clockOutAt:a.originalClockOut},
      {clockInAt:a.requestedClockIn,clockOutAt:a.requestedClockOut},
    )}
  </p>}
 <div className="bg-zinc-50 rounded-lg p-3 border border-zinc-100">
 <p className="text-xs font-semibold text-zinc-700 mb-1">Staff Reason</p>
 <p className="text-sm text-zinc-600">{a.reason}</p>
 </div>

 {a.firstJobArrival && (() => {
 const fa = a.firstJobArrival;
 const at = new Date(fa.firstJobArrivalAt).toLocaleTimeString('en-SG', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'Asia/Singapore' });
 const late = fa.minutesLate;
 const lateStr = late >= 60 ? `${Math.floor(late / 60)}h ${late % 60}m` : `${late}m`;
 return fa.lateFirstJob ? (
 <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg p-3" data-testid={`flag-late-firstjob-${a.id}`}>
 <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
 <div>
 <p className="text-xs font-bold text-red-700 uppercase tracking-wider">Late first-job arrival</p>
 <p className="text-xs text-red-700 mt-0.5">
 GPS shows they reached the first job at <span className="font-bold font-mono">{at}</span> — <span className="font-bold">{lateStr}</span> after the {fa.deadline} rule. This overtime may be a late start, not extra work.
 </p>
 </div>
 </div>
 ) : (
 <div className="flex items-start gap-2 bg-emerald-50 border border-emerald-200 rounded-lg p-3" data-testid={`flag-ontime-firstjob-${a.id}`}>
 <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
 <p className="text-xs text-emerald-700">
 On time — first job reached at <span className="font-bold font-mono">{at}</span> (within the {fa.deadline} rule).
 </p>
 </div>
 );
 })()}

 {a.status === 'pending' && (() => {
 const composed = composeRejectReason(a);
 return (
 <div className="space-y-3 pt-2">
 {/* Impact reasons — tap to build the explanation the staff member sees */}
 <div>
 <p className="text-[10px] font-semibold text-zinc-500 uppercase tracking-widest mb-1.5">Reason for declining (staff will see this)</p>
 <div className="flex flex-wrap gap-1.5">
 {REJECT_IMPACT_REASONS.map(r => {
 const on = (reasons[a.id] || []).includes(r.id);
 return (
 <button key={r.id} type="button" onClick={() => toggleReason(a.id, r.id)}
 className={`text-xs px-2.5 py-1 rounded-full border transition-colors ${on ? "bg-[#0A0A0A] text-white border-[#0A0A0A]" : "bg-white text-zinc-600 border-zinc-300 hover:border-zinc-400"}`}
 data-testid={`chip-reason-${r.id}-${a.id}`}>
 {r.chip}
 </button>
 );
 })}
 </div>
 </div>
 <textarea value={notes[a.id] || ""} onChange={e => setNotes(n => ({ ...n, [a.id]: e.target.value }))}
 placeholder="Add any extra note to the staff member (optional)" rows={2}
 className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] resize-none transition-colors"
 data-testid={`textarea-admin-note-${a.id}`} />
 {composed.trim() && (
 <div className="rounded-lg bg-zinc-50 border border-zinc-200 p-3">
 <p className="text-[10px] font-semibold text-zinc-500 uppercase tracking-widest mb-1">Preview — what staff will see</p>
 <p className="text-xs text-zinc-700 whitespace-pre-line">{composed}</p>
 </div>
 )}
 <div className="flex gap-3">
 <button onClick={() => reviewMut.mutate({ id: a.id, status: "approved", adminNote: notes[a.id] || "" })}
  disabled={reviewMut.isPending || !!attendanceAmendmentDateError(
    {clockInAt:a.originalClockIn,clockOutAt:a.originalClockOut},
    {clockInAt:a.requestedClockIn,clockOutAt:a.requestedClockOut},
  )}
 className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg bg-emerald-600 text-white text-xs font-medium hover:bg-emerald-700 transition-colors disabled:opacity-50"
 data-testid={`button-approve-amendment-${a.id}`}>
 <Check className="w-3.5 h-3.5" /> Approve
 </button>
 <button onClick={() => {
   const reason = composeRejectReason(a);
   if (!reason.trim()) {
     toast({ title: "Reason required", description: "Pick at least one reason (or write a note) so the staff member knows why it was declined.", variant: "destructive" });
     return;
   }
   reviewMut.mutate({ id: a.id, status: "rejected", adminNote: reason });
 }}
 disabled={reviewMut.isPending}
 className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg bg-red-600 text-white text-xs font-medium hover:bg-red-700 transition-colors disabled:opacity-50"
 data-testid={`button-reject-amendment-${a.id}`}>
 <X className="w-3.5 h-3.5" /> Reject
 </button>
 </div>
 </div>
 );
 })()}
 {a.status !== 'pending' && a.adminNote && (
 <div className="mt-2 rounded-lg bg-zinc-50 border border-zinc-200 p-3">
 <p className="text-[10px] font-semibold text-zinc-500 uppercase tracking-widest mb-1">Reason sent to staff</p>
 <p className="text-xs text-zinc-600 whitespace-pre-line leading-relaxed">{a.adminNote}</p>
 </div>
 )}
 </div>
 </div>
 ))}
 </div>
 );
}

// ─── Leave Tab ─────────────────────────────────────────────────────────────────

function LeaveTab() {
 const qc = useQueryClient();
 const { toast } = useToast();
 const [statusFilter, setStatusFilter] = useState("pending");
 const [notes, setNotes] = useState<Record<number, string>>({});

 const { data: leaves = [], isLoading } = useQuery<any[]>({
 queryKey: ["/api/admin/leave", statusFilter],
 queryFn: async () => {
 const params = statusFilter !== "all" ? `?status=${statusFilter}` : "";
 const res = await fetch(`${API_BASE}/api/admin/leave${params}`, { credentials: "include" });
 return res.json();
 },
 refetchInterval: 30_000,
 });

 // Fetch all leaves for the year to compute balances
 const { data: allLeaves = [] } = useQuery<any[]>({
 queryKey: ["/api/admin/leave", "all"],
 queryFn: async () => {
 const res = await fetch(`${API_BASE}/api/admin/leave`, { credentials: "include" });
 return res.json();
 },
 refetchInterval: 30_000,
 });

 // Build per-staff used days map (approved annual leave only)
 const usedAnnualByStaff = (allLeaves as any[]).reduce((acc: Record<number, number>, l: any) => {
 if (l.leaveType === "annual" && l.status === "approved" && l.userId) {
 acc[l.userId] = (acc[l.userId] || 0) + parseFloat(l.totalDays || "0");
 }
 return acc;
 }, {});

 // Pending counts per filter
 const pendingCount = (allLeaves as any[]).filter((l: any) => l.status === "pending").length;

 const reviewMut = useMutation({
 mutationFn: ({ id, status }: { id: number; status: "approved" | "rejected" }) =>
 apiRequest("PATCH", `/api/admin/leave/${id}`, { status, adminNote: notes[id] || "" }),
 onSuccess: () => {
 qc.invalidateQueries({ queryKey: ["/api/admin/leave"] });
 toast({ title: "Leave request reviewed" });
 },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 return (
 <div className="space-y-4">
 <div className="flex gap-2 flex-wrap">
 {([["pending", "Pending"], ["approved", "Approved"], ["rejected", "Rejected"], ["all", "All"]] as const).map(([v, l]) => (
 <button key={v} onClick={() => setStatusFilter(v)}
 className={`inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-sm font-medium border transition-all ${statusFilter === v ? "bg-zinc-900 text-white border-zinc-900" : "border-zinc-200 text-zinc-600 hover:bg-zinc-50 hover:border-zinc-300"}`}
 data-testid={`filter-leave-${v}`}>
 {l}
 {v === "pending" && pendingCount > 0 && (
 <span className="min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
 {pendingCount}
 </span>
 )}
 </button>
 ))}
 </div>

 {isLoading ? (
 <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-blue-500" /></div>
 ) : leaves.length === 0 ? (
 <div className="text-center py-16 border border-dashed border-zinc-200 rounded-none">
 <Calendar className="w-10 h-10 text-zinc-300 mx-auto mb-3" />
 <p className="font-semibold text-zinc-400">No {statusFilter !== "all" ? statusFilter : ""} leave requests</p>
 </div>
 ) : (
 <div className="space-y-3">
 {(leaves as any[]).map((l: any) => {
 const entitlement = parseInt(l.user?.annualLeaveEntitlement || "14");
 const usedDays = usedAnnualByStaff[l.userId] || 0;
 const remaining = entitlement - usedDays;
 const isAnnual = l.leaveType === "annual";

 return (
 <div key={l.id} className="bg-white border border-zinc-200 rounded-none overflow-hidden">
 {/* Card header */}
 <div className="px-4 pt-3 pb-2">
 <div className="flex items-start justify-between gap-3">
 <div className="flex-1 min-w-0">
 <div className="flex items-center gap-2 mb-1 flex-wrap">
 <p className="font-semibold text-zinc-900">{l.user?.name}</p>
 <StatusBadge status={l.status} />
 <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-zinc-100 text-zinc-500">
 {LEAVE_TYPE_LABELS[l.leaveType] || l.leaveType}
 </span>
 </div>
 <div className="flex items-center gap-2 text-sm flex-wrap">
 <span className="font-semibold text-zinc-900">
 {format(parseISO(l.startDate), "d MMM")} – {format(parseISO(l.endDate), "d MMM yyyy")}
 </span>
 <span className="text-zinc-400 text-xs">
 Submitted {format(new Date(l.createdAt || l.startDate), "d MMM")}
 </span>
 </div>
 {l.reason && <p className="text-xs text-zinc-400 mt-1 italic">"{l.reason}"</p>}
 </div>
 {/* Days requested + balance */}
 <div className="shrink-0 text-right">
 <p className="text-2xl font-bold text-zinc-900 leading-none">{parseFloat(l.totalDays)}d</p>
 <p className="text-[10px] text-zinc-400 mt-0.5">requested</p>
 {isAnnual && (
 <p className={`text-[10px] font-bold mt-1 ${remaining < 0 ? "text-red-500" : remaining < 3 ? "text-amber-600" : "text-emerald-600"}`}>
 {remaining < 0 ? `${Math.abs(remaining).toFixed(1)}d over` : `${remaining.toFixed(1)}d left`}
 </p>
 )}
 </div>
 </div>
 {/* Leave balance bar for annual leave */}
 {isAnnual && (
 <div className="mt-2.5">
 <div className="flex items-center justify-between text-[10px] text-zinc-400 mb-1">
 <span>{usedDays.toFixed(1)} used of {entitlement} days entitlement</span>
 <span className={remaining < 0 ? "text-red-500 font-bold" : ""}>{remaining > 0 ? `${remaining.toFixed(1)} remaining` : "Exceeded"}</span>
 </div>
 <div className="h-1.5 bg-zinc-200 rounded-full overflow-hidden">
 <div
 className={`h-full rounded-full transition-all ${remaining < 0 ? "bg-red-500" : remaining < 3 ? "bg-amber-500" : "bg-emerald-500"}`}
 style={{ width: `${Math.min(100, (usedDays / entitlement) * 100)}%` }}
 />
 </div>
 </div>
 )}
 </div>

 {l.status === 'pending' && (
 <div className="px-4 pb-4 space-y-3 border-t border-zinc-100 pt-3">
 <textarea value={notes[l.id] || ""} onChange={e => setNotes(n => ({ ...n, [l.id]: e.target.value }))}
 placeholder="Admin note (optional)" rows={2}
 className="w-full px-3 py-2 border border-zinc-300 rounded-lg text-sm bg-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors resize-none" />
 <div className="flex gap-2">
 <button onClick={() => reviewMut.mutate({ id: l.id, status: "approved" })}
 disabled={reviewMut.isPending}
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium transition-colors disabled:opacity-50"
 data-testid={`button-approve-leave-${l.id}`}>
 <Check className="w-3.5 h-3.5" /> Approve
 </button>
 <button onClick={() => reviewMut.mutate({ id: l.id, status: "rejected" })}
 disabled={reviewMut.isPending}
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm font-medium transition-colors disabled:opacity-50"
 data-testid={`button-reject-leave-${l.id}`}>
 <X className="w-3.5 h-3.5" /> Reject
 </button>
 </div>
 </div>
 )}
 {l.adminNote && (
 <p className="px-4 pb-3 text-xs text-zinc-400 italic border-t border-zinc-100 pt-2">Admin note: {l.adminNote}</p>
 )}
 </div>
 );
 })}
 </div>
 )}
 </div>
 );
}

// ─── Payslips Tab ──────────────────────────────────────────────────────────────

function PayslipsTab() {
 const qc = useQueryClient();
 const { toast } = useToast();
 const today = new Date();

 const { data: staff = [] } = useQuery<any[]>({ queryKey: ["/api/staff"] });
 const [filterUserId, setFilterUserId] = useState<string>("");
 const [showGenerate, setShowGenerate] = useState(false);
 const [showReview, setShowReview] = useState(false);
 const [genForm, setGenForm] = useState({
 userId: "",
 periodStart: format(startOfMonth(today), "yyyy-MM-dd"),
 periodEnd: format(endOfMonth(today), "yyyy-MM-dd"),
 notes: "",
 });
 const [expandedId, setExpandedId] = useState<number | null>(null);
 const [printingPayslip, setPrintingPayslip] = useState<any | null>(null);

 // Loans state
 const [showLoans, setShowLoans] = useState(false);
 const [showAddLoan, setShowAddLoan] = useState(false);
 const [loanForm, setLoanForm] = useState({
 description: "",
 totalAmount: "",
 monthlyRepayment: "",
 repaymentType: "monthly",
 startDate: format(today, "yyyy-MM-dd"),
 });
 const [editingLoanId, setEditingLoanId] = useState<number | null>(null);
 const [editLoanForm, setEditLoanForm] = useState({ description: "", totalAmount: "", monthlyRepayment: "", repaymentType: "monthly" });

 const { data: allLoans = [] } = useQuery<any[]>({
 queryKey: ["/api/admin/staff-loans"],
 queryFn: async () => {
 const res = await fetch(`${API_BASE}/api/admin/staff-loans`, { credentials: "include" });
 return res.json();
 },
 refetchInterval: 30_000,
 });
 const loans = filterUserId
 ? allLoans.filter((l: any) => l.userId === parseInt(filterUserId))
 : [];

 const addLoanMut = useMutation({
 mutationFn: () => apiRequest("POST", "/api/admin/staff-loans", {
 userId: parseInt(filterUserId),
 description: loanForm.description,
 totalAmount: parseFloat(loanForm.totalAmount),
 monthlyRepayment: loanForm.repaymentType === "one_time" ? 0 : parseFloat(loanForm.monthlyRepayment),
 repaymentType: loanForm.repaymentType,
 startDate: loanForm.startDate,
 }),
 onSuccess: () => {
 qc.invalidateQueries({ queryKey: ["/api/admin/staff-loans"] });
 setShowAddLoan(false);
 setLoanForm({ description: "", totalAmount: "", monthlyRepayment: "", repaymentType: "monthly", startDate: format(today, "yyyy-MM-dd") });
 toast({ title: "Loan recorded" });
 },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 const deleteLoanMut = useMutation({
 mutationFn: (id: number) => apiRequest("DELETE", `/api/admin/staff-loans/${id}`),
 onSuccess: () => { qc.invalidateQueries({ queryKey: ["/api/admin/staff-loans"] }); toast({ title: "Loan deleted" }); },
 });

 const toggleLoanActiveMut = useMutation({
 mutationFn: ({ id, isActive }: { id: number; isActive: boolean }) =>
 apiRequest("PATCH", `/api/admin/staff-loans/${id}`, { isActive }),
 onSuccess: () => { qc.invalidateQueries({ queryKey: ["/api/admin/staff-loans"] }); },
 });
 const editLoanMut = useMutation({
 mutationFn: (p: { id: number; description: string; totalAmount: number; monthlyRepayment: number; repaymentType: string }) =>
 apiRequest("PATCH", `/api/admin/staff-loans/${p.id}`, p),
 onSuccess: () => {
 qc.invalidateQueries({ queryKey: ["/api/admin/staff-loans"] });
 setEditingLoanId(null);
 toast({ title: "Loan updated", description: "Previous repayments were preserved." });
 },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 const { data: payslips = [], isLoading } = useQuery<any[]>({
 queryKey: ["/api/admin/payslips", filterUserId],
 queryFn: async () => {
 const params = filterUserId ? `?userId=${filterUserId}` : "";
 const res = await fetch(`${API_BASE}/api/admin/payslips${params}`, { credentials: "include" });
 return res.json();
 },
 refetchInterval: 30_000,
 });

 const generateMut = useMutation({
 mutationFn: (override?: { userId: string; periodStart: string; periodEnd: string }) =>
 apiRequest("POST", "/api/admin/payslips/generate", {
 userId: parseInt(override ? override.userId : genForm.userId),
 periodStart: override ? override.periodStart : genForm.periodStart,
 periodEnd: override ? override.periodEnd : genForm.periodEnd,
 notes: override ? undefined : (genForm.notes || undefined),
 }),
 onSuccess: () => {
 qc.invalidateQueries({ queryKey: ["/api/admin/payslips"] });
 setShowGenerate(false);
 setShowReview(false);
 toast({ title: "Payslip generated" });
 },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 const deleteMut = useMutation({
 mutationFn: (id: number) => apiRequest("DELETE", `/api/admin/payslips/${id}`),
 onSuccess: () => { qc.invalidateQueries({ queryKey: ["/api/admin/payslips"] }); toast({ title: "Payslip deleted" }); },
 });

 return (
 <div className="space-y-4">
 <div className="flex flex-wrap gap-3 items-center">
 <select value={filterUserId} onChange={e => setFilterUserId(e.target.value)}
 className="h-9 px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors min-w-[150px]" data-testid="select-payslip-staff">
 <option value="">All Staff</option>
 {staff.map((s: any) => <option key={s.id} value={s.id}>{s.name}</option>)}
 </select>
 <button onClick={() => setShowReview(true)}
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 text-sm font-medium transition-colors"
 data-testid="button-review-clockins">
 <Clock className="w-4 h-4" /> Review Clock-Ins
 </button>
 <button onClick={() => setShowGenerate(!showGenerate)}
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors"
 data-testid="button-generate-payslip">
 <Plus className="w-4 h-4" /> Generate Payslip
 </button>
 <button onClick={() => setShowLoans(!showLoans)}
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 text-sm font-medium transition-colors"
 data-testid="button-toggle-loans">
 <CreditCard className="w-4 h-4" /> Manage Loans
 </button>
 </div>

 {/* ── Staff Loans Panel ── */}
 {showLoans && (
 <div className="bg-white border border-zinc-200 rounded-none p-5 space-y-4">
 <div className="flex items-center justify-between">
 <div className="flex items-center gap-2">
 <CreditCard className="w-4 h-4 text-zinc-500" />
 <h3 className="text-sm font-semibold text-zinc-900">Staff Loans</h3>
 </div>
 {filterUserId && (
 <button onClick={() => setShowAddLoan(!showAddLoan)}
 className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg bg-zinc-900 hover:bg-zinc-700 text-white text-xs font-medium transition-colors"
 data-testid="button-add-loan">
 <Plus className="w-3.5 h-3.5" /> Add Loan
 </button>
 )}
 </div>

 {!filterUserId ? (
 <p className="text-sm text-zinc-400">Select a staff member above to view and manage their loans.</p>
 ) : (
 <>
 {showAddLoan && (
 <div className="bg-zinc-50 border border-zinc-200 rounded-none p-4 space-y-3">
 <h4 className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">New Loan</h4>
 <div>
 <label className="block text-xs font-semibold text-zinc-500 mb-1">Description / Purpose</label>
 <input type="text" value={loanForm.description} onChange={e => setLoanForm(f => ({ ...f, description: e.target.value }))}
 placeholder="e.g. Personal advance, Equipment loan"
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="input-loan-description" />
 </div>
 <div className="grid grid-cols-2 gap-3">
 <div>
 <label className="block text-xs font-semibold text-zinc-500 mb-1">Total Loan Amount (S$)</label>
 <input type="number" min="0" step="0.01" value={loanForm.totalAmount} onChange={e => setLoanForm(f => ({ ...f, totalAmount: e.target.value }))}
 placeholder="0.00"
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="input-loan-amount" />
 </div>
  <div>
  <label className="block text-xs font-semibold text-zinc-500 mb-1">Deduction Type</label>
  <select value={loanForm.repaymentType} onChange={e => setLoanForm(f => ({ ...f, repaymentType: e.target.value }))}
  className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white"
  data-testid="select-loan-repayment-type">
  <option value="monthly">Monthly repayment</option>
  <option value="one_time">One-time deduction on next payslip</option>
  </select>
  </div>
 <div>
 <label className="block text-xs font-semibold text-zinc-500 mb-1">Monthly Repayment (S$)</label>
  <input type="number" min="0" step="0.01" value={loanForm.monthlyRepayment} onChange={e => setLoanForm(f => ({ ...f, monthlyRepayment: e.target.value }))}
  disabled={loanForm.repaymentType === "one_time"}
 placeholder="0.00"
  className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white disabled:bg-zinc-100 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="input-loan-repayment" />
 </div>
 </div>
 <div>
 <label className="block text-xs font-semibold text-zinc-500 mb-1">Start Date</label>
 <input type="date" value={loanForm.startDate} onChange={e => setLoanForm(f => ({ ...f, startDate: e.target.value }))}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="input-loan-start-date" />
 </div>
 <div className="flex gap-2">
 <button onClick={() => addLoanMut.mutate()}
  disabled={!loanForm.description || !loanForm.totalAmount || (loanForm.repaymentType === "monthly" && !loanForm.monthlyRepayment) || addLoanMut.isPending}
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-50"
 data-testid="button-confirm-add-loan">
 {addLoanMut.isPending ? <><Loader2 className="w-4 h-4 animate-spin" /> Saving...</> : "Save Loan"}
 </button>
 <button onClick={() => setShowAddLoan(false)}
 className="inline-flex items-center h-9 px-4 rounded-lg border border-zinc-200 text-zinc-600 hover:bg-zinc-50 text-sm font-medium transition-colors">Cancel</button>
 </div>
 </div>
 )}

 {loans.length === 0 ? (
 <p className="text-sm text-zinc-400">No loans recorded for this staff member.</p>
 ) : (
 <div className="space-y-2">
 {loans.map((loan: any) => {
 const remaining = parseFloat(loan.remainingBalance || "0");
 const total = parseFloat(loan.totalAmount || "0");
 const pct = total > 0 ? Math.max(0, Math.min(100, (remaining / total) * 100)) : 0;
 return (
 <div key={loan.id} data-testid={`loan-${loan.id}`}
 className={`border rounded-none p-4 ${loan.isActive ? "border-zinc-200 bg-white" : "border-zinc-100 bg-zinc-50"}`}>
 <div className="flex items-start justify-between gap-2">
 <div className="flex-1 min-w-0">
 <div className="flex items-center gap-2 flex-wrap">
 <p className="font-semibold text-sm text-zinc-900">{loan.description}</p>
 <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide ${remaining > 0 ? "bg-amber-100 text-amber-700" : "bg-zinc-100 text-zinc-600"}`}>
 {staffLoanStatus(loan)}
 </span>
 </div>
 <p className="text-xs text-zinc-500 mt-0.5">
  Started {loan.startDate} · {loan.repaymentType === "one_time" ? "one-time deduction on next payslip" : `S$${parseFloat(loan.monthlyRepayment).toFixed(2)}/month repayment`}
 </p>
 <div className="mt-2.5 flex items-center gap-3">
 <div className="flex-1 bg-zinc-100 rounded-full h-1.5">
 <div className="bg-amber-500 h-1.5 rounded-full transition-all" style={{ width: `${pct}%` }} />
 </div>
 <span className="text-xs font-mono font-bold text-zinc-700 shrink-0">
 {payslipLoanPresentation(loan, undefined).outstanding} / S${total.toFixed(2)}
 </span>
 </div>
 </div>
 <div className="flex gap-1 shrink-0">
  <button
  onClick={() => {
    setEditingLoanId(loan.id);
    setEditLoanForm({
      description: loan.description || "",
      totalAmount: String(total),
      monthlyRepayment: String(parseFloat(loan.monthlyRepayment || "0")),
       repaymentType: loan.repaymentType || "monthly",
    });
  }}
  className="p-1.5 rounded-lg hover:bg-zinc-100 text-zinc-400 hover:text-zinc-600 transition-colors"
  title="Edit loan amount"
  data-testid={`btn-edit-loan-${loan.id}`}>
  <Pencil className="w-3.5 h-3.5" />
  </button>
 <button
 onClick={() => toggleLoanActiveMut.mutate({ id: loan.id, isActive: !loan.isActive })}
 className="p-1.5 rounded-lg hover:bg-zinc-100 text-zinc-400 hover:text-zinc-600 transition-colors"
 title={loan.isActive ? "Pause repayments" : "Resume repayments"}
 data-testid={`btn-toggle-loan-${loan.id}`}>
 {loan.isActive ? <Check className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
 </button>
 <button
 onClick={() => { if (confirm("Delete this loan record?")) deleteLoanMut.mutate(loan.id); }}
 className="p-1.5 rounded-lg hover:bg-red-50 text-zinc-400 hover:text-red-500 transition-colors"
 data-testid={`btn-delete-loan-${loan.id}`}>
 <Trash2 className="w-3.5 h-3.5" />
 </button>
 </div>
  {editingLoanId === loan.id && (
  <div className="mt-3 pt-3 border-t border-zinc-100 space-y-2">
  <p className="text-[11px] text-zinc-500">
  Edit the total without changing repayments already made. The unpaid balance recalculates automatically.
  </p>
  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
  <input type="text" value={editLoanForm.description}
  onChange={e => setEditLoanForm(f => ({ ...f, description: e.target.value }))}
  className="h-9 px-2 border border-zinc-300 rounded-lg text-sm" placeholder="Description" />
  <input type="number" min="0.01" step="0.01" value={editLoanForm.totalAmount}
  onChange={e => setEditLoanForm(f => ({ ...f, totalAmount: e.target.value }))}
  className="h-9 px-2 border border-zinc-300 rounded-lg text-sm" placeholder="Total amount"
  data-testid={`input-edit-loan-amount-${loan.id}`} />
   <select value={editLoanForm.repaymentType} onChange={e => setEditLoanForm(f => ({ ...f, repaymentType: e.target.value }))}
   className="h-9 px-2 border border-zinc-300 rounded-lg text-sm">
   <option value="monthly">Monthly repayment</option>
   <option value="one_time">One-time deduction on next payslip</option>
   </select>
   <input type="number" min="0" step="0.01" value={editLoanForm.monthlyRepayment}
  onChange={e => setEditLoanForm(f => ({ ...f, monthlyRepayment: e.target.value }))}
   disabled={editLoanForm.repaymentType === "one_time"}
   className="h-9 px-2 border border-zinc-300 rounded-lg text-sm disabled:bg-zinc-100" placeholder="Monthly repayment" />
  </div>
  <div className="flex gap-2">
  <button onClick={() => editLoanMut.mutate({
    id: loan.id,
    description: editLoanForm.description.trim(),
    totalAmount: parseFloat(editLoanForm.totalAmount),
    monthlyRepayment: editLoanForm.repaymentType === "one_time" ? 0 : parseFloat(editLoanForm.monthlyRepayment),
    repaymentType: editLoanForm.repaymentType,
  })}
  disabled={!editLoanForm.description.trim() || !Number.isFinite(parseFloat(editLoanForm.totalAmount)) ||
    parseFloat(editLoanForm.totalAmount) <= 0 || (editLoanForm.repaymentType === "monthly" && !Number.isFinite(parseFloat(editLoanForm.monthlyRepayment))) || editLoanMut.isPending}
  className="h-8 px-3 rounded-lg bg-[#0A0A0A] text-white text-xs font-medium disabled:opacity-50"
  data-testid={`button-save-edit-loan-${loan.id}`}>Save changes</button>
  <button onClick={() => setEditingLoanId(null)}
  className="h-8 px-3 rounded-lg border border-zinc-200 text-zinc-600 text-xs font-medium">Cancel</button>
  </div>
  </div>
  )}
 </div>
 </div>
 );
 })}
 </div>
 )}
 </>
 )}
 </div>
 )}


 {showGenerate && (
 <div className="bg-white border border-zinc-200 rounded-none p-5 space-y-4">
 <h3 className="text-sm font-semibold text-zinc-900">Generate Payslip</h3>
 <div>
 <label className="block text-xs font-semibold text-zinc-500 mb-1">Staff Member</label>
 <select value={genForm.userId} onChange={e => setGenForm(f => ({ ...f, userId: e.target.value }))}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" data-testid="select-gen-staff">
 <option value="">Select staff member...</option>
 {staff.map((s: any) => (
 <option key={s.id} value={s.id}>
 {s.name} (@{s.username})
 </option>
 ))}
 </select>
 </div>
 {/* Selected staff info card */}
 {genForm.userId && (() => {
 const s = (staff as any[]).find((x: any) => String(x.id) === genForm.userId);
 return s ? (
 <div className="bg-zinc-50 border border-zinc-200 rounded-lg px-4 py-3 space-y-3">
 <div className="flex items-center gap-3">
 <div className="w-9 h-9 rounded-full bg-zinc-200 text-zinc-700 font-bold text-sm flex items-center justify-center shrink-0">
 {s.name.split(" ").map((w: string) => w[0]).slice(0,2).join("").toUpperCase()}
 </div>
 <div className="flex-1 min-w-0">
 <p className="font-semibold text-sm truncate text-zinc-900">{s.name}</p>
 <p className="text-xs font-mono text-zinc-400">@{s.username}</p>
 </div>
 </div>
 {/* Pay package summary — 3 components */}
 <div className="grid grid-cols-3 gap-2">
 <div className="bg-white border border-zinc-200 rounded-lg px-2 py-1.5 text-center">
 <p className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wide">Monthly</p>
 <p className="text-xs font-bold text-zinc-900 font-mono mt-0.5">
 S${parseFloat(s.monthlyRate || "0").toFixed(0)}
 </p>
 </div>
 <div className="bg-white border border-zinc-200 rounded-lg px-2 py-1.5 text-center">
 <p className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wide">Reg/hr</p>
 <p className="text-xs font-bold text-zinc-900 font-mono mt-0.5">
 S${parseFloat(s.hourlyRate || "0").toFixed(2)}
 </p>
 </div>
 <div className="bg-amber-50 border border-amber-200 rounded-lg px-2 py-1.5 text-center">
 <p className="text-[10px] text-amber-700 font-semibold uppercase tracking-wide">OT/hr</p>
 <p className="text-xs font-bold text-amber-700 font-mono mt-0.5">
 S${parseFloat(s.overtimeRate || "0").toFixed(2)}
 </p>
 </div>
 </div>
 </div>
 ) : null;
 })()}

 {/* Period quick presets */}
 <div>
 <label className="block text-xs font-semibold text-zinc-500 mb-2">Pay Period</label>
 <div className="flex gap-2 mb-2 flex-wrap">
 {[
 { label: "This Month", fn: () => { const t = new Date(); return [format(startOfMonth(t), "yyyy-MM-dd"), format(endOfMonth(t), "yyyy-MM-dd")]; } },
 { label: "Last Month", fn: () => { const pm = new Date(); pm.setMonth(pm.getMonth() - 1); return [format(startOfMonth(pm), "yyyy-MM-dd"), format(endOfMonth(pm), "yyyy-MM-dd")]; } },
 { label: "2 Months Ago", fn: () => { const pm = new Date(); pm.setMonth(pm.getMonth() - 2); return [format(startOfMonth(pm), "yyyy-MM-dd"), format(endOfMonth(pm), "yyyy-MM-dd")]; } },
 ].map(({ label, fn }) => (
 <button key={label} type="button"
 onClick={() => { const [s, e] = fn(); setGenForm(f => ({ ...f, periodStart: s, periodEnd: e })); }}
 className="inline-flex items-center h-7 px-3 rounded-md text-xs font-medium border border-zinc-200 text-zinc-600 hover:bg-zinc-50 hover:border-zinc-300 transition-colors">
 {label}
 </button>
 ))}
 </div>
 <div className="grid grid-cols-2 gap-3">
 <div>
 <label className="block text-[11px] font-semibold text-zinc-500 mb-1">From</label>
 <input type="date" value={genForm.periodStart} onChange={e => setGenForm(f => ({ ...f, periodStart: e.target.value }))}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" data-testid="input-period-start" />
 </div>
 <div>
 <label className="block text-[11px] font-semibold text-zinc-500 mb-1">To</label>
 <input type="date" value={genForm.periodEnd} onChange={e => setGenForm(f => ({ ...f, periodEnd: e.target.value }))}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" data-testid="input-period-end" />
 </div>
 </div>
 </div>
 <textarea value={genForm.notes} onChange={e => setGenForm(f => ({ ...f, notes: e.target.value }))}
 placeholder="Notes (optional)" rows={2}
 className="w-full px-3 py-2 border border-zinc-300 rounded-lg text-sm bg-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors resize-none" />
 <div className="flex gap-2">
 <button onClick={() => generateMut.mutate(undefined)} disabled={!genForm.userId || generateMut.isPending}
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-50"
 data-testid="button-confirm-generate">
 {generateMut.isPending ? <><Loader2 className="w-4 h-4 animate-spin" /> Generating...</> : "Generate"}
 </button>
 <button onClick={() => setShowGenerate(false)}
 className="inline-flex items-center h-9 px-4 rounded-lg border border-zinc-200 text-zinc-600 hover:bg-zinc-50 text-sm font-medium transition-colors">Cancel</button>
 </div>
 <p className="text-xs text-zinc-400">Payslip is auto-calculated from clock-in/out records and leave deductions for the period.</p>
 </div>
 )}

 {isLoading ? (
 <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-blue-500" /></div>
 ) : payslips.length === 0 ? (
 <div className="text-center py-16 border border-dashed border-zinc-200 rounded-none">
 <FileText className="w-10 h-10 text-zinc-300 mx-auto mb-3" />
 <p className="font-semibold text-zinc-400">No payslips yet</p>
 <p className="text-sm text-zinc-400">Generate payslips for your staff above</p>
 </div>
 ) : (
 <div className="space-y-3">
 {payslips.map((ps: any) => {
 const isOpen = expandedId === ps.id;
 const isMonthlyBased = parseFloat(ps.user?.monthlyRate || "0") > 0;
 const basicPay = parseFloat(ps.basicPay || "0");
 const mealAllowance = parseFloat(ps.mealAllowance || "0");
 const loanDeduction = parseFloat(ps.loanDeduction || "0");
 const timeDeduction = parseFloat(ps.timeDeduction || "0");
 const detailItems = isMonthlyBased
 ? [
 { label: "Basic Salary", val: `S$${basicPay.toFixed(2)}` },
 { label: "Regular Hours", val: `${parseFloat(ps.regularHours).toFixed(1)}h` },
 { label: "Regular Pay", val: `S$${parseFloat(ps.regularPay).toFixed(2)}` },
 { label: "OT Hours", val: `${parseFloat(ps.overtimeHours).toFixed(1)}h` },
 { label: "OT Pay", val: `S$${parseFloat(ps.overtimePay).toFixed(2)}` },
 ...(mealAllowance > 0 ? [{ label: "Meal Allowance", val: `S$${mealAllowance.toFixed(2)}` }] : []),
 { label: "Leave Deduction", val: `-S$${parseFloat(ps.leaveDeduction).toFixed(2)}` },
 ...(timeDeduction > 0 ? [{ label: "Working-Time Deduction", val: `-S$${timeDeduction.toFixed(2)}` }] : []),
 ...(loanDeduction > 0 ? [{ label: "Loan Repayment", val: `-S$${loanDeduction.toFixed(2)}` }] : []),
 ]
 : [
 { label: "Regular Hours", val: `${parseFloat(ps.regularHours).toFixed(1)}h` },
 { label: "OT Hours", val: `${parseFloat(ps.overtimeHours).toFixed(1)}h` },
 { label: "Regular Pay", val: `S$${parseFloat(ps.regularPay).toFixed(2)}` },
 { label: "OT Pay", val: `S$${parseFloat(ps.overtimePay).toFixed(2)}` },
 ...(mealAllowance > 0 ? [{ label: "Meal Allowance", val: `S$${mealAllowance.toFixed(2)}` }] : []),
 { label: "Leave Deduction", val: `-S$${parseFloat(ps.leaveDeduction).toFixed(2)}` },
 ...(timeDeduction > 0 ? [{ label: "Working-Time Deduction", val: `-S$${timeDeduction.toFixed(2)}` }] : []),
 ...(loanDeduction > 0 ? [{ label: "Loan Repayment", val: `-S$${loanDeduction.toFixed(2)}` }] : []),
 ];
 return (
 <div key={ps.id} className="bg-white border border-zinc-200 rounded-none overflow-hidden">
 <button onClick={() => setExpandedId(isOpen ? null : ps.id)}
 className="w-full px-4 py-3 flex items-center justify-between hover:bg-zinc-50 transition-colors"
 data-testid={`payslip-admin-${ps.id}`}>
 <div className="flex items-center gap-2.5 text-left">
 <div className="w-9 h-9 rounded-full bg-zinc-200 text-zinc-700 font-bold text-sm flex items-center justify-center shrink-0">
 {ps.user?.name?.charAt(0)}
 </div>
 <div>
 <p className="font-semibold text-zinc-900">{ps.user?.name}</p>
 <p className="text-xs font-mono text-zinc-400">@{ps.user?.username}</p>
 <p className="text-xs text-zinc-400">
 {format(parseISO(ps.periodStart), "d MMM")} – {format(parseISO(ps.periodEnd), "d MMM yyyy")}
 </p>
 </div>
 </div>
 <div className="flex items-center gap-2">
 <span
 className={`text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 rounded-full ${ps.acknowledgedAt ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`}
 data-testid={`status-signoff-${ps.id}`}>
 {ps.acknowledgedAt ? "✓ Signed" : "Pending"}
 </span>
 <div className="text-right">
 <p className="text-xl font-bold text-zinc-900">S${parseFloat(ps.grossPay).toFixed(2)}</p>
 <p className="text-xs text-zinc-500">Gross Pay</p>
 </div>
 <button
 onClick={e => { e.stopPropagation(); setPrintingPayslip(ps); }}
 className="p-2 rounded-lg hover:bg-zinc-100 text-zinc-400 hover:text-zinc-700 transition-colors"
 title="View / Print official payslip"
 data-testid={`button-print-${ps.id}`}>
 <Printer className="w-4 h-4" />
 </button>
 {isOpen ? <ChevronUp className="w-4 h-4 text-zinc-400" /> : <ChevronDown className="w-4 h-4 text-zinc-400" />}
 </div>
 </button>

 {isOpen && (
 <div className="border-t border-zinc-100 p-4 space-y-3">
 <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-sm">
 {detailItems.map(({ label, val }) => (
 <div key={label} className="bg-zinc-50 border border-zinc-200 rounded-lg p-2.5">
 <p className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wide mb-0.5">{label}</p>
 <p className="font-semibold text-zinc-900">{val}</p>
 </div>
 ))}
 <div className="bg-zinc-900 text-white rounded-lg p-2.5">
 <p className="text-[10px] font-semibold uppercase tracking-wide mb-0.5 text-zinc-400">Gross Pay</p>
 <p className="font-bold">S${parseFloat(ps.grossPay).toFixed(2)}</p>
 </div>
 </div>
 {ps.notes && (
 <div className="bg-zinc-50 rounded-lg px-3 py-2">
 <p className="text-xs text-zinc-500">{ps.notes}</p>
 </div>
 )}
 {ps.acknowledgedAt ? (
 <div className="bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2.5">
 <p className="text-[10px] font-bold uppercase tracking-wide text-emerald-700 mb-1.5">Employee Sign-Off</p>
 {ps.signature && (
 <img src={ps.signature} alt="Employee signature"
 className="h-14 bg-white rounded border border-emerald-200 px-2 object-contain object-left"
 data-testid={`img-signature-${ps.id}`} />
 )}
 <p className="text-[11px] text-emerald-600 mt-1.5">
 Signed {format(new Date(ps.acknowledgedAt), "d MMM yyyy, h:mm a")} · retained as official record
 </p>
  <p className="text-[11px] text-emerald-700 mt-1">Signed payslips cannot be deleted or changed. Keep this record and document any correction in the Notes field.</p>
 </div>
 ) : (
 <button onClick={() => { if (confirm("Delete this payslip?")) deleteMut.mutate(ps.id); }}
 className="inline-flex items-center gap-1.5 text-xs text-red-600 font-semibold hover:text-red-700 transition-colors"
 data-testid={`button-delete-payslip-${ps.id}`}>
 <Trash2 className="w-3.5 h-3.5" /> Delete Payslip
 </button>
 )}
 </div>
 )}
 </div>
 );
 })}
 </div>
 )}

 {printingPayslip && (
 <OfficialPayslip
 payslip={printingPayslip}
 loans={allLoans.filter((l: any) => l.userId === printingPayslip.userId)}
 onClose={() => setPrintingPayslip(null)}
 />
 )}

 {showReview && (
 <ReviewClockInsModal
 staff={staff}
 defaultUserId={filterUserId || undefined}
 periodStart={genForm.periodStart}
 periodEnd={genForm.periodEnd}
 onClose={() => setShowReview(false)}
 onGenerate={(uid, s, e) => generateMut.mutate({ userId: uid, periodStart: s, periodEnd: e })}
 />
 )}
 </div>
 );
}

// ─── GPS Tracking Tab ─────────────────────────────────────────────────────────

/** Ticks every second — used for live stop timers */
function useLiveClock() {
 const [now, setNow] = useState(new Date());
 useEffect(() => {
 const id = setInterval(() => setNow(new Date()), 1000);
 return () => clearInterval(id);
 }, []);
 return now;
}

/** Format a duration in seconds into "Xh Ym Zs" */
function fmtDuration(totalSeconds: number): string {
 if (totalSeconds < 0) totalSeconds = 0;
 const h = Math.floor(totalSeconds / 3600);
 const m = Math.floor((totalSeconds % 3600) / 60);
 const s = totalSeconds % 60;
 if (h > 0) return `${h}h ${m}m`;
 if (m > 0) return `${m}m ${s}s`;
 return `${s}s`;
}

function haversineM(lat1: number, lng1: number, lat2: number, lng2: number): number {
 const R = 6371000;
 const φ1 = (lat1 * Math.PI) / 180;
 const φ2 = (lat2 * Math.PI) / 180;
 const Δφ = ((lat2 - lat1) * Math.PI) / 180;
 const Δλ = ((lng2 - lng1) * Math.PI) / 180;
 const a = Math.sin(Δφ / 2) ** 2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) ** 2;
 return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function fmtDist(m: number) {
 return m >= 1000 ? `${(m / 1000).toFixed(1)} km` : `${Math.round(m)} m`;
}

type TrackPoint = { id: number; lat: string; lng: string; accuracy: string | null; speed: string | null; heading: string | null; recordedAt: string };

type StopSegment = { type: "stop"; lat: number; lng: number; startTime: Date; endTime: Date; isOngoing: boolean };
type MoveSegment = { type: "move"; distM: number; startTime: Date; endTime: Date; avgSpeedKmh: number };
type Segment = StopSegment | MoveSegment;

function buildSegments(points: TrackPoint[], isToday: boolean): Segment[] {
 if (points.length < 2) return [];
 const STOP_DIST_M = 50;
 const STOP_MIN_PTS = 2;

 const segs: Segment[] = [];
 let i = 0;

 while (i < points.length - 1) {
 const a = points[i];
 const aLat = parseFloat(a.lat), aLng = parseFloat(a.lng);

 let j = i + 1;
 while (j < points.length) {
 const d = haversineM(aLat, aLng, parseFloat(points[j].lat), parseFloat(points[j].lng));
 if (d <= STOP_DIST_M) j++;
 else break;
 }

 if (j - i >= STOP_MIN_PTS) {
 const start = new Date(a.recordedAt);
 const end = new Date(points[j - 1].recordedAt);
 segs.push({ type: "stop", lat: aLat, lng: aLng, startTime: start, endTime: end, isOngoing: false });
 i = j;
 } else {
 const b = points[i + 1];
 const distM = haversineM(aLat, aLng, parseFloat(b.lat), parseFloat(b.lng));
 const start = new Date(a.recordedAt);
 const end = new Date(b.recordedAt);
 const secs = Math.max(1, (end.getTime() - start.getTime()) / 1000);
 const speedKmh = (distM / secs) * 3.6;
 const prev = segs[segs.length - 1];
 if (prev && prev.type === "move") {
 (prev as MoveSegment).distM += distM;
 (prev as MoveSegment).endTime = end;
 (prev as MoveSegment).avgSpeedKmh = Math.max((prev as MoveSegment).avgSpeedKmh, speedKmh);
 } else {
 segs.push({ type: "move", distM, startTime: start, endTime: end, avgSpeedKmh: speedKmh });
 }
 i++;
 }
 }

 // Mark last stop as ongoing if viewing today and last point was < 5 min ago
 if (isToday && segs.length > 0) {
 const last = segs[segs.length - 1];
 const lastPoint = points[points.length - 1];
 const ageMs = Date.now() - new Date(lastPoint.recordedAt).getTime();
 if (last.type === "stop" && ageMs < 5 * 60 * 1000) {
 (last as StopSegment).isOngoing = true;
 }
 }

 return segs;
}

/** Reverse geocode a lat/lng to a short street address */
function useStopAddress(lat: number, lng: number) {
 const key = `${lat.toFixed(4)},${lng.toFixed(4)}`;
 const [addr, setAddr] = useState<string>("");
 useEffect(() => {
 if (geocodeCache[key]) { setAddr(geocodeCache[key]); return; }
 let cancelled = false;
 fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&zoom=17&addressdetails=1`, {
 headers: { "Accept-Language": "en" },
 })
 .then(r => r.json())
 .then(data => {
 if (cancelled) return;
 const a = data?.address;
 const parts = [
 a?.road || a?.pedestrian || a?.footway || a?.path,
 a?.suburb || a?.neighbourhood || a?.quarter || a?.city_district || a?.town || a?.village || a?.city,
 ].filter(Boolean);
 const result = parts.length ? parts.join(", ") : (data?.display_name?.split(",").slice(0, 2).join(", ") || key);
 geocodeCache[key] = result;
 if (!cancelled) setAddr(result);
 })
 .catch(() => { if (!cancelled) setAddr(key); });
 return () => { cancelled = true; };
 }, [key]);
 return addr;
}

/** Dwell-duration tier: helps admin instantly spot long stays. */
type StopTier = "quick" | "normal" | "long" | "extended";
function stopTier(durationSec: number): StopTier {
 const m = durationSec / 60;
 if (m < 15) return "quick";
 if (m < 45) return "normal";
 if (m < 120) return "long";
 return "extended";
}
const TIER_STYLES: Record<StopTier, { label: string; pill: string; card: string; dot: string; spine: string }> = {
 quick:    { label: "QUICK STOP",    pill: "bg-[#EBE9E2] text-[#0A0A0A] border border-black/10",     card: "bg-white border border-black/10",                  dot: "bg-[#EBE9E2] border-2 border-black/30 text-[#0A0A0A]", spine: "bg-black/15" },
 normal:   { label: "STATIONARY",    pill: "bg-amber-100 text-amber-800 border border-amber-200",   card: "bg-white border border-amber-200",                 dot: "bg-amber-100 border-2 border-amber-400 text-amber-700", spine: "bg-amber-200" },
 long:     { label: "LONG STAY",     pill: "bg-[#FBEBEB] text-[#C1121F] border border-[#C1121F]/30", card: "bg-[#FBEBEB]/60 border border-[#C1121F]/25",      dot: "bg-[#FBEBEB] border-2 border-[#C1121F] text-[#C1121F]", spine: "bg-[#C1121F]/30" },
 extended: { label: "EXTENDED STAY", pill: "bg-[#C1121F] text-white border border-[#C1121F]",       card: "bg-[#FBEBEB] border-2 border-[#C1121F]",          dot: "bg-[#C1121F] border-2 border-[#C1121F] text-white",    spine: "bg-[#C1121F]/50" },
};

/** One stop row — has its own live clock if ongoing */
function StopRow({ seg, idx, now }: { seg: StopSegment; idx: number; now: Date }) {
 const addr = useStopAddress(seg.lat, seg.lng);
 const mapsUrl = `https://www.google.com/maps?q=${seg.lat},${seg.lng}`;
 const endTime = seg.isOngoing ? now : seg.endTime;
 const durationSec = Math.floor((endTime.getTime() - seg.startTime.getTime()) / 1000);
 const tier = stopTier(durationSec);
 const t = TIER_STYLES[tier];

 return (
 <div className="flex items-stretch gap-0" data-testid={`gps-stop-${idx}`}>
 {/* Timeline spine */}
 <div className="flex flex-col items-center w-10 shrink-0">
 <div className={`w-px flex-1 ${t.spine}`} />
 <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${t.dot}`}>
 <CircleDot className="w-4 h-4" />
 </div>
 <div className={`w-px flex-1 ${t.spine}`} />
 </div>

 {/* Content */}
 <div className={`flex-1 my-1 mr-2 rounded-none px-4 py-3 ${seg.isOngoing ? "bg-[#FBEBEB] border border-[#C1121F]/30" : t.card}`}>
 <div className="flex items-start justify-between gap-2">
 <div className="flex-1 min-w-0">
 <div className="flex items-center gap-2 flex-wrap">
 <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-none ${t.pill}`}>{t.label}</span>
 {seg.isOngoing && (
 <span className="flex items-center gap-1 text-[10px] font-bold text-white bg-[#C1121F] px-2 py-0.5 rounded-none">
 <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse inline-block" />
 STAFF HERE NOW
 </span>
 )}
 </div>
 <p className="text-2xl font-extrabold text-[#0A0A0A] mt-1 leading-none tracking-tight">
 {fmtDuration(durationSec)}
 {seg.isOngoing && <span className="text-[#C1121F] text-sm font-bold ml-2 align-middle">· STILL HERE</span>}
 </p>
 <p className="text-[11px] text-[#0A0A0A]/60 mt-1 font-medium uppercase tracking-wider">
 {format(seg.startTime, "HH:mm")} – {seg.isOngoing ? "now" : format(seg.endTime, "HH:mm")}
 </p>
 </div>
 </div>
 <a href={mapsUrl} target="_blank" rel="noreferrer"
 className="inline-flex items-center gap-1.5 mt-2 text-[12px] text-[#0A0A0A] font-semibold hover:underline">
 <MapPin className="w-3.5 h-3.5 shrink-0" />
 <span className="truncate">{addr || `${seg.lat.toFixed(5)}, ${seg.lng.toFixed(5)}`}</span>
 <span className="text-[#0A0A0A]/40">↗</span>
 </a>
 </div>
 </div>
 );
}

/** Top-N longest stays of the day — surfaces "where they stayed longer" at a glance. */
function LongestStaysRail({ stops, now }: { stops: StopSegment[]; now: Date }) {
 if (stops.length === 0) return null;
 const withDur = stops.map((s, i) => {
 const end = s.isOngoing ? now : s.endTime;
 const sec = Math.max(0, Math.floor((end.getTime() - s.startTime.getTime()) / 1000));
 return { seg: s, sec, origIdx: i };
 }).sort((a, b) => b.sec - a.sec).slice(0, 3);
 const top = withDur[0]?.sec ?? 1;

 return (
 <div className="bg-white border border-black/10 rounded-none overflow-hidden">
 <div className="px-5 py-3 border-b border-black/10 flex items-center justify-between gap-3">
 <div className="flex items-center gap-2">
 <CircleDot className="w-4 h-4 text-[#C1121F]" />
 <p className="text-sm font-bold text-[#0A0A0A] uppercase tracking-wider">Longest Stays</p>
 </div>
 <p className="text-[10px] text-[#0A0A0A]/50 uppercase tracking-wider font-semibold">Where staff stayed longest</p>
 </div>
 <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-black/10">
 {withDur.map(({ seg, sec, origIdx }, rank) => (
 <LongestStayCard key={origIdx} seg={seg} sec={sec} rank={rank} maxSec={top} />
 ))}
 {/* Pad to 3 columns visually */}
 {Array.from({ length: Math.max(0, 3 - withDur.length) }).map((_, i) => (
 <div key={`pad-${i}`} className="hidden sm:block px-5 py-4" />
 ))}
 </div>
 </div>
 );
}

function LongestStayCard({ seg, sec, rank, maxSec }: { seg: StopSegment; sec: number; rank: number; maxSec: number }) {
 const addr = useStopAddress(seg.lat, seg.lng);
 const tier = stopTier(sec);
 const t = TIER_STYLES[tier];
 const pct = Math.max(8, Math.round((sec / maxSec) * 100));
 const mapsUrl = `https://www.google.com/maps?q=${seg.lat},${seg.lng}`;
 return (
 <a href={mapsUrl} target="_blank" rel="noreferrer"
 className="block px-5 py-4 hover:bg-[#F5F4F0] transition-colors group"
 data-testid={`longest-stay-${rank}`}>
 <div className="flex items-center gap-2 mb-2 min-w-0">
 <span className="inline-flex items-center justify-center w-5 h-5 rounded-none bg-[#0A0A0A] text-white text-[10px] font-bold shrink-0">{rank + 1}</span>
 <div className="flex items-center gap-1.5 ml-auto shrink-0">
 <span className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 whitespace-nowrap ${t.pill}`}>{t.label}</span>
 {seg.isOngoing && (
 <span className="inline-flex items-center gap-1 text-[9px] font-bold text-white bg-[#C1121F] px-1.5 py-0.5 whitespace-nowrap">
 <span className="w-1 h-1 rounded-full bg-white animate-pulse inline-block" />
 LIVE
 </span>
 )}
 </div>
 </div>
 <p className="text-2xl font-extrabold text-[#0A0A0A] leading-none tracking-tight">{fmtDuration(sec)}</p>
 <p className="text-[11px] text-[#0A0A0A]/60 font-medium uppercase tracking-wider mt-1">
 {format(seg.startTime, "HH:mm")} – {seg.isOngoing ? "now" : format(seg.endTime, "HH:mm")}
 </p>
 <div className="h-1 bg-black/5 mt-2">
 <div className="h-full bg-[#0A0A0A] group-hover:bg-[#C1121F] transition-colors" style={{ width: `${pct}%` }} />
 </div>
 <p className="flex items-center gap-1 mt-2 text-[11px] text-[#0A0A0A] font-semibold truncate">
 <MapPin className="w-3 h-3 shrink-0" />
 <span className="truncate">{addr || `${seg.lat.toFixed(5)}, ${seg.lng.toFixed(5)}`}</span>
 </p>
 </a>
 );
}

/** One move row */
function MoveRow({ seg, idx }: { seg: MoveSegment; idx: number }) {
 const durationSec = Math.floor((seg.endTime.getTime() - seg.startTime.getTime()) / 1000);
 const speedLabel = seg.avgSpeedKmh > 0.5 ? `${seg.avgSpeedKmh.toFixed(1)} km/h` : null;

 return (
 <div className="flex items-stretch gap-0" data-testid={`gps-move-${idx}`}>
 <div className="flex flex-col items-center w-10 shrink-0">
 <div className="w-px flex-1 bg-blue-200" />
 <div className="w-6 h-6 rounded-full bg-blue-100 border border-blue-300 flex items-center justify-center">
 <MoveRight className="w-3 h-3 text-[#0A0A0A]" />
 </div>
 <div className="w-px flex-1 bg-blue-200" />
 </div>
 <div className="flex-1 flex items-center gap-3 py-2 pr-2">
 <div>
 <p className="text-[11px] font-semibold uppercase tracking-wider text-[#0A0A0A]">Moving</p>
 <div className="flex items-center gap-2 flex-wrap mt-0.5">
 <span className="text-sm font-semibold text-zinc-700">{fmtDist(seg.distM)}</span>
 <span className="text-[11px] text-zinc-300">·</span>
 <span className="text-[11px] text-zinc-500">{fmtDuration(durationSec)}</span>
 {speedLabel && <>
 <span className="text-[11px] text-zinc-300">·</span>
 <span className="text-[11px] text-zinc-500">{speedLabel}</span>
 </>}
 </div>
 <p className="text-[10px] text-zinc-400 mt-0.5">
 {format(seg.startTime, "HH:mm:ss")} → {format(seg.endTime, "HH:mm:ss")}
 </p>
 </div>
 </div>
 </div>
 );
}

// ── Job-site / payroll check ──────────────────────────────────────────────
// Matches a staff member's GPS stops against the geocoded addresses of the
// jobs assigned to them that day. Surfaces, per the Staff Handbook GPS / payroll
// rules: which job sites were actually visited, how long staff spent on site,
// and any long stops (>15 min) AWAY from every assigned job — the "dragging
// hours" / personal-detour signal admins use to check payroll and OT claims.
const JOB_MATCH_RADIUS_M = 150; // GPS + geocode slop — treat within 150 m as "at this site"
const OFFJOB_LONG_MIN = 15;     // Handbook: a stop over 15 min should have been reported

type DayJobSite = { label: string; address: string; lat: number | null; lng: number | null };
type DayJob = {
  id: number;
  referenceNo: string;
  customer: string | null;
  status: string;
  scheduledAt: string | null;
  timeWindow: string | null;
  sites: DayJobSite[];
};

/** One flagged off-job stop row — looks up a human-readable street for the spot. */
function OffJobStopRow({ lat, lng, startTime, endTime, durSec, isOngoing, now }: {
  lat: number; lng: number; startTime: Date; endTime: Date; durSec: number; isOngoing: boolean; now: Date;
}) {
  const addr = useStopAddress(lat, lng);
  const liveSec = isOngoing ? Math.max(0, Math.floor((now.getTime() - startTime.getTime()) / 1000)) : durSec;
  const mapsUrl = `https://www.google.com/maps?q=${lat},${lng}`;
  return (
    <div className="flex items-start justify-between gap-3 px-4 py-3 border-b border-black/5 last:border-b-0">
      <div className="min-w-0">
        <p className="text-sm font-bold text-[#0A0A0A] truncate">{addr || `${lat.toFixed(4)}, ${lng.toFixed(4)}`}</p>
        <p className="text-[11px] text-[#0A0A0A]/55 font-semibold">
          {format(startTime, "HH:mm")}{isOngoing ? " — now" : `–${format(endTime, "HH:mm")}`} · not at any job
          {" · "}
          <a href={mapsUrl} target="_blank" rel="noreferrer" className="underline">map</a>
        </p>
      </div>
      <span className={`shrink-0 px-2 py-1 text-[11px] font-extrabold uppercase tracking-wider rounded-none ${isOngoing ? "bg-[#C1121F] text-white" : "bg-[#FBEBEB] text-[#C1121F] border border-[#C1121F]/30"}`}>
        {fmtDuration(liveSec)}
      </span>
    </div>
  );
}

function JobSiteCheck({ staffId, date, stops, now }: {
  staffId: number | null; date: string; stops: StopSegment[]; now: Date;
}) {
  const { data, isLoading } = useQuery<{ jobs: DayJob[] }>({
    queryKey: ["/api/admin/staff", staffId, "day-jobs", date],
    queryFn: async () => {
      if (!staffId) return { jobs: [] };
      const r = await fetch(`${API_BASE}/api/admin/staff/${staffId}/day-jobs?date=${date}`, { credentials: "include" });
      if (!r.ok) return { jobs: [] };
      return r.json();
    },
    enabled: !!staffId && validGpsDay(date),
  });

  const jobs = data?.jobs ?? [];

  // Every geocoded site across all of today's jobs, with a stable key.
  const geoSites = useMemo(() => {
    const out: { key: string; jobId: number; lat: number; lng: number }[] = [];
    jobs.forEach(j => j.sites.forEach((s, i) => {
      if (s.lat != null && s.lng != null) out.push({ key: `${j.id}:${i}`, jobId: j.id, lat: s.lat, lng: s.lng });
    }));
    return out;
  }, [jobs]);

  // Assign each GPS stop to its nearest job site (if within radius) or mark it
  // off-job. A "stop" is the unit of time the staff member spent in one place.
  const stopInfos = useMemo(() => stops.map(st => {
    let bestKey: string | null = null;
    let bestD = Infinity;
    for (const site of geoSites) {
      const d = haversineM(st.lat, st.lng, site.lat, site.lng);
      if (d < bestD) { bestD = d; bestKey = site.key; }
    }
    const onJob = bestKey != null && bestD <= JOB_MATCH_RADIUS_M;
    const end = st.isOngoing ? now : st.endTime;
    const durSec = Math.max(0, Math.floor((end.getTime() - st.startTime.getTime()) / 1000));
    return { st, siteKey: onJob ? bestKey! : null, durSec };
  }), [stops, geoSites, now]);

  // Per-site "visited" is judged independently against THAT site's coordinates
  // (any stop within radius counts), so two jobs at the same building both read
  // as visited. Off-job time below still uses nearest-assignment to avoid
  // double-counting a single stop across co-located sites.
  const siteByKey = useMemo(() => {
    const m = new Map<string, { lat: number; lng: number }>();
    geoSites.forEach(s => m.set(s.key, { lat: s.lat, lng: s.lng }));
    return m;
  }, [geoSites]);

  const perSite = (key: string) => {
    const site = siteByKey.get(key);
    if (!site) return { visited: false, arrival: null as Date | null, secs: 0 };
    const matched = stops.filter(st => haversineM(st.lat, st.lng, site.lat, site.lng) <= JOB_MATCH_RADIUS_M);
    const visited = matched.length > 0;
    const arrival = visited ? new Date(Math.min(...matched.map(st => st.startTime.getTime()))) : null;
    const secs = matched.reduce((a, st) => {
      const end = st.isOngoing ? now : st.endTime;
      return a + Math.max(0, Math.floor((end.getTime() - st.startTime.getTime()) / 1000));
    }, 0);
    return { visited, arrival, secs };
  };

  const offJob = stopInfos.filter(si => si.siteKey == null);
  const offJobLong = offJob
    .filter(si => si.durSec / 60 >= OFFJOB_LONG_MIN)
    .sort((a, b) => b.durSec - a.durSec);
  const offJobSecs = offJob.reduce((a, m) => a + m.durSec, 0);
  const onJobSecs = stopInfos.filter(si => si.siteKey != null).reduce((a, m) => a + m.durSec, 0);

  const totalSites = geoSites.length;
  const visitedSites = geoSites.filter(s => perSite(s.key).visited).length;
  const currentlyOffJob = stopInfos.some(si => si.siteKey == null && si.st.isOngoing);

  if (!staffId) return null;

  return (
    <div className="bg-white border border-black/10 rounded-none overflow-hidden">
      <div className="px-5 py-3 border-b border-black/10 flex items-center justify-between flex-wrap gap-2">
        <p className="text-sm font-bold text-[#0A0A0A] uppercase tracking-wider">Job Site Check · Payroll</p>
        <span className="text-[10px] text-[#0A0A0A]/45 font-bold uppercase tracking-wider">Within {JOB_MATCH_RADIUS_M} m = on site</span>
      </div>

      {isLoading && (
        <div className="flex items-center gap-2 px-6 py-8 text-zinc-400">
          <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
          <span className="text-sm">Loading jobs…</span>
        </div>
      )}

      {!isLoading && jobs.length === 0 && (
        <div className="px-4 py-10 text-center">
          <MapPin className="w-7 h-7 text-zinc-300 mx-auto mb-2" />
          <p className="text-sm font-semibold text-zinc-400">No jobs scheduled for this date</p>
          <p className="text-xs text-zinc-400 mt-1">Only jobs with a scheduled date appear here.</p>
        </div>
      )}

      {!isLoading && jobs.length > 0 && (
        <div className="p-4 space-y-4">
          {currentlyOffJob && (
            <div className="flex items-center gap-2 px-3 py-2 bg-[#C1121F] text-white text-[12px] font-bold uppercase tracking-wider rounded-none">
              <span className="w-2 h-2 rounded-full bg-white animate-pulse inline-block" />
              Currently away from all job sites
            </div>
          )}

          {/* Payroll summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: "Sites Visited", value: `${visitedSites}/${totalSites}`, accent: totalSites > 0 && visitedSites < totalSites },
              { label: "Time On Site", value: fmtDuration(onJobSecs), accent: false },
              { label: "Time Off-Job", value: fmtDuration(offJobSecs), accent: offJobSecs > 0 },
              { label: "Long Off-Job Stops", value: String(offJobLong.length), accent: offJobLong.length > 0 },
            ].map(({ label, value, accent }) => (
              <div key={label} className={`rounded-none p-4 ${accent ? "bg-[#C1121F] text-white" : "bg-white border border-black/10"}`}>
                <p className={`text-[10px] font-bold uppercase tracking-wider mb-1 ${accent ? "text-white/75" : "text-[#0A0A0A]/50"}`}>{label}</p>
                <p className={`text-xl font-extrabold tracking-tight ${accent ? "text-white" : "text-[#0A0A0A]"}`}>{value}</p>
              </div>
            ))}
          </div>

          {/* Per-job site visits */}
          <div className="space-y-3">
            {jobs.map(job => (
              <div key={job.id} className="border border-black/10 rounded-none">
                <div className="px-4 py-2.5 border-b border-black/10 flex items-center justify-between flex-wrap gap-1.5">
                  <p className="text-[13px] font-extrabold text-[#0A0A0A]">
                    {job.referenceNo}{job.customer ? ` · ${job.customer}` : ""}
                  </p>
                  <p className="text-[11px] text-[#0A0A0A]/55 font-semibold uppercase tracking-wider">
                    {job.timeWindow || (job.scheduledAt ? format(new Date(job.scheduledAt), "HH:mm") : "—")} · {job.status}
                  </p>
                </div>
                <div>
                  {job.sites.map((site, i) => {
                    const located = site.lat != null && site.lng != null;
                    const info = located ? perSite(`${job.id}:${i}`) : null;
                    return (
                      <div key={i} className="flex items-start justify-between gap-3 px-4 py-2.5 border-b border-black/5 last:border-b-0">
                        <div className="min-w-0">
                          <p className="text-[10px] font-bold text-[#0A0A0A]/45 uppercase tracking-wider">{site.label}</p>
                          <p className="text-sm text-[#0A0A0A] truncate">{site.address}</p>
                        </div>
                        {!located ? (
                          <span className="shrink-0 px-2 py-1 text-[11px] font-bold uppercase tracking-wider rounded-none bg-[#EBE9E2] text-[#0A0A0A]/60 border border-black/10">
                            Not located
                          </span>
                        ) : info?.visited ? (
                          <span className="shrink-0 inline-flex flex-col items-end">
                            <span className="px-2 py-1 text-[11px] font-extrabold uppercase tracking-wider rounded-none bg-emerald-600 text-white inline-flex items-center gap-1">
                              <Check className="w-3 h-3" /> Visited
                            </span>
                            <span className="text-[11px] text-[#0A0A0A]/55 font-semibold mt-1">
                              {info.arrival ? format(info.arrival, "HH:mm") : ""} · {fmtDuration(info.secs)} on site
                            </span>
                          </span>
                        ) : (
                          <span className="shrink-0 px-2 py-1 text-[11px] font-extrabold uppercase tracking-wider rounded-none bg-[#FBEBEB] text-[#C1121F] border border-[#C1121F]/30 inline-flex items-center gap-1">
                            <X className="w-3 h-3" /> Not visited
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* Long off-job stops — possible unpaid / dragging hours */}
          {offJobLong.length > 0 && (
            <div className="border border-[#C1121F]/30 rounded-none">
              <div className="px-4 py-2.5 border-b border-[#C1121F]/20 bg-[#FBEBEB]/60 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-[#C1121F]" />
                <p className="text-[12px] font-extrabold text-[#C1121F] uppercase tracking-wider">
                  Long stops away from jobs ({offJobLong.length}) — over {OFFJOB_LONG_MIN} min
                </p>
              </div>
              <div>
                {offJobLong.map((si, idx) => (
                  <OffJobStopRow
                    key={idx}
                    lat={si.st.lat}
                    lng={si.st.lng}
                    startTime={si.st.startTime}
                    endTime={si.st.endTime}
                    durSec={si.durSec}
                    isOngoing={si.st.isOngoing}
                    now={now}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function GpsTrackingTab() {
 const { data: allStaff = [] } = useQuery<any[]>({ queryKey: ["/api/staff"] });
 const [selectedStaffId, setSelectedStaffId] = useState<number | null>(null);
 const todayStr = singaporeGpsDay();
 const [selectedDate, setSelectedDate] = useState(todayStr);
 const now = useLiveClock();

 const staffId = selectedStaffId ?? (allStaff[0]?.id ?? null);
 const isToday = selectedDate === todayStr;

 const { data: rawPoints = [], isLoading, isError, error, refetch } = useQuery<TrackPoint[]>({
 queryKey: ["/api/admin/staff", staffId, "gps-track", selectedDate],
 queryFn: async () => {
 if (!staffId) return [];
 return loadGpsHistory<TrackPoint>(`${API_BASE}/api/admin/staff/${staffId}/gps-track?date=${selectedDate}`);
 },
 enabled: !!staffId && validGpsDay(selectedDate),
 retry: false,
 refetchInterval: isToday ? 12000 : 60000, // 12s when live, 60s for historical
 });

 const {data: activeLocations = {}} = useQuery<Record<string, unknown>>({
   queryKey:["/api/admin/live-locations"],
   queryFn:async()=>{
     const response=await fetch(`${API_BASE}/api/admin/live-locations`,{credentials:"include"});
     if(!response.ok)throw new Error("Active shift status unavailable");
     return response.json();
   },
   enabled:isToday,
   refetchInterval:12000,
 });
 const activeShift = isToday && !isError && !!activeLocations[String(staffId)];
 const selectedStaff = allStaff.find((s: any) => s.id === staffId);
 const segments = buildSegments(rawPoints, activeShift);

 const totalDistM = rawPoints.length < 2 ? 0 : rawPoints.reduce((sum, pt, i) => {
 if (i === 0) return sum;
 const prev = rawPoints[i - 1];
 const d = haversineM(parseFloat(prev.lat), parseFloat(prev.lng), parseFloat(pt.lat), parseFloat(pt.lng));
 return d < 500 ? sum + d : sum;
 }, 0);

 const stops = segments.filter((s): s is StopSegment => s.type === "stop");
 const totalStops = stops.length;
 const firstSeen = rawPoints.length > 0 ? new Date(rawPoints[0].recordedAt) : null;
 const lastSeen = rawPoints.length > 0 ? new Date(rawPoints[rawPoints.length - 1].recordedAt) : null;
 const isLive = activeShift && lastSeen && (now.getTime() - lastSeen.getTime()) < 5 * 60 * 1000;
 const onShiftSecs = gpsElapsedSeconds(firstSeen,lastSeen,!!isLive,now);

 // Total dwell time across all stops — answers "how long was staff stationary today"
 const totalDwellSecs = stops.reduce((sum, s) => {
 const end = s.isOngoing ? now : s.endTime;
 return sum + Math.max(0, Math.floor((end.getTime() - s.startTime.getTime()) / 1000));
 }, 0);

 return (
 <div className="pb-16 space-y-4">

 {/* Filters */}
 <div className="flex flex-wrap gap-3 items-end">
 <div>
 <label className="block text-[10px] font-bold text-[#0A0A0A]/60 uppercase tracking-wider mb-1">Staff Member</label>
 <select value={staffId ?? ""} onChange={e => setSelectedStaffId(Number(e.target.value))}
 className="h-9 px-3 border border-black/15 rounded-none text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="select-gps-staff">
 {(allStaff as any[]).map((s: any) => (
 <option key={s.id} value={s.id}>{s.name}</option>
 ))}
 </select>
 </div>
 <div>
 <label className="block text-[10px] font-bold text-[#0A0A0A]/60 uppercase tracking-wider mb-1">Date</label>
 <input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)}
 className="h-9 px-3 border border-black/15 rounded-none text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="input-gps-date" />
 </div>
 {isLive && (
 <div className="inline-flex items-center gap-1.5 h-9 px-3 rounded-none bg-[#C1121F] text-white text-[11px] font-bold uppercase tracking-wider">
 <span className="w-2 h-2 rounded-full bg-white animate-pulse inline-block" />
 Live Tracking
 </div>
 )}
 </div>

 {/* Stats bar */}
 {!validGpsDay(selectedDate) && <p role="status" className="text-sm text-amber-800">Choose a valid Singapore date to view GPS history.</p>}
 {isError && <div role="alert" className="border border-red-200 p-3 text-sm text-red-800">
   {error instanceof Error ? error.message : "GPS history unavailable."}
   <button type="button" onClick={()=>refetch()} className="ml-3 underline font-semibold" data-testid="button-retry-gps-history">Retry GPS history</button>
 </div>}
 {rawPoints.length > 0 && (
 <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
 {[
 { label: "On Shift",      value: firstSeen ? fmtDuration(onShiftSecs) : "—", accent: false },
 { label: "Total Distance", value: fmtDist(totalDistM),                       accent: false },
 { label: "Stops",          value: String(totalStops),                        accent: false },
 { label: "Time Stationary", value: fmtDuration(totalDwellSecs),              accent: totalDwellSecs > onShiftSecs * 0.5 },
 { label: "GPS Points",     value: String(rawPoints.length),                  accent: false },
 ].map(({ label, value, accent }) => (
 <div key={label} className={`rounded-none p-4 ${accent ? "bg-[#0A0A0A] text-white" : "bg-white border border-black/10"}`}>
 <p className={`text-[10px] font-bold uppercase tracking-wider mb-1 ${accent ? "text-white/70" : "text-[#0A0A0A]/50"}`}>{label}</p>
 <p className={`text-xl font-extrabold tracking-tight ${accent ? "text-white" : "text-[#0A0A0A]"}`}>{value}</p>
 </div>
 ))}
 </div>
 )}

 {/* Job-site / payroll check — did staff actually go to their assigned jobs? */}
 <JobSiteCheck staffId={staffId} date={selectedDate} stops={stops} now={now} />

 {/* Longest stays — answers "where did staff stay longer" at a glance */}
 {stops.length > 0 && <LongestStaysRail stops={stops} now={now} />}

 {/* Map */}
 {rawPoints.length > 0 && (
 <div className="bg-white border border-black/10 rounded-none overflow-hidden">
 <div className="px-5 py-3 border-b border-black/10 flex items-center justify-between flex-wrap gap-2">
 <p className="text-sm font-bold text-[#0A0A0A] uppercase tracking-wider">
 Route Map — {selectedStaff?.name ?? "—"} · {selectedDate}
 </p>
 <div className="flex flex-wrap items-center gap-3 text-[10px] text-[#0A0A0A]/60 font-bold uppercase tracking-wider">
 <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block" />Start</span>
 <span className="flex items-center gap-1"><span className="w-2.5 h-1.5 bg-slate-400 inline-block" />Stopped</span>
 <span className="flex items-center gap-1"><span className="w-2.5 h-1.5 bg-amber-400 inline-block" />Slow</span>
 <span className="flex items-center gap-1"><span className="w-2.5 h-1.5 bg-blue-500 inline-block" />Normal</span>
 <span className="flex items-center gap-1"><span className="w-2.5 h-1.5 bg-emerald-500 inline-block" />Fast</span>
 <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-[#C1121F] inline-block" />Long Stay</span>
 </div>
 </div>
 <GpsMap points={rawPoints} height={480} isLive={!!isLive} />
 </div>
 )}

 {/* Timeline */}
 <div className="bg-white border border-black/10 rounded-none overflow-hidden">
 <div className="px-5 py-3 border-b border-black/10 flex items-center justify-between">
 <p className="text-sm font-bold text-[#0A0A0A] uppercase tracking-wider">
 Activity Timeline — {selectedStaff?.name ?? "—"} · {selectedDate}
 </p>
 {isLive && lastSeen && (
 <p className="text-[10px] text-[#0A0A0A]/50 font-bold uppercase tracking-wider">
 Updated {Math.floor((now.getTime() - lastSeen.getTime()) / 1000)}s ago
 </p>
 )}
 </div>

 {isLoading && (
 <div className="flex items-center gap-2 px-6 py-10 text-zinc-400">
 <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
 <span className="text-sm">Loading…</span>
 </div>
 )}

 {!isLoading && !isError && validGpsDay(selectedDate) && rawPoints.length === 0 && (
 <div className="px-4 py-12 text-center">
 <Navigation2 className="w-8 h-8 text-zinc-300 mx-auto mb-3" />
 <p className="text-sm font-semibold text-zinc-400">No GPS data for this date</p>
 <p className="text-xs text-zinc-400 mt-1">Data records every 30 s when staff are clocked in.</p>
 </div>
 )}

 {!isLoading && segments.length > 0 && (
 <div className="px-2 py-3">

 {/* Session start */}
 <div className="flex items-stretch gap-0">
 <div className="flex flex-col items-center w-10 shrink-0">
 <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center">
 <div className="w-3 h-3 rounded-full bg-white" />
 </div>
 <div className="w-px flex-1 bg-emerald-300" />
 </div>
 <div className="flex-1 flex items-center pb-1">
 <div>
 <p className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider">Shift started</p>
 <p className="text-base font-bold text-zinc-900">{firstSeen ? format(firstSeen, "HH:mm:ss") : "—"}</p>
 </div>
 </div>
 </div>

 {/* Segments */}
 {segments.map((seg, idx) =>
 seg.type === "stop"
 ? <StopRow key={idx} seg={seg} idx={idx} now={now} />
 : <MoveRow key={idx} seg={seg} idx={idx} />
 )}

 {/* Last seen / end */}
 <div className="flex items-stretch gap-0">
 <div className="flex flex-col items-center w-10 shrink-0">
 <div className={`w-px flex-1 ${isLive ? "bg-red-300" : "bg-slate-300"}`} />
 <div className={`w-8 h-8 rounded-full flex items-center justify-center ${isLive ? "bg-red-500" : "bg-slate-400"}`}>
 <div className="w-3 h-3 rounded-full bg-white" />
 </div>
 </div>
 <div className="flex-1 flex items-center pt-1">
 <div>
 <p className={`text-[11px] font-semibold uppercase tracking-wider ${isLive ? "text-red-600" : "text-zinc-400"}`}>
 {isLive ? "Currently here" : "Last seen"}
 </p>
 <p className="text-base font-bold text-zinc-900">
 {lastSeen ? format(lastSeen, "HH:mm:ss") : "—"}
 </p>
 {isLive && lastSeen && (
 <p className="text-[11px] text-red-500 font-bold">
 {fmtDuration(Math.floor((now.getTime() - lastSeen.getTime()) / 1000))} ago
 </p>
 )}
 </div>
 </div>
 </div>
 </div>
 )}
 </div>
 </div>
 );
}
