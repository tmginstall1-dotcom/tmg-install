import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { quoteSourceLabel } from "@shared/growth-reporting";
import { GoogleOutcomeReview } from "@/components/GoogleOutcomeReview";
import type { measurementReport } from "../../../../server/enquiry-measurement";

type Report = Awaited<ReturnType<typeof measurementReport>>;
export function EnquiryMeasurement({ days }: { days: number }) {
  const report = useQuery<Report>({
    queryKey: ["/api/ai/attribution/measurement", days],
    queryFn: async () => { const res = await apiRequest("GET", `/api/ai/attribution/measurement?days=${days}`); return res.json(); },
  });
  const [selected, setSelected] = useState<Report["enquiries"][number] | null>(null);
  const [family, setFamily] = useState("office");
  const [reason, setReason] = useState("");
  const [reviewed, setReviewed] = useState(false);
  const [pending, setPending] = useState(false);
  const [message, setMessage] = useState("");
  const reviewRef = useRef<HTMLDivElement>(null);
  const reasonRef = useRef<HTMLTextAreaElement>(null);
  useEffect(() => {
    if (selected) { reviewRef.current?.scrollIntoView({ block: "start" }); reasonRef.current?.focus({ preventScroll: true }); }
  }, [selected?.id]);
  async function refreshReview() {
    const refreshed = await report.refetch();
    const current = refreshed.data?.enquiries.find(row => row.id === selected?.id);
    if (current) { setSelected(current); setReviewed(false); setMessage("Context refreshed. Your reason is retained; review the current quote again before confirming."); }
  }
  async function qualify() {
    if (!selected || pending || !reviewed) return;
    setPending(true); setMessage("");
    try {
      await apiRequest("POST", `/api/ai/attribution/qualify/${selected.id}`, { family, reason, expectedVersion: selected.version });
      setSelected(null); setReason(""); setReviewed(false);
      setMessage("Staff qualification saved. No customer message, booking or ad upload was made.");
      await report.refetch();
    } catch (error) { setMessage(error instanceof Error ? error.message : "Not saved. Your review reason is retained; retry when ready."); }
    finally { setPending(false); }
  }
  if (report.isPending) return <p role="status">Loading internal enquiry measurement…</p>;
  if (report.isError || !report.data) return <div role="alert">Measurement unavailable. <button className="underline" onClick={() => report.refetch()}>Retry</button></div>;
  const data = report.data;
  return <section className="space-y-5" aria-label="Enquiry measurement">
    <div className="bg-white border border-zinc-200 p-5">
      <h2 className="font-semibold">Enquiries to customers · internal measurement</h2>
      <p className="text-sm text-zinc-600 mt-2">{data.note}</p>
      <p className="text-xs text-zinc-500 mt-2">Period totals, not a same-session conversion funnel. Contact clicks are events, not unique people. Lifecycle capture starts with this release; no historical replay.</p>
    </div>
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
      <div className="bg-white border p-4"><p className="text-xs">Contact-link clicks</p><p className="text-2xl font-bold">{data.contactClicks}</p><p className="text-xs text-zinc-500">Not submitted enquiries</p></div>
      {(["submitted", "qualified", "confirmed", "payments"] as const).map((key, index) => <div className="bg-white border p-4" key={key}>
        <p className="text-xs">{["Submitted enquiries", "Staff-qualified enquiries", "Staff-confirmed jobs", "Verified receipts"][index]}</p>
        <p className="text-2xl font-bold">{data[key].count}</p><p className="text-xs text-zinc-500">{data[key].unattributed} unattributed</p>
      </div>)}
    </div>
    <div className="bg-white border p-4 text-sm"><strong>Verified gross receipts: S${data.verifiedGrossReceived.toFixed(2)}</strong>
      <p className="text-xs text-zinc-600 mt-1">{data.paymentPhases.map(p => `${p.phase}: ${p.count}`).join(" · ")}. Separate receipt amounts—not estimated quotes, net revenue or profit.</p>
    </div>
    {message && <p role="status" className="border bg-white p-3 text-sm">{message}</p>}
    {selected && <div ref={reviewRef} className="bg-white border border-zinc-300 p-5 space-y-3 scroll-mt-20">
      <h3 className="font-semibold">Review {selected.referenceNo}</h3>
      <p className="text-sm">{data.definition}</p>
      <label className="block text-sm">Furniture family<select className="block border w-full p-2 mt-1" value={family} onChange={e => setFamily(e.target.value)} disabled={pending}>
        <option value="office">Office furniture</option><option value="taobao">Taobao furniture</option><option value="system">System furniture</option><option value="other_installation">Other installation / dismantling</option>
      </select></label>
      <label className="block text-sm">Staff review reason<textarea ref={reasonRef} className="block border w-full p-2 mt-1" value={reason} onChange={e => setReason(e.target.value)} maxLength={1000} disabled={pending} /></label>
      <label className="flex gap-2 text-sm"><input type="checkbox" checked={reviewed} onChange={e => setReviewed(e.target.checked)} disabled={pending} />I reviewed the request, quantities, contact and suitability.</label>
      <div className="flex flex-wrap gap-3"><button className="bg-black text-white px-4 py-2 disabled:opacity-50" disabled={pending || !reviewed} onClick={qualify}>{pending ? "Saving…" : "Save staff qualification"}</button>
        <button className="border px-4 py-2" disabled={pending} onClick={refreshReview}>Refresh quote context</button>
        <button className="border px-4 py-2" disabled={pending} onClick={() => { setSelected(null); setReason(""); setReviewed(false); }}>Cancel</button></div>
    </div>}
    <div className="bg-white border p-4">
      <h3 className="font-semibold mb-3">Recent enquiries · up to 100</h3>
      <ul className="divide-y">{data.enquiries.map(row => <li key={row.id} className="py-3 flex flex-wrap items-center gap-3 justify-between">
        <div className="text-sm"><a href={`/admin/quotes/${row.id}`} className="font-semibold underline">{row.referenceNo}</a>
          <p className="text-xs text-zinc-600">{quoteSourceLabel(row.channel)} · {row.status} · {row.attributionStatus === "captured" ? `Captured campaign: ${row.campaign || row.source}` : `Unattributed (${row.attributionStatus})`}</p>
          {row.capturedAt && <p className="text-xs text-zinc-500">Visit captured {new Date(row.capturedAt).toLocaleString("en-SG", { timeZone: "Asia/Singapore" })} · age at enquiry {row.ageAtEnquiryMs == null ? "unknown" : `${Math.round(row.ageAtEnquiryMs / 60000)} min`}</p>}
        </div>
        {row.qualified ? <span className="text-xs">Staff qualified</span> : <button className="text-sm border px-3 py-2" disabled={pending || !!selected} onClick={() => { setSelected(row); setReviewed(false); setReason(""); setMessage(""); }}>Review qualification</button>}
      </li>)}</ul>
      {!data.enquiries.length && <p className="text-sm text-zinc-500">No enquiries in this period.</p>}
    </div>
    <GoogleOutcomeReview />
  </section>;
}
