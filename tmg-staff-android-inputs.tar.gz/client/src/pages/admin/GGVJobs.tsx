import { useState, useRef, useCallback, useEffect, Fragment } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
 Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
 Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
 Plus, Pencil, Trash2, ChevronLeft, ChevronRight,
 TruckIcon, Flag, AlertCircle, Upload, Loader2, CheckCheck,
 FileImage, Eye, ArrowUpRight, UserPlus,
} from "lucide-react";
import { Link } from "wouter";

type GGVJob = {
 id: number;
 date: string;
 vehicleGroup: string;
 vehicleType: string;
 jobNo: string | null;
 bookingRef: string | null;
 timeStart: string | null;
 timeEnd: string | null;
 listedPrice: string | null;
 deduction: string | null;
 actualPrice: string | null;
 serviceType: string | null;
 remarks: string | null;
 address: string | null;
 postalCode: string | null;
 distanceKm: string | null;
 ratePerKm: string | null;
 flagged: boolean;
 cancelled: boolean;
 returnFee: string | null;
 quoteId: number | null;
 assignedStaffId: number | null;
 assignedTeamId: number | null;
 assigneeName: string | null;
};

type Team = { id: number; name: string };
type Staff = { id: number; name: string };

type ScannedJob = {
 jobNo: string | null;
 bookingRef: string | null;
 timeStart: string | null;
 timeEnd: string | null;
 listedPrice: number | null;
 deduction: number | null;
 actualPrice: number | null;
 serviceType: string | null;
 remarks: string | null;
 address: string | null;
 postalCode: string | null;
 distanceKm: number | null;
 ratePerKm: number | null;
 flagged: boolean;
};

type ScanResult = {
 date: string | null;
 vehicleGroup: string;
 vehicleType: string;
 jobs: ScannedJob[];
};

const SERVICE_TYPES = [
 "D+A", "R+A+DISS", "ASD+ASA", "D+A+DISS", "A+DISS", "D only", "A only", "Other",
];

const EMPTY_FORM = {
 jobNo: "",
 bookingRef: "",
 timeStart: "",
 timeEnd: "",
 listedPrice: "",
 deduction: "",
 actualPrice: "",
 serviceType: "",
 remarks: "",
 address: "",
 postalCode: "",
 distanceKm: "",
 ratePerKm: "",
 flagged: false,
 cancelled: false,
 returnFee: "18.50",
};

function todaySGT() {
 const nowSGT = new Date(Date.now() + 8 * 60 * 60 * 1000);
 return nowSGT.toISOString().slice(0, 10);
}

const DELIVERY_FEE = 23.80;

function isDeliveryJob(jobNo: string | null | undefined): boolean {
 return !!(jobNo && jobNo.trim().toUpperCase().startsWith("S"));
}

function effectiveActual(job: GGVJob): number {
 // Cancelled on-site (rejected entry / no parking): the job price does NOT
 // count — the only money earned is the return-to-warehouse fee.
 if (job.cancelled) {
 const fee = parseFloat(job.returnFee ?? "");
 return isNaN(fee) ? 0 : fee;
 }
 const base = parseFloat(job.actualPrice ?? "");
 return (isNaN(base) ? 0 : base) + (isDeliveryJob(job.jobNo) ? DELIVERY_FEE : 0);
}

function effectiveScannedActual(job: ScannedJob): number {
 const base = job.actualPrice ?? 0;
 return base + (isDeliveryJob(job.jobNo) ? DELIVERY_FEE : 0);
}

function fmt(val: string | number | null | undefined, prefix = "$") {
 const n = typeof val === "number" ? val : parseFloat(val ?? "");
 if (isNaN(n)) return "—";
 return `${prefix}${n.toFixed(2)}`;
}

function sum(jobs: GGVJob[], key: keyof GGVJob) {
 return jobs.reduce((s, j) => {
 const v = parseFloat((j[key] as string) ?? "");
 return s + (isNaN(v) ? 0 : v);
 }, 0);
}

function shiftDate(date: string, days: number) {
 const d = new Date(date + "T00:00:00Z");
 d.setUTCDate(d.getUTCDate() + days);
 return d.toISOString().slice(0, 10);
}

function formatDisplay(date: string) {
 const d = new Date(date + "T00:00:00Z");
 return d.toLocaleDateString("en-SG", { weekday: "short", day: "numeric", month: "short", year: "numeric", timeZone: "UTC" });
}

export default function GGVJobs() {
 const { toast } = useToast();
 const [selectedDate, setSelectedDate] = useState(todaySGT);
 const [dialogOpen, setDialogOpen] = useState(false);
 const [editingJob, setEditingJob] = useState<GGVJob | null>(null);
 const [form, setForm] = useState({ ...EMPTY_FORM });
 const [vehicleGroup, setVehicleGroup] = useState("TMG1 GGV 029");
 const [vehicleType, setVehicleType] = useState("EV VAN");
 const [deleteId, setDeleteId] = useState<number | null>(null);
 const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
 const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false);
 const [bulkAssignOpen, setBulkAssignOpen] = useState(false);
 const [bulkAssignee, setBulkAssignee] = useState("");

 // Scan state
 const fileInputRef = useRef<HTMLInputElement>(null);
 const [scanning, setScanning] = useState(false);
 const [scanResult, setScanResult] = useState<ScanResult | null>(null);
 const [previewOpen, setPreviewOpen] = useState(false);
 const [selectedRows, setSelectedRows] = useState<boolean[]>([]);
 const [previewDate, setPreviewDate] = useState("");
 const [importing, setImporting] = useState(false);
 const [previewImage, setPreviewImage] = useState<string | null>(null);

 const queryKey = ["/api/admin/ggv-jobs", selectedDate];

 const { data: jobs = [], isLoading } = useQuery<GGVJob[]>({
 queryKey,
 queryFn: async () => {
 const res = await fetch(`/api/admin/ggv-jobs?date=${selectedDate}`, { credentials: "include" });
 return res.json();
 },
 });

 const createMut = useMutation({
 mutationFn: (data: any) => apiRequest("POST", "/api/admin/ggv-jobs", data),
 onSuccess: () => { queryClient.invalidateQueries({ queryKey }); setDialogOpen(false); toast({ title: "Job added" }); },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 const updateMut = useMutation({
 mutationFn: ({ id, data }: { id: number; data: any }) => apiRequest("PATCH", `/api/admin/ggv-jobs/${id}`, data),
 onSuccess: () => { queryClient.invalidateQueries({ queryKey }); setDialogOpen(false); toast({ title: "Job updated" }); },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 const deleteMut = useMutation({
 mutationFn: (id: number) => apiRequest("DELETE", `/api/admin/ggv-jobs/${id}`),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey });
 setSelectedIds(prev => { if (deleteId == null) return prev; const next = new Set(prev); next.delete(deleteId); return next; });
 setDeleteId(null);
 toast({ title: "Job deleted" });
 },
 onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
 });

 const bulkDeleteMut = useMutation({
 mutationFn: (ids: number[]) => apiRequest("POST", "/api/admin/ggv-jobs/bulk-delete", { ids }),
 onSuccess: async (res: any) => {
 const data = await (res?.json ? res.json() : Promise.resolve(res));
 const n = data?.deleted ?? selectedIds.size;
 queryClient.invalidateQueries({ queryKey });
 setSelectedIds(new Set());
 setBulkDeleteOpen(false);
 toast({ title: `${n} job${n !== 1 ? "s" : ""} deleted` });
 },
 onError: (e: any) => toast({ title: "Bulk delete failed", description: e.message, variant: "destructive" }),
 });

 // Teams & staff for the assignment dropdowns (admin-gated, same as elsewhere).
 const { data: teamsList = [] } = useQuery<Team[]>({ queryKey: ["/api/teams"] });
 const { data: staffList = [] } = useQuery<Staff[]>({ queryKey: ["/api/staff"] });

 const assignMut = useMutation({
 mutationFn: (payload: { ids: number[]; assignedStaffId?: number | null; assignedTeamId?: number | null }) =>
 apiRequest("POST", "/api/admin/ggv-jobs/assign", payload),
 onSuccess: async (res: any, vars) => {
 const data = await (res?.json ? res.json() : Promise.resolve(res));
 const n = data?.count ?? vars.ids.length;
 queryClient.invalidateQueries({ queryKey });
 toast({ title: n === 1 ? "Job assigned" : `${n} jobs assigned` });
 },
 onError: (e: any) => toast({ title: "Assign failed", description: e.message, variant: "destructive" }),
 });

 // Translate a job's current assignment into the <select> value, and back.
 function assigneeValue(job: GGVJob) {
 if (job.assignedTeamId) return `team:${job.assignedTeamId}`;
 if (job.assignedStaffId) return `staff:${job.assignedStaffId}`;
 return "";
 }
 function parseAssignee(value: string): { assignedStaffId?: number | null; assignedTeamId?: number | null } {
 if (!value) return { assignedStaffId: null };
 const [type, rawId] = value.split(":");
 const numId = parseInt(rawId, 10);
 return type === "team" ? { assignedTeamId: numId } : { assignedStaffId: numId };
 }
 function handleInlineAssign(job: GGVJob, value: string) {
 if (value === assigneeValue(job)) return;
 assignMut.mutate({ ids: [job.id], ...parseAssignee(value) });
 }
 async function handleBulkAssign() {
 const ids = Array.from(selectedIds);
 if (!ids.length) return;
 try {
 await assignMut.mutateAsync({ ids, ...parseAssignee(bulkAssignee) });
 setSelectedIds(new Set());
 setBulkAssignOpen(false);
 setBulkAssignee("");
 } catch { /* error toast handled by mutation */ }
 }

 // Reset selection whenever the visible job set changes (date change, refresh, etc.)
 // Drop any selected IDs that no longer exist in the current page.
 useEffect(() => {
 setSelectedIds(prev => {
 if (prev.size === 0) return prev;
 const visible = new Set(jobs.map(j => j.id));
 const next = new Set<number>();
 prev.forEach(id => { if (visible.has(id)) next.add(id); });
 return next.size === prev.size ? prev : next;
 });
 }, [jobs]);

 function toggleSelect(id: number) {
 setSelectedIds(prev => {
 const next = new Set(prev);
 if (next.has(id)) next.delete(id); else next.add(id);
 return next;
 });
 }

 function toggleSelectAll() {
 setSelectedIds(prev => {
 if (jobs.length === 0) return prev;
 const allSelected = prev.size === jobs.length && jobs.every(j => prev.has(j.id));
 return allSelected ? new Set() : new Set(jobs.map(j => j.id));
 });
 }

 const allOnPageSelected = jobs.length > 0 && selectedIds.size >= jobs.length && jobs.every(j => selectedIds.has(j.id));
 const someOnPageSelected = selectedIds.size > 0 && !allOnPageSelected;

 // ── Upload & AI Scan (multi-file) ──────────────────────────────────────────

 const [scanProgress, setScanProgress] = useState({ current: 0, total: 0 });

 const handleFileChange = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
 const files = Array.from(e.target.files ?? []);
 if (!files.length) return;

 setScanning(true);
 setScanProgress({ current: 0, total: files.length });

 const mergedJobs: (ScannedJob & { _source?: string })[] = [];
 let detectedDate: string | null = null;
 let detectedGroup = "";
 let detectedType = "";
 const previews: string[] = [];

 for (let i = 0; i < files.length; i++) {
 const file = files[i];
 setScanProgress({ current: i + 1, total: files.length });

 // Collect image preview data URL
 await new Promise<void>((resolve) => {
 const reader = new FileReader();
 reader.onload = (ev) => { previews.push(ev.target?.result as string); resolve(); };
 reader.readAsDataURL(file);
 });

 try {
 const fd = new FormData();
 fd.append("image", file);
 const res = await fetch("/api/admin/ggv-jobs/scan", {
 method: "POST",
 credentials: "include",
 body: fd,
 });
 if (!res.ok) {
 const err = await res.json();
 throw new Error(err.message || "Scan failed");
 }
 const data: ScanResult = await res.json();
 if (data.jobs?.length) {
 // Tag each row with its source filename for display
 data.jobs.forEach(j => mergedJobs.push({ ...j, _source: file.name }));
 if (!detectedDate && data.date) detectedDate = data.date;
 if (!detectedGroup && data.vehicleGroup) detectedGroup = data.vehicleGroup;
 if (!detectedType && data.vehicleType) detectedType = data.vehicleType;
 }
 } catch (err: any) {
 toast({ title: `File ${i + 1} scan failed`, description: `${file.name}: ${err.message}`, variant: "destructive" });
 }
 }

 setScanning(false);
 setScanProgress({ current: 0, total: 0 });
 if (fileInputRef.current) fileInputRef.current.value = "";

 if (!mergedJobs.length) {
 toast({ title: "No jobs found", description: "AI couldn't extract any job rows from the uploaded image(s).", variant: "destructive" });
 return;
 }

 setScanResult({ date: detectedDate, vehicleGroup: detectedGroup, vehicleType: detectedType, jobs: mergedJobs });
 setSelectedRows(mergedJobs.map(() => true));
 setPreviewDate(detectedDate || selectedDate);
 if (detectedGroup) setVehicleGroup(detectedGroup);
 if (detectedType) setVehicleType(detectedType);
 setPreviewImage(previews[0] ?? null); // show first image as thumbnail
 setPreviewOpen(true);
 }, [selectedDate, toast]);

 async function handleImport() {
 if (!scanResult) return;
 setImporting(true);
 const toImport = scanResult.jobs.filter((_, i) => selectedRows[i]);
 let saved = 0;
 for (const job of toImport) {
 try {
 await apiRequest("POST", "/api/admin/ggv-jobs", {
 date: previewDate || selectedDate,
 vehicleGroup: scanResult.vehicleGroup || vehicleGroup,
 vehicleType: scanResult.vehicleType || vehicleType,
 jobNo: job.jobNo || null,
 bookingRef: job.bookingRef || null,
 timeStart: job.timeStart || null,
 timeEnd: job.timeEnd || null,
 listedPrice: job.listedPrice != null ? String(job.listedPrice) : null,
 deduction: job.deduction != null ? String(job.deduction) : "0",
 actualPrice: job.actualPrice != null ? String(job.actualPrice) : null,
 serviceType: job.serviceType || null,
 remarks: job.remarks || null,
 address: job.address || null,
 postalCode: job.postalCode || null,
 distanceKm: job.distanceKm != null ? String(job.distanceKm) : null,
 ratePerKm: job.ratePerKm != null ? String(job.ratePerKm) : null,
 flagged: job.flagged ?? false,
 });
 saved++;
 } catch {}
 }
 setImporting(false);
 setPreviewOpen(false);
 setScanResult(null);
 setPreviewImage(null);
 // If the date extracted matches selectedDate, the query will refresh
 if (previewDate) setSelectedDate(previewDate);
 queryClient.invalidateQueries({ queryKey: ["/api/admin/ggv-jobs"] });
 toast({ title: `${saved} job${saved !== 1 ? "s" : ""} imported successfully` });
 }

 // ── Manual add/edit ─────────────────────────────────────────────────────────

 function openAdd() {
 setEditingJob(null);
 setForm({ ...EMPTY_FORM });
 setDialogOpen(true);
 }

 function openEdit(job: GGVJob) {
 setEditingJob(job);
 setVehicleGroup(job.vehicleGroup);
 setVehicleType(job.vehicleType);
 setForm({
 jobNo: job.jobNo ?? "",
 bookingRef: job.bookingRef ?? "",
 timeStart: job.timeStart ?? "",
 timeEnd: job.timeEnd ?? "",
 listedPrice: job.listedPrice ?? "",
 deduction: job.deduction ?? "",
 actualPrice: job.actualPrice ?? "",
 serviceType: job.serviceType ?? "",
 remarks: job.remarks ?? "",
 address: job.address ?? "",
 postalCode: job.postalCode ?? "",
 distanceKm: job.distanceKm ?? "",
 ratePerKm: job.ratePerKm ?? "",
 flagged: job.flagged,
 cancelled: job.cancelled ?? false,
 returnFee: job.returnFee ?? "18.50",
 });
 setDialogOpen(true);
 }

 function handleSave() {
 const payload = {
 date: selectedDate, vehicleGroup, vehicleType,
 jobNo: form.jobNo || null, bookingRef: form.bookingRef || null,
 timeStart: form.timeStart || null, timeEnd: form.timeEnd || null,
 listedPrice: form.listedPrice || null, deduction: form.deduction || "0",
 actualPrice: form.actualPrice || null, serviceType: form.serviceType || null,
 remarks: form.remarks || null, address: form.address || null,
 postalCode: form.postalCode || null, distanceKm: form.distanceKm || null,
 ratePerKm: form.ratePerKm || null, flagged: form.flagged,
 cancelled: form.cancelled, returnFee: form.cancelled ? (form.returnFee || "18.50") : form.returnFee || null,
 };
 if (editingJob) updateMut.mutate({ id: editingJob.id, data: payload });
 else createMut.mutate(payload);
 }

 // Cancelled jobs don't count towards Listed / Deductions — only their return
 // fee flows into Actual (via effectiveActual).
 const activeJobs = jobs.filter(j => !j.cancelled);
 const totalListed = sum(activeJobs, "listedPrice");
 const totalDeduction = sum(activeJobs, "deduction");
 const totalActual = jobs.reduce((s, j) => s + effectiveActual(j), 0);
 const isPending = createMut.isPending || updateMut.isPending;
 const selectedCount = selectedRows.filter(Boolean).length;

 return (
 <div className="lg:pl-56 pt-14 min-h-screen bg-[#F5F4F0]">
 <div className="p-4 lg:p-6 pb-28 md:pb-6 max-w-[1600px] mx-auto">

 {/* Header */}
 <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
 <div className="flex items-center gap-3">
 <div className="w-9 h-9 rounded-none bg-[#EBE9E2] flex items-center justify-center">
 <TruckIcon className="w-5 h-5 text-[#0A0A0A]" />
 </div>
 <div>
 <h1 className="text-lg font-black text-[#0A0A0A] tracking-tight">GGV Job Tracker</h1>
 <p className="text-[11px] text-black/55">Daily delivery & installation job log</p>
 </div>
 </div>
 <div className="flex items-center gap-2 flex-wrap">
 {/* Bulk assign & delete — only visible when rows are selected */}
 {selectedIds.size > 0 && (
 <Button
 onClick={() => { setBulkAssignee(""); setBulkAssignOpen(true); }}
 variant="outline"
 data-testid="btn-bulk-assign"
 className="border-black/15 text-[#0A0A0A] hover:bg-black/5 font-bold text-xs gap-1.5"
 >
 <UserPlus className="w-3.5 h-3.5" /> Assign {selectedIds.size}
 </Button>
 )}
 {selectedIds.size > 0 && (
 <Button
 onClick={() => setBulkDeleteOpen(true)}
 variant="outline"
 data-testid="btn-bulk-delete"
 className="border-[#C1121F]/40 text-[#C1121F] hover:bg-[#FBEBEB] hover:text-[#C1121F] font-bold text-xs gap-1.5"
 >
 <Trash2 className="w-3.5 h-3.5" /> Delete {selectedIds.size}
 </Button>
 )}
 {/* Upload & Scan — multiple files */}
 <input
 ref={fileInputRef}
 type="file"
 accept="image/*,.png,.jpg,.jpeg,.webp"
 multiple
 className="hidden"
 onChange={handleFileChange}
 data-testid="input-scan-file"
 />
 <Button
 onClick={() => fileInputRef.current?.click()}
 disabled={scanning}
 data-testid="btn-scan-upload"
 variant="outline"
 className="border-[#0A0A0A]/40 text-[#0A0A0A] hover:bg-[#EBE9E2] hover:text-[#0A0A0A]/65 font-bold text-xs gap-1.5"
 >
 {scanning ? (
 <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Scanning…</>
 ) : (
 <><Upload className="w-3.5 h-3.5" /> Upload & Scan</>
 )}
 </Button>
 <Button
 onClick={openAdd}
 data-testid="btn-add-ggv-job"
 className="bg-[#EBE9E2]0 hover:bg-[#0A0A0A] text-black font-bold text-xs gap-1.5"
 >
 <Plus className="w-3.5 h-3.5" /> Add Job
 </Button>
 </div>
 </div>

 {/* Scanning progress banner */}
 {scanning && (
 <div className="mb-4 flex items-center gap-3 bg-[#EBE9E2] border border-[#0A0A0A]/25 rounded-none px-4 py-3">
 <Loader2 className="w-4 h-4 text-[#0A0A0A] animate-spin shrink-0" />
 <div className="flex-1">
 <p className="text-sm text-[#0A0A0A]/65 font-medium">
 {scanProgress.total > 1
 ? `Scanning image ${scanProgress.current} of ${scanProgress.total}…`
 : "AI is reading your spreadsheet…"}
 </p>
 {scanProgress.total > 1 && (
 <div className="mt-1.5 h-1.5 bg-[#0A0A0A]/20 rounded-full overflow-hidden">
 <div
 className="h-full bg-[#0A0A0A] rounded-full transition-all duration-500"
 style={{ width: `${(scanProgress.current / scanProgress.total) * 100}%` }}
 />
 </div>
 )}
 </div>
 <span className="text-xs text-[#0A0A0A] font-mono">5–15s / image</span>
 </div>
 )}

 {/* Date nav + vehicle header */}
 <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-4">
 <div className="flex items-center gap-2 bg-white border border-black/10 rounded-lg px-2 py-1.5">
 <button onClick={() => setSelectedDate(d => shiftDate(d, -1))} data-testid="btn-prev-day" className="p-1 text-black/55 hover:text-[#0A0A0A] rounded transition-colors">
 <ChevronLeft className="w-4 h-4" />
 </button>
 <input
 type="date"
 value={selectedDate}
 onChange={e => setSelectedDate(e.target.value)}
 data-testid="input-date"
 className="bg-transparent text-sm font-semibold text-[#0A0A0A] outline-none w-36"
 />
 <button onClick={() => setSelectedDate(d => shiftDate(d, 1))} data-testid="btn-next-day" className="p-1 text-black/55 hover:text-[#0A0A0A] rounded transition-colors">
 <ChevronRight className="w-4 h-4" />
 </button>
 </div>
 <span className="text-black/55 text-sm hidden sm:block">{formatDisplay(selectedDate)}</span>
 <div className="flex items-center gap-2 ml-auto">
 <div className="flex items-center gap-1.5 bg-white border border-black/10 rounded-lg px-3 py-1.5">
 <span className="text-[10px] text-black/55 uppercase font-bold tracking-wide">Group</span>
 <input value={vehicleGroup} onChange={e => setVehicleGroup(e.target.value)} className="bg-transparent text-sm font-semibold text-[#0A0A0A] outline-none w-28" />
 </div>
 <div className="flex items-center gap-1.5 bg-white border border-black/10 rounded-lg px-3 py-1.5">
 <span className="text-[10px] text-black/55 uppercase font-bold tracking-wide">Van</span>
 <input value={vehicleType} onChange={e => setVehicleType(e.target.value)} className="bg-transparent text-sm font-semibold text-black/65 outline-none w-20" />
 </div>
 </div>
 </div>

 {/* ── Mobile card view (< md) ──────────────────────────────────────────── */}
 <div className="md:hidden space-y-2">
 {isLoading && (
 <div className="text-center py-10 text-black/55 text-sm">Loading…</div>
 )}
 {!isLoading && jobs.length === 0 && (
 <div className="rounded-none border border-black/10 bg-white p-8 flex flex-col items-center gap-3 text-black/75">
 <FileImage className="w-9 h-9" />
 <div className="text-center">
 <p className="text-sm font-semibold text-black/55">No jobs for this day</p>
 <p className="text-xs mt-1">Upload a spreadsheet screenshot or tap Add Job</p>
 </div>
 <button
 onClick={() => fileInputRef.current?.click()}
 className="flex items-center gap-1.5 text-xs text-[#0A0A0A] font-semibold border border-[#0A0A0A]/30 px-3 py-1.5 rounded-lg"
 >
 <Upload className="w-3 h-3" /> Upload & Scan
 </button>
 </div>
 )}
 {jobs.length > 0 && (
 <div className="flex items-center gap-2 px-1 pb-1">
 <Checkbox
 checked={allOnPageSelected ? true : someOnPageSelected ? "indeterminate" : false}
 onCheckedChange={toggleSelectAll}
 data-testid="checkbox-select-all-mobile"
 className="border-black/12"
 />
 <span className="text-[11px] text-black/55 font-semibold uppercase tracking-wider">
 {selectedIds.size > 0 ? `${selectedIds.size} selected` : "Select all"}
 </span>
 </div>
 )}
 {jobs.map((job) => {
 const isFlagged = job.flagged;
 const isDelivery = isDeliveryJob(job.jobNo);
 const effActual = effectiveActual(job);
 const deductAmt = parseFloat(job.deduction ?? "0");
 const isSelected = selectedIds.has(job.id);
 return (
 <div
 key={job.id}
 data-testid={`row-ggv-${job.id}`}
 className={`rounded-none border px-4 py-3 ${
 isSelected
 ? "bg-[#EBE9E2] border-[#0A0A0A]/40"
 : isFlagged
 ? "bg-[#FBEBEB] border-[#C1121F]/30"
 : job.remarks?.trim()
 ? "bg-[#C1121F]/8 border-[#C1121F]/20"
 : "bg-white border-black/10"
 }`}
 >
 {/* Top row: job no + service + actual $ */}
 <div className="flex items-start justify-between gap-2">
 <Checkbox
 checked={isSelected}
 onCheckedChange={() => toggleSelect(job.id)}
 data-testid={`checkbox-select-${job.id}`}
 className="mt-0.5 border-black/12 shrink-0"
 />
 <div className="min-w-0 flex-1">
 <div className="flex items-center gap-1.5 flex-wrap">
 {isFlagged && <Flag className="w-3 h-3 text-[#C1121F] shrink-0" />}
 <span className="font-mono text-[11px] text-black/65">{job.jobNo || "—"}</span>
 {job.serviceType && (
 <span className="text-[10px] font-black bg-[#EBE9E2] text-[#0A0A0A]/65 px-1.5 py-0.5 rounded">
 {job.serviceType}
 </span>
 )}
 {isDelivery && (
 <span className="text-[9px] font-black bg-[#EBE9E2] text-[#0A0A0A] px-1.5 py-0.5 rounded">
 DEL
 </span>
 )}
 {job.cancelled && (
 <span className="text-[9px] font-black bg-[#C1121F] text-white px-1.5 py-0.5 rounded" data-testid={`badge-cancelled-${job.id}`}>
 CANCELLED
 </span>
 )}
 </div>
 <p className="text-xs text-black/55 mt-0.5 break-words leading-snug">{job.address || "—"}</p>
 </div>
 <div className="text-right shrink-0">
 <span className={`text-lg font-black tabular-nums ${job.cancelled ? "text-[#C1121F]" : "text-[#0A0A0A]"}`}>${effActual.toFixed(2)}</span>
 {job.cancelled ? (
 <div className="text-[9px] text-[#C1121F] font-medium">return fee only</div>
 ) : isDelivery && (
 <div className="text-[9px] text-[#0A0A0A] font-medium">+${DELIVERY_FEE.toFixed(2)} del.</div>
 )}
 </div>
 </div>
 {/* Bottom row: time + prices + actions */}
 <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/5">
 <div className="flex items-center gap-3 text-[11px] text-black/55">
 {(job.timeStart || job.timeEnd) && (
 <span>{job.timeStart ?? "?"}{job.timeEnd ? `–${job.timeEnd}` : ""}</span>
 )}
 {job.listedPrice && (
 <span className={`tabular-nums ${job.cancelled ? "line-through text-black/35" : ""}`}>${parseFloat(job.listedPrice).toFixed(2)}</span>
 )}
 {!job.cancelled && deductAmt > 0 && (
 <span className="text-[#C1121F] tabular-nums">-${deductAmt.toFixed(2)}</span>
 )}
 </div>
 <div className="flex items-center gap-1">
 <select
 value={assigneeValue(job)}
 onChange={(e) => handleInlineAssign(job, e.target.value)}
 disabled={assignMut.isPending}
 data-testid={`select-assignee-${job.id}`}
 title="Assign staff or team"
 className="max-w-[7.5rem] text-[11px] bg-white border border-black/15 rounded-none px-1.5 py-1 text-[#0A0A0A] focus:outline-none focus:border-black/40 disabled:opacity-50"
 >
 <option value="">Unassigned</option>
 {teamsList.length > 0 && (
 <optgroup label="Teams">
 {teamsList.map((t) => <option key={`team:${t.id}`} value={`team:${t.id}`}>{t.name}</option>)}
 </optgroup>
 )}
 <optgroup label="Staff">
 {staffList.map((s) => <option key={`staff:${s.id}`} value={`staff:${s.id}`}>{s.name}</option>)}
 </optgroup>
 </select>
 {job.quoteId && (
 <Link
 href={`/admin/quotes/${job.quoteId}`}
 data-testid={`link-dashboard-${job.id}`}
 title="Open job on dashboard"
 className="p-1.5 rounded text-black/55 hover:text-[#0A0A0A] hover:bg-white/10 transition-colors"
 >
 <ArrowUpRight className="w-3.5 h-3.5" />
 </Link>
 )}
 <button
 onClick={() => openEdit(job)}
 data-testid={`btn-edit-${job.id}`}
 className="p-1.5 rounded text-black/55 hover:text-[#0A0A0A] hover:bg-white/10 transition-colors"
 >
 <Pencil className="w-3.5 h-3.5" />
 </button>
 <button
 onClick={() => setDeleteId(job.id)}
 data-testid={`btn-delete-${job.id}`}
 className="p-1.5 rounded text-black/55 hover:text-[#C1121F] hover:bg-[#FBEBEB] transition-colors"
 >
 <Trash2 className="w-3.5 h-3.5" />
 </button>
 </div>
 </div>
 {job.remarks?.trim() && (
 <p className="text-[11px] text-[#C1121F] mt-1.5 italic">{job.remarks}</p>
 )}
 </div>
 );
 })}
 {/* Mobile totals bar */}
 {jobs.length > 0 && (
 <div className="grid grid-cols-3 gap-2 pt-1">
 {[
 { label: "Listed", value: `$${totalListed.toFixed(2)}`, color: "text-black/65" },
 { label: "Deductions", value: totalDeduction > 0 ? `-$${totalDeduction.toFixed(2)}` : "—", color: "text-[#C1121F]" },
 { label: "Actual", value: `$${totalActual.toFixed(2)}`, color: "text-[#0A0A0A]", big: true },
 ].map(({ label, value, color, big }) => (
 <div key={label} className="bg-white border border-black/10 rounded-none p-3 text-center">
 <p className="text-[9px] font-black uppercase tracking-widest text-black/55 mb-0.5">{label}</p>
 <p className={`font-black tabular-nums ${big ? "text-base" : "text-sm"} ${color}`}>{value}</p>
 </div>
 ))}
 </div>
 )}
 </div>

 {/* ── Desktop table (≥ md) ─────────────────────────────────────────────── */}
 <div className="hidden md:block rounded-none border border-black/10 overflow-hidden bg-white">
 <div className="overflow-x-auto">
 <table className="w-full text-sm min-w-[1260px]">
 <thead>
 <tr className="border-b border-black/10 bg-white">
 <th className="px-3 py-2.5 w-10">
 <Checkbox
 checked={allOnPageSelected ? true : someOnPageSelected ? "indeterminate" : false}
 onCheckedChange={toggleSelectAll}
 data-testid="checkbox-select-all"
 className="border-black/12"
 />
 </th>
 <th className="text-left px-3 py-2.5 text-[10px] font-black uppercase tracking-widest text-black/55 w-36">Job No</th>
 <th className="text-left px-3 py-2.5 text-[10px] font-black uppercase tracking-widest text-black/55 w-36">Booking Ref</th>
 <th className="text-left px-3 py-2.5 text-[10px] font-black uppercase tracking-widest text-black/55 w-24">Time</th>
 <th className="text-right px-3 py-2.5 text-[10px] font-black uppercase tracking-widest text-black/55 w-24">Listed</th>
 <th className="text-right px-3 py-2.5 text-[10px] font-black uppercase tracking-widest text-black/55 w-24">Deduction</th>
 <th className="text-right px-3 py-2.5 text-[10px] font-black uppercase tracking-widest text-[#0A0A0A] w-28">Actual $</th>
 <th className="text-left px-3 py-2.5 text-[10px] font-black uppercase tracking-widest text-black/55 w-28">Service</th>
 <th className="text-left px-3 py-2.5 text-[10px] font-black uppercase tracking-widest text-black/55 w-44">Address</th>
 <th className="text-left px-3 py-2.5 text-[10px] font-black uppercase tracking-widest text-black/55 w-20">Postal</th>
 <th className="text-right px-3 py-2.5 text-[10px] font-black uppercase tracking-widest text-black/55 w-20">Dist km</th>
 <th className="text-right px-3 py-2.5 text-[10px] font-black uppercase tracking-widest text-black/55 w-16">Rate</th>
 <th className="text-left px-3 py-2.5 text-[10px] font-black uppercase tracking-widest text-black/55 w-40">Assignee</th>
 <th className="text-left px-3 py-2.5 text-[10px] font-black uppercase tracking-widest text-black/55">Remarks</th>
 <th className="px-3 py-2.5 w-16"></th>
 </tr>
 </thead>
 <tbody>
 {isLoading && (
 <tr><td colSpan={15} className="text-center py-12 text-black/55 text-sm">Loading…</td></tr>
 )}
 {!isLoading && jobs.length === 0 && (
 <tr>
 <td colSpan={15} className="text-center py-12">
 <div className="flex flex-col items-center gap-3 text-black/75">
 <FileImage className="w-10 h-10" />
 <div>
 <p className="text-sm font-semibold text-black/55">No jobs for this day</p>
 <p className="text-xs mt-1">Upload a spreadsheet screenshot to auto-fill, or click "Add Job" to enter manually</p>
 </div>
 <button
 onClick={() => fileInputRef.current?.click()}
 className="mt-1 flex items-center gap-1.5 text-xs text-[#0A0A0A] hover:text-[#0A0A0A]/65 font-semibold border border-[#0A0A0A]/30 px-3 py-1.5 rounded-lg hover:bg-[#EBE9E2] transition-colors"
 >
 <Upload className="w-3 h-3" /> Upload & Scan
 </button>
 </div>
 </td>
 </tr>
 )}
 {jobs.map((job) => {
 const isFlagged = job.flagged;
 const hasRemarks = !!(job.remarks?.trim());
 const isDelivery = isDeliveryJob(job.jobNo);
 const effActual = effectiveActual(job);
 const isSelected = selectedIds.has(job.id);
 return (
 <tr
 key={job.id}
 data-testid={`row-ggv-${job.id}`}
 className={`border-b border-white/5 transition-colors ${
 isSelected ? "bg-[#EBE9E2] hover:bg-[#EBE9E2]"
 : isFlagged ? "bg-[#FBEBEB] hover:bg-[#FBEBEB]"
 : hasRemarks ? "bg-[#C1121F]/8 hover:bg-[#C1121F]/12"
 : "hover:bg-white/[0.03]"
 }`}
 >
 <td className="px-3 py-2.5">
 <Checkbox
 checked={isSelected}
 onCheckedChange={() => toggleSelect(job.id)}
 data-testid={`checkbox-select-${job.id}`}
 className="border-black/12"
 />
 </td>
 <td className="px-3 py-2.5 font-mono text-xs text-black/65">
 <div className="flex items-center gap-1.5">
 {isFlagged && <Flag className="w-3 h-3 text-[#C1121F] shrink-0" />}
 {job.jobNo || <span className="text-black/75">—</span>}
 </div>
 </td>
 <td className="px-3 py-2.5 font-mono text-xs text-black/55">{job.bookingRef || <span className="text-black/75">—</span>}</td>
 <td className="px-3 py-2.5 text-xs text-black/55">
 {job.timeStart && job.timeEnd ? `${job.timeStart}–${job.timeEnd}` : job.timeStart || "—"}
 </td>
 <td className={`px-3 py-2.5 text-right text-xs tabular-nums ${job.cancelled ? "line-through text-black/35" : "text-black/55"}`}>{fmt(job.listedPrice)}</td>
 <td className="px-3 py-2.5 text-right text-xs tabular-nums text-[#C1121F]">{!job.cancelled && parseFloat(job.deduction ?? "0") > 0 ? `-${fmt(job.deduction)}` : "—"}</td>
 <td className="px-3 py-2.5 text-right">
 <span className={`text-sm font-black tabular-nums ${job.cancelled ? "text-[#C1121F]" : "text-[#0A0A0A]"}`}>${effActual.toFixed(2)}</span>
 {job.cancelled ? (
 <div className="text-[9px] tabular-nums text-[#C1121F] font-medium leading-tight">return fee only</div>
 ) : isDelivery && (
 <div className="text-[9px] tabular-nums text-[#0A0A0A] font-medium leading-tight">
 +${DELIVERY_FEE.toFixed(2)} del.
 </div>
 )}
 </td>
 <td className="px-3 py-2.5">
 {job.serviceType
 ? <span className="text-[10px] font-black bg-[#EBE9E2] text-[#0A0A0A]/65 px-1.5 py-0.5 rounded">{job.serviceType}</span>
 : <span className="text-black/75 text-xs">—</span>}
 </td>
 <td className="px-3 py-2.5 text-xs text-black/55 max-w-[11rem] truncate" title={job.address ?? ""}>{job.address || "—"}</td>
 <td className="px-3 py-2.5 text-xs text-black/55">{job.postalCode || "—"}</td>
 <td className="px-3 py-2.5 text-right text-xs text-black/55">{job.distanceKm ? parseFloat(job.distanceKm).toFixed(2) : "—"}</td>
 <td className="px-3 py-2.5 text-right text-xs text-black/55">{job.ratePerKm ? parseFloat(job.ratePerKm).toFixed(2) : "—"}</td>
 <td className="px-3 py-2.5">
 <select
 value={assigneeValue(job)}
 onChange={(e) => handleInlineAssign(job, e.target.value)}
 disabled={assignMut.isPending}
 data-testid={`select-assignee-table-${job.id}`}
 title="Assign staff or team"
 className="w-full max-w-[9rem] text-xs bg-white border border-black/15 rounded-none px-1.5 py-1 text-[#0A0A0A] focus:outline-none focus:border-black/40 disabled:opacity-50"
 >
 <option value="">Unassigned</option>
 {teamsList.length > 0 && (
 <optgroup label="Teams">
 {teamsList.map((t) => <option key={`team:${t.id}`} value={`team:${t.id}`}>{t.name}</option>)}
 </optgroup>
 )}
 <optgroup label="Staff">
 {staffList.map((s) => <option key={`staff:${s.id}`} value={`staff:${s.id}`}>{s.name}</option>)}
 </optgroup>
 </select>
 </td>
 <td className="px-3 py-2.5 text-xs text-[#C1121F] max-w-[10rem] truncate" title={job.remarks ?? ""}>{job.remarks || "—"}</td>
 <td className="px-3 py-2.5">
 <div className="flex items-center gap-1 justify-end">
 {job.quoteId && (
 <Link href={`/admin/quotes/${job.quoteId}`} data-testid={`link-dashboard-${job.id}`} title="Open job on dashboard" className="p-1.5 rounded text-black/55 hover:text-[#0A0A0A] hover:bg-white/10 transition-colors">
 <ArrowUpRight className="w-3.5 h-3.5" />
 </Link>
 )}
 <button onClick={() => openEdit(job)} data-testid={`btn-edit-${job.id}`} className="p-1.5 rounded text-black/55 hover:text-[#0A0A0A] hover:bg-white/10 transition-colors">
 <Pencil className="w-3.5 h-3.5" />
 </button>
 <button onClick={() => setDeleteId(job.id)} data-testid={`btn-delete-${job.id}`} className="p-1.5 rounded text-black/55 hover:text-[#C1121F] hover:bg-[#FBEBEB] transition-colors">
 <Trash2 className="w-3.5 h-3.5" />
 </button>
 </div>
 </td>
 </tr>
 );
 })}
 </tbody>
 {jobs.length > 0 && (
 <tfoot>
 <tr className="border-t border-black/10 bg-white">
 <td colSpan={4} className="px-3 py-3 text-[10px] font-black uppercase tracking-widest text-black/55">{jobs.length} job{jobs.length !== 1 ? "s" : ""}</td>
 <td className="px-3 py-3 text-right text-xs font-bold tabular-nums text-black/65">${totalListed.toFixed(2)}</td>
 <td className="px-3 py-3 text-right text-xs font-bold tabular-nums text-[#C1121F]">{totalDeduction > 0 ? `-$${totalDeduction.toFixed(2)}` : "—"}</td>
 <td className="px-3 py-3 text-right"><span className="text-base font-black tabular-nums text-[#0A0A0A]">${totalActual.toFixed(2)}</span></td>
 <td colSpan={8} />
 </tr>
 </tfoot>
 )}
 </table>
 </div>
 </div>

 {/* Summary cards — desktop only (mobile has inline totals in card view) */}
 {jobs.length > 0 && (
 <div className="hidden md:grid grid-cols-3 gap-3 mt-4">
 {[
 { label: "Total Listed", value: `$${totalListed.toFixed(2)}`, color: "text-black/65" },
 { label: "Total Deductions", value: totalDeduction > 0 ? `-$${totalDeduction.toFixed(2)}` : "—", color: "text-[#C1121F]" },
 { label: "Total Actual", value: `$${totalActual.toFixed(2)}`, color: "text-[#0A0A0A]", big: true },
 ].map(({ label, value, color, big }) => (
 <div key={label} className="bg-white border border-black/10 rounded-none p-4 text-center">
 <p className="text-[10px] font-black uppercase tracking-widest text-black/55 mb-1">{label}</p>
 <p className={`font-black tabular-nums ${big ? "text-2xl" : "text-lg"} ${color}`}>{value}</p>
 </div>
 ))}
 </div>
 )}
 </div>

 {/* ── AI Scan Preview Modal ────────────────────────────────────────────── */}
 <Dialog open={previewOpen} onOpenChange={v => { if (!importing) setPreviewOpen(v); }}>
 <DialogContent className="bg-white border-black/10 text-[#0A0A0A] max-w-5xl max-h-[90vh] overflow-y-auto">
 <DialogHeader>
 <DialogTitle className="flex items-center gap-2 font-black text-[#0A0A0A]">
 <Eye className="w-4 h-4 text-[#0A0A0A]" />
 Review Scanned Jobs
 <span className="ml-auto text-xs font-normal text-black/55">
 {scanResult?.jobs.length} row{scanResult?.jobs.length !== 1 ? "s" : ""} found — {selectedCount} selected
 </span>
 </DialogTitle>
 </DialogHeader>

 {/* Date override */}
 <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
 <div className="flex items-center gap-2 flex-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest shrink-0">Save to date</Label>
 <input
 type="date"
 value={previewDate}
 onChange={e => setPreviewDate(e.target.value)}
 className="bg-white border border-black/10 rounded text-sm text-[#0A0A0A] px-2 py-1 outline-none"
 />
 </div>
 <div className="flex items-center gap-2">
 <button
 onClick={() => setSelectedRows(r => r.map(() => true))}
 className="text-xs text-[#0A0A0A] hover:text-[#0A0A0A]/65 font-semibold"
 >Select all</button>
 <span className="text-black/75">·</span>
 <button
 onClick={() => setSelectedRows(r => r.map(() => false))}
 className="text-xs text-black/55 hover:text-[#0A0A0A] font-semibold"
 >None</button>
 </div>
 </div>

 {/* Preview image thumbnail — only shown for single upload */}
 {previewImage && scanResult && !scanResult.jobs.some(j => (j as any)._source && (j as any)._source !== scanResult.jobs[0] && (j as any)._source !== (scanResult.jobs[0] as any)._source) && (
 <div className="rounded-lg overflow-hidden border border-black/10 max-h-36 flex items-center justify-center bg-black">
 <img src={previewImage} alt="Uploaded spreadsheet" className="max-h-36 object-contain opacity-80" />
 </div>
 )}

 {/* Extracted rows table */}
 <div className="overflow-x-auto rounded-lg border border-black/10">
 <table className="w-full text-xs min-w-[900px]">
 <thead>
 <tr className="bg-white border-b border-black/10">
 <th className="px-2 py-2 w-8"></th>
 <th className="text-left px-2 py-2 text-black/55 font-black uppercase tracking-wider">Job No</th>
 <th className="text-left px-2 py-2 text-black/55 font-black uppercase tracking-wider">Booking Ref</th>
 <th className="text-left px-2 py-2 text-black/55 font-black uppercase tracking-wider">Time</th>
 <th className="text-right px-2 py-2 text-black/55 font-black uppercase tracking-wider">Listed</th>
 <th className="text-right px-2 py-2 text-black/55 font-black uppercase tracking-wider">Deduct</th>
 <th className="text-right px-2 py-2 text-[#0A0A0A] font-black uppercase tracking-wider">Actual $</th>
 <th className="text-left px-2 py-2 text-black/55 font-black uppercase tracking-wider">Type</th>
 <th className="text-left px-2 py-2 text-black/55 font-black uppercase tracking-wider">Address</th>
 <th className="text-left px-2 py-2 text-black/55 font-black uppercase tracking-wider">Postal</th>
 <th className="text-right px-2 py-2 text-black/55 font-black uppercase tracking-wider">km</th>
 <th className="text-left px-2 py-2 text-black/55 font-black uppercase tracking-wider">Remarks</th>
 </tr>
 </thead>
 <tbody>
 {scanResult?.jobs.map((job, i) => {
 const source = (job as any)._source as string | undefined;
 const prevSource = i > 0 ? ((scanResult.jobs[i - 1] as any)._source as string | undefined) : null;
 const isNewSource = source && source !== prevSource;
 const isMultiFile = scanResult.jobs.some((j, idx) => idx > 0 && (j as any)._source !== (scanResult.jobs[0] as any)._source);
 return (
 <Fragment key={i}>
 {isMultiFile && isNewSource && (
 <tr key={`source-${i}`} className="bg-white border-b border-black/10">
 <td colSpan={12} className="px-2 py-1.5">
 <div className="flex items-center gap-1.5">
 <FileImage className="w-3 h-3 text-[#0A0A0A]" />
 <span className="text-[10px] font-black text-[#0A0A0A] uppercase tracking-widest truncate max-w-xs">{source}</span>
 </div>
 </td>
 </tr>
 )}
 <tr
 key={i}
 className={`border-b border-white/5 transition-colors ${
 !selectedRows[i] ? "opacity-40" :
 job.flagged ? "bg-[#FBEBEB]" : ""
 }`}
 >
 <td className="px-2 py-2 text-center">
 <Checkbox
 checked={selectedRows[i] ?? true}
 onCheckedChange={v => setSelectedRows(r => r.map((val, idx) => idx === i ? !!v : val))}
 className="border-black/12"
 />
 </td>
 <td className="px-2 py-2 font-mono text-black/65">
 <div className="flex items-center gap-1">
 {job.flagged && <Flag className="w-2.5 h-2.5 text-[#C1121F]" />}
 {job.jobNo || <span className="text-black/75">—</span>}
 </div>
 </td>
 <td className="px-2 py-2 font-mono text-black/55">{job.bookingRef || "—"}</td>
 <td className="px-2 py-2 text-black/55">
 {job.timeStart && job.timeEnd ? `${job.timeStart}–${job.timeEnd}` : job.timeStart || "—"}
 </td>
 <td className="px-2 py-2 text-right text-black/55">{fmt(job.listedPrice)}</td>
 <td className="px-2 py-2 text-right text-[#C1121F]">{(job.deduction ?? 0) > 0 ? `-${fmt(job.deduction)}` : "—"}</td>
 <td className="px-2 py-2 text-right font-black text-[#0A0A0A]">
 {fmt(effectiveScannedActual(job))}
 {isDeliveryJob(job.jobNo) && (
 <div className="text-[9px] font-medium text-black/55">+${DELIVERY_FEE.toFixed(2)} del.</div>
 )}
 </td>
 <td className="px-2 py-2">
 {job.serviceType
 ? <span className="bg-[#EBE9E2] text-[#0A0A0A]/65 px-1 py-0.5 rounded text-[10px] font-bold">{job.serviceType}</span>
 : "—"}
 </td>
 <td className="px-2 py-2 text-black/55 max-w-[12rem] truncate" title={job.address ?? ""}>{job.address || "—"}</td>
 <td className="px-2 py-2 text-black/55">{job.postalCode || "—"}</td>
 <td className="px-2 py-2 text-right text-black/55">{job.distanceKm != null ? job.distanceKm.toFixed(2) : "—"}</td>
 <td className="px-2 py-2 text-[#C1121F] max-w-[10rem] truncate" title={job.remarks ?? ""}>{job.remarks || "—"}</td>
 </tr>
 </Fragment>
 );
 })}
 </tbody>
 {scanResult && selectedCount > 0 && (
 <tfoot>
 <tr className="border-t border-black/10 bg-white">
 <td colSpan={6} className="px-2 py-2 text-black/55">{selectedCount} selected</td>
 <td className="px-2 py-2 text-right font-black text-[#0A0A0A]">
 ${scanResult.jobs.filter((_, i) => selectedRows[i]).reduce((s, j) => s + effectiveScannedActual(j), 0).toFixed(2)}
 </td>
 <td colSpan={5} />
 </tr>
 </tfoot>
 )}
 </table>
 </div>

 <DialogFooter className="gap-2">
 <Button variant="ghost" onClick={() => setPreviewOpen(false)} disabled={importing} className="text-black/55 hover:text-[#0A0A0A]">
 Cancel
 </Button>
 <Button
 onClick={handleImport}
 disabled={importing || selectedCount === 0}
 className="bg-[#EBE9E2]0 hover:bg-[#0A0A0A] text-black font-black gap-1.5"
 data-testid="btn-import-jobs"
 >
 {importing ? (
 <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Importing…</>
 ) : (
 <><CheckCheck className="w-3.5 h-3.5" /> Import {selectedCount} job{selectedCount !== 1 ? "s" : ""}</>
 )}
 </Button>
 </DialogFooter>
 </DialogContent>
 </Dialog>

 {/* ── Add / Edit Dialog ──────────────────────────────────────────────────── */}
 <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
 <DialogContent className="bg-white border-black/10 text-[#0A0A0A] max-w-2xl max-h-[90vh] overflow-y-auto">
 <DialogHeader>
 <DialogTitle className="text-[#0A0A0A] font-black">{editingJob ? "Edit Job" : "Add Job"}</DialogTitle>
 </DialogHeader>
 <div className="space-y-4">
 <div className="grid grid-cols-2 gap-3 p-3 bg-white/5 rounded-lg">
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Vehicle Group</Label>
 <Input value={vehicleGroup} onChange={e => setVehicleGroup(e.target.value)} className="bg-white border-black/10 text-[#0A0A0A] text-sm h-8" data-testid="input-vehicle-group" />
 </div>
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Vehicle Type</Label>
 <Input value={vehicleType} onChange={e => setVehicleType(e.target.value)} className="bg-white border-black/10 text-[#0A0A0A] text-sm h-8" data-testid="input-vehicle-type" />
 </div>
 </div>
 <div className="grid grid-cols-2 gap-3">
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Job No</Label>
 <Input value={form.jobNo} onChange={e => setForm(f => ({ ...f, jobNo: e.target.value }))} placeholder="S045260062103" className="bg-white border-black/10 text-[#0A0A0A] text-sm h-9 font-mono" data-testid="input-job-no" />
 </div>
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Booking Ref</Label>
 <Input value={form.bookingRef} onChange={e => setForm(f => ({ ...f, bookingRef: e.target.value }))} placeholder="V045260161488" className="bg-white border-black/10 text-[#0A0A0A] text-sm h-9 font-mono" data-testid="input-booking-ref" />
 </div>
 </div>
 <div className="grid grid-cols-2 gap-3">
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Time Start</Label>
 <Input type="time" value={form.timeStart} onChange={e => setForm(f => ({ ...f, timeStart: e.target.value }))} className="bg-white border-black/10 text-[#0A0A0A] text-sm h-9" data-testid="input-time-start" />
 </div>
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Time End</Label>
 <Input type="time" value={form.timeEnd} onChange={e => setForm(f => ({ ...f, timeEnd: e.target.value }))} className="bg-white border-black/10 text-[#0A0A0A] text-sm h-9" data-testid="input-time-end" />
 </div>
 </div>
 <div className="grid grid-cols-3 gap-3">
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Listed ($)</Label>
 <Input type="number" step="0.01" value={form.listedPrice} onChange={e => setForm(f => ({ ...f, listedPrice: e.target.value }))} placeholder="99.90" className="bg-white border-black/10 text-[#0A0A0A] text-sm h-9" data-testid="input-listed-price" />
 </div>
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Deduction ($)</Label>
 <Input type="number" step="0.01" value={form.deduction} onChange={e => setForm(f => ({ ...f, deduction: e.target.value }))} placeholder="18.33" className="bg-white border-black/10 text-[#C1121F] text-sm h-9" data-testid="input-deduction" />
 </div>
 <div className="space-y-1">
 <Label className="text-[10px] text-[#0A0A0A] uppercase font-black tracking-widest">Actual Price ($) ★</Label>
 <Input type="number" step="0.01" value={form.actualPrice} onChange={e => setForm(f => ({ ...f, actualPrice: e.target.value }))} placeholder="9.17" className="bg-[#EBE9E2] border-black/12 text-[#0A0A0A] font-black text-sm h-9" data-testid="input-actual-price" />
 </div>
 </div>
 <div className="grid grid-cols-2 gap-3">
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Service Type</Label>
 <Select value={form.serviceType || "__none__"} onValueChange={v => setForm(f => ({ ...f, serviceType: v === "__none__" ? "" : v }))}>
 <SelectTrigger className="bg-white border-black/10 text-[#0A0A0A] h-9 text-sm" data-testid="select-service-type">
 <SelectValue placeholder="Select…" />
 </SelectTrigger>
 <SelectContent className="bg-white border-black/10 text-[#0A0A0A]">
 <SelectItem value="__none__">— None —</SelectItem>
 {SERVICE_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
 </SelectContent>
 </Select>
 </div>
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Flag Row</Label>
 <button type="button" onClick={() => setForm(f => ({ ...f, flagged: !f.flagged }))} data-testid="btn-flagged"
 className={`w-full h-9 rounded-md border text-sm font-bold flex items-center justify-center gap-2 transition-colors ${form.flagged ? "bg-[#FBEBEB] border-[#C1121F]/40 text-[#C1121F]" : "bg-white border-black/10 text-black/55 hover:text-white"}`}>
 <Flag className="w-3.5 h-3.5" />{form.flagged ? "Flagged" : "Not Flagged"}
 </button>
 </div>
 </div>
 <div className="grid grid-cols-2 gap-3">
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Job Cancelled</Label>
 <button type="button" onClick={() => setForm(f => ({ ...f, cancelled: !f.cancelled }))} data-testid="btn-cancelled"
 className={`w-full h-9 rounded-md border text-sm font-bold flex items-center justify-center gap-2 transition-colors ${form.cancelled ? "bg-[#C1121F] border-[#C1121F] text-white" : "bg-white border-black/10 text-black/55"}`}>
 {form.cancelled ? "Cancelled — price not counted" : "Not Cancelled"}
 </button>
 </div>
 {form.cancelled && (
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Return Fee ($)</Label>
 <Input type="number" step="0.01" value={form.returnFee} onChange={e => setForm(f => ({ ...f, returnFee: e.target.value }))} placeholder="18.50" className="bg-white border-black/10 text-[#0A0A0A] text-sm h-9" data-testid="input-return-fee" />
 <p className="text-[10px] text-black/45 leading-snug">Items returned to warehouse — only this fee counts, not the job price.</p>
 </div>
 )}
 </div>
 <div className="grid grid-cols-3 gap-3">
 <div className="col-span-2 space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Address</Label>
 <Input value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} placeholder="17 Jalan Tenteram #08-120" className="bg-white border-black/10 text-[#0A0A0A] text-sm h-9" data-testid="input-address" />
 </div>
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Postal Code</Label>
 <Input value={form.postalCode} onChange={e => setForm(f => ({ ...f, postalCode: e.target.value }))} placeholder="321017" className="bg-white border-black/10 text-[#0A0A0A] text-sm h-9" data-testid="input-postal-code" />
 </div>
 </div>
 <div className="grid grid-cols-2 gap-3">
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Distance (km)</Label>
 <Input type="number" step="0.01" value={form.distanceKm} onChange={e => setForm(f => ({ ...f, distanceKm: e.target.value }))} placeholder="15.95" className="bg-white border-black/10 text-[#0A0A0A] text-sm h-9" data-testid="input-distance" />
 </div>
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Rate / km</Label>
 <Input type="number" step="0.01" value={form.ratePerKm} onChange={e => setForm(f => ({ ...f, ratePerKm: e.target.value }))} placeholder="0.06" className="bg-white border-black/10 text-[#0A0A0A] text-sm h-9" data-testid="input-rate-per-km" />
 </div>
 </div>
 <div className="space-y-1">
 <Label className="text-[10px] text-black/55 uppercase font-black tracking-widest">Remarks / Notes</Label>
 <Input value={form.remarks} onChange={e => setForm(f => ({ ...f, remarks: e.target.value }))} placeholder="SHI DONG 04/03 COMPLETED" className="bg-white border-black/10 text-[#C1121F] text-sm h-9" data-testid="input-remarks" />
 </div>
 </div>
 <DialogFooter className="mt-2 gap-2">
 <Button variant="ghost" onClick={() => setDialogOpen(false)} className="text-black/55 hover:text-[#0A0A0A]">Cancel</Button>
 <Button onClick={handleSave} disabled={isPending} className="bg-[#EBE9E2]0 hover:bg-[#0A0A0A] text-black font-black" data-testid="btn-save-job">
 {isPending ? "Saving…" : editingJob ? "Save Changes" : "Add Job"}
 </Button>
 </DialogFooter>
 </DialogContent>
 </Dialog>

 {/* Bulk delete confirm */}
 <Dialog open={bulkDeleteOpen} onOpenChange={v => { if (!bulkDeleteMut.isPending) setBulkDeleteOpen(v); }}>
 <DialogContent className="bg-white border-black/10 text-[#0A0A0A] max-w-sm">
 <DialogHeader>
 <DialogTitle className="flex items-center gap-2 text-[#C1121F]">
 <AlertCircle className="w-5 h-5" /> Delete {selectedIds.size} job{selectedIds.size !== 1 ? "s" : ""}?
 </DialogTitle>
 </DialogHeader>
 <p className="text-sm text-black/55">
 The selected job entr{selectedIds.size !== 1 ? "ies" : "y"} will be permanently deleted. This cannot be undone.
 </p>
 <DialogFooter className="gap-2">
 <Button variant="ghost" onClick={() => setBulkDeleteOpen(false)} disabled={bulkDeleteMut.isPending} className="text-black/55 hover:text-[#0A0A0A]">Cancel</Button>
 <Button
 onClick={() => bulkDeleteMut.mutate(Array.from(selectedIds))}
 disabled={bulkDeleteMut.isPending || selectedIds.size === 0}
 className="bg-[#0A0A0A] hover:bg-[#0A0A0A] text-white font-black gap-1.5"
 data-testid="btn-confirm-bulk-delete"
 >
 {bulkDeleteMut.isPending ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Deleting…</> : <><Trash2 className="w-3.5 h-3.5" /> Delete {selectedIds.size}</>}
 </Button>
 </DialogFooter>
 </DialogContent>
 </Dialog>

 {/* Bulk assign */}
 <Dialog open={bulkAssignOpen} onOpenChange={v => { if (!assignMut.isPending) setBulkAssignOpen(v); }}>
 <DialogContent className="bg-white border-black/10 text-[#0A0A0A] max-w-sm">
 <DialogHeader>
 <DialogTitle className="flex items-center gap-2">
 <UserPlus className="w-5 h-5" /> Assign {selectedIds.size} job{selectedIds.size !== 1 ? "s" : ""}
 </DialogTitle>
 </DialogHeader>
 <p className="text-sm text-black/55">
 Choose a team or staff member for the selected job{selectedIds.size !== 1 ? "s" : ""}, or set to Unassigned to clear.
 </p>
 <select
 value={bulkAssignee}
 onChange={(e) => setBulkAssignee(e.target.value)}
 disabled={assignMut.isPending}
 data-testid="select-bulk-assignee"
 className="w-full text-sm bg-white border border-black/15 rounded-none px-2.5 py-2 text-[#0A0A0A] focus:outline-none focus:border-black/40 disabled:opacity-50"
 >
 <option value="">Unassigned (clear)</option>
 {teamsList.length > 0 && (
 <optgroup label="Teams">
 {teamsList.map((t) => <option key={`team:${t.id}`} value={`team:${t.id}`}>{t.name}</option>)}
 </optgroup>
 )}
 <optgroup label="Staff">
 {staffList.map((s) => <option key={`staff:${s.id}`} value={`staff:${s.id}`}>{s.name}</option>)}
 </optgroup>
 </select>
 <DialogFooter className="gap-2">
 <Button variant="ghost" onClick={() => setBulkAssignOpen(false)} disabled={assignMut.isPending} className="text-black/55 hover:text-[#0A0A0A]">Cancel</Button>
 <Button
 onClick={handleBulkAssign}
 disabled={assignMut.isPending || selectedIds.size === 0}
 className="bg-[#0A0A0A] hover:bg-[#0A0A0A] text-white font-black gap-1.5"
 data-testid="btn-confirm-bulk-assign"
 >
 {assignMut.isPending ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Assigning…</> : <><UserPlus className="w-3.5 h-3.5" /> Assign {selectedIds.size}</>}
 </Button>
 </DialogFooter>
 </DialogContent>
 </Dialog>

 {/* Delete confirm */}
 <Dialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
 <DialogContent className="bg-white border-black/10 text-[#0A0A0A] max-w-sm">
 <DialogHeader>
 <DialogTitle className="flex items-center gap-2 text-[#C1121F]">
 <AlertCircle className="w-5 h-5" /> Delete Job
 </DialogTitle>
 </DialogHeader>
 <p className="text-sm text-black/55">This job entry will be permanently deleted.</p>
 <DialogFooter className="gap-2">
 <Button variant="ghost" onClick={() => setDeleteId(null)} className="text-black/55 hover:text-[#0A0A0A]">Cancel</Button>
 <Button onClick={() => deleteId && deleteMut.mutate(deleteId)} disabled={deleteMut.isPending} className="bg-[#0A0A0A] hover:bg-[#0A0A0A] text-white font-black" data-testid="btn-confirm-delete">
 {deleteMut.isPending ? "Deleting…" : "Delete"}
 </Button>
 </DialogFooter>
 </DialogContent>
 </Dialog>
 </div>
 );
}
