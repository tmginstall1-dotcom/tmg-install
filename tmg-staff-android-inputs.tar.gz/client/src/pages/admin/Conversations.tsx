import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAdminPush } from "@/hooks/use-admin-push";
import {
 MessageCircle, Send, Phone, RefreshCw, User, Bot, Search, X,
 ExternalLink, MapPin, Package, Calendar, Building2, Layers,
 CheckCheck, Zap, ArrowLeft, ImageIcon, BotOff, FileText,
 TriangleAlert, AlertCircle, ChevronDown, Paperclip, Smile,
 StickyNote, Plus, RotateCcw, ListChecks, Trash2, Copy,
 Mic, MessageSquare, Mail, PhoneCall,
} from "lucide-react";
import EmojiPicker, { EmojiClickData, Theme } from "emoji-picker-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { PaymentMessageDialog } from "@/components/shared/PaymentMessageDialog";
import { DeliveryRecovery } from "@/components/admin/WhatsappFirstOperations";
import { WhatsappMessageMedia } from "@/components/admin/WhatsappMessageMedia";
import { InternalQuotationPanel } from "@/components/admin/InternalQuotationPanel";

const API_BASE = (import.meta.env.VITE_API_BASE as string) || "";

// ── Types ─────────────────────────────────────────────────────────────────────

type Conversation = {
 phone: string;
 name: string | null;
 lastMessage: string;
 lastAt: string;
 unreadCount: number;
 state: string | null;
 botPaused: boolean;
 pendingQuoteRef: string | null;
 pendingQuoteStatus: string | null;
 customerName: string | null;
};

type WaMessage = {
 id: number;
 phone: string;
 direction: "inbound" | "outbound";
 body: string;
 mediaType: string | null;
 mediaUrl: string | null;
 hasAttachment?: boolean;
 mediaFilename?: string|null;
 sentBy: string | null;
 readAt: string | null;
 createdAt: string;
 deliveryStatus?: string | null;
 deliveryError?: string | null;
};

type ThreadData = {
 messages: WaMessage[];
 session: any;
};
type TextSendPayload = { phone: string; message: string; requestId: string; signature: string };
type FileSendPayload = { phone: string; file: File; caption?: string; requestId: string; signature: string };
type ComposerSession={
 drafts:Record<string,ChatDraft>;requests:Record<string,{signature:string;requestId:string}>;
 actions:Set<string>;quoteRequests:Record<string,string>;quoteActions:Set<string>;notes:Record<string,boolean>;
 changed:()=>void;
};
type ChatDraft = { text: string; file: File | null };
type DeliveryAttemptBlock = { id?: number; status: string; requestId: string; signature: string; kind: "text" | "file" };
const AMBIGUOUS_DELIVERY_STATUSES = new Set(["unknown", "sending", "pending", "processing"]);

function deliveryFailure(result: any, httpStatus: number): Error & { deliveryResult?: any } {
 const detail = result?.reason || result?.message || `WhatsApp did not accept this message (${result?.status || httpStatus}).`;
 const error = new Error(detail) as Error & { deliveryResult?: any };
 if (result && (result.status != null || result.id != null)) error.deliveryResult = result;
 return error;
}

async function postWhatsAppJson(url: string, payload: Record<string, unknown>) {
 let response: Response;
 try {
   response = await apiRequest("POST", url, payload);
 } catch (error: any) {
   let parsed: any;
   try { parsed = JSON.parse(String(error?.message ?? error ?? "")); } catch { /* apiRequest may return a plain transport/provider error */ }
   if (parsed && typeof parsed === "object" && (parsed.status != null || parsed.id != null)) {
     throw deliveryFailure(parsed, 409);
   }
   throw error;
 }
 const result = await response.json().catch(() => ({}));
 if (!response.ok || !result.ok || !["sent", "delivered", "read"].includes(result.status)) {
   throw deliveryFailure(result, response.status);
 }
 return result;
}

// ── State config ───────────────────────────────────────────────────────────────

const STATE_CONFIG: Record<string, { label: string; color: string; bg: string; dot: string }> = {
 awaiting_name: { label: "Getting name", color: "text-sky-600", bg: "bg-sky-50 border-sky-200", dot: "bg-sky-500" },
 awaiting_address: { label: "Getting address", color: "text-sky-600", bg: "bg-sky-50 border-sky-200", dot: "bg-sky-500" },
 awaiting_items: { label: "Listing items", color: "text-[#0A0A0A]", bg: "bg-[#EBE9E2] border-violet-200", dot: "bg-violet-500" },
 awaiting_items_verify: { label: "Verifying items", color: "text-[#0A0A0A]", bg: "bg-[#EBE9E2] border-violet-200", dot: "bg-violet-500" },
 awaiting_service_type: { label: "Service type", color: "text-amber-600", bg: "bg-amber-50 border-amber-200", dot: "bg-amber-500" },
 awaiting_floor: { label: "Floor details", color: "text-amber-600", bg: "bg-amber-50 border-amber-200", dot: "bg-amber-500" },
 awaiting_access: { label: "Access info", color: "text-amber-600", bg: "bg-amber-50 border-amber-200", dot: "bg-amber-500" },
 awaiting_to_address: { label: "Destination", color: "text-amber-600", bg: "bg-amber-50 border-amber-200", dot: "bg-amber-500" },
 awaiting_date: { label: "Choosing date", color: "text-orange-600", bg: "bg-orange-50 border-orange-200", dot: "bg-orange-500" },
 awaiting_confirmation: { label: "Confirming", color: "text-yellow-700", bg: "bg-yellow-50 border-yellow-200", dot: "bg-yellow-500" },
 submitted: { label: "Submitted ✓", color: "text-emerald-700", bg: "bg-emerald-50 border-emerald-200", dot: "bg-emerald-500" },
};

function getState(state: string | null) {
 if (!state) return { label: "No session", color: "text-gray-400", bg: "bg-gray-50 border-gray-200", dot: "bg-gray-300" };
 return STATE_CONFIG[state] || { label: state.replace(/_/g, " "), color: "text-gray-500", bg: "bg-gray-50 border-gray-200", dot: "bg-gray-400" };
}

// ── Formatting ─────────────────────────────────────────────────────────────────

function formatPhone(phone: string) {
 if (phone.startsWith("65") && phone.length >= 10)
 return `+65 ${phone.slice(2, 6)} ${phone.slice(6)}`;
 return `+${phone}`;
}

function relativeTime(dateStr: string) {
 const diff = Date.now() - new Date(dateStr).getTime();
 const mins = Math.floor(diff / 60000);
 if (mins < 1) return "Now";
 if (mins < 60) return `${mins}m`;
 const hrs = Math.floor(mins / 60);
 if (hrs < 24) return `${hrs}h`;
 const days = Math.floor(hrs / 24);
 if (days === 1) return "Yesterday";
 return new Date(dateStr).toLocaleDateString("en-SG", { day: "numeric", month: "short" });
}

function formatTime(dateStr: string) {
 return new Date(dateStr).toLocaleTimeString("en-SG", { hour: "2-digit", minute: "2-digit" });
}

function formatDateHeader(dateStr: string) {
 const d = new Date(dateStr);
 const today = new Date();
 const yesterday = new Date(today);
 yesterday.setDate(today.getDate() - 1);
 if (d.toDateString() === today.toDateString()) return "Today";
 if (d.toDateString() === yesterday.toDateString()) return "Yesterday";
 return d.toLocaleDateString("en-SG", { weekday: "long", day: "numeric", month: "long" });
}

// ── Avatar ─────────────────────────────────────────────────────────────────────

const PALETTES = [
 "from-violet-400 to-purple-600",
 "from-sky-400 to-blue-600",
 "from-emerald-400 to-teal-600",
 "from-amber-400 to-orange-500",
 "from-pink-400 to-rose-600",
 "from-indigo-400 to-blue-600",
 "from-teal-400 to-cyan-600",
 "from-fuchsia-400 to-pink-600",
];

function avatarGradient(phone: string) {
 const n = parseInt(phone.slice(-3), 10) || 0;
 return PALETTES[n % PALETTES.length];
}

function getInitials(name: string | null, phone: string) {
 if (name) {
 const parts = name.trim().split(/\s+/);
 if (parts.length >= 2) return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
 return name.slice(0, 2).toUpperCase();
 }
 return phone.slice(-2);
}

function Avatar({ name, phone, size = "md" }: { name: string | null; phone: string; size?: "sm" | "md" | "lg" }) {
 const sz = { sm: "w-8 h-8 text-[11px]", md: "w-10 h-10 text-xs", lg: "w-14 h-14 text-base" };
 return (
 <div className={`rounded-full bg-gradient-to-br ${avatarGradient(phone)} ${sz[size]} flex items-center justify-center flex-shrink-0 font-bold text-white `}>
 {getInitials(name, phone)}
 </div>
 );
}

// ── WhatsApp markdown helpers ─────────────────────────────────────────────────

function stripWhatsAppMarkdown(text: string): string {
 return text
 .replace(/\*([^*\n]+)\*/g, "$1")
 .replace(/_([^_\n]+)_/g, "$1")
 .replace(/~([^~\n]+)~/g, "$1")
 .replace(/`([^`\n]+)`/g, "$1")
 .replace(/\n/g, " ")
 .trim();
}

function formatWhatsAppText(text: string): React.ReactNode {
 const segments: React.ReactNode[] = [];
 let remaining = text;
 let key = 0;

 while (remaining.length > 0) {
 const url=remaining.match(/^https?:\/\/[^\s<>]+/);
 const bold = remaining.match(/^\*([^*\n]+)\*/);
 const italic = remaining.match(/^_([^_\n]+)_/);
 const strike = remaining.match(/^~([^~\n]+)~/);
 const mono = remaining.match(/^`([^`\n]+)`/);
 const nl = remaining.match(/^(\n)/);

 if(url){
 const href=url[0].replace(/[.,;)]$/,"");
 segments.push(<a key={key++} href={href} target="_blank" rel="noopener noreferrer" className="underline break-all">{href}</a>);
 remaining=remaining.slice(href.length);
 } else if (bold) {
 segments.push(<strong key={key++} className="font-bold">{bold[1]}</strong>);
 remaining = remaining.slice(bold[0].length);
 } else if (italic) {
 segments.push(<em key={key++} className="italic">{italic[1]}</em>);
 remaining = remaining.slice(italic[0].length);
 } else if (strike) {
 segments.push(<del key={key++} className="line-through opacity-80">{strike[1]}</del>);
 remaining = remaining.slice(strike[0].length);
 } else if (mono) {
 segments.push(<code key={key++} className="font-mono text-[0.9em] bg-black/10 rounded px-0.5">{mono[1]}</code>);
 remaining = remaining.slice(mono[0].length);
 } else if (nl) {
 segments.push(<br key={key++} />);
 remaining = remaining.slice(1);
 } else {
 // consume characters until next special char or newline
 const nextSpecial = remaining.search(/[*_~`\n]|https?:\/\//);
 if (nextSpecial === -1) {
 segments.push(<span key={key++}>{remaining}</span>);
 remaining = "";
 } else if (nextSpecial === 0) {
 segments.push(<span key={key++}>{remaining[0]}</span>);
 remaining = remaining.slice(1);
 } else {
 segments.push(<span key={key++}>{remaining.slice(0, nextSpecial)}</span>);
 remaining = remaining.slice(nextSpecial);
 }
 }
 }
 return <>{segments}</>;
}

// ── Skeletons ──────────────────────────────────────────────────────────────────

function ConvoSkeleton() {
 return (
 <div className="px-4 py-3.5 border-b border-zinc-100 animate-pulse">
 <div className="flex items-start gap-3">
 <div className="w-10 h-10 rounded-full bg-zinc-200 flex-shrink-0" />
 <div className="flex-1 space-y-2 pt-1">
 <div className="flex justify-between">
 <div className="h-3.5 bg-zinc-200 rounded w-28" />
 <div className="h-2.5 bg-zinc-100 rounded w-8" />
 </div>
 <div className="h-2.5 bg-zinc-100 rounded w-44" />
 <div className="h-2.5 bg-zinc-100 rounded w-20" />
 </div>
 </div>
 </div>
 );
}

// ── InfoRow ────────────────────────────────────────────────────────────────────

function InfoRow({ icon, label, value, multiline = false }: {
 icon: React.ReactNode; label: string; value: string; multiline?: boolean;
}) {
 return (
 <div className="bg-zinc-50 rounded-lg px-3 py-2.5 border border-zinc-200">
 <div className="flex items-center gap-1.5 mb-1 text-zinc-400">
 {icon}
 <span className="text-[9px] uppercase tracking-wider font-semibold">{label}</span>
 </div>
 <p className={`text-xs text-zinc-700 leading-relaxed ${multiline ? "whitespace-pre-line" : "truncate"}`}>{value}</p>
 </div>
 );
}

// ── Message bubble (handles text + image) ──────────────────────────────────────

function MessageBubble({
  msg, isOut, isAdm, isBot, samePrev, sameNext, adminLabel, selectedPhone, selectedConvoName, onDelete, onRecovery,
}: {
 msg: WaMessage; isOut: boolean; isAdm: boolean; isBot: boolean;
 samePrev: boolean; sameNext: boolean; adminLabel: string | null;
 selectedPhone: string; selectedConvoName: string | null;
  onDelete: (id: number) => void; onRecovery: () => void;
}) {
 const [copied, setCopied] = useState(false);
 const [showTime, setShowTime] = useState(false);
 const holdTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
 const { toast } = useToast();

 const handleBubbleTouchStart = () => {
 holdTimerRef.current = setTimeout(() => {
 const text = msg.body?.startsWith("http") ? null : msg.body;
 if (!text) return;
 navigator.clipboard?.writeText(text).then(() => {
 setCopied(true);
 setTimeout(() => setCopied(false), 1500);
 }).catch(() => toast({ title: "Copy not supported in this browser" }));
 }, 600);
 };

 const handleBubbleTouchEnd = () => {
 if (holdTimerRef.current) { clearTimeout(holdTimerRef.current); holdTimerRef.current = null; }
 };

 const hasMedia=!!msg.mediaUrl||msg.hasAttachment===true;
 const isImage = msg.mediaType?.startsWith("image") ?? false;
 const isDocument = !isImage && !!msg.mediaUrl && !!msg.mediaType && !msg.mediaType.startsWith("video") && !msg.mediaType.startsWith("audio");
 const isVideo = msg.mediaType?.startsWith("video") ?? false;
 const isAudio = msg.mediaType?.startsWith("audio") ?? false;

 // Detect legacy [Document] body (no mediaUrl stored — old messages before fix)
 const isLegacyDoc = !msg.mediaUrl && (!!msg.mediaType || (msg.body?.startsWith("[Document") ?? false));

 // Detect special message types from body labels
 const reactionMatch = msg.body?.match(/^\[Reaction:\s*(.+)\]$/);
 const isReaction = !!reactionMatch;
 const reactionEmoji = reactionMatch?.[1] || "👍";
 const isVoiceNote = !msg.mediaUrl && msg.body === "[Voice note]";
 const isStickerMsg = !msg.mediaUrl && msg.body === "[Sticker]";
 const isLocationMsg = !msg.mediaUrl && msg.body === "[Location sent]";
 // Contact share — body is "[Contact shared]" / "[N contacts shared]" optionally
 // followed by detail lines ("Name — +65 1234 5678"). Detect the label, then
 // parse out the detail lines so we can render the actual name/phone instead of
 // the old "Open WhatsApp to view" placeholder.
 const contactLabelMatch = !msg.mediaUrl
 ? msg.body?.match(/^\[(?:\d+\s+)?contacts?\s+shared\]/i)
 : null;
 const isContactMsg = !!contactLabelMatch;
 const contactDetailLines = isContactMsg
 ? (msg.body || "")
 .split("\n")
 .slice(1)
 .map((l) => l.trim())
 .filter(Boolean)
 : [];
 const isUnsupported = !msg.mediaUrl && (msg.body === "[Message]" || (msg.body?.startsWith("[Unsupported") ?? false) || (msg.body?.startsWith("[System:") ?? false));
 // Pull out the human-readable reason the server captured, when present:
 //   "[Unsupported: <reason>]" or "[System: <reason>]" → "<reason>"
 const unsupportedDetail = msg.body?.match(/^\[(?:Unsupported|System):\s*(.+)\]$/)?.[1]?.trim() || null;

 // Resolve all media by inbox message ID through the authenticated media route.
 const mediaSrc = msg.mediaUrl ? `${API_BASE}/api/admin/whatsapp/messages/${msg.id}/media` : null;
 const imgSrc = isImage ? mediaSrc : null;

 // Filename: prefer body text when it contains [Document: filename.pdf], else use mime type
 const docFilename = (() => {
 if(msg.mediaFilename)return msg.mediaFilename;
 const m = msg.body?.match(/^\[Document:\s*(.+)\](?:\n|$)/);
 if (m) return m[1];
 if (msg.mediaType && msg.mediaType !== 'application/octet-stream') {
 const ext = msg.mediaType.split("/")[1]?.split(";")[0] || "file";
 return `document.${ext}`;
 }
 return "document";
 })();

 const isNote = !!msg.sentBy?.startsWith("note:");
 const noteAuthor = isNote ? msg.sentBy!.replace("note:", "") : null;

 const bubbleStyle = isNote
 ? "bg-[#fffbd5] text-amber-900 border border-amber-200 "
 : isOut
 ? isAdm
 ? "bg-[#d9fdd3] text-gray-900"
 : "bg-[#d9fdd3] text-gray-900"
 : "bg-white text-gray-800 ";

 // WhatsApp-style: first message in group gets a "tail", grouped ones are slightly smaller radius
 const radius = isOut
 ? `rounded-[12px] ${samePrev ? "rounded-tr-[4px]" : ""} ${sameNext ? "rounded-br-[4px]" : ""}`
 : `rounded-[12px] ${samePrev ? "rounded-tl-[4px]" : ""} ${sameNext ? "rounded-bl-[4px]" : ""}`;

 const topGap = samePrev ? "mt-[2px]" : "mt-4";

 return (
 <>
 <div
 key={msg.id}
 data-testid={`msg-${msg.id}`}
 className={`flex items-end gap-2 ${isOut ? "justify-end" : "justify-start"} ${topGap} relative`}
 onTouchStart={handleBubbleTouchStart}
 onTouchEnd={handleBubbleTouchEnd}
 onTouchMove={handleBubbleTouchEnd}
 onClick={() => setShowTime(v => !v)}
 onContextMenu={e => { e.preventDefault(); handleBubbleTouchStart(); setTimeout(handleBubbleTouchEnd, 100); }}
 >
 {copied && (
 <span className={`absolute z-20 -top-7 text-[11px] font-semibold px-2.5 py-1 rounded-full bg-zinc-800 text-white flex items-center gap-1 pointer-events-none ${isOut ? "right-0" : "left-0"}`}>
 <Copy className="w-3 h-3" /> Copied
 </span>
 )}
 {/* Inbound avatar */}
 {!isOut && (
 <div className="w-8 flex-shrink-0 self-end mb-0.5">
 {!sameNext && (
 <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${avatarGradient(selectedPhone)} flex items-center justify-center text-white text-[10px] font-bold`}>
 {getInitials(selectedConvoName, selectedPhone)}
 </div>
 )}
 </div>
 )}

 {/* Bubble */}
 <div className="max-w-[72%] sm:max-w-[60%] lg:max-w-[55%]">
 {isNote && !samePrev && (
 <div className="flex items-center justify-end gap-1 mb-1 mr-1">
 <StickyNote className="w-3 h-3 text-amber-500" />
 <p className="text-[10px] text-amber-600 font-semibold">Internal Note · {noteAuthor || "Admin"}</p>
 </div>
 )}
 {isAdm && !isNote && !samePrev && (
 <p className="text-[10px] text-gray-400 text-right mb-0.5 mr-1 font-semibold">
 {adminLabel || "Admin"}
 </p>
 )}

 {/* Image bubble */}
  {isImage && msg.mediaUrl ? (
  <div className={`overflow-hidden ${radius} ${bubbleStyle} p-2`}>
  <WhatsappMessageMedia messageId={msg.id} mediaType={msg.mediaType} filename={docFilename} />
 {msg.body && !msg.body.startsWith("http") && msg.body !== "[image]" && (
 <p className="text-sm px-2 pt-1 pb-0.5 leading-relaxed break-words">{formatWhatsAppText(msg.body)}</p>
 )}
 </div>

  ) : isDocument && msg.mediaUrl ? (
  <div className={`px-3 py-2 ${radius} ${bubbleStyle}`}>
  <WhatsappMessageMedia messageId={msg.id} mediaType={msg.mediaType} filename={docFilename} />
  </div>

  ) : isVideo && msg.mediaUrl ? (
  <div className={`overflow-hidden ${radius} ${bubbleStyle} p-2`}>
  <WhatsappMessageMedia messageId={msg.id} mediaType={msg.mediaType} filename={docFilename} />
 {msg.body && msg.body !== "[Video]" && (
 <p className="text-sm px-2 pt-1 pb-0.5 leading-relaxed break-words">{formatWhatsAppText(msg.body)}</p>
 )}
 </div>

  ) : isAudio && hasMedia ? (
  <div className={`px-3 py-2 ${radius} ${bubbleStyle}`}>
  <WhatsappMessageMedia messageId={msg.id} mediaType={msg.mediaType} filename={docFilename} />
 </div>

  ) : hasMedia ? (
  <div className={`px-3 py-2 ${radius} ${bubbleStyle}`}>
  <WhatsappMessageMedia messageId={msg.id} mediaType={msg.mediaType} filename={docFilename} />
  </div>

 ) : isLegacyDoc ? (
 /* Legacy document — no media URL stored, show label with warning */
 <div className={`flex items-center gap-3 px-4 py-3 ${radius} ${bubbleStyle} min-w-[200px]`}>
 <div className={`p-2 rounded-lg flex-shrink-0 ${isOut ? "bg-white/20" : "bg-gray-100"}`}>
 <FileText className="w-5 h-5 flex-shrink-0 opacity-60" />
 </div>
 <div className="flex-1 min-w-0">
 <p className="text-sm font-semibold">{isImage ? "Image attachment" : "Attachment"}</p>
 <p className={`text-[11px] mt-0.5 ${isOut ? "opacity-60" : "text-gray-400"}`}>
 Original file unavailable. Ask the customer to resend it.
 </p>
 </div>
 </div>

 ) : isReaction ? (
 /* Reaction bubble — large emoji pill */
 <div className={`flex items-center gap-2 px-3 py-1.5 ${radius} bg-white/80 border border-black/8 `}>
 <span className="text-2xl leading-none">{reactionEmoji}</span>
 <span className="text-[11px] text-gray-400 italic">Reaction</span>
 </div>

 ) : isVoiceNote ? (
 /* Voice note — no media stored, prompt to open WhatsApp */
 <div className={`flex items-center gap-3 px-4 py-3 ${radius} ${bubbleStyle} min-w-[180px]`}>
 <Mic className="w-4 h-4 flex-shrink-0 text-[#25D366]" />
 <div>
 <p className="text-sm font-semibold">Voice message</p>
 <p className={`text-[11px] mt-0.5 ${isOut ? "opacity-60" : "text-gray-400"}`}>Open WhatsApp to listen</p>
 </div>
 </div>

 ) : isStickerMsg ? (
 /* Sticker label */
 <div className={`flex items-center gap-2 px-3.5 py-2 ${radius} ${bubbleStyle}`}>
 <span className="text-xl">🎭</span>
 <span className="text-sm italic opacity-60">Sticker</span>
 </div>

 ) : isLocationMsg ? (
 /* Location shared */
 <div className={`flex items-center gap-3 px-4 py-3 ${radius} ${bubbleStyle} min-w-[180px]`}>
 <MapPin className="w-4 h-4 flex-shrink-0 text-red-500" />
 <div>
 <p className="text-sm font-semibold">Location shared</p>
 <p className={`text-[11px] mt-0.5 ${isOut ? "opacity-60" : "text-gray-400"}`}>Open WhatsApp to view</p>
 </div>
 </div>

 ) : isContactMsg ? (
 /* Contact shared — show the actual name/phone when we captured it */
 <div className={`flex items-start gap-3 px-4 py-3 ${radius} ${bubbleStyle} min-w-[180px] max-w-[280px]`}>
 <User className="w-4 h-4 flex-shrink-0 text-blue-500 mt-0.5" />
 <div className="min-w-0">
 <p className="text-sm font-semibold">
 {contactDetailLines.length > 1 ? `${contactDetailLines.length} contacts shared` : "Contact shared"}
 </p>
 {contactDetailLines.length > 0 ? (
 <div className="mt-0.5 space-y-0.5">
 {contactDetailLines.map((line, i) => (
 <p key={i} className="text-[13px] leading-snug break-words" data-testid={`text-shared-contact-${i}`}>
 {line}
 </p>
 ))}
 </div>
 ) : (
 <p className={`text-[11px] mt-0.5 ${isOut ? "opacity-60" : "text-gray-400"}`}>Open WhatsApp to view</p>
 )}
 </div>
 </div>

 ) : isUnsupported ? (
 /* Unknown / unsupported message type */
 <div className={`flex items-center gap-3 px-4 py-3 ${radius} ${bubbleStyle} min-w-[180px] opacity-70`}>
 <MessageSquare className="w-4 h-4 flex-shrink-0 text-gray-400" />
 <div>
 <p className="text-sm italic text-gray-500" data-testid={`text-unsupported-${msg.id}`}>{unsupportedDetail || "Message not displayable here"}</p>
 <p className={`text-[11px] mt-0.5 text-gray-400`}>Open WhatsApp to view</p>
 </div>
 </div>

 ) : (
 /* Text bubble */
 <div className={`px-3.5 py-2 text-sm leading-relaxed break-words ${radius} ${bubbleStyle}`}>
 {isImage && !imgSrc ? (
 <span className="flex items-center gap-2 opacity-70">
 <ImageIcon className="w-4 h-4 flex-shrink-0" />
 <span className="italic">Photo</span>
 </span>
 ) : (
 formatWhatsAppText(msg.body || "")
 )}
 </div>
 )}

 {(!sameNext || showTime) && (
 <div className={`flex items-center gap-1 mt-0.5 ${isOut ? "justify-end pr-1" : "pl-1"}`}>
 <span className="text-[10px] text-gray-400/80 tabular-nums">
 {showTime
 ? new Date(msg.createdAt).toLocaleString("en-SG", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })
 : formatTime(msg.createdAt)}
 </span>
 {isNote && <StickyNote className="w-3 h-3 text-amber-400" />}
 {isBot && <Bot className="w-3 h-3 text-gray-400" />}
 {isOut && !isNote && <span className={`text-[10px] ${["failed", "blocked"].includes((msg.deliveryStatus || "").toLowerCase()) ? "text-red-700" : "text-gray-500"}`}>
   {({ sent: "Accepted", delivered: "Delivered", read: "Read", failed: "Failed", blocked: "Blocked", unknown: "Unconfirmed" } as Record<string, string>)[(msg.deliveryStatus || "unknown").toLowerCase()] || "Unconfirmed"}
 </span>}
 {isOut && !isNote && ["delivered", "read"].includes((msg.deliveryStatus || "").toLowerCase()) && <CheckCheck className="w-3 h-3 text-[#53bdeb]" />}
 {isOut && !isNote && (msg.deliveryError || ["failed", "blocked", "unknown", "sending", "pending", "processing"].includes((msg.deliveryStatus || "").toLowerCase())) && <div role="status" className="mt-1 max-w-full break-words rounded border border-red-200 bg-red-50 px-2 py-1.5 text-[11px] leading-snug text-red-800">
   {msg.deliveryError || "No additional delivery detail was recorded."}
   {["failed", "blocked"].includes((msg.deliveryStatus || "").toLowerCase()) && <span className="block font-semibold">Retry a definite failure from Delivery recovery.</span>}
   {["unknown", "sending", "pending", "processing"].includes((msg.deliveryStatus || "").toLowerCase()) && <span className="block font-semibold">Reconcile first; do not resend blindly.</span>}
   {["failed", "blocked", "unknown", "sending", "pending", "processing"].includes((msg.deliveryStatus || "").toLowerCase()) && <button type="button" onClick={e => { e.stopPropagation(); onRecovery(); }} className="mt-1 font-semibold underline">Open delivery recovery</button>}
 </div>}
 {showTime && (
 <button
 type="button"
 data-testid={`button-delete-msg-${msg.id}`}
 className="ml-1 flex items-center gap-1 text-[10px] font-semibold text-red-400 hover:text-red-600 transition-colors"
 onClick={(e) => {
 e.stopPropagation();
 if (window.confirm("Delete this message from the inbox?\n\nThis only removes it here — the customer still sees it in WhatsApp.")) {
 onDelete(msg.id);
 }
 }}
 >
 <Trash2 className="w-3 h-3" /> Delete
 </button>
 )}
 </div>
 )}
 </div>

 {/* Outbound avatar */}
 {isOut && (
 <div className="w-8 flex-shrink-0 self-end mb-0.5">
 {!sameNext && (
 isBot
 ? <div className="w-8 h-8 rounded-full bg-[#25D366]/10 border border-[#25D366]/20 flex items-center justify-center">
 <Bot className="w-4 h-4 text-[#25D366]" />
 </div>
 : <div className="w-8 h-8 rounded-full bg-indigo-100 border border-indigo-200 flex items-center justify-center">
 <User className="w-4 h-4 text-indigo-600" />
 </div>
 )}
 </div>
 )}
 </div>
 </>
 );
}

// ── Chat Panel ─────────────────────────────────────────────────────────────────

function ChatPanel({
 selectedPhone,
 selectedConvo,
 onClose,
 composer,
}: {
 selectedPhone: string;
 selectedConvo: Conversation | undefined;
 onClose: () => void;
 composer:ComposerSession;
}) {
 const [replyText, setReplyText] = useState("");
 const [noteMode, setNoteModeState] = useState(()=>composer.notes[selectedPhone]||false);
 const setNoteMode=(value:boolean)=>{composer.notes[selectedPhone]=value;setNoteModeState(value);};
 const [showQuickReplies, setShowQuickReplies] = useState(false);
 const [showEmojiPicker, setShowEmojiPicker] = useState(false);
 const [showInfo, setShowInfo] = useState(false);
 const [showMobileInfo, setShowMobileInfo] = useState(false);
 const [generatedQuote, setGeneratedQuote] = useState<{ quoteId: number; referenceNo: string } | null>(null);
 const [attachFile, setAttachFile] = useState<File | null>(null);
 const [previewUrl, setPreviewUrl] = useState<string | null>(null);
 const [showResetConfirm, setShowResetConfirm] = useState(false);
 const [showTemplates, setShowTemplates] = useState(false);
 const [showSearch, setShowSearch] = useState(false);
 const [searchQuery, setSearchQuery] = useState("");
 const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [sendErrors, setSendErrors] = useState<Record<string, string>>({});
  const [networkRetries, setNetworkRetries] = useState<Record<string, { kind: "text"; payload: TextSendPayload } | { kind: "file"; payload: FileSendPayload }>>({});
  const [failedAttempts, setFailedAttempts] = useState<Record<string, DeliveryAttemptBlock>>({});
  const [uncertainAttempts, setUncertainAttempts] = useState<Record<string, DeliveryAttemptBlock>>({});
  const [quoteBlockedAttempts, setQuoteBlockedAttempts] = useState<Record<string, { phone: string; id?: number; status: string }>>({});
  const [showQuoteShare, setShowQuoteShare] = useState(false);
  const [selectedShareQuote, setSelectedShareQuote] = useState("");
 const searchInputRef = useRef<HTMLInputElement>(null);
 const messagesEndRef = useRef<HTMLDivElement>(null);
 const chatScrollRef = useRef<HTMLDivElement>(null);
 const [hasNewMessages, setHasNewMessages] = useState(false);
 const textareaRef = useRef<HTMLTextAreaElement>(null);
 const fileInputRef = useRef<HTMLInputElement>(null);
 const emojiPickerRef = useRef<HTMLDivElement>(null);
  const chatDraftsRef = {current:composer.drafts};
  const requestIdsRef = {current:composer.requests};
  const activePhoneRef=useRef(selectedPhone);
  activePhoneRef.current=selectedPhone;
  const actionLocksRef = {current:composer.actions};
  const noteLocksRef = useRef(new Set<string>());
  const quoteRequestIdsRef = {current:composer.quoteRequests};
  const quoteLocksRef = {current:composer.quoteActions};
 const queryClient = useQueryClient();
 const { toast } = useToast();

  const getRequestId = (phone: string, signature: string) => {
    const current = requestIdsRef.current[phone];
    if (current?.signature === signature) return current.requestId;
    const requestId = crypto.randomUUID();
    requestIdsRef.current[phone] = { signature, requestId };
    return requestId;
  };
  const forgetRequestId = (phone: string) => { delete requestIdsRef.current[phone]; };
  const textSignature = (message: string) => `text:${message}`;
  const fileSignature = (file: File, caption: string) => `file:${file.name}:${file.size}:${file.lastModified}:${file.type}:${caption}`;
  const quoteAttemptKey = (phone: string, quoteId: number, version: number) => `${phone}:${quoteId}:v${version}`;
  const updateReplyText = (nextText: string) => {
    chatDraftsRef.current[selectedPhone] = { text: nextText, file: attachFile };
    if (nextText !== replyText) {
      forgetRequestId(selectedPhone);
      if (!uncertainAttempts[selectedPhone] && !networkRetries[selectedPhone]) {
        setSendErrors(current => { const next = { ...current }; delete next[selectedPhone]; return next; });
      }
    }
    setReplyText(nextText);
  };

 /* Auto-resize textarea as content grows */
 useEffect(() => {
 const ta = textareaRef.current;
 if (!ta) return;
 ta.style.height = "auto";
 ta.style.height = `${Math.min(ta.scrollHeight, 140)}px`;
 }, [replyText]);

 /* Reply bar is in-flow (flex-shrink-0 at bottom of right panel flex column).
 No fixed positioning needed: interactive-widget=resizes-content in index.html
 causes the layout viewport to shrink with the keyboard, so in-flow elements
 at the container bottom are always visible above the keyboard. */

 /* When keyboard opens on mobile (viewport shrinks), scroll to bottom */
 useEffect(() => {
 const onVpResize = () => {
 const scroll = chatScrollRef.current;
 if (!scroll) return;
 setTimeout(() => {
 scroll.scrollTop = scroll.scrollHeight;
 }, 120);
 };
 window.visualViewport?.addEventListener("resize", onVpResize);
 return () => window.visualViewport?.removeEventListener("resize", onVpResize);
 }, []);

 const { data: thread, isLoading: loadingThread } = useQuery<ThreadData>({
 queryKey: ["/api/admin/whatsapp/conversations", selectedPhone],
 queryFn: async ({signal}) => {
 const phone=selectedPhone;
 const res = await fetch(`${API_BASE}/api/admin/whatsapp/conversations/${phone}`, { credentials: "include", signal });
 if(!res.ok)throw new Error("Conversation could not be loaded. Please retry.");
 return {...await res.json(),recipientPhone:phone};
 },
 refetchInterval: 5_000,
 refetchIntervalInBackground: true,
 });

 useEffect(() => {
   const attempt = uncertainAttempts[selectedPhone];
   if (!attempt || attempt.id == null || !thread?.messages) return;
   const message = thread.messages.find(item => item.id === attempt.id);
   const status = String(message?.deliveryStatus || "").toLowerCase();
   if (!message || ["unknown", "sending", "pending", "processing"].includes(status)) return;
   setUncertainAttempts(current => {
     if (current[selectedPhone]?.requestId !== attempt.requestId) return current;
     const next = { ...current };
     delete next[selectedPhone];
     return next;
   });
   if (["failed", "blocked"].includes(status)) {
     setFailedAttempts(current => ({ ...current, [selectedPhone]: { ...attempt, status } }));
     setSendErrors(current => ({ ...current, [selectedPhone]: message.deliveryError || `${status} — use Delivery recovery and provide an accountable retry reason.` }));
   } else if (["sent", "delivered", "read"].includes(status)) {
     if (requestIdsRef.current[selectedPhone]?.requestId === attempt.requestId) forgetRequestId(selectedPhone);
     setSendErrors(current => { const next = { ...current }; delete next[selectedPhone]; return next; });
     const current = chatDraftsRef.current[selectedPhone];
     if (attempt.kind === "text" && current && current.text.trim() === attempt.signature.slice("text:".length) && !current.file) {
       chatDraftsRef.current[selectedPhone] = { text: "", file: null };
       setReplyText("");
     }
     if (attempt.kind === "file" && current?.file && fileSignature(current.file, current.text.trim()) === attempt.signature) {
       chatDraftsRef.current[selectedPhone] = { text: "", file: null };
       setReplyText("");
       clearAttach();
     }
   }
 }, [thread?.messages, selectedPhone, uncertainAttempts]);

 useEffect(() => {
   if (!thread?.messages) return;
   for (const [key, attempt] of Object.entries(quoteBlockedAttempts)) {
     if (attempt.phone !== selectedPhone || attempt.id == null) continue;
     const message = thread.messages.find(item => item.id === attempt.id);
     const status = String(message?.deliveryStatus || "").toLowerCase();
     if (!["sent", "delivered", "read"].includes(status)) continue;
     setQuoteBlockedAttempts(current => { const next = { ...current }; delete next[key]; return next; });
     delete quoteRequestIdsRef.current[key];
   }
 }, [thread?.messages, selectedPhone, quoteBlockedAttempts]);

 const { data: dbCannedReplies = [] } = useQuery<{ id: number; shortcut: string; title: string; body: string; active: boolean }[]>({
 queryKey: ["/api/admin/canned-replies"],
 });

 const shareableQuotesQuery = useQuery<{ id: number; referenceNo: string; version: number; total: number; url: string }[]>({
   queryKey: ["/api/admin/whatsapp/conversations", selectedPhone, "shareable-quotes"],
   queryFn: async () => (await apiRequest("GET", `/api/admin/whatsapp/conversations/${encodeURIComponent(selectedPhone)}/shareable-quotes`)).json(),
   enabled: !!selectedPhone && showQuoteShare,
 });
 const currentQuotation = useQuery<{quote:{id:number}|null;staffDocument?:{mediaUrl:string;status:string}}>({
   queryKey:["/api/admin/whatsapp-first/conversations",selectedPhone,"internal-quotation"],
   queryFn:async({signal})=>{
     const response=await fetch(`/api/admin/whatsapp-first/conversations/${encodeURIComponent(selectedPhone!)}/internal-quotation`,{credentials:"include",signal});
     if(!response.ok)throw new Error("Current quotation could not be loaded");
     return response.json();
   },enabled:!!selectedPhone,
 });
 const shareQuoteMutation = useMutation({
   mutationFn: async (payload: { phone: string; quoteId: number; expectedVersion: number; requestId: string; attemptKey: string }) => {
     const result = await postWhatsAppJson(`/api/admin/whatsapp/conversations/${encodeURIComponent(payload.phone)}/share-quote`, {
       quoteId: payload.quoteId, expectedVersion: payload.expectedVersion, requestId: payload.requestId,
     });
     return { result, payload };
   },
   onSuccess: ({ result, payload }) => {
     quoteLocksRef.current.delete(payload.attemptKey);
     if (quoteRequestIdsRef.current[payload.attemptKey] === payload.requestId) delete quoteRequestIdsRef.current[payload.attemptKey];
     setQuoteBlockedAttempts(current => { const next = { ...current }; delete next[payload.attemptKey]; return next; });
     refreshThread(payload.phone);
     toast({ title: "Quotation accepted by WhatsApp", description: result.status === "sent" ? "Accepted for sending; delivery is not yet confirmed." : `Provider status: ${result.status}.` });
     setShowQuoteShare(false);
   },
   onError: (error: Error, payload) => {
     if (payload?.attemptKey) quoteLocksRef.current.delete(payload.attemptKey);
     if (payload?.phone) refreshThread(payload.phone);
     const result = (error as any).deliveryResult;
     if (payload?.attemptKey && result?.status && !["sent", "delivered", "read"].includes(String(result.status).toLowerCase())) {
       setQuoteBlockedAttempts(current => ({ ...current, [payload.attemptKey]: { phone: payload.phone, id: result.id != null ? Number(result.id) : undefined, status: String(result.status).toLowerCase() } }));
     }
     const detail = [result?.status ? `Status ${result.status}` : "", result?.id != null ? `attempt #${result.id}` : ""].filter(Boolean).join(" · ");
     toast({ title: "Quotation share not confirmed", description: `${error.message}${detail ? ` (${detail})` : ""} Reconcile delivery before sharing again if the outcome is unconfirmed.`, variant: "destructive" });
   },
 });

 const refreshThread = (phone: string) => {
   queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations", phone] });
   queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations"] });
 };
 const sendMutation = useMutation({
 mutationFn: async (payload: TextSendPayload) => {
   const result = await postWhatsAppJson(`/api/admin/whatsapp/conversations/${encodeURIComponent(payload.phone)}/send`, { message: payload.message, requestId: payload.requestId });
   return { result, payload };
 },
 onSuccess: ({ result, payload }) => {
   actionLocksRef.current.delete(payload.phone);composer.changed();
   if (requestIdsRef.current[payload.phone]?.requestId === payload.requestId) forgetRequestId(payload.phone);
   setFailedAttempts(current => current[payload.phone]?.requestId === payload.requestId ? (() => { const next = { ...current }; delete next[payload.phone]; return next; })() : current);
   setUncertainAttempts(current => current[payload.phone]?.requestId === payload.requestId ? (() => { const next = { ...current }; delete next[payload.phone]; return next; })() : current);
   setSendErrors(current => { const next = { ...current }; delete next[payload.phone]; return next; });
   setNetworkRetries(current => { const next = { ...current }; delete next[payload.phone]; return next; });
   const current = chatDraftsRef.current[payload.phone];
   if (current?.text.trim() === payload.message && !current.file) {
     chatDraftsRef.current[payload.phone] = { text: "", file: null };
     if (activePhoneRef.current === payload.phone) setReplyText("");
   }
   setShowQuickReplies(false);
   refreshThread(payload.phone);
   toast({ title: "Accepted by WhatsApp", description: result.status === "sent" ? "Accepted for sending; delivery is not yet confirmed." : `Provider status: ${result.status}.` });
 },
 onError: (err: any, payload) => {
   actionLocksRef.current.delete(payload.phone);composer.changed();
   const result = err?.deliveryResult;
   const status = String(result?.status || "").toLowerCase();
   const attempt: DeliveryAttemptBlock = { id: result?.id != null && Number.isFinite(Number(result.id)) ? Number(result.id) : undefined, status, requestId: payload.requestId, signature: payload.signature, kind: "text" };
   if (["failed", "blocked"].includes(status)) {
     setFailedAttempts(current => ({ ...current, [payload.phone]: attempt }));
     setUncertainAttempts(current => { const next = { ...current }; delete next[payload.phone]; return next; });
   }
   if (["unknown", "sending", "pending", "processing"].includes(status) || !status || err instanceof TypeError) setUncertainAttempts(current => ({ ...current, [payload.phone]: { ...attempt, status: status || "unknown" } }));
   const reason = result?.reason || result?.message || err?.message || "Could not send message";
   setSendErrors(current => ({ ...current, [payload.phone]: reason }));
   setNetworkRetries(current => {
     const next = { ...current };
     if (err instanceof TypeError || !status) next[payload.phone] = { kind: "text", payload };
     else delete next[payload.phone];
     return next;
   });
   refreshThread(payload.phone);
   toast({ title: "Message not confirmed", description: reason, variant: "destructive" });
 },
 });

 const pauseBotMutation = useMutation({
 mutationFn: () => apiRequest("POST", `/api/admin/whatsapp/conversations/${selectedPhone}/pause-bot`),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations", selectedPhone] });
 toast({ title: "Bot paused — you are now in Admin Mode" });
 },
 onError: () => toast({ title: "Failed to pause bot", variant: "destructive" }),
 });

 const resumeBotMutation = useMutation({
 mutationFn: () => apiRequest("POST", `/api/admin/whatsapp/conversations/${selectedPhone}/resume-bot`),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations", selectedPhone] });
 toast({ title: "Bot resumed — AI is back in control" });
 },
 onError: () => toast({ title: "Failed to resume bot", variant: "destructive" }),
 });

 const generateQuoteMutation = useMutation({
 mutationFn: (phone:string) => apiRequest("POST", `/api/admin/whatsapp/conversations/${phone}/generate-quote`),
 onSuccess: (data: any,phone:string) => {
 queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations", phone] });
 queryClient.invalidateQueries({ queryKey: ["/api/quotes"] });
 if(phone!==activePhoneRef.current)return;
 setGeneratedQuote({ quoteId: data.quoteId, referenceNo: data.referenceNo });
 toast({ title: `Quote ${data.referenceNo} created!`, description: "Opening quote in a new tab…" });
 window.open(`/admin/quotes/${data.quoteId}?edit=1`, "_blank");
 },
 onError: (err: any) => toast({ title: "Could not generate quote", description: err?.message || "Check that address has been collected", variant: "destructive" }),
 });

 const deleteMessageMutation = useMutation({
 mutationFn: async (messageId: number) => apiRequest("DELETE", `/api/admin/whatsapp/conversations/${selectedPhone}/messages/${messageId}`),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations", selectedPhone] });
 queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations"] });
 toast({ title: "Message deleted", description: "Removed from this inbox only — the customer still sees it in WhatsApp." });
 },
 onError: (err: any) => toast({ title: "Failed to delete message", description: err?.message, variant: "destructive" }),
 });

 const noteMutation = useMutation({
 mutationFn: async (payload: { phone: string; note: string }) => apiRequest("POST", `/api/admin/whatsapp/conversations/${encodeURIComponent(payload.phone)}/note`, { note: payload.note }),
 onSuccess: (_response, payload) => {
 noteLocksRef.current.delete(payload.phone);
 const current = chatDraftsRef.current[payload.phone];
 if (current?.text === payload.note && !current.file) {
   chatDraftsRef.current[payload.phone] = { text: "", file: null };
   if (selectedPhone === payload.phone) setReplyText("");
 }
 queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations", payload.phone] });
 toast({ title: "Note added" });
 },
 onError: (err: any, payload) => { noteLocksRef.current.delete(payload.phone); toast({ title: "Failed to add note", description: err?.message, variant: "destructive" }); },
 });

 const sendFileMutation = useMutation({
 mutationFn: async (payload: FileSendPayload) => {
 const formData = new FormData();
 formData.append("file", payload.file);
 if (payload.caption) formData.append("caption", payload.caption);
 formData.append("requestId", payload.requestId);
 const res = await fetch(`${API_BASE}/api/admin/whatsapp/conversations/${encodeURIComponent(payload.phone)}/send-media`, {
 method: "POST",
 credentials: "include",
 body: formData,
 });
 const result = await res.json().catch(() => ({}));
 if (!res.ok || !result.ok || !["sent", "delivered", "read"].includes(result.status)) throw deliveryFailure(result, res.status);
 return { result, payload };
 },
 onSuccess: ({ result, payload }) => {
 actionLocksRef.current.delete(payload.phone);composer.changed();
 if (requestIdsRef.current[payload.phone]?.requestId === payload.requestId) forgetRequestId(payload.phone);
 setFailedAttempts(current => current[payload.phone]?.requestId === payload.requestId ? (() => { const next = { ...current }; delete next[payload.phone]; return next; })() : current);
 setUncertainAttempts(current => current[payload.phone]?.requestId === payload.requestId ? (() => { const next = { ...current }; delete next[payload.phone]; return next; })() : current);
 setSendErrors(current => { const next = { ...current }; delete next[payload.phone]; return next; });
 setNetworkRetries(current => { const next = { ...current }; delete next[payload.phone]; return next; });
 const current = chatDraftsRef.current[payload.phone];
 if (current?.text.trim() === (payload.caption || "") && current.file === payload.file) {
   chatDraftsRef.current[payload.phone] = { text: "", file: null };
   if (activePhoneRef.current === payload.phone) {
     setReplyText("");
     clearAttach();
   }
 }
 setShowQuickReplies(false);
 refreshThread(payload.phone);
 toast({ title: "Attachment accepted by WhatsApp", description: result.status === "sent" ? "Accepted for sending; delivery is not yet confirmed." : `Provider status: ${result.status}.` });
 },
 onError: (err: any, payload) => {
   actionLocksRef.current.delete(payload.phone);composer.changed();
   const result = err?.deliveryResult;
   const status = String(result?.status || "").toLowerCase();
   const attempt: DeliveryAttemptBlock = { id: result?.id != null && Number.isFinite(Number(result.id)) ? Number(result.id) : undefined, status, requestId: payload.requestId, signature: payload.signature, kind: "file" };
   if (["failed", "blocked"].includes(status)) {
     setFailedAttempts(current => ({ ...current, [payload.phone]: attempt }));
     setUncertainAttempts(current => { const next = { ...current }; delete next[payload.phone]; return next; });
   }
   if (["unknown", "sending", "pending", "processing"].includes(status) || !status || err instanceof TypeError) setUncertainAttempts(current => ({ ...current, [payload.phone]: { ...attempt, status: status || "unknown" } }));
   setSendErrors(current => ({ ...current, [payload.phone]: result?.reason || result?.message || err?.message || "Attachment was not confirmed." }));
   setNetworkRetries(current => {
     const next = { ...current };
     if (err instanceof TypeError || !status) next[payload.phone] = { kind: "file", payload };
     else delete next[payload.phone];
     return next;
   });
   refreshThread(payload.phone);
   toast({ title: "Attachment not confirmed", description: err?.message, variant: "destructive" });
 },
 });

 const resetSessionMutation = useMutation({
 mutationFn: () => apiRequest("DELETE", `/api/admin/whatsapp/conversations/${selectedPhone}/session`),
 onSuccess: () => {
 setShowResetConfirm(false);
 queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations", selectedPhone] });
 queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations"] });
 toast({ title: "Session cleared", description: "The bot will restart from the beginning on the next message." });
 },
 onError: () => toast({ title: "Failed to reset session", variant: "destructive" }),
 });

 const markReadMutation = useMutation({
 mutationFn: () => apiRequest("POST", `/api/admin/whatsapp/conversations/${selectedPhone}/mark-read`),
 onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations"] }),
 });

 /* Mark conversation as done — resumes bot and marks all as read */
 const markDoneMutation = useMutation({
 mutationFn: async () => {
 await apiRequest("POST", `/api/admin/whatsapp/conversations/${selectedPhone}/resume-bot`);
 await apiRequest("POST", `/api/admin/whatsapp/conversations/${selectedPhone}/mark-read`);
 },
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations", selectedPhone] });
 queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations"] });
 toast({ title: "Conversation marked as done", description: "Bot resumed, all messages marked read." });
 },
 onError: () => toast({ title: "Failed to mark done", variant: "destructive" }),
 });

 const isNearBottom = () => {
 const el = chatScrollRef.current;
 if (!el) return true;
 return el.scrollHeight - el.scrollTop - el.clientHeight < 120;
 };

 const scrollToBottom = (smooth = true) => {
 messagesEndRef.current?.scrollIntoView({ behavior: smooth ? "smooth" : "instant" });
 setHasNewMessages(false);
 };

 useEffect(() => {
 if (isNearBottom()) scrollToBottom(true);
 else setHasNewMessages(true);
 }, [thread?.messages?.length]);

 useEffect(() => {
 setTimeout(() => scrollToBottom(false), 80);
 }, [selectedPhone]);

 // Auto-mark messages as read when opening a conversation
 useEffect(() => {
 if (thread?.messages?.length) markReadMutation.mutate();
 }, [selectedPhone, thread?.messages?.length]);

 useEffect(() => {
 const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
 document.addEventListener("keydown", handler);
 return () => document.removeEventListener("keydown", handler);
 }, [onClose]);

 useEffect(() => {
 if (!showEmojiPicker) return;
 const handler = (e: MouseEvent) => {
 if (emojiPickerRef.current && !emojiPickerRef.current.contains(e.target as Node)) setShowEmojiPicker(false);
 };
 document.addEventListener("mousedown", handler);
 return () => document.removeEventListener("mousedown", handler);
 }, [showEmojiPicker]);

 // Reset state when switching conversations
 useEffect(() => {
 setNoteModeState(composer.notes[selectedPhone]||false);
 const savedDraft = chatDraftsRef.current[selectedPhone] || { text: "", file: null };
 chatDraftsRef.current[selectedPhone] = savedDraft;
 setReplyText(savedDraft.text);
 setAttachFile(savedDraft.file);
 if (previewUrl) URL.revokeObjectURL(previewUrl);
 setPreviewUrl(savedDraft.file ? URL.createObjectURL(savedDraft.file) : null);
 if (fileInputRef.current) fileInputRef.current.value = "";
 setGeneratedQuote(null);
 setShowResetConfirm(false);
 setShowMobileInfo(false);
 setShowTemplates(false);
 setShowQuickReplies(false);
 setShowEmojiPicker(false);
 setShowSearch(false);
 setSearchQuery("");
 setShowQuoteShare(false);
 setSelectedShareQuote("");
 }, [selectedPhone]);

 function clearAttach(invalidateRequest = false) {
 if (invalidateRequest) {
   forgetRequestId(selectedPhone);
   if (!uncertainAttempts[selectedPhone] && !networkRetries[selectedPhone]) {
     setSendErrors(current => { const next = { ...current }; delete next[selectedPhone]; return next; });
   }
 }
 chatDraftsRef.current[selectedPhone] = { text: chatDraftsRef.current[selectedPhone]?.text ?? replyText, file: null };
 setAttachFile(null);
 if (previewUrl) URL.revokeObjectURL(previewUrl);
 setPreviewUrl(null);
 if (fileInputRef.current) fileInputRef.current.value = "";
 }

 function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
 const file = e.target.files?.[0];
 if (!file) return;
 const allowedImages = ["image/jpeg", "image/jpg", "image/png"];
 const allowedDocs = [
 "application/pdf",
 "application/msword",
 "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
 "application/vnd.ms-excel",
 "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
 "text/plain",
 ];
 if (![...allowedImages, ...allowedDocs].includes(file.type)) {
 toast({ title: "File type not supported", description: "Choose JPEG or PNG (up to 5 MB), or PDF, Word, Excel or text (up to 16 MB).", variant: "destructive" });
 return;
 }
 const maxBytes = allowedImages.includes(file.type) ? 5 * 1024 * 1024 : 16 * 1024 * 1024;
 if (file.size > maxBytes) {
 toast({ title: "File too large", description: allowedImages.includes(file.type) ? "JPEG and PNG images must be 5 MB or smaller." : "Documents must be 16 MB or smaller.", variant: "destructive" });
 return;
 }
 forgetRequestId(selectedPhone);
 if (!uncertainAttempts[selectedPhone] && !networkRetries[selectedPhone]) setSendErrors(current => { const next = { ...current }; delete next[selectedPhone]; return next; });
 if (previewUrl) URL.revokeObjectURL(previewUrl);
 setAttachFile(file);
 chatDraftsRef.current[selectedPhone] = { text: replyText, file };
 setPreviewUrl(URL.createObjectURL(file));
 setShowEmojiPicker(false);
 setShowQuickReplies(false);
 }

 function submitText(payload: TextSendPayload) {
   if (actionLocksRef.current.has(payload.phone)) return;
   actionLocksRef.current.add(payload.phone);composer.changed();
   sendMutation.mutate(payload);
 }
 function submitFile(payload: FileSendPayload) {
   if (actionLocksRef.current.has(payload.phone)) return;
   actionLocksRef.current.add(payload.phone);composer.changed();
   sendFileMutation.mutate(payload);
 }

 function handleSend() {
 if (noteMode) {
 if (!replyText.trim() || noteMutation.isPending || noteLocksRef.current.has(selectedPhone)) return;
 noteLocksRef.current.add(selectedPhone);
 noteMutation.mutate({ phone: selectedPhone, note: replyText.trim() });
 return;
 }
 if (actionLocksRef.current.has(selectedPhone)) return;
 if (uncertainAttempts[selectedPhone] || thread?.messages?.some(message =>
   message.direction === "outbound" && AMBIGUOUS_DELIVERY_STATUSES.has(String(message.deliveryStatus || "").toLowerCase())
 )) {
   setSendErrors(current => ({ ...current, [selectedPhone]: "Delivery is unconfirmed. Reconcile this recorded attempt in Delivery recovery before sending anything else in this conversation." }));
   setShowInfo(true);
   setShowMobileInfo(true);
   return;
 }
 if (networkRetries[selectedPhone]) {
   toast({ title: "Check the previous send first", description: "Use Check send status, or Delivery recovery if the result remains uncertain.", variant: "destructive" });
   return;
 }
 // Block any send-to-customer path while the WhatsApp 24-hour window
 // is closed — covers attachments AND the Enter-key shortcut, not just
 // the on-screen send button. Internal notes (handled above) still go
 // through because they never touch WhatsApp.
 if (windowClosed) {
 toast({
 title: "WhatsApp 24-hour window closed",
 description: "Free-form messages cannot be sent outside the customer-service window. Use an approved-template workflow or switch to Internal Note.",
 variant: "destructive",
 });
 return;
 }
 if (attachFile) {
 const caption = replyText.trim();
 const signature = fileSignature(attachFile, caption);
 const requestId = getRequestId(selectedPhone, signature);
 if (failedAttempts[selectedPhone]?.requestId === requestId) {
   setSendErrors(current => ({ ...current, [selectedPhone]: "This attachment already has a definite failed/blocked attempt. Use Delivery recovery to retry it with an accountable reason; do not create a duplicate send." }));
   setShowInfo(true);
   setShowMobileInfo(true);
   return;
 }
 setSendErrors(current => { const next = { ...current }; delete next[selectedPhone]; return next; });
 submitFile({ phone: selectedPhone, file: attachFile, caption: caption || undefined, requestId, signature });
 return;
 }
 if (!replyText.trim()) return;
 const message = replyText.trim();
 const signature = textSignature(message);
 const requestId = getRequestId(selectedPhone, signature);
 if (failedAttempts[selectedPhone]?.requestId === requestId) {
   setSendErrors(current => ({ ...current, [selectedPhone]: "This message already has a definite failed/blocked attempt. Use Delivery recovery to retry it with an accountable reason; do not create a duplicate send." }));
   setShowInfo(true);
   setShowMobileInfo(true);
   return;
 }
 setSendErrors(current => { const next = { ...current }; delete next[selectedPhone]; return next; });
 submitText({ phone: selectedPhone, message, requestId, signature });
 }

 function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
 if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); }
 }

 function insertEmoji(emoji: string) {
 const ta = textareaRef.current;
 if (!ta) { updateReplyText(replyText + emoji); return; }
 const start = ta.selectionStart ?? replyText.length;
 const end = ta.selectionEnd ?? replyText.length;
 const newText = replyText.slice(0, start) + emoji + replyText.slice(end);
 updateReplyText(newText);
 setTimeout(() => {
 ta.focus();
 ta.setSelectionRange(start + emoji.length, start + emoji.length);
 }, 0);
 }

 const session = (thread as any)?.recipientPhone===selectedPhone?thread?.session:undefined;
 const botPaused: boolean = session?.botPaused ?? selectedConvo?.botPaused ?? false;
 const coordinator=(() => {try{return JSON.parse(session?.structuredState||"{}").whatsappFirst;}catch{return undefined;}})();
 const existingQuoteId=currentQuotation.data?.quote?.id;
 const canGenerateQuote = !!session?.collectedAddress && !!(coordinator?.facts?.items?.length||
   session?.collectedItems&&session.collectedItems!=="__scanning__") && currentQuotation.isSuccess&&!currentQuotation.data?.staffDocument&&!generatedQuote && !existingQuoteId;
 const threadLoaded = !loadingThread && thread !== undefined;
 const isImageFile = attachFile?.type.startsWith("image/") ?? false;
 const isSending = composer.actions.has(selectedPhone)||sendMutation.isPending || sendFileMutation.isPending || noteMutation.isPending;
 const currentComposerSignature = attachFile
   ? fileSignature(attachFile, replyText.trim())
   : textSignature(replyText.trim());
 const currentFailedAttempt = failedAttempts[selectedPhone];
 const currentAttemptAlreadyFailed = !!currentFailedAttempt
   && currentFailedAttempt.signature === currentComposerSignature
   && requestIdsRef.current[selectedPhone]?.requestId === currentFailedAttempt.requestId;
 const composerMustReconcile = !!uncertainAttempts[selectedPhone] || !!thread?.messages?.some(message =>
   message.direction === "outbound" && AMBIGUOUS_DELIVERY_STATUSES.has(String(message.deliveryStatus || "").toLowerCase())
 );

 /* WhatsApp 24-hour window status — derived from the most recent system
 failure log (Meta error 131047 / "messaging window is closed"). The
 window re-opens the moment the customer sends an inbound message, so
 we compare timestamps. Used to block sending normal messages while
 still permitting internal notes (notes never hit WhatsApp). */
 const windowClosed = (() => {
 const all = thread?.messages ?? [];
 const lastFail = [...all].reverse().find(m =>
 m.direction === "outbound" &&
 m.sentBy === "system" &&
 (m.body?.includes("131047") || m.body?.includes("messaging window is closed"))
 );
 if (!lastFail) return false;
 const lastInbound = [...all].reverse().find(m => m.direction === "inbound");
 return !lastInbound || new Date(lastFail.createdAt) > new Date(lastInbound.createdAt);
 })();
 const sendBlocked = windowClosed && !noteMode;

 /* Quick-reply templates shown in message mode */
 const QUICK_TEMPLATES = [
 { label: "Greeting", text: "Hi there! Thank you for contacting TMG Install. How can we help you today?" },
 { label: "On our way", text: "Our team is on the way and will arrive shortly. Please ensure the area is accessible. Thank you!" },
 { label: "Quote ready", text: "Your quote is ready! Please check the link we've sent and let us know if you have any questions." },
 { label: "Confirm appt", text: "Just confirming your appointment is scheduled. Our team will arrive at the agreed time. See you soon!" },
 { label: "Follow up", text: "Hi, just following up on your recent enquiry. Have you had a chance to review the quote? Let us know if you'd like to proceed." },
 { label: "Thank you", text: "Thank you for choosing TMG Install. It was a pleasure working with you. Feel free to reach out anytime." },
 ];

 const searchLower = searchQuery.trim().toLowerCase();
 const grouped: { date: string; messages: WaMessage[] }[] = [];
 if (thread?.messages) {
 let lastDate = "";
 for (const msg of thread.messages) {
 if (searchLower && !msg.body?.toLowerCase().includes(searchLower)) continue;
 const d = formatDateHeader(msg.createdAt);
 if (d !== lastDate) { grouped.push({ date: d, messages: [] }); lastDate = d; }
 grouped[grouped.length - 1].messages.push(msg);
 }
 }
 const totalSearchResults = searchLower ? grouped.reduce((sum, g) => sum + g.messages.length, 0) : 0;
 const selectedQuoteForShare = shareableQuotesQuery.data?.find(q => String(q.id) === selectedShareQuote);
 const selectedQuoteAttemptKey = selectedQuoteForShare ? quoteAttemptKey(selectedPhone, selectedQuoteForShare.id, selectedQuoteForShare.version) : "";
 const selectedQuoteBlocked = selectedQuoteAttemptKey ? quoteBlockedAttempts[selectedQuoteAttemptKey] : undefined;

 // On mobile: fixed inset-0 full-screen overlay (interactive-widget=resizes-content
 // makes the layout viewport shrink with keyboard, so inset-0 ends above the keyboard).
 // On desktop (lg+): static flex-1 inside the parent flex layout as before.
 return (
 <div className="fixed inset-0 z-[9999] flex overflow-hidden lg:static lg:flex-1 lg:z-auto" data-testid="chat-panel">

 {/* ═══ LEFT: Info Panel ═══════════════════════════════════════════════ */}
 {showInfo && (
 <div className="hidden lg:flex flex-col w-64 xl:w-72 flex-shrink-0 bg-white border-r border-gray-200 overflow-y-auto">
 <div className="px-4 py-5">
 <p className="text-[9px] font-bold text-gray-400 uppercase tracking-[0.2em] mb-4">Customer Info</p>

 <div className="flex flex-col items-center text-center gap-2 mb-5">
 <Avatar name={selectedConvo?.name ?? null} phone={selectedPhone} size="lg" />
 <div>
 <p className="text-sm font-bold text-gray-900">{selectedConvo?.name || "Unknown"}</p>
 <p className="text-xs text-gray-400 mt-0.5 font-mono">{formatPhone(selectedPhone)}</p>
 </div>
 <a
 key={`recipient-${selectedPhone}`}
 href={`https://wa.me/${selectedPhone}`}
 target="_blank"
 rel="noopener noreferrer"
 className="flex items-center gap-1.5 text-[11px] text-[#25D366] hover:underline font-medium"
 >
 <ExternalLink className="w-3 h-3" />
 Open in WhatsApp
 </a>
 </div>

 {selectedConvo?.state && (
 <div className={`rounded-none px-3 py-3 mb-3 border ${getState(selectedConvo.state).bg}`}>
 <p className="text-[9px] text-gray-400 uppercase tracking-wider mb-1.5 font-semibold">Bot State</p>
 <div className="flex items-center gap-2">
 <div className={`w-2 h-2 rounded-full ${getState(selectedConvo.state).dot}`} />
 <span className={`text-xs font-semibold ${getState(selectedConvo.state).color}`}>
 {getState(selectedConvo.state).label}
 </span>
 </div>
 </div>
 )}

 <div className="space-y-2">
 {session?.collectedAddress && <InfoRow icon={<MapPin className="w-3 h-3" />} label="Address" value={session.collectedAddress} />}
 {session?.collectedToAddress && <InfoRow icon={<MapPin className="w-3 h-3" />} label="Destination" value={session.collectedToAddress} />}
 {session?.collectedItems && session.collectedItems !== "__scanning__" && (
 <InfoRow icon={<Package className="w-3 h-3" />} label="Items" value={session.collectedItems} multiline />
 )}
 {session?.floorLevel && (
 <InfoRow icon={<Building2 className="w-3 h-3" />} label="Floor" value={`Level ${session.floorLevel} · ${session.hasLift ? "Lift" : "No lift"}`} />
 )}
 {session?.accessDifficulty && (
 <InfoRow icon={<Layers className="w-3 h-3" />} label="Access" value={({ easy: "Easy", medium: "Moderate", hard: "Difficult" } as any)[session.accessDifficulty] || session.accessDifficulty} />
 )}
 {session?.preferredDate && <InfoRow icon={<Calendar className="w-3 h-3" />} label="Preferred Date" value={session.preferredDate} />}
 </div>

 {/* Reset Session */}
 <div className="mt-5 pt-4 border-t border-gray-100">
 {showResetConfirm ? (
 <div className="space-y-2">
 <p className="text-xs text-red-600 font-semibold text-center">Clear this session?</p>
 <p className="text-[10px] text-gray-400 text-center leading-relaxed">Bot will restart from scratch on the next message.</p>
 <div className="flex gap-2">
 <button
 onClick={() => setShowResetConfirm(false)}
 className="flex-1 py-1.5 text-xs font-semibold rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-50"
 >Cancel</button>
 <button
 onClick={() => resetSessionMutation.mutate()}
 disabled={resetSessionMutation.isPending}
 data-testid="confirm-reset-session"
 className="flex-1 py-1.5 text-xs font-semibold rounded-lg bg-red-50 border border-red-200 text-red-600 hover:bg-red-100 disabled:opacity-60"
 >{resetSessionMutation.isPending ? "Clearing…" : "Yes, clear"}</button>
 </div>
 </div>
 ) : (
 <button
 onClick={() => setShowResetConfirm(true)}
 data-testid="reset-session-btn"
 className="w-full flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg border border-gray-200 text-gray-500 hover:border-red-200 hover:text-red-600 hover:bg-red-50 transition-all"
 >
 <RotateCcw className="w-3 h-3" /> Reset Bot Session
 </button>
 )}
 </div>
 <div className="mt-4">
 <DeliveryRecovery phone={selectedPhone} />
 </div>
 </div>
 </div>
 )}

 {/* ═══ RIGHT: Chat Panel ═══════════════════════════════════════════════ */}
 <div className="flex-1 flex flex-col min-w-0 bg-white">

 {/* Header — WhatsApp-style dark green */}
 <div className="flex-shrink-0" style={{ background: "#1f2c34" }}>
 <div className="flex items-center gap-2.5 px-3 sm:px-4 py-3">
 {/* Back button — mobile only */}
 <button
 onClick={onClose}
 data-testid="back-to-list"
 className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/10 active:bg-white/20 text-white transition-all -ml-1 lg:hidden"
 >
 <ArrowLeft className="w-5 h-5" />
 </button>

 <div className="flex-shrink-0">
 <Avatar name={selectedConvo?.name ?? null} phone={selectedPhone} size="sm" />
 </div>

 <div className="flex-1 min-w-0">
 <p className="text-sm font-semibold text-white truncate leading-tight">
 {selectedConvo?.name || formatPhone(selectedPhone)}
 </p>
 <p className="text-[11px] text-white/60 mt-0.5 truncate leading-tight">
 {selectedConvo?.name ? formatPhone(selectedPhone) : "WhatsApp"}
 {selectedConvo?.state && (
 <span className="ml-2 opacity-80">· {getState(selectedConvo.state).label}</span>
 )}
 </p>
 </div>

 <div className="flex items-center gap-1 flex-shrink-0">
 {/* Call customer — opens phone dialer (works even outside WA 24h window) */}
 <a
 href={`tel:+${selectedPhone}`}
 className="w-8 h-8 flex items-center justify-center rounded-full text-white/70 hover:bg-emerald-500/20 hover:text-emerald-300 transition-all"
 data-testid="call-customer"
 title="Call customer"
 aria-label={`Call customer at ${formatPhone(selectedPhone)}`}
 >
 <PhoneCall className="w-4 h-4" />
 </a>

 {/* Email customer — only if we have one on file */}
 {session?.collectedEmail && (
 <a
 href={`mailto:${session.collectedEmail}?subject=${encodeURIComponent("Following up — TMG Install")}&body=${encodeURIComponent(`Hi ${selectedConvo?.name || "there"},\n\n`)}`}
 className="w-8 h-8 flex items-center justify-center rounded-full text-white/70 hover:bg-blue-500/20 hover:text-blue-300 transition-all"
 data-testid="email-customer"
 title={`Email ${session.collectedEmail}`}
 aria-label={`Email customer at ${session.collectedEmail}`}
 >
 <Mail className="w-4 h-4" />
 </a>
 )}

 {/* WhatsApp open link */}
 <a
 href={`https://wa.me/${selectedPhone}`}
 target="_blank"
 rel="noopener noreferrer"
 className="w-8 h-8 flex items-center justify-center rounded-full text-white/70 hover:bg-white/10 hover:text-white transition-all"
 data-testid="open-whatsapp"
 title="Open in WhatsApp"
 aria-label="Open conversation in WhatsApp"
 >
 <MessageCircle className="w-4 h-4" />
 </a>

 {/* Bot pause / resume toggle */}
 {threadLoaded && (
 botPaused ? (
 <button
 onClick={() => resumeBotMutation.mutate()}
 disabled={resumeBotMutation.isPending}
 data-testid="resume-bot-btn"
 className="w-8 h-8 flex items-center justify-center rounded-full bg-amber-500 text-white hover:bg-amber-400 transition-all disabled:opacity-60 sm:w-auto sm:h-auto sm:px-2.5 sm:py-1.5 sm:rounded-none sm:gap-1.5 sm:text-xs sm:font-semibold"
 title="Resume bot"
 >
 <Bot className="w-3.5 h-3.5" />
 <span className="hidden sm:inline">Resume Bot</span>
 </button>
 ) : (
 <button
 onClick={() => pauseBotMutation.mutate()}
 disabled={pauseBotMutation.isPending}
 data-testid="pause-bot-btn"
 className="w-8 h-8 flex items-center justify-center rounded-full text-white/70 hover:bg-white/10 hover:text-white transition-all disabled:opacity-60 sm:w-auto sm:h-auto sm:px-2.5 sm:py-1.5 sm:rounded-none sm:gap-1.5 sm:text-xs sm:font-semibold"
 title="Take over from bot"
 >
 <BotOff className="w-3.5 h-3.5" />
 <span className="hidden sm:inline text-white/70">Take Over</span>
 </button>
 )
 )}

 {/* Mark Done — visible when bot is paused (admin mode) */}
 {threadLoaded && botPaused && (
 <button
 onClick={() => markDoneMutation.mutate()}
 disabled={markDoneMutation.isPending}
 data-testid="mark-done-btn"
 className="w-8 h-8 flex items-center justify-center rounded-full bg-[#25D366] text-white hover:bg-[#1db954] transition-all disabled:opacity-60 sm:w-auto sm:h-auto sm:px-2.5 sm:py-1.5 sm:rounded-none sm:gap-1.5 sm:text-xs sm:font-semibold"
 title="Mark done — resume bot and mark read"
 >
 <CheckCheck className="w-3.5 h-3.5" />
 <span className="hidden sm:inline">Done</span>
 </button>
 )}

 {/* Mobile: show customer info drawer */}
 <button
 onClick={() => setShowMobileInfo(v => !v)}
 className="w-8 h-8 flex items-center justify-center rounded-full text-white/70 hover:bg-white/10 hover:text-white transition-all lg:hidden"
 title="Customer info"
 data-testid="mobile-info-btn"
 >
 <User className="w-3.5 h-3.5" />
 </button>

 {/* Search in thread */}
 <button
 onClick={() => { setShowSearch(v => !v); setSearchQuery(""); setTimeout(() => searchInputRef.current?.focus(), 80); }}
 className={`w-8 h-8 flex items-center justify-center rounded-full transition-all ${
 showSearch ? "bg-white/20 text-white" : "text-white/70 hover:bg-white/10 hover:text-white"
 }`}
 title="Search in conversation"
 data-testid="btn-search-thread"
 >
 <Search className="w-3.5 h-3.5" />
 </button>

 {/* Desktop: Info panel toggle */}
 {threadLoaded && (
 <button
 onClick={() => setShowInfo(v => !v)}
 className={`hidden lg:flex px-2.5 py-1.5 rounded-none text-xs font-semibold transition-all ${
 showInfo ? "bg-white/20 text-white" : "text-white/70 hover:bg-white/10 hover:text-white"
 }`}
 data-testid="toggle-info"
 >
 Info
 </button>
 )}
 </div>
 </div>

 {/* Search bar — dark themed to match header */}
 {showSearch && (
 <div className="flex items-center gap-2 px-3 pb-3 pt-1" style={{ background: "#1f2c34" }}>
 <div className="flex-1 flex items-center gap-2 rounded-none px-3 py-2" style={{ background: "#2a3942" }}>
 <Search className="w-3.5 h-3.5 text-white/40 flex-shrink-0" />
 <input
 ref={searchInputRef}
 type="text"
 value={searchQuery}
 onChange={e => setSearchQuery(e.target.value)}
 placeholder="Search messages…"
 className="flex-1 bg-transparent text-sm text-white placeholder:text-white/40 outline-none"
 data-testid="search-thread-input"
 />
 {searchQuery && (
 <button onClick={() => setSearchQuery("")} className="text-white/40 hover:text-white/80">
 <X className="w-3.5 h-3.5" />
 </button>
 )}
 </div>
 <button onClick={() => { setShowSearch(false); setSearchQuery(""); }} className="text-xs font-semibold text-[#25D366]">
 Cancel
 </button>
 </div>
 )}

 {/* Admin Mode banner — compact single-line strip */}
 {botPaused && (
 <div className="flex items-center justify-between px-3 py-1 bg-amber-500 flex-shrink-0">
 <div className="flex items-center gap-1.5 text-white text-[11px] font-semibold min-w-0">
 <TriangleAlert className="w-3 h-3 flex-shrink-0" />
 <span className="truncate">Admin Mode — Bot paused. No auto-reply.</span>
 </div>
 <button
 onClick={() => resumeBotMutation.mutate()}
 disabled={resumeBotMutation.isPending}
 className="ml-3 text-[11px] font-bold text-white/90 hover:text-white underline underline-offset-2 flex-shrink-0 disabled:opacity-60"
 data-testid="resume-bot-inline"
 >
 Resume
 </button>
 </div>
 )}
 </div>

 {/* Mobile info drawer — slides down when info btn tapped */}
 {showMobileInfo && (
 <div className="lg:hidden flex-shrink-0 border-b border-gray-200 bg-white animate-in slide-in-from-top-2 duration-200 z-10">
 <div className="px-4 py-3 max-h-[75dvh] overflow-y-auto">
 <div className="flex items-center justify-between mb-3">
 <p className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.18em]">Customer Info</p>
 <button onClick={() => setShowMobileInfo(false)} className="w-6 h-6 rounded-full hover:bg-gray-100 flex items-center justify-center text-gray-400">
 <X className="w-3.5 h-3.5" />
 </button>
 </div>
 <div className="flex items-center gap-3 mb-3 pb-3 border-b border-gray-100">
 <Avatar name={selectedConvo?.name ?? null} phone={selectedPhone} size="md" />
 <div>
 <p className="text-sm font-bold text-gray-900">{selectedConvo?.name || "Unknown"}</p>
 <p className="text-xs text-gray-400 font-mono">{formatPhone(selectedPhone)}</p>
 {selectedConvo?.state && (
 <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border mt-1 inline-block ${getState(selectedConvo.state).color} ${getState(selectedConvo.state).bg}`}>
 {getState(selectedConvo.state).label}
 </span>
 )}
 </div>
 </div>
 <div className="grid grid-cols-2 gap-2">
 {session?.collectedAddress && <InfoRow icon={<MapPin className="w-3 h-3" />} label="Address" value={session.collectedAddress} />}
 {session?.collectedItems && session.collectedItems !== "__scanning__" && (
 <InfoRow icon={<Package className="w-3 h-3" />} label="Items" value={session.collectedItems} multiline />
 )}
 {session?.floorLevel && (
 <InfoRow icon={<Building2 className="w-3 h-3" />} label="Floor" value={`Level ${session.floorLevel} · ${session.hasLift ? "Lift" : "No lift"}`} />
 )}
 {session?.preferredDate && <InfoRow icon={<Calendar className="w-3 h-3" />} label="Date" value={session.preferredDate} />}
 </div>
 <div className="flex gap-2 mt-3 pt-2 border-t border-gray-100">
 <a
 href={`https://wa.me/${selectedPhone}`}
 target="_blank"
 rel="noopener noreferrer"
 className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg bg-[#25D366]/10 border border-[#25D366]/30 text-[#25D366] hover:bg-[#25D366]/20 transition-all"
 >
 <Phone className="w-3 h-3" /> Open in WA
 </a>
 {canGenerateQuote && (
 <button
 onClick={() => { generateQuoteMutation.mutate(selectedPhone); setShowMobileInfo(false); }}
 disabled={generateQuoteMutation.isPending}
 className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg bg-blue-50 border border-blue-200 text-[#0A0A0A] hover:bg-blue-100 transition-all disabled:opacity-60"
 >
 <FileText className="w-3 h-3" /> Gen Quote
 </button>
 )}
 {botPaused && (
 <button
 onClick={() => { markDoneMutation.mutate(); setShowMobileInfo(false); }}
 disabled={markDoneMutation.isPending}
 className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-600 hover:bg-emerald-100 transition-all disabled:opacity-60"
 >
 <CheckCheck className="w-3 h-3" /> Done
 </button>
 )}
 </div>
 <div className="mt-3">
   <DeliveryRecovery phone={selectedPhone} />
 </div>
 </div>
 </div>
 )}

 {/* Messages — wrapper is flex-1 + relative so chatScrollRef can use absolute inset-0.
 absolute inset-0 is bulletproof: fills the parent regardless of flex-height
 resolution quirks on iOS Safari (flex-1/h-full can both fail there). */}
 <div className="relative flex-1 overflow-hidden" style={{ background: "#e5ddd5", backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23c8b9a8' fill-opacity='0.25'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E\")" }}>
 {hasNewMessages && (
 <button
 onClick={() => scrollToBottom(true)}
 className="absolute bottom-3 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#25D366] text-white text-xs font-semibold animate-bounce"
 >
 <ChevronDown className="w-3.5 h-3.5" /> New messages
 </button>
 )}
 <div ref={chatScrollRef} className="absolute inset-0 overflow-y-auto overscroll-contain px-3 sm:px-5 py-4" style={{ background: "#e5ddd5", backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23c8b9a8' fill-opacity='0.25'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E\")"} }>
  <InternalQuotationPanel key={selectedPhone} phone={selectedPhone} isActiveRecipient={() => activePhoneRef.current === selectedPhone} />
  {loadingThread && (
 <div className="space-y-4 py-2 animate-pulse">
 {[false, true, false, true, false].map((r, i) => (
 <div key={i} className={`flex ${r ? "justify-end" : "justify-start"}`}>
 <div className={`rounded-none bg-gray-200 ${r ? "w-52 h-12" : "w-60 h-14"}`} />
 </div>
 ))}
 </div>
 )}

 {!loadingThread && grouped.length === 0 && (
 <div className="flex flex-col items-center justify-center h-full gap-2 text-gray-400 text-sm">
 <Search className="w-8 h-8 opacity-30" />
 <span>{searchLower ? `No messages matching "${searchQuery}"` : "No messages yet"}</span>
 </div>
 )}

 {searchLower && totalSearchResults > 0 && (
 <div className="flex justify-center mb-3">
 <span className="text-[11px] font-semibold px-3 py-1 rounded-full bg-white/80 border border-violet-200 text-[#0A0A0A] ">
 {totalSearchResults} result{totalSearchResults !== 1 ? "s" : ""} for "{searchQuery}"
 </span>
 </div>
 )}

 {grouped.map(group => (
 <div key={group.date}>
 <div className="flex items-center gap-3 my-5">
 <div className="flex-1 h-px bg-gray-200" />
 <span className="text-[11px] text-gray-400 font-medium px-3 py-1 rounded-full bg-white border border-gray-200 ">
 {group.date}
 </span>
 <div className="flex-1 h-px bg-gray-200" />
 </div>

 <div className="space-y-0.5">
 {group.messages.map((msg, idx) => {
 const isOut = msg.direction === "outbound";
 const isAdm = !!msg.sentBy?.startsWith("admin:");
 const isBot = isOut && !isAdm && !msg.sentBy?.startsWith("note:");
 const adminLabel = isAdm ? msg.sentBy!.replace("admin:", "") : null;
 const prev = idx > 0 ? group.messages[idx - 1] : null;
 const next = idx < group.messages.length - 1 ? group.messages[idx + 1] : null;
 const samePrev = prev?.direction === msg.direction && prev?.sentBy === msg.sentBy;
 const sameNext = next?.direction === msg.direction && next?.sentBy === msg.sentBy;
 return (
 <MessageBubble
 key={msg.id}
 msg={msg}
 isOut={isOut}
 isAdm={isAdm}
 isBot={isBot}
 samePrev={samePrev}
 sameNext={sameNext}
 adminLabel={adminLabel}
 selectedPhone={selectedPhone}
 selectedConvoName={selectedConvo?.name ?? null}
 onDelete={(id) => deleteMessageMutation.mutate(id)}
 onRecovery={() => { setShowInfo(true); setShowMobileInfo(true); }}
 />
 );
 })}
 </div>
 </div>
 ))}
 <div ref={messagesEndRef} className="h-1" />
 </div>
 </div>

 {/* Generated quote success banner */}
 {generatedQuote && (
 <div className="flex-shrink-0 flex items-center gap-3 px-4 py-2.5 bg-emerald-50 border-t border-emerald-200">
 <CheckCheck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
 <span className="text-xs font-semibold text-emerald-700 flex-1">Quote <span className="font-bold">{generatedQuote.referenceNo}</span> created successfully</span>
 <a
 href={`/admin/quotes/${generatedQuote.quoteId}?edit=1`}
 target="_blank"
 rel="noopener noreferrer"
 className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-900 underline underline-offset-2 flex-shrink-0"
 >
 Open Quote
 </a>
 </div>
 )}

 {/* Generate Quote action bar — shown when session has enough data */}
 {existingQuoteId&&!generatedQuote&&<div className="flex-shrink-0 flex items-center justify-between gap-2 px-3 py-2 bg-blue-50 border-t border-blue-200 text-xs">
 <span>{currentQuotation.data?.staffDocument?"Staff quotation — review saved scope and pricing before sharing.":"Existing enquiry draft / quotation — review its scope and pricing before sharing."}</span>
 <a className="font-semibold underline whitespace-nowrap" href={`/admin/quotes/${existingQuoteId}?edit=1`}>Edit quote</a>
 </div>}
 {!existingQuoteId&&currentQuotation.data?.staffDocument&&<div className="flex-shrink-0 px-3 py-2 bg-blue-50 border-t border-blue-200 text-xs">
   Staff document · {currentQuotation.data.staffDocument.status}. <a className="font-semibold underline" target="_blank" rel="noopener noreferrer" href={currentQuotation.data.staffDocument.mediaUrl}>Open original document</a>
 </div>}
 {!generatedQuote && canGenerateQuote && (
 <div className="flex-shrink-0 flex items-center gap-2 px-3 py-2.5 bg-blue-50 border-t border-blue-200 sm:gap-3 sm:px-4">
 <FileText className="w-4 h-4 text-[#0A0A0A] flex-shrink-0" />
 <span className="text-xs text-[#0A0A0A] flex-1 min-w-0 truncate sm:whitespace-normal sm:truncate-none">
 {session?.collectedItems
 ? "Address & items collected — ready to generate a quote."
 : "Furniture details are still needed. Review the enquiry before creating a quotation."}
 </span>
 <button
 onClick={() => generateQuoteMutation.mutate(selectedPhone)}
 disabled={generateQuoteMutation.isPending}
 data-testid="generate-quote-btn"
 className="flex items-center gap-1.5 px-3 py-1.5 rounded-none text-xs font-semibold bg-[#0A0A0A] text-white hover:bg-black transition-all disabled:opacity-60 flex-shrink-0 whitespace-nowrap"
 >
 {generateQuoteMutation.isPending
 ? <div className="w-3 h-3 border-2 border-white/50 border-t-white rounded-full animate-spin" />
 : <FileText className="w-3.5 h-3.5" />
 }
 Generate Quote
 </button>
 </div>
 )}

 {/* Reply Box — in the flex flow at the bottom of the right panel column.
 interactive-widget=resizes-content (index.html) causes the layout
 viewport to shrink when keyboard is open, so flex-shrink-0 here is
 always visible above the keyboard without any fixed positioning. */}
 <div
 className="flex-shrink-0 border-t border-gray-200 bg-white shadow-[0_-2px_10px_rgba(0,0,0,0.07)]"
 style={{ paddingBottom: "max(0px, env(safe-area-inset-bottom))" }}
 >
 {!noteMode && <div className="flex items-center justify-between gap-2 px-3 pt-2 text-[10px] text-gray-500">
 <span>This composer sends free-form replies only: use within 24 hours of the customer’s last message. Outside that window, use the approved-template process; standard replies are not templates. “Sent” means provider accepted, not delivered.</span>
   <button type="button" onClick={() => setShowQuoteShare(v => !v)} className="shrink-0 font-semibold text-[#075e54] underline underline-offset-2" aria-expanded={showQuoteShare}>
     {showQuoteShare ? "Close quote share" : "Share quotation"}
   </button>
 </div>}
 {showQuoteShare && !noteMode && <div className="mx-3 mt-2 grid gap-2 rounded border border-emerald-200 bg-emerald-50/70 p-3 sm:grid-cols-[1fr_auto]">
   <div className="min-w-0">
     <label htmlFor="share-quote-select" className="mb-1 block text-xs font-semibold text-emerald-950">Choose an issued quotation</label>
     {shareableQuotesQuery.isLoading ? <div className="h-8 animate-pulse rounded bg-emerald-100" /> :
       shareableQuotesQuery.error ? <div role="alert" className="text-xs text-red-700">Could not load available quotations. <button type="button" onClick={() => shareableQuotesQuery.refetch()} className="font-semibold underline">Try again</button></div> :
       !shareableQuotesQuery.data?.length ? <p className="text-xs text-gray-600">No shareable issued quotations are available for this conversation.</p> :
       <select id="share-quote-select" value={selectedShareQuote} onChange={e => setSelectedShareQuote(e.target.value)} className="h-9 w-full rounded border border-emerald-300 bg-white px-2 text-xs">
         <option value="">Select a quotation…</option>
         {shareableQuotesQuery.data.map(quote => <option key={`${quote.id}-${quote.version}`} value={String(quote.id)}>{quote.referenceNo} · v{quote.version} · S${Number(quote.total).toFixed(2)}</option>)}
       </select>}
     <p className="mt-1 text-[10px] text-gray-600">Sharing sends the selected quotation only. It does not book a service or request payment.</p>
   </div>
    <button type="button" onClick={() => {
      if (composerMustReconcile) {
        setShowInfo(true);
        setShowMobileInfo(true);
        return;
      }
     const quote = shareableQuotesQuery.data?.find(q => String(q.id) === selectedShareQuote);
     if (quote) {
       const attemptKey = quoteAttemptKey(selectedPhone, quote.id, quote.version);
       if (quoteLocksRef.current.has(attemptKey) || quoteBlockedAttempts[attemptKey]) return;
       quoteLocksRef.current.add(attemptKey);
       const requestId = quoteRequestIdsRef.current[attemptKey] || crypto.randomUUID();
       quoteRequestIdsRef.current[attemptKey] = requestId;
       shareQuoteMutation.mutate({ phone: selectedPhone, quoteId: quote.id, expectedVersion: quote.version, requestId, attemptKey });
     }
    }} disabled={!selectedShareQuote || shareQuoteMutation.isPending || composerMustReconcile || !!selectedQuoteBlocked || !shareableQuotesQuery.data?.some(q => String(q.id) === selectedShareQuote)} className="self-end rounded bg-[#075e54] px-3 py-2 text-xs font-semibold text-white hover:bg-[#064e46] disabled:opacity-50">
     {shareQuoteMutation.isPending ? "Sharing…" : "Share quote"}
   </button>
    {composerMustReconcile && <p className="sm:col-span-2 text-[11px] font-medium text-amber-800">Reconcile the existing unconfirmed attempt in Delivery recovery before sending a quote.</p>}
   {selectedQuoteBlocked && <div role="alert" className="sm:col-span-2 rounded border border-amber-300 bg-amber-50 px-2.5 py-2 text-[11px] text-amber-950">
     Quote share status: {selectedQuoteBlocked.status}{selectedQuoteBlocked.id != null ? ` · attempt #${selectedQuoteBlocked.id}` : ""}. Reconcile unconfirmed delivery or use Delivery recovery’s accountable retry for a definite failure.
     <button type="button" onClick={() => { setShowInfo(true); setShowMobileInfo(true); }} className="ml-2 font-semibold underline">Open delivery recovery</button>
   </div>}
 </div>}
 {sendErrors[selectedPhone] && <div role="alert" className="mx-3 mt-2 flex items-start justify-between gap-2 rounded border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-800">
   <span className="min-w-0 break-words">
     {sendErrors[selectedPhone]}
     {(failedAttempts[selectedPhone] || uncertainAttempts[selectedPhone]) && <span className="ml-1 font-semibold">Status {failedAttempts[selectedPhone]?.status || uncertainAttempts[selectedPhone]?.status}{(failedAttempts[selectedPhone] || uncertainAttempts[selectedPhone])?.id != null ? ` · attempt #${(failedAttempts[selectedPhone] || uncertainAttempts[selectedPhone])?.id}` : ""}.</span>}
     {" "}{networkRetries[selectedPhone] ? "No result was received. Check send status before sending anything again." : "Check Delivery recovery before trying again; an unconfirmed attempt may already have reached WhatsApp."}
   </span>
   {networkRetries[selectedPhone] && <button type="button" disabled={isSending} onClick={() => networkRetries[selectedPhone].kind === "text" ? submitText(networkRetries[selectedPhone].payload) : submitFile(networkRetries[selectedPhone].payload)} className="shrink-0 rounded border border-red-300 px-2 py-1 font-semibold disabled:opacity-50">Check send status</button>}
   {(failedAttempts[selectedPhone] || uncertainAttempts[selectedPhone]) && <button type="button" onClick={() => { setShowInfo(true); setShowMobileInfo(true); }} className="shrink-0 font-semibold underline">Open Delivery recovery</button>}
   {!networkRetries[selectedPhone] && !uncertainAttempts[selectedPhone] && !failedAttempts[selectedPhone] && <button type="button" onClick={() => setSendErrors(current => { const next = { ...current }; delete next[selectedPhone]; return next; })} aria-label="Dismiss send error" className="shrink-0 font-semibold underline">Dismiss</button>}
 </div>}

 {/* Combined Quick Templates + Canned Replies panel (inside fixed unit) */}
 {(showTemplates || showQuickReplies) && !noteMode && (
 <div className="border-b border-gray-100 bg-white px-3 pt-2.5 pb-1 max-h-52 overflow-y-auto">
 <div className="flex items-center justify-between mb-2">
 <p className="text-[10px] text-gray-400 font-semibold uppercase tracking-wider">Quick Replies</p>
 <button onClick={() => { setShowTemplates(false); setShowQuickReplies(false); }} className="text-gray-300 hover:text-gray-500"><X className="w-3.5 h-3.5" /></button>
 </div>
 <div className="flex flex-wrap gap-1.5 mb-2">
 {QUICK_TEMPLATES.map(t => (
 <button
 key={t.label}
 onClick={() => { updateReplyText(t.text); setShowTemplates(false); setShowQuickReplies(false); setTimeout(() => textareaRef.current?.focus(), 0); }}
 className="px-2.5 py-1 rounded-full border border-gray-200 bg-gray-50 text-xs font-medium text-gray-600 hover:bg-indigo-50 hover:border-indigo-200 hover:text-indigo-600 transition-all"
 >
 {t.label}
 </button>
 ))}
 </div>
 {dbCannedReplies.filter(r => r.active).length > 0 && (
 <div className="border-t border-gray-100 pt-2">
 <p className="text-[10px] text-gray-300 font-semibold uppercase tracking-wider mb-1.5">Saved Replies</p>
 <div className="space-y-1">
 {dbCannedReplies.filter(r => r.active).map(r => (
 <button
 key={r.id}
 onClick={() => { updateReplyText(r.body.replace(/\\n/g, "\n")); setShowTemplates(false); setShowQuickReplies(false); textareaRef.current?.focus(); }}
 className="w-full text-left px-3 py-2 rounded-none hover:bg-gray-50 transition-all border border-transparent hover:border-gray-200"
 >
 <div className="flex items-center gap-2 mb-0.5">
 <code className="text-[10px] font-mono bg-zinc-100 text-zinc-600 px-1 rounded">{r.shortcut}</code>
 <span className="text-xs font-semibold text-gray-700">{r.title}</span>
 </div>
 <p className="text-xs text-gray-400 truncate">{r.body}</p>
 </button>
 ))}
 </div>
 </div>
 )}
 </div>
 )}
 {/* Hidden file input */}
 <input
 ref={fileInputRef}
 type="file"
 accept="image/jpeg,image/png,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/plain,.doc,.docx,.xls,.xlsx,.txt"
 className="hidden"
 onChange={handleFileSelect}
 data-testid="file-input"
 />

 {/* Note mode indicator strip — thin, replaces the full tab row */}
 {noteMode && (
 <div className="flex items-center justify-between px-3 py-1 bg-amber-50 border-b border-amber-200">
 <div className="flex items-center gap-1 text-[11px] font-semibold text-amber-700">
 <StickyNote className="w-3 h-3" />
 <span>Internal Note — not sent to customer</span>
 </div>
 <button
 onClick={() => { setNoteMode(false); clearAttach(); }}
 className="text-[11px] text-amber-600 hover:text-amber-800 font-semibold underline"
 data-testid="cancel-note-mode"
 >
 Cancel
 </button>
 </div>
 )}

 {/* File/image preview panel */}
 {attachFile && (
 <div className="px-4 pt-3 pb-2 border-b border-gray-100 bg-gray-50">
 <div className="flex items-start gap-3">
 <div className="relative flex-shrink-0">
 {isImageFile && previewUrl ? (
 <img
 src={previewUrl}
 alt="Preview"
 className="w-20 h-20 object-cover rounded-none border border-gray-200 "
 />
 ) : (
 <div className="w-20 h-20 rounded-none border border-gray-200 bg-blue-50 flex flex-col items-center justify-center gap-1">
 <FileText className="w-7 h-7 text-blue-400" />
 <span className="text-[9px] font-bold text-blue-400 uppercase">{attachFile.name.split(".").pop()}</span>
 {previewUrl && <a href={previewUrl} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()} className="text-[9px] font-semibold text-blue-700 underline">Preview</a>}
 </div>
 )}
 <button
 type="button"
 onClick={() => clearAttach(true)}
 aria-label={`Remove attachment ${attachFile.name}`}
 className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-gray-800 text-white flex items-center justify-center hover:bg-red-600 transition-all"
 >
 <X className="w-3 h-3" />
 </button>
 </div>
 <div className="flex-1 min-w-0">
 <p className="text-xs font-semibold text-gray-700 truncate">{attachFile.name}</p>
 <p className="text-[10px] text-gray-400 mb-1.5">{(attachFile.size / 1024).toFixed(0)} KB · {attachFile.type.split("/")[1]?.split(";")[0]?.toUpperCase()}</p>
 <input
 type="text"
 value={replyText}
 onChange={e => updateReplyText(e.target.value)}
 placeholder="Add a caption (optional)…"
 className="w-full h-8 px-2.5 text-xs border border-gray-200 rounded-lg bg-white focus:outline-none focus:border-blue-400 placeholder:text-gray-400"
 data-testid="file-caption-input"
 />
 </div>
 </div>
 </div>
 )}

 {/* Emoji picker — floats above reply box */}
 {showEmojiPicker && (
 <div ref={emojiPickerRef} className="absolute bottom-full left-3 z-50 mb-1 rounded-none overflow-hidden border border-gray-200">
 <EmojiPicker
 theme={Theme.LIGHT}
 onEmojiClick={(data: EmojiClickData) => {
 insertEmoji(data.emoji);
 setShowEmojiPicker(false);
 }}
 width={300}
 height={340}
 searchDisabled={false}
 skinTonesDisabled
 previewConfig={{ showPreview: false }}
 />
 </div>
 )}

 {/* ── 24-hour-window failure banner — actionable fallback ───────
 Surfaces Call/Email actions inline so admin can reach the
 customer immediately when the WhatsApp window is closed
 (windowClosed is hoisted above so the input row can also
 disable Send and switch the placeholder). */}
 {windowClosed && (
 <div className="mx-2 mb-1.5 px-3 py-2.5 bg-amber-50 border border-amber-200 rounded-none">
 <div className="flex items-start gap-2 mb-2">
 <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
 <div className="flex-1 min-w-0">
 <p className="text-[12px] font-bold text-amber-900 leading-tight">WhatsApp 24-hour window closed</p>
 <p className="text-[11px] text-amber-700 mt-0.5 leading-snug">
 Free-form replies are blocked outside the 24-hour window. Use an approved template where eligible, or reach them another way:
 </p>
 </div>
 </div>
 <div className="flex items-center gap-1.5 flex-wrap">
 <a
 href={`tel:+${selectedPhone}`}
 data-testid="banner-call-customer"
 className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 text-white text-[11px] font-semibold rounded-lg hover:bg-emerald-700 active:scale-[0.98] transition-all"
 >
 <PhoneCall className="w-3.5 h-3.5" /> Call {formatPhone(selectedPhone)}
 </a>
 {session?.collectedEmail && (
 <a
 href={`mailto:${session.collectedEmail}?subject=${encodeURIComponent("Following up — TMG Install")}&body=${encodeURIComponent(`Hi ${selectedConvo?.name || "there"},\n\n`)}`}
 data-testid="banner-email-customer"
 className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#0A0A0A] text-white text-[11px] font-semibold rounded-lg hover:bg-black active:scale-[0.98] transition-all"
 >
 <Mail className="w-3.5 h-3.5" /> Email
 </a>
 )}
 <button
 onClick={() => { navigator.clipboard.writeText(`+${selectedPhone}`); toast({ title: "Phone number copied" }); }}
 data-testid="banner-copy-phone"
 className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-amber-300 text-amber-900 text-[11px] font-semibold rounded-lg hover:bg-amber-100 active:scale-[0.98] transition-all"
 >
 <Copy className="w-3.5 h-3.5" /> Copy number
 </button>
 <button
 onClick={() => setShowPaymentDialog(true)}
 data-testid="banner-generate-payment-message"
 className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#0A0A0A] text-white text-[11px] font-semibold rounded-lg hover:bg-violet-700 active:scale-[0.98] transition-all"
 >
 <FileText className="w-3.5 h-3.5" /> Generate payment text
 </button>
 </div>
 </div>
 )}

 {/* Payment-message snippet dialog (works regardless of WhatsApp window) */}
 {selectedPhone && (
 <PaymentMessageDialog
 key={selectedPhone}
 open={showPaymentDialog}
 onClose={() => setShowPaymentDialog(false)}
 fetchUrl={`${API_BASE}/api/admin/whatsapp/conversations/${selectedPhone}/payment-message`}
 />
 )}

 <div className="px-2 pb-2 pt-1.5">
 <div className="flex items-end gap-1">
 {/* Left icon group — attach + note toggle */}
 <div className="flex flex-col items-center gap-1 pb-0.5">
 {/* Attach (message mode only) */}
 {!noteMode ? (
 <button
 onClick={() => { fileInputRef.current?.click(); setShowEmojiPicker(false); }}
 className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
 attachFile ? "bg-emerald-500 text-white" : "text-gray-400 hover:text-gray-700 hover:bg-gray-100"
 }`}
 title="Attach image or document"
 data-testid="btn-attach-file"
 >
 <Paperclip className="w-5 h-5" />
 </button>
 ) : (
 <div className="w-8 h-8" />
 )}
 </div>

 {/* Textarea wrapper */}
 <div className="flex-1 relative">
 {/* Text input — auto-resizes via useEffect */}
 {!attachFile && (
 <Textarea
 ref={textareaRef}
 value={replyText}
 onChange={e => updateReplyText(e.target.value)}
 onKeyDown={handleKeyDown}
 placeholder={
 noteMode
 ? "Internal note (not sent to customer)…"
 : sendBlocked
 ? "WhatsApp 24h window closed — Call/Email above, or switch to Internal Note"
 : "Message"
 }
 className={`resize-none overflow-hidden text-[15px] text-gray-900 placeholder:text-gray-400 min-h-[40px] py-2 px-3 rounded-none border transition-colors leading-relaxed focus-visible:ring-0 ${
 noteMode
 ? "bg-amber-50 border-amber-200 focus:border-amber-400"
 : "bg-[#F0F0F0] border-transparent focus:border-gray-300 focus:bg-white"
 }`}
 rows={1}
 data-testid="reply-input"
 />
 )}
 {attachFile && <div className="flex-1 h-10" />}
 </div>

 {/* Right icon group — emoji, note toggle, templates/canned, send */}
 <div className="flex items-center gap-0.5 pb-0.5">
 {/* Emoji */}
 <button
 onClick={() => { setShowEmojiPicker(v => !v); setShowQuickReplies(false); setShowTemplates(false); }}
 className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
 showEmojiPicker ? "text-yellow-500 bg-yellow-50" : "text-gray-400 hover:text-yellow-500 hover:bg-gray-100"
 }`}
 title="Emoji"
 data-testid="btn-emoji-picker"
 >
 <Smile className="w-5 h-5" />
 </button>

 {/* Internal Note toggle */}
 <button
 onClick={() => {
 if (noteMode) { setNoteMode(false); }
 else { setNoteMode(true); setShowQuickReplies(false); setShowTemplates(false); if (attachFile) clearAttach(true); }
 }}
 className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
 noteMode ? "text-amber-600 bg-amber-100" : "text-gray-400 hover:text-amber-500 hover:bg-gray-100"
 }`}
 title={noteMode ? "Cancel note mode" : "Write internal note (not sent to customer)"}
 data-testid="mode-note"
 >
 <StickyNote className="w-4.5 h-4.5 w-[18px] h-[18px]" />
 </button>

 {/* Templates + Canned — shown only in message mode */}
 {!noteMode && (
 <button
 onClick={() => {
 if (showTemplates || showQuickReplies) { setShowTemplates(false); setShowQuickReplies(false); }
 else { setShowTemplates(true); setShowEmojiPicker(false); }
 }}
 className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
 showTemplates || showQuickReplies ? "text-[#0A0A0A] bg-[#EBE9E2]" : "text-gray-400 hover:text-[#0A0A0A] hover:bg-gray-100"
 }`}
 title="Quick templates and canned replies"
 data-testid="btn-templates"
 >
 <ListChecks className="w-[18px] h-[18px]" />
 </button>
 )}

 {/* Send / record button — WhatsApp style: mic when empty, send when text */}
 {(replyText.trim() || attachFile) ? (
 <Button
 onClick={handleSend}
 disabled={sendBlocked || (!noteMode && composerMustReconcile) || (!noteMode && currentAttemptAlreadyFailed) || (attachFile ? isSending : (!replyText.trim() || isSending))}
 title={sendBlocked ? "WhatsApp 24-hour window is closed — switch to Internal Note, or use Call/Email" : undefined}
 className={`w-9 h-9 rounded-full text-white flex-shrink-0 p-0 flex items-center justify-center disabled:opacity-40 transition-all ml-0.5 ${
 noteMode ? "bg-amber-500 hover:bg-amber-600" : "bg-[#25D366] hover:bg-[#1db954]"
 }`}
 data-testid="send-reply"
 >
 {isSending
 ? <div className="w-3.5 h-3.5 border-2 border-white/50 border-t-white rounded-full animate-spin" />
 : noteMode ? <StickyNote className="w-4 h-4" /> : <Send className="w-4 h-4" />
 }
 </Button>
 ) : (
 <button
 className="w-9 h-9 rounded-full bg-[#25D366] text-white flex-shrink-0 flex items-center justify-center ml-0.5"
 title="Hold to record voice (coming soon)"
 data-testid="btn-voice"
 onClick={() => textareaRef.current?.focus()}
 >
 <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current"><path d="M12 15c1.66 0 3-1.34 3-3V6c0-1.66-1.34-3-3-3S9 4.34 9 6v6c0 1.66 1.34 3 3 3zm5.91-3c-.49 0-.9.36-.98.85C16.52 15.2 14.47 17 12 17s-4.52-1.8-4.93-4.15c-.08-.49-.49-.85-.98-.85-.61 0-1.09.54-1 1.14.49 3 2.89 5.35 5.91 5.78V21c0 .55.45 1 1 1s1-.45 1-1v-2.08c3.02-.43 5.42-2.78 5.91-5.78.1-.6-.39-1.14-1-1.14z"/></svg>
 </button>
 )}
 </div>

 </div>
 </div>
 </div>
 </div>
 </div>
 );
}

// ── SwipeableConvoRow ──────────────────────────────────────────────────────────
// Uses native addEventListener with { passive: false } so we can call
// e.preventDefault() on horizontal swipes — this stops iOS scroll from
// stealing the gesture, which is the root cause of the swipe not sticking.

function SwipeableConvoRow({
 phone,
 onOpen,
 onDelete,
 isSelected,
 className,
 children,
}: {
 phone: string;
 onOpen: () => void;
 onDelete: () => void;
 isSelected: boolean;
 className?: string;
 children: React.ReactNode;
}) {
 const DELETE_W = 80;
 const rowRef = useRef<HTMLDivElement>(null);
 const slideRef = useRef<HTMLDivElement>(null);
 // Use a single mutable ref for all gesture state to avoid stale-closure issues
 const g = useRef({ startX: 0, startY: 0, open: false, offset: 0, moved: false, dirLocked: false });
 const [renderOffset, setRenderOffset] = useState(0);
 const [animated, setAnimated] = useState(false);
 const isOpenRef = useRef(false);

 const animateTo = (x: number) => {
 setAnimated(true);
 setRenderOffset(x);
 isOpenRef.current = x < 0;
 g.current.open = x < 0;
 g.current.offset = x;
 };

 const close = () => animateTo(0);
 const open = () => animateTo(-DELETE_W);

 // Attach non-passive touch listeners to the sliding element
 useEffect(() => {
 const el = slideRef.current;
 if (!el) return;

 const onStart = (e: TouchEvent) => {
 g.current.startX = e.touches[0].clientX;
 g.current.startY = e.touches[0].clientY;
 g.current.moved = false;
 g.current.dirLocked = false;
 setAnimated(false);
 };

 const onMove = (e: TouchEvent) => {
 const dx = e.touches[0].clientX - g.current.startX;
 const dy = e.touches[0].clientY - g.current.startY;

 if (!g.current.dirLocked) {
 if (Math.abs(dx) < 4 && Math.abs(dy) < 4) return; // too small to determine
 g.current.dirLocked = true;
 if (Math.abs(dy) > Math.abs(dx)) return; // vertical — let scroll win
 }
 // Horizontal swipe: prevent the list from scrolling vertically
 e.preventDefault();
 g.current.moved = true;
 const base = g.current.open ? -DELETE_W : 0;
 const newOffset = Math.min(0, Math.max(-DELETE_W, base + dx));
 g.current.offset = newOffset;
 setRenderOffset(newOffset);
 };

 const onEnd = (e: TouchEvent) => {
 const dx = e.changedTouches[0].clientX - g.current.startX;
 if (!g.current.moved) {
 // It was a tap, not a swipe
 if (g.current.open) close();
 else onOpen();
 return;
 }
 if (g.current.open) {
 dx > 30 ? close() : open();
 } else {
 dx < -40 ? open() : close();
 }
 };

 el.addEventListener("touchstart", onStart, { passive: true });
 el.addEventListener("touchmove", onMove, { passive: false }); // ← key: non-passive
 el.addEventListener("touchend", onEnd, { passive: true });
 return () => {
 el.removeEventListener("touchstart", onStart);
 el.removeEventListener("touchmove", onMove);
 el.removeEventListener("touchend", onEnd);
 };
 // onOpen is stable — defined inline in the map, but re-attaching on each render is fine
 // eslint-disable-next-line react-hooks/exhaustive-deps
 }, []);

 // Close when another conversation is selected or when tapping outside
 useEffect(() => {
 if (!isSelected && isOpenRef.current) close();
 }, [isSelected]);

 useEffect(() => {
 if (!isOpenRef.current) return;
 const onOutside = (e: TouchEvent | MouseEvent) => {
 if (rowRef.current && !rowRef.current.contains(e.target as Node)) close();
 };
 document.addEventListener("touchstart", onOutside, { passive: true });
 document.addEventListener("mousedown", onOutside);
 return () => {
 document.removeEventListener("touchstart", onOutside);
 document.removeEventListener("mousedown", onOutside);
 };
 }, [renderOffset]); // re-subscribe when open state changes via renderOffset

 return (
 <div ref={rowRef} className="relative overflow-hidden border-b border-zinc-100">
 {/* Red action — sits behind the sliding row */}
 <div className="absolute inset-y-0 right-0 w-[80px] flex items-center justify-center bg-red-500">
 <button
 onTouchEnd={e => { e.stopPropagation(); onDelete(); }}
 onClick={e => { e.stopPropagation(); onDelete(); }}
 className="flex flex-col items-center justify-center gap-1 text-white w-full h-full active:bg-red-600 transition-colors"
 data-testid={`delete-convo-${phone}`}
 >
 <Trash2 className="w-[22px] h-[22px]" />
 <span className="text-[11px] font-bold tracking-wide">Delete</span>
 </button>
 </div>
 {/* Sliding foreground */}
 <div
 ref={slideRef}
 style={{
 transform: `translateX(${renderOffset}px)`,
 transition: animated ? "transform 0.22s cubic-bezier(0.25,0.46,0.45,0.94)" : "none",
 willChange: "transform",
 }}
 className={`relative z-10 bg-white ${className ?? ""}`}
 >
 {children}
 </div>
 </div>
 );
}

// ── Main ───────────────────────────────────────────────────────────────────────

export default function AdminConversations() {
 const [,setComposerEpoch]=useState(0);
 const composer=useRef<ComposerSession>({drafts:{},requests:{},actions:new Set(),quoteRequests:{},quoteActions:new Set(),notes:{},changed:()=>{}});
 composer.current.changed=()=>setComposerEpoch(v=>v+1);
 const [selectedPhone, setSelectedPhone] = useState<string | null>(() => {
   const phone = new URLSearchParams(window.location.search).get("phone");
   return phone && /^\+?\d{8,15}$/.test(phone) ? phone.replace(/\D/g, "") : null;
 });
 const [search, setSearch] = useState("");
 const [filter, setFilter] = useState<"all" | "unread" | "active" | "submitted" | "escalation">("all");
 const [showNewChat, setShowNewChat] = useState(false);
 const [newChatPhone, setNewChatPhone] = useState("");
 const [newChatMessage, setNewChatMessage] = useState("");
 const queryClient = useQueryClient();
 const { toast } = useToast();

 const deleteConvoMutation = useMutation({
 mutationFn: (phone: string) => apiRequest("DELETE", `/api/admin/whatsapp/conversations/${phone}`),
 onSuccess: (_data, phone) => {
 queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations"] });
 if (selectedPhone === phone) setSelectedPhone(null);
 toast({ title: "Conversation deleted" });
 },
 onError: () => toast({ title: "Failed to delete", variant: "destructive" }),
 });

 /* Override the dark landing-page gradient on <html> so any layout gaps are white */
 useEffect(() => {
 const prev = document.documentElement.style.background;
 document.documentElement.style.background = "white";
 return () => { document.documentElement.style.background = prev; };
 }, []);

 /* Container height: visual viewport minus the fixed 56px admin header.
 visualViewport.height already excludes the keyboard (when open) and the
 Safari bottom toolbar, so the container stays in the visible area naturally.
 interactive-widget=resizes-content (set in index.html) makes the layout
 viewport also resize with the keyboard on iOS 16+, which means in-flow
 elements at the bottom of a 100dvh container are never behind the keyboard. */
 useEffect(() => {
 const update = () => {
 const vh = window.visualViewport?.height ?? window.innerHeight;
 document.documentElement.style.setProperty("--conv-h", `${vh - 56}px`);
 };
 update();
 window.visualViewport?.addEventListener("resize", update);
 window.addEventListener("resize", update);
 return () => {
 window.visualViewport?.removeEventListener("resize", update);
 window.removeEventListener("resize", update);
 };
 }, []);

 const { data: convos = [], isLoading: loadingConvos } = useQuery<Conversation[]>({
 queryKey: ["/api/admin/whatsapp/conversations"],
 refetchInterval: 6_000,
 refetchIntervalInBackground: true,
 });

 // ── Push notification subscription state ──────────────────────────────────
 // Used to render an "Enable alerts" banner when the admin hasn't opted in.
 const { state: pushState, subscribe: subscribePush } = useAdminPush();
 const [pushBannerDismissed, setPushBannerDismissed] = useState<boolean>(() => {
 try { return sessionStorage.getItem("convos_push_banner_dismissed") === "1"; }
 catch { return false; }
 });

 // ── Audible chime + tab-title flash for new inbound messages ──────────────
 // Works without push permission as long as the page is open. Uses Web Audio
 // to synthesise a short two-note chime so we don't ship an audio asset.
 const audioCtxRef = useRef<AudioContext | null>(null);
 const titleFlashRef = useRef<{ orig: string; timer: number | null }>({ orig: "", timer: null });
 function playChime() {
 try {
 const Ctx = (window as any).AudioContext || (window as any).webkitAudioContext;
 if (!Ctx) return;
 if (!audioCtxRef.current) audioCtxRef.current = new Ctx();
 const ctx = audioCtxRef.current!;
 if (ctx.state === "suspended") ctx.resume().catch(() => {});
 const now = ctx.currentTime;
 [880, 1320].forEach((freq, i) => {
 const osc = ctx.createOscillator();
 const gain = ctx.createGain();
 osc.type = "sine";
 osc.frequency.value = freq;
 gain.gain.setValueAtTime(0.0001, now + i * 0.18);
 gain.gain.exponentialRampToValueAtTime(0.18, now + i * 0.18 + 0.02);
 gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.18 + 0.16);
 osc.connect(gain).connect(ctx.destination);
 osc.start(now + i * 0.18);
 osc.stop(now + i * 0.18 + 0.18);
 });
 } catch {/* noop */}
 }
 function flashTitle(message: string) {
 try {
 if (!titleFlashRef.current.orig) titleFlashRef.current.orig = document.title;
 let toggle = false;
 if (titleFlashRef.current.timer) window.clearInterval(titleFlashRef.current.timer);
 titleFlashRef.current.timer = window.setInterval(() => {
 document.title = toggle ? titleFlashRef.current.orig : `🔔 ${message}`;
 toggle = !toggle;
 }, 1000);
 } catch {/* noop */}
 }
 // Stop the title flash as soon as the admin focuses the tab. Both listeners
 // and any active timer are cleaned up on unmount to avoid leaks across
 // remounts (the user might navigate away from this page and come back).
 useEffect(() => {
 function clearFlash() {
 if (titleFlashRef.current.timer) {
 window.clearInterval(titleFlashRef.current.timer);
 titleFlashRef.current.timer = null;
 }
 if (titleFlashRef.current.orig) document.title = titleFlashRef.current.orig;
 }
 function onVisibility() { if (!document.hidden) clearFlash(); }
 window.addEventListener("focus", clearFlash);
 document.addEventListener("visibilitychange", onVisibility);
 return () => {
 window.removeEventListener("focus", clearFlash);
 document.removeEventListener("visibilitychange", onVisibility);
 clearFlash();
 };
 }, []);

 // Track previous unread counts to detect new messages in background conversations
 const prevConvosRef = useRef<Conversation[]>([]);
 const selectedPhoneRef = useRef(selectedPhone);
 selectedPhoneRef.current = selectedPhone;
 useEffect(() => {
 if (!convos.length) { prevConvosRef.current = convos; return; }
 const prev = prevConvosRef.current;
 if (prev.length > 0) {
 for (const convo of convos) {
 if (convo.phone === selectedPhoneRef.current) continue;
 const prevConvo = prev.find(p => p.phone === convo.phone);
 if (!prevConvo) continue;
 if (convo.unreadCount > prevConvo.unreadCount) {
 const who = convo.name || formatPhone(convo.phone);
 const preview = stripWhatsAppMarkdown(convo.lastMessage || "").slice(0, 80);
 toast({ title: `💬 ${who}`, description: preview });
 playChime();
 if (document.hidden) flashTitle(`New message from ${who}`);
 break;
 }
 }
 }
 prevConvosRef.current = convos;
 }, [convos]);

 const selectedConvo = convos.find(c => c.phone === selectedPhone);
 const totalUnread = convos.reduce((s, c) => s + c.unreadCount, 0);
 const totalEscalation = convos.filter(c => c.botPaused).length;
 const totalPendingQuotes = convos.filter(c => !!c.pendingQuoteRef).length;

 const filteredConvos = convos.filter(c => {
 const q = search.toLowerCase();
 const matchSearch = !q || [c.name, c.phone, c.lastMessage].some(v => v?.toLowerCase().includes(q));
 const matchFilter =
 filter === "unread" ? c.unreadCount > 0 :
 filter === "active" ? (!!c.state && c.state !== "submitted") :
 filter === "submitted" ? c.state === "submitted" :
 filter === "escalation" ? c.botPaused :
 true;
 return matchSearch && matchFilter;
 });

 const newChatMutation = useMutation({
 mutationFn: async ({ phone, message }: { phone: string; message: string }) => {
 const res = await apiRequest("POST", "/api/admin/whatsapp/conversations/new", { phone, message });
 return res.json();
 },
 onSuccess: (data: any) => {
 setShowNewChat(false);
 setNewChatPhone("");
 setNewChatMessage("");
 queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations"] });
 if (data?.phone) setSelectedPhone(data.phone);
 toast({ title: "Message sent", description: "Conversation started. Bot is paused — you're in admin mode." });
 },
 onError: (err: any) => {
 let reason = err?.message || "Failed to send message";
 try { reason = JSON.parse(reason.replace(/^\d+:\s*/, "")).message || reason; } catch {}
 toast({ title: "Failed to start chat", description: reason, variant: "destructive" });
 },
 });

 function openConvo(phone: string) {
 const url=new URL(window.location.href);url.searchParams.set("phone",phone);window.history.replaceState(null,"",url);
 setSelectedPhone(phone);
 queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations"] });
 }

 return (
 <div
 className="flex bg-[#F5F4F0] overflow-hidden lg:pl-56"
 style={{ marginTop: 56, height: "var(--conv-h, calc(100dvh - 56px))" }}
 data-testid="admin-conversations"
 >

 {/* ═══ New Chat Dialog ════════════════════════════════════════════════ */}
 {showNewChat && (
 <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/50 " onClick={() => setShowNewChat(false)}>
 <div className="bg-white rounded-none w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
 <div className="flex items-center justify-between mb-5">
 <div>
 <h2 className="text-base font-bold text-gray-900">New Chat</h2>
 <p className="text-xs text-gray-400 mt-0.5">Start a conversation with any number</p>
 </div>
 <button onClick={() => setShowNewChat(false)} className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-gray-400">
 <X className="w-4 h-4" />
 </button>
 </div>
 <div className="space-y-3">
 <div>
 <label className="text-xs font-semibold text-gray-500 mb-1 block">Phone Number (SG)</label>
 <input
 type="tel"
 value={newChatPhone}
 onChange={e => setNewChatPhone(e.target.value)}
 placeholder="e.g. 91234567 or 6591234567"
 className="w-full h-10 px-3 text-sm border border-gray-200 rounded-none focus:outline-none focus:border-blue-400 bg-gray-50 placeholder:text-gray-400"
 data-testid="new-chat-phone"
 autoFocus
 />
 </div>
 <div>
 <label className="text-xs font-semibold text-gray-500 mb-1 block">First Message</label>
 <textarea
 value={newChatMessage}
 onChange={e => setNewChatMessage(e.target.value)}
 placeholder="Hi! I'm reaching out from TMG Install regarding your enquiry…"
 rows={3}
 className="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-none focus:outline-none focus:border-blue-400 bg-gray-50 placeholder:text-gray-400 resize-none"
 data-testid="new-chat-message"
 />
 </div>
 <div className="flex gap-2 pt-1">
 <button onClick={() => setShowNewChat(false)} className="flex-1 py-2.5 text-sm font-semibold rounded-none border border-gray-200 text-gray-500 hover:bg-gray-50 transition-all">
 Cancel
 </button>
 <button
 onClick={() => {
 if (!newChatPhone.trim() || !newChatMessage.trim()) return;
 newChatMutation.mutate({ phone: newChatPhone.trim(), message: newChatMessage.trim() });
 }}
 disabled={!newChatPhone.trim() || !newChatMessage.trim() || newChatMutation.isPending}
 data-testid="new-chat-send"
 className="flex-1 py-2.5 text-sm font-semibold rounded-none bg-[#25D366] text-white hover:bg-[#1db954] disabled:opacity-50 transition-all flex items-center justify-center gap-2"
 >
 {newChatMutation.isPending
 ? <div className="w-4 h-4 border-2 border-white/50 border-t-white rounded-full animate-spin" />
 : <Send className="w-3.5 h-3.5" />
 }
 Send Message
 </button>
 </div>
 </div>
 </div>
 </div>
 )}

 {/* ═══ Conversation List — full width on mobile when no chat, fixed width on desktop ═══ */}
 <div className={`flex flex-col flex-shrink-0 border-r border-gray-200 bg-white w-full lg:w-[340px] xl:w-[380px] ${selectedPhone ? "hidden lg:flex" : "flex"}`}>
 {/* Header — dark green like WhatsApp sidebar */}
 <div style={{ background: "#1f2c34" }}>
 <div className="flex items-center justify-between px-4 pt-4 pb-3">
 <div className="flex items-center gap-2">
 <span className="text-[16px] font-semibold text-white">WhatsApp</span>
 {totalUnread > 0 && (
 <span className="px-2 py-0.5 rounded-full bg-[#25D366] text-white text-[10px] font-bold min-w-[20px] text-center">
 {totalUnread > 99 ? "99+" : totalUnread}
 </span>
 )}
 {totalPendingQuotes > 0 && (
 <span className="px-2 py-0.5 rounded-full bg-blue-500 text-white text-[10px] font-bold min-w-[20px] text-center" title={`${totalPendingQuotes} pending quote${totalPendingQuotes !== 1 ? 's' : ''}`}>
 📋 {totalPendingQuotes}
 </span>
 )}
 </div>
 <div className="flex items-center gap-1">
 <button
 onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp/conversations"] })}
 className="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center text-white/60 hover:text-white transition-all"
 data-testid="refresh-conversations"
 title="Refresh"
 >
 <RefreshCw className="w-4 h-4" />
 </button>
 <button
 onClick={() => setShowNewChat(true)}
 data-testid="new-chat-btn"
 className="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center text-white/60 hover:text-white transition-all"
 title="New chat"
 >
 <Plus className="w-4.5 h-4.5 w-[18px] h-[18px]" />
 </button>
 </div>
 </div>

 {/* Enable-alerts banner — shows when admin hasn't subscribed to push.
 Also shown for "unsupported" so users on browsers without push
 support get clear fallback guidance instead of silent failure. */}
 {!pushBannerDismissed && (pushState === "default" || pushState === "denied" || pushState === "unsupported") && (
 <div className="mx-3 mb-3 rounded-lg bg-amber-500/15 border border-amber-400/30 px-3 py-2.5 flex items-start gap-2.5" data-testid="push-banner">
 <span className="text-amber-300 text-sm leading-none mt-0.5">🔔</span>
 <div className="flex-1 min-w-0">
 <p className="text-[12px] font-semibold text-amber-100 leading-tight">
 {pushState === "denied" ? "Notifications blocked"
 : pushState === "unsupported" ? "Background alerts not available"
 : "Get alerted when customers text"}
 </p>
 <p className="text-[11px] text-amber-100/70 mt-0.5 leading-snug">
 {pushState === "denied"
 ? "Allow notifications in your browser settings, then reload this page."
 : pushState === "unsupported"
 ? "This browser doesn't support background notifications. Keep this tab open — you'll still hear a chime and see a tab-title alert when a new message arrives."
 : "Turn on browser notifications to be alerted the moment a new WhatsApp message arrives — even when this tab isn't open."}
 </p>
 {pushState === "default" && (
 <button
 onClick={async () => {
 const ok = await subscribePush();
 if (ok) toast({ title: "Alerts enabled", description: "You'll get a notification on every new message." });
 else toast({ title: "Could not enable alerts", description: "Check your browser notification settings.", variant: "destructive" });
 }}
 data-testid="button-enable-push"
 className="mt-1.5 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-amber-400 text-amber-950 text-[11px] font-bold hover:bg-amber-300 transition-all"
 >
 Enable alerts
 </button>
 )}
 </div>
 <button
 onClick={() => {
 setPushBannerDismissed(true);
 try { sessionStorage.setItem("convos_push_banner_dismissed", "1"); } catch {}
 }}
 data-testid="button-dismiss-push-banner"
 className="text-amber-100/60 hover:text-amber-100 transition-colors flex-shrink-0"
 title="Dismiss"
 >
 <X className="w-3.5 h-3.5" />
 </button>
 </div>
 )}

 {/* Search — dark styled */}
 <div className="relative mx-3 mb-3">
 <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/40 pointer-events-none" />
 <input
 type="text"
 value={search}
 onChange={e => setSearch(e.target.value)}
 placeholder="Search or start new chat"
 className="h-9 w-full rounded-lg text-sm text-white placeholder:text-white/40 pl-9 pr-7 focus:outline-none transition-all"
 style={{ background: "#2a3942" }}
 data-testid="search-conversations"
 />
 {search && (
 <button onClick={() => setSearch("")} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/80">
 <X className="w-3 h-3" />
 </button>
 )}
 </div>
 </div>

 {/* Filter Tabs — Yeezy flat, ink-underline for active, urgent red for attention */}
 <div className="px-3 pt-2 pb-0 border-b border-black/10 bg-white">
 <div className="flex gap-0">
 {(["all", "unread", "active", "escalation", "submitted"] as const).map(f => {
 const isActive = filter === f;
 const isUrgent = f === "escalation" && totalEscalation > 0;
 return (
 <button
 key={f}
 onClick={() => setFilter(f)}
 className={`flex-1 text-[11px] font-bold uppercase tracking-wider py-2 transition-colors relative ${
 isActive
 ? isUrgent
 ? "text-[#C1121F]"
 : "text-[#0A0A0A]"
 : isUrgent
 ? "text-[#C1121F]/70 hover:text-[#C1121F]"
 : "text-[#0A0A0A]/45 hover:text-[#0A0A0A]"
 }`}
 data-testid={`filter-${f}`}
 >
 {f === "escalation" ? (
 <span className="inline-flex items-center justify-center gap-1">
 <AlertCircle className="w-3 h-3 flex-shrink-0" />
 <span>{totalEscalation > 0 ? totalEscalation : "0"}</span>
 </span>
 ) : f === "unread" && totalUnread > 0 ? (
 `Unread · ${totalUnread}`
 ) : (
 f.charAt(0).toUpperCase() + f.slice(1)
 )}
 {/* Active underline */}
 <span className={`absolute left-2 right-2 -bottom-px h-0.5 transition-opacity ${
 isActive ? (isUrgent ? "bg-[#C1121F] opacity-100" : "bg-[#0A0A0A] opacity-100") : "opacity-0"
 }`} />
 </button>
 );
 })}
 </div>
 </div>

 {/* List */}
 <div className="flex-1 overflow-y-auto overscroll-contain">
 {loadingConvos && [0,1,2,3].map(i => <ConvoSkeleton key={i} />)}

 {!loadingConvos && filteredConvos.length === 0 && (
 <div className="flex flex-col items-center justify-center py-20 gap-3 px-6 text-center">
 <div className={`w-14 h-14 rounded-none flex items-center justify-center ${filter === "escalation" ? "bg-red-50" : "bg-zinc-100"}`}>
 {filter === "escalation"
 ? <AlertCircle className="w-7 h-7 text-red-300" />
 : <MessageCircle className="w-7 h-7 text-zinc-300" />
 }
 </div>
 <p className="text-sm font-medium text-zinc-400">
 {search ? "No results found" : filter === "escalation" ? "No escalations — all clear!" : filter !== "all" ? `No ${filter} conversations` : "No conversations yet"}
 </p>
 </div>
 )}

 {filteredConvos.map(convo => {
 const sc = getState(convo.state);
 const hasUnread = convo.unreadCount > 0;
 const isPaused = convo.botPaused;
 return (
 <SwipeableConvoRow
 key={convo.phone}
 phone={convo.phone}
 onOpen={() => openConvo(convo.phone)}
 onDelete={() => deleteConvoMutation.mutate(convo.phone)}
 isSelected={selectedPhone === convo.phone}
 className={
 selectedPhone === convo.phone ? "bg-blue-50" :
 isPaused ? "bg-red-50/40" : ""
 }
 >
 <button
 onClick={() => openConvo(convo.phone)}
 data-testid={`convo-${convo.phone}`}
 className={`w-full text-left px-4 py-3.5 cursor-pointer transition-colors ${
 selectedPhone === convo.phone ? "bg-[#e9f5fb] hover:bg-[#e0eef8]" :
 isPaused ? "hover:bg-red-50/60" : "hover:bg-[#f5f5f5]"
 }`}
 >
 <div className="flex items-center gap-3">
 <div className="relative flex-shrink-0">
 <Avatar name={convo.name} phone={convo.phone} size="md" />
 {isPaused
 ? <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-white bg-red-500" />
 : <span className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-white ${sc.dot}`} />
 }
 </div>
 <div className="flex-1 min-w-0">
 <div className="flex items-baseline justify-between gap-2">
 <span className={`text-[14.5px] leading-tight truncate ${hasUnread ? "font-semibold text-zinc-900" : "font-medium text-zinc-700"}`}>
 {convo.name || formatPhone(convo.phone)}
 </span>
 <span className={`text-[11px] flex-shrink-0 tabular-nums ${hasUnread ? "text-[#25D366] font-semibold" : "text-zinc-400"}`}>
 {relativeTime(convo.lastAt)}
 </span>
 </div>
 <div className="flex items-center justify-between gap-2 mt-0.5">
 <p className={`text-[13px] truncate leading-snug flex-1 min-w-0 ${hasUnread ? "text-zinc-700 font-medium" : "text-zinc-400"}`}>
 {convo.lastMessage ? stripWhatsAppMarkdown(convo.lastMessage) : (convo.name ? formatPhone(convo.phone) : "WhatsApp")}
 </p>
 {hasUnread && (
 <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-[#25D366] text-white text-[11px] font-bold flex items-center justify-center flex-shrink-0">
 {convo.unreadCount > 9 ? "9+" : convo.unreadCount}
 </span>
 )}
 </div>
 {(isPaused || convo.pendingQuoteRef || selectedPhone === convo.phone) && (
 <div className="flex items-center gap-1.5 mt-1 flex-wrap">
 {isPaused && (
 <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md text-red-700 bg-red-50 border border-red-200 flex items-center gap-1">
 <AlertCircle className="w-2.5 h-2.5" /> Needs Attention
 </span>
 )}
 {convo.pendingQuoteRef && (
 <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md text-[#0A0A0A] bg-blue-50 border border-blue-200 flex items-center gap-1">
 📋 {convo.pendingQuoteRef} · {convo.pendingQuoteStatus === 'new' ? 'New Request' : 'Quote Sent'}
 </span>
 )}
 {!isPaused && !convo.pendingQuoteRef && selectedPhone === convo.phone && (
 <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md border ${sc.color} ${sc.bg}`}>
 {sc.label}
 </span>
 )}
 </div>
 )}
 </div>
 </div>
 </button>
 </SwipeableConvoRow>
 );
 })}
 </div>

 <div className="px-4 py-2 border-t border-zinc-100">
 <p className="text-[10px] text-zinc-400">{convos.length} conversation{convos.length !== 1 ? "s" : ""} · auto-refreshes</p>
 </div>
 </div>

 {/* Right side: ChatPanel or empty state */}
 {selectedPhone ? (
 <ChatPanel
 selectedPhone={selectedPhone}
 selectedConvo={selectedConvo}
 composer={composer.current}
 onClose={() => {const url=new URL(window.location.href);url.searchParams.delete("phone");window.history.replaceState(null,"",url);setSelectedPhone(null);}}
 />
 ) : (
 <div className="hidden lg:flex flex-1 items-center justify-center flex-col gap-4 bg-[#F5F4F0]">
 <div className="w-16 h-16 rounded-none bg-white border border-zinc-200 flex items-center justify-center">
 <MessageCircle className="w-8 h-8 text-zinc-300" />
 </div>
 <div className="text-center">
 <p className="text-sm font-semibold text-zinc-400">Select a conversation</p>
 <p className="text-xs text-zinc-300 mt-1">Click any chat to open it · or start a new one</p>
 </div>
 <button
 onClick={() => setShowNewChat(true)}
 className="flex items-center gap-1.5 px-4 py-2 rounded-none bg-[#25D366] text-white text-sm font-semibold hover:bg-[#1db954] transition-all "
 data-testid="empty-state-new-chat"
 >
 <Plus className="w-4 h-4" /> New Chat
 </button>
 </div>
 )}
 </div>
 );
}
