import { useParams, Link, useLocation } from "wouter";
import {PaymentEvidenceCorrection} from "@/components/admin/PaymentEvidenceCorrection";
import {fillDetectedAdminRate} from "@shared/adminCatalogRate";
import { useQuote, useUpdateQuoteStatus, useRequestFinalPayment, useConfirmBooking, useEditQuote, useCloseQuote } from "@/hooks/use-quotes";
import { useStaffList } from "@/hooks/use-staff";
import { useQuery, useMutation } from "@tanstack/react-query";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { useState, useEffect, useRef } from "react";
import { 
 ArrowLeft, UserPlus, CheckCircle2, Clock, MapPin, Receipt, AlertTriangle, 
 DollarSign, Phone, MessageCircle, Edit2, Save, X, Plus, Trash2, Calendar, XCircle, Camera,
 ClipboardList, CalendarCheck, Zap, BadgeCheck, AlertOctagon, Send, Loader2, Mail,
 Printer, Timer, QrCode, RotateCcw, Handshake, Sparkles, FileText, Copy, Users, PenLine, Wallet,
 ArrowRight, Route, Truck, Shield,
} from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatItemDescription, formatItemServiceLabel, hasPartialWorkScope, requiresStaffTimeAssessment } from "@/lib/itemLabel";
import { calcOvertimeCharge, calcSecondDayContinuation, requiresFullUpfront, splitDepositFinal, PricingConfig, evaluateJobMargin, getJobSchedule, computeSiteTime, detectTimingFlags, computeMultiStopRelocationPrice, relocationVolumeFromCatalog, isWrappingRollupLine, effectiveCarryPrice, computeDRPrice, type SiteVisit, type MultiStopPriceResult } from "@shared/pricing";
import { BusinessRulesDefaults } from "@shared/businessRules";
import { quotePaymentSummary } from "@shared/paymentState";
import {isReviewQuotation,hasGeneratedReviewNotes,customerQuotationNote,isTransportPricingPending} from "@shared/quotation-document-notes";
import { QuoteScheduleNote } from "@/components/shared/QuoteScheduleNote";
import { getQuoteTerms } from "@shared/terms";
import { PaymentMessageDialog } from "@/components/shared/PaymentMessageDialog";
import { InvoiceMessageDialog } from "@/components/shared/InvoiceMessageDialog";
import type { QuoteStop, CatalogItem } from "@shared/schema";
import { genStopId, groupStops, itemRouteLabel } from "@/lib/stops";
import { StaffSchedulingReview } from "@/components/admin/StaffSchedulingReview";
import QuoteEditingWorkspace from "@/components/admin/QuoteEditingWorkspace";
import { QuoteWorkspaceReview, type QuoteWorkspaceFacts, type QuoteWorkspaceRequirement } from "@/components/admin/QuoteWorkspaceReview";
import {quoteDraftPayload,changedSurcharge,QuoteDraftValidation,pendingWorkspaceLine,reconcileWorkspaceDraft} from "@/lib/quotation-draft";
import {formatSingaporeDay} from "@/lib/singapore-calendar";
import {renderSavedQuoteDocument} from "@shared/quotation-document";

const TERMINAL_STATUSES_UI = ['closed', 'cancelled'];

// Multi-stop relocation (additive) editing helpers.
type MultiStopResult = MultiStopPriceResult;
interface EditStop {
 id: string;
 kind: "pickup" | "dropoff";
 address: string;
 postalCode: string;
 floor: string;
 hasLift: boolean | null;
}
const makeEditStop = (kind: "pickup" | "dropoff"): EditStop => ({
 id: genStopId(), kind, address: "", postalCode: "", floor: "", hasLift: null,
});

function formatMoney(v: any) {
 return `$${Number(v || 0).toFixed(2)}`;
}

function WhatsAppSourceOfTruth({ quote }: { quote: any }) {
 const intake = (quote.leadIntake && typeof quote.leadIntake === "object" && !Array.isArray(quote.leadIntake))
 ? quote.leadIntake as Record<string, any>
 : {};
 const record = (value: unknown): Record<string, any> =>
 value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, any> : {};
 // Producers have changed over time: current AI quotes wrap facts, legacy
 // quotes persist the rich wizard state, and admin-created quotes add routing.
 // Keep the intake's direct fields first, then AI facts, then legacy state.
 const currentFacts = record(intake.currentFacts);
 const structuredState = record(intake.structuredState);
 const routing = record(intake.routing);
 const first = (...values: any[]): any => values.find((value) =>
 value !== undefined && value !== null && value !== "");
 const intakeValue = (topLevel: string[], factFields: string[] = topLevel, stateFields: string[] = topLevel) =>
 first(...topLevel.map(key => intake[key]), ...factFields.map(key => currentFacts[key]), ...stateFields.map(key => structuredState[key]));
 const truthy = (value: unknown) => value === true ? "Yes" : value === false ? "No" : value ? String(value) : null;
 const selectedServices = intakeValue(["selectedServices"], ["selectedServices"], ["selected_services"]);
 const services = Array.isArray(selectedServices)
 ? selectedServices
 : typeof selectedServices === "string" && selectedServices.trim()
 ? selectedServices.split(",").map(service => service.trim()).filter(Boolean)
 : (() => { try { return JSON.parse(quote.selectedServices || "[]"); } catch { return []; } })();
 const itemScopes = [...new Set((quote.items || []).filter((item: any) => item.serviceType !== "discount").map((item: any) => formatItemServiceLabel(item, quote.items)).filter(Boolean))];
 const serviceLabel = itemScopes.length ? itemScopes.join(", ") : services.length
 ? services.map((service: string) => service.replace(/_/g, " + ")).join(", ")
 : intakeValue(["serviceType", "serviceIntent"], ["serviceType", "serviceIntent"], ["service_scope"]) || "—";
 const access = [
 intakeValue(["floorLevel"], ["floorLevel"], ["floor_from"]) != null ? `Floor ${intakeValue(["floorLevel"], ["floorLevel"], ["floor_from"])}` : null,
 truthy(intakeValue(["hasLift"], ["hasLift"], ["lift_from"])) ? `Lift: ${truthy(intakeValue(["hasLift"], ["hasLift"], ["lift_from"]))}` : null,
 intakeValue(["accessDifficulty"], ["accessDifficulty"], ["access_difficulty"]) ? `Access: ${intakeValue(["accessDifficulty"], ["accessDifficulty"], ["access_difficulty"])}` : null,
 ].filter(Boolean).join(" · ") || "—";
 const scheduled = quote.scheduledAt
 ? `${formatSingaporeDay(quote.scheduledAt, "MMM d, yyyy")} ${quote.timeWindow ? `· ${quote.timeWindow}` : ""}`
 : [quote.preferredDate || intakeValue(["preferredDate"], ["preferredDate"], ["preferred_date_iso", "preferred_date"]), quote.preferredTimeWindow || intakeValue(["preferredTimeWindow"], ["preferredTimeWindow"], ["preferred_time_window"])].filter(Boolean).join(" · ") || "Not set";
 const fromAddress = quote.pickupAddress || quote.serviceAddress || intakeValue(["jobAddress"], ["jobAddress"], ["from_address"]);
 const toAddress = quote.dropoffAddress || intakeValue(["toAddress"], ["toAddress"], ["to_address"]);
 const addresses = [fromAddress ? `From: ${fromAddress}` : null, toAddress ? `To: ${toAddress}` : null].filter(Boolean).join(" · ") || "—";
 const photosPresent = intakeValue(["photosPresent"], ["photosPresent"]);
 const photoSignal = photosPresent === true
 ? "Customer photos supplied"
 : quote.detectionPhotoUrl ? "Detection photo stored" : "No photo signal stored";
 const manualCategory = intakeValue(["manualCategoryHint", "manualCategory", "categoryOverride"]);
 const detectedCategory = intakeValue(["photoDetectedCategory", "detectedCategory", "leadCategory"], ["photoDetectedCategory", "detectedCategory", "leadCategory"]) || quote.leadCategory;
 const routeCategory = first(intake.leadCategory, routing.category, currentFacts.leadCategory, structuredState.lead_category, quote.leadCategory);
 const routePriority = first(intake.leadPriority, routing.priority, currentFacts.leadPriority, structuredState.lead_priority, quote.leadPriority);
 const routePath = first(intake.recommendedSalesPath, routing.path, routing.recommendedSalesPath, currentFacts.recommendedSalesPath, structuredState.recommended_sales_path, quote.recommendedSalesPath);
 const intakeMissingFacts = intakeValue(["missingFacts"], ["missingFacts"]);
 const reviewReasons = [
 ...(Array.isArray(intake.reviewReasons) ? intake.reviewReasons : []),
 ...(Array.isArray(currentFacts.reviewReasons) ? currentFacts.reviewReasons : []),
 intakeValue(["reviewReason", "manualReviewReason"], ["reviewReason", "manualReviewReason"]),
 intakeValue(["detectionNeedsReview"], ["detectionNeedsReview"]) ? "Photo detection requires review" : null,
 Array.isArray(intakeMissingFacts) && intakeMissingFacts.length ? `Missing facts: ${intakeMissingFacts.join(", ")}` : null,
 quote.requiresManualReview ? "Quote marked for manual review" : null,
 ...(quote.items || []).filter((item: any) => item.serviceType !== "discount" && !item.catalogItemId)
 .map((item: any) => `No canonical catalog match: ${item.detectedName || item.originalDescription}`),
 ...(String(quote.notes || "").split("\n").filter((line) =>
 /missing facts|unmatched items|review (?:price|required)|manual review/i.test(line))),
 ].filter(Boolean).map(String);
 const uniqueReviewReasons = reviewReasons.filter((reason, index) => reviewReasons.indexOf(reason) === index);
 const customerPhone = quote.customerWhatsappPhone || quote.customer?.phone || intakeValue(["conversationPhone", "phone"], ["phone"]) || "—";
 const conversationState = intakeValue(["conversationState"], ["aiState"]);
 const conversationDetail = [conversationState ? `State: ${conversationState}` : null, intake.whatsappEventKey ? "WhatsApp event recorded" : null].filter(Boolean).join(" · ");
 const intakeSource = intakeValue(["source", "sourceChannel"], ["sourceChannel"]) || quote.sourceChannel;
 const confidence = intakeValue(["confidenceLevel"], ["confidenceLevel"]);

  return (
  <details className="border border-emerald-200 bg-white" data-testid="section-whatsapp-source-of-truth">
  <summary className="cursor-pointer list-none px-4 py-3 text-xs font-semibold text-emerald-900 hover:bg-emerald-50 [&::-webkit-details-marker]:hidden">WhatsApp intake, history & provenance · collapsed</summary>
  <div className="border-t border-emerald-200">
  <div className="bg-white border-emerald-200 rounded-none overflow-hidden">
 <div className="px-5 py-3.5 bg-emerald-50 border-b border-emerald-200 flex items-center gap-2">
 <MessageCircle className="w-4 h-4 text-emerald-700" />
 <div>
 <h2 className="text-sm font-semibold text-emerald-900">WhatsApp intake reference</h2>
 <p className="text-[11px] text-emerald-700">Original intake summary. Use Edit quote to update customer details, items and charges.</p>
 </div>
 {customerPhone !== "—" && <a className="ml-auto text-xs font-semibold underline text-emerald-900" href={`/admin/conversations?phone=${encodeURIComponent(customerPhone)}`}>View Chat</a>}
 </div>
 <div className="p-5 space-y-4">
 <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-3 text-sm">
 <div><p className="text-xs text-zinc-500">Customer / contact</p><p className="text-zinc-900 font-medium">{quote.customer?.name || intakeValue(["customerName"], ["customerName"], ["customer_name"]) || "—"} <span className="font-normal text-zinc-500">· {customerPhone}</span></p></div>
 <div><p className="text-xs text-zinc-500">Conversation linkage / source</p><p className="text-zinc-900">WhatsApp · {intakeSource} · contact {customerPhone}{conversationDetail ? <span className="text-zinc-500"> · {conversationDetail}</span> : null}</p></div>
 <div><p className="text-xs text-zinc-500">Service / access</p><p className="text-zinc-900 capitalize">{serviceLabel} <span className="text-zinc-500 normal-case">· {access}</span></p></div>
 <div><p className="text-xs text-zinc-500">Schedule / addresses</p><p className="text-zinc-900">{scheduled} <span className="text-zinc-500">· {addresses}</span></p></div>
 <div><p className="text-xs text-zinc-500">Provenance / category / photo</p><p className="text-zinc-900">{manualCategory ? `Manual: ${manualCategory}` : "No manual category"} <span className="text-zinc-500">· {detectedCategory ? `Detected: ${detectedCategory}` : "No detected category"} · {photoSignal}</span></p></div>
 <div><p className="text-xs text-zinc-500">Quotation state</p><p className="text-zinc-900">{isReviewQuotation(quote) ? `Final pricing pending · proposed components ${formatMoney(quote.total)}` : `${formatMoney(quote.total)} · ${quotePaymentSummary(quote).status}`}</p></div>
 </div>
 <div className="border-t border-zinc-100 pt-3">
 <p className="text-xs font-semibold text-zinc-700 mb-1">Review reasons</p>
 {uniqueReviewReasons.length ? <ul className="list-disc pl-4 space-y-0.5 text-xs text-amber-800">{uniqueReviewReasons.map((reason) => <li key={reason}>{reason}</li>)}</ul> : <p className="text-xs text-zinc-500">No explicit review reason recorded.</p>}
 </div>
 </div>
  </div>
  </div>
  </details>
 );
}

function needsWhatsAppScopeReview(quote: any) {
 const raw = quote?.leadIntake;
 if (raw && typeof raw === "object" && !Array.isArray(raw)) return raw.quoteFixed === false;
 if (typeof raw === "string") {
  try { return JSON.parse(raw)?.quoteFixed === false; } catch { return false; }
 }
 return false;
}

function intakeFactsForQuote(quote: any): Record<string, any> {
 const raw=quote?.leadIntake;
 let intake:Record<string,any>={};
 if(raw&&typeof raw==="object"&&!Array.isArray(raw))intake=raw;
 else if(typeof raw==="string"){try{const parsed=JSON.parse(raw);if(parsed&&typeof parsed==="object"&&!Array.isArray(parsed))intake=parsed;}catch{}}
 const current=intake.currentFacts&&typeof intake.currentFacts==="object"?intake.currentFacts:{};
 const structured=intake.structuredState&&typeof intake.structuredState==="object"?intake.structuredState:{};
 const review=intake.workspaceReview&&typeof intake.workspaceReview==="object"?intake.workspaceReview:{};
 const reviewFacts=review.facts&&typeof review.facts==="object"?review.facts:{};
 const stops=Array.isArray(quote?.stops)?quote.stops:[];
 const pickup=stops.find((stop:any)=>stop.kind==="pickup");
 const dropoff=stops.find((stop:any)=>stop.kind==="dropoff");
 const first=(...values:any[])=>values.find(value=>value!==undefined&&value!==null&&value!=="");
 const booleanFact=(value:any)=>value===true||["true","yes","1"].includes(String(value).toLowerCase())?true:
  value===false||["false","no","0"].includes(String(value).toLowerCase())?false:null;
 return {
  customerName:first(quote?.customer?.name,intake.customerName,current.customerName,structured.customer_name,""),
  jobAddress:first(quote?.serviceAddress,quote?.pickupAddress,intake.jobAddress,current.jobAddress,structured.from_address,""),
  toAddress:first(quote?.dropoffAddress,dropoff?.address,intake.toAddress,current.toAddress,structured.to_address,""),
  floorLevel:first(pickup?.floor,reviewFacts.floorLevel,intake.floorLevel,current.floorLevel,structured.floor_from,""),
  hasLift:booleanFact(first(pickup?.hasLift,reviewFacts.hasLift,intake.hasLift,current.hasLift,structured.lift_from,null)),
  destinationFloor:first(dropoff?.floor,reviewFacts.destinationFloor,intake.destinationFloor,current.destinationFloor,structured.floor_to,""),
  destinationLift:booleanFact(first(dropoff?.hasLift,reviewFacts.destinationLift,intake.destinationLift,current.destinationLift,structured.lift_to,null)),
  itemLocation:first(reviewFacts.itemLocation,intake.itemLocation,current.itemLocation,structured.item_location,""),
  carryingRequired:booleanFact(first(reviewFacts.carryingRequired,intake.carryingRequired,current.carryingRequired,structured.carrying_required,null)),
  samePropertyMove:reviewFacts.samePropertyMove??intake.samePropertyMove??current.samePropertyMove??null,
  accessDifficulty:first(reviewFacts.accessDifficulty,intake.accessDifficulty,current.accessDifficulty,""),
 };
}

function intakeRequirementsForQuote(quote: any): QuoteWorkspaceRequirement[] {
 const raw=quote?.leadIntake;
 let intake:Record<string,any>={};
 if(raw&&typeof raw==="object"&&!Array.isArray(raw))intake=raw;
 else if(typeof raw==="string"){try{const parsed=JSON.parse(raw);if(parsed&&typeof parsed==="object"&&!Array.isArray(parsed))intake=parsed;}catch{}}
 const source=intake.reviewRequirements||intake.requirements||quote?.reviewRequirements||[];
 if(!Array.isArray(source))return [];
 return source.flatMap((item:any)=>typeof item==="string"?[{field:item,message:item}]:
  item&&typeof item==="object"&&item.field?[{field:String(item.field),message:String(item.message||"Needs review.")}]:[]);
}

function workspaceReviewForQuote(quote: any): Record<string, any> {
 const raw=quote?.leadIntake;
 let intake:Record<string,any>={};
 if(raw&&typeof raw==="object"&&!Array.isArray(raw))intake=raw;
 else if(typeof raw==="string"){try{const parsed=JSON.parse(raw);if(parsed&&typeof parsed==="object"&&!Array.isArray(parsed))intake=parsed;}catch{}}
 return intake.workspaceReview&&typeof intake.workspaceReview==="object"?intake.workspaceReview:{};
}

/** Determine which contact channels are available for a quote */
function getContactChannels(quote: any) {
 const email = quote?.customer?.email || "";
 const hasRealEmail = !!email && !email.includes("@tmginstall.com");
 const rawPhone = quote?.customerWhatsappPhone || quote?.customer?.phone || "";
 const hasPhone = !!rawPhone;
 return { hasRealEmail, hasPhone, email: hasRealEmail ? email : "", phone: rawPhone };
}

/**
 * Standardised payment notification buttons.
 * Renders Email / WhatsApp / Both buttons depending on available contact data.
 * Falls back to a phone-entry form when no contact info is stored.
 */
const TIME_WINDOWS = [
 { value: "09:00-12:00", label: "Morning (09:00 – 12:00)" },
 { value: "13:00-17:00", label: "Afternoon (13:00 – 17:00)" },
 { value: "09:00-17:00", label: "Full Day (09:00 – 17:00)" },
];
const TIME_PRESETS = TIME_WINDOWS.map(t => t.value);
const CUSTOM_TW = "__custom__";

function ScheduleEditor({
 quoteId,
 scheduledAt,
 timeWindow,
 preferredDate,
 preferredTimeWindow,
 currentStatus,
}: {
 quoteId: number;
 scheduledAt: string | Date | null | undefined;
 timeWindow: string | null | undefined;
 preferredDate?: string | null;
 preferredTimeWindow?: string | null;
 currentStatus: string;
}) {
 const { toast } = useToast();

 // Pre-deposit statuses use preferredDate / preferredTimeWindow; once the
 // booking is real (deposit paid onwards) we use scheduledAt / timeWindow.
 // The editor falls back to the preferred values so admins can change a
 // requested date even before deposit has been received.
 const isPreBooking = ['submitted', 'under_review', 'approved', 'deposit_requested'].includes(currentStatus);
 const preferredDateNorm = preferredDate && preferredDate.toLowerCase() !== 'flexible'
 ? preferredDate
 : '';

 const computeInitialDate = () => {
 if (scheduledAt) return formatSingaporeDay(scheduledAt, "yyyy-MM-dd");
 if (preferredDateNorm) {
 try { return format(new Date(preferredDateNorm + "T12:00:00"), "yyyy-MM-dd"); }
 catch { return ""; }
 }
 return "";
 };
 const computeInitialTw = () => {
 const tw = scheduledAt ? timeWindow : (timeWindow || preferredTimeWindow);
 return tw && /^\d{2}:\d{2}-\d{2}:\d{2}$/.test(tw) ? tw : "09:00-12:00";
 };

 const initialDate = computeInitialDate();
 const initialTw = computeInitialTw();
 const [editing, setEditing] = useState(false);
 const [dateVal, setDateVal] = useState(initialDate);
 const [twVal, setTwVal] = useState(initialTw);
 // We need a separate flag for custom mode because a custom range can
 // legitimately equal a preset (e.g. someone typing 09:00–17:00 manually),
 // and conversely picking Custom while currently on Full Day must NOT collapse
 // back to Full Day. Without this flag the Custom inputs never appear.
 const [customMode, setCustomMode] = useState(!TIME_PRESETS.includes(initialTw));

 // Resync local state if the upstream quote changes (e.g. after another save).
 useEffect(() => {
 const fresh = computeInitialTw();
 setDateVal(computeInitialDate());
 setTwVal(fresh);
 setCustomMode(!TIME_PRESETS.includes(fresh));
 // eslint-disable-next-line react-hooks/exhaustive-deps
 }, [scheduledAt, timeWindow, preferredDate, preferredTimeWindow]);

 const save = useMutation({
 mutationFn: async (mode: "save" | "pending") => {
 if (mode === "pending") {
 // Customer has asked to reschedule but the new date isn't decided yet.
 // Clear the booking slot AND flip status to booking_pending so the
 // header badge reads "Pending Date Confirmation" instead of staying
 // on "In Progress".
 return apiRequest("PATCH", `/api/quotes/${quoteId}/edit`, {
 quoteUpdates: { scheduledAt: null, timeWindow: null, status: "booking_pending" },
 }).then(r => r.json());
 }
 if (!dateVal) throw new Error("Please select a date");
 if (!/^\d{2}:\d{2}-\d{2}:\d{2}$/.test(twVal)) throw new Error("Please select a time window");
 const startTime = twVal.split("-")[0];
 // Build SG-local datetime (UTC+08:00) so the saved instant matches what the admin sees.
 const isoLocalSg = `${dateVal}T${startTime}:00+08:00`;
 const scheduledAtIso = new Date(isoLocalSg).toISOString();
 // If we're saving a fresh date for a job that was sitting in booking_pending,
 // promote it back to "booked" so the badge stops saying "Pending Date Confirmation".
 // For pre-deposit statuses (e.g. deposit_requested) we leave the status alone —
 // the customer still needs to pay the deposit.
 const statusFlip = (currentStatus === "booking_pending") ? { status: "booked" as const } : {};
 return apiRequest("PATCH", `/api/quotes/${quoteId}/edit`, {
 quoteUpdates: { scheduledAt: scheduledAtIso, timeWindow: twVal, ...statusFlip },
 }).then(r => r.json());
 },
 onSuccess: (_data, mode) => {
 queryClient.invalidateQueries({ queryKey: ['/api/quotes/:id', String(quoteId)] });
 queryClient.invalidateQueries({ queryKey: ['/api/quotes'] });
 toast({ title: mode === "pending" ? "Marked as pending date confirmation" : "Schedule updated" });
 setEditing(false);
 },
 onError: (e: any) => {
 toast({ title: "Could not update schedule", description: e?.message || "Please try again", variant: "destructive" });
 },
 });

 if (!editing) {
 const displayDate = scheduledAt
 ? `${formatSingaporeDay(scheduledAt, 'EEE, MMM d')} · ${timeWindow || "—"}`
 : preferredDateNorm
 ? (() => {
 try {
 const d = format(new Date(preferredDateNorm + "T12:00:00"), 'EEE, MMM d');
 return `${d} · ${preferredTimeWindow || timeWindow || "—"} (requested)`;
 } catch { return `${preferredDateNorm} (requested)`; }
 })()
 : null;
 const headerLabel = scheduledAt ? "Confirmed Date" : (isPreBooking ? "Requested Date" : "Confirmed Date");
 return (
 <div className="bg-zinc-50 border border-zinc-200 rounded-lg p-4">
 <div className="flex items-start justify-between gap-3">
 <div className="min-w-0 flex-1">
 <p className="text-xs font-medium text-zinc-500 mb-1.5">{headerLabel}</p>
 {displayDate ? (
 <p className="font-semibold text-zinc-900 text-sm flex items-center gap-1.5" data-testid="text-confirmed-date">
 <Calendar className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
 <span>{displayDate}</span>
 </p>
 ) : (
 <p className="text-amber-700 text-sm font-medium flex items-center gap-1.5" data-testid="text-pending-date">
 <Calendar className="w-3.5 h-3.5 text-amber-500 shrink-0" />
 <span>Pending date confirmation</span>
 </p>
 )}
 </div>
 <button
 onClick={() => {
 const panel=document.querySelector('[data-testid="staff-scheduling-review"]');
 panel?.scrollIntoView({behavior:"smooth",block:"center"});
 (panel?.querySelector('[data-testid="schedule-date"]') as HTMLInputElement)?.focus({preventScroll:true});
 }}
 data-testid="button-edit-schedule"
 className="text-xs font-medium text-[#0A0A0A] hover:text-[#0A0A0A] hover:underline whitespace-nowrap mt-0.5"
 >
 Edit
 </button>
 </div>
 </div>
 );
 }

 return (
 <div className="bg-zinc-50 border border-zinc-200 rounded-lg p-4 space-y-3">
 <p className="text-xs font-medium text-zinc-500">Edit Date & Time</p>
 <div className="space-y-2">
 <input
 type="date"
 value={dateVal}
 onChange={e => setDateVal(e.target.value)}
 data-testid="input-scheduled-date"
 className="h-10 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 text-left focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
 />
 {(() => {
 const [startVal, endVal] = (twVal && twVal.includes("-")) ? twVal.split("-") : ["09:00", "18:00"];
 // Show Custom in the dropdown whenever the user is in custom mode OR the
 // saved value isn't a preset (e.g. an admin previously saved 09:00–18:00).
 const showAsCustom = customMode || !TIME_PRESETS.includes(twVal);
 return (
 <>
 <select
 value={showAsCustom ? CUSTOM_TW : twVal}
 onChange={e => {
 if (e.target.value === CUSTOM_TW) {
 setCustomMode(true);
 // Seed with a non-preset range (an hour of overtime past Full Day)
 // so the inputs render and the user immediately sees a custom value
 // rather than collapsing back to "Full Day".
 if (TIME_PRESETS.includes(twVal)) {
 setTwVal("09:00-18:00");
 }
 } else {
 setCustomMode(false);
 setTwVal(e.target.value);
 }
 }}
 data-testid="select-time-window"
 className="h-10 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
 >
 {TIME_WINDOWS.map(tw => (
 <option key={tw.value} value={tw.value}>{tw.label}</option>
 ))}
 <option value={CUSTOM_TW}>Custom (overtime)…</option>
 </select>
 {showAsCustom && (
 <div className="grid grid-cols-2 gap-2">
 <div>
 <label className="text-[11px] font-medium text-zinc-500 mb-1 block">Start</label>
 <input
 type="time"
 value={startVal}
 onChange={e => setTwVal(`${e.target.value}-${endVal}`)}
 data-testid="input-time-start"
 className="h-10 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
 />
 </div>
 <div>
 <label className="text-[11px] font-medium text-zinc-500 mb-1 block">End (overtime allowed)</label>
 <input
 type="time"
 value={endVal}
 onChange={e => setTwVal(`${startVal}-${e.target.value}`)}
 data-testid="input-time-end"
 className="h-10 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
 />
 </div>
 </div>
 )}
 </>
 );
 })()}
 </div>
 <div className="grid grid-cols-2 gap-2">
 <button
 onClick={() => save.mutate("save")}
 disabled={save.isPending}
 data-testid="button-save-schedule"
 className="h-10 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium disabled:opacity-50 transition-colors"
 >
 {save.isPending && save.variables === "save" ? "Saving…" : "Save"}
 </button>
 <button
 onClick={() => {
 setDateVal(initialDate);
 setTwVal(initialTw);
 setEditing(false);
 }}
 disabled={save.isPending}
 data-testid="button-cancel-schedule"
 className="h-10 px-4 rounded-lg bg-white border border-zinc-300 text-zinc-700 hover:bg-zinc-50 text-sm font-medium disabled:opacity-50 transition-colors"
 >
 Cancel
 </button>
 </div>
 {!isPreBooking && (
 <button
 onClick={() => save.mutate("pending")}
 disabled={save.isPending}
 data-testid="button-mark-pending-date"
 className="w-full h-10 px-4 rounded-lg bg-white border border-amber-300 text-amber-700 hover:bg-amber-50 text-sm font-medium disabled:opacity-50 transition-colors"
 >
 {save.isPending && save.variables === "pending" ? "Saving…" : "Mark as Pending — date to be confirmed"}
 </button>
 )}
 </div>
 );
}

function AiEmailDrafter({ quote }: { quote: any }) {
 const { toast } = useToast();
 const [open, setOpen] = useState(false);
 const [intent, setIntent] = useState<"follow_up" | "send_quote" | "reschedule" | "reminder" | "custom">("follow_up");
 const [extra, setExtra] = useState("");
 const [draft, setDraft] = useState<{ subject: string; body: string } | null>(null);

 const draftMut = useMutation({
 mutationFn: async () => {
 const res = await apiRequest("POST", "/api/ai/draft-email", {
 quoteId: quote.id,
 intent,
 extraInstructions: extra || undefined,
 });
 return res.json();
 },
 onSuccess: (data) => {
 setDraft({ subject: data.subject, body: data.body });
 },
 onError: (e: any) => {
 toast({ title: "Could not draft email", description: e?.message || "Try again", variant: "destructive" });
 },
 });

 const copyAll = async () => {
 if (!draft) return;
 const txt = `Subject: ${draft.subject}\n\n${draft.body}`;
 try {
 await navigator.clipboard.writeText(txt);
 toast({ title: "Copied to clipboard" });
 } catch {
 toast({ title: "Copy failed", description: "Select and copy manually", variant: "destructive" });
 }
 };

 if (!quote.customer?.email || quote.customer.email.endsWith("@whatsapp.tmginstall.local")) {
 return null;
 }

 return (
 <div className="bg-white border border-zinc-200 rounded-none overflow-hidden ">
 <button
 onClick={() => setOpen(o => !o)}
 data-testid="button-toggle-ai-email-drafter"
 className="w-full flex items-center justify-between px-4 py-3 hover:bg-zinc-50 transition-colors"
 >
 <span className="flex items-center gap-2 text-sm font-semibold text-zinc-900">
 <Sparkles className="w-4 h-4 text-violet-500" />
 AI Email Drafter
 </span>
 <span className="text-xs text-zinc-400">{open ? "Hide" : "Show"}</span>
 </button>
 {open && (
 <div className="px-4 pb-4 space-y-3 border-t border-zinc-100">
 <div className="space-y-1.5 pt-3">
 <label className="text-xs font-medium text-zinc-500">Email type</label>
 <select
 value={intent}
 onChange={e => setIntent(e.target.value as any)}
 data-testid="select-email-intent"
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-violet-500"
 >
 <option value="follow_up">Follow-up (no response)</option>
 <option value="send_quote">Send quote</option>
 <option value="reschedule">Reschedule request</option>
 <option value="reminder">Day-before reminder</option>
 <option value="custom">Custom (use instructions)</option>
 </select>
 </div>
 <div className="space-y-1.5">
 <label className="text-xs font-medium text-zinc-500">Extra instructions (optional)</label>
 <textarea
 value={extra}
 onChange={e => setExtra(e.target.value.slice(0, 500))}
 placeholder="e.g. Mention free reschedule once if they ask…"
 data-testid="input-email-extra"
 rows={2}
 className="w-full px-3 py-2 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-violet-500 resize-none"
 />
 </div>
 <button
 onClick={() => draftMut.mutate()}
 disabled={draftMut.isPending}
 data-testid="button-generate-email-draft"
 className="w-full h-9 rounded-lg bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-700 hover:to-blue-700 text-white text-sm font-medium disabled:opacity-50 flex items-center justify-center gap-1.5"
 >
 <Sparkles className="w-3.5 h-3.5" />
 {draftMut.isPending ? "Drafting…" : (draft ? "Re-draft" : "Draft email with AI")}
 </button>

 {draft && (
 <div className="space-y-2 pt-2 border-t border-zinc-100">
 <div>
 <label className="text-xs font-medium text-zinc-500">Subject</label>
 <input
 value={draft.subject}
 onChange={e => setDraft({ ...draft, subject: e.target.value })}
 data-testid="input-email-subject"
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 mt-1"
 />
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-500">Body</label>
 <textarea
 value={draft.body}
 onChange={e => setDraft({ ...draft, body: e.target.value })}
 data-testid="input-email-body"
 rows={10}
 className="w-full px-3 py-2 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 mt-1 font-mono text-xs leading-relaxed"
 />
 </div>
 <div className="flex gap-2">
 <button
 onClick={copyAll}
 data-testid="button-copy-email"
 className="flex-1 h-9 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-white text-sm font-medium"
 >
 Copy subject + body
 </button>
 <a
 href={`mailto:${encodeURIComponent(quote.customer.email)}?subject=${encodeURIComponent(draft.subject)}&body=${encodeURIComponent(draft.body)}`}
 data-testid="link-open-mail-client"
 className="h-9 px-4 rounded-lg bg-white border border-zinc-300 text-zinc-700 hover:bg-zinc-50 text-sm font-medium flex items-center"
 >
 Open in mail
 </a>
 </div>
 <p className="text-[11px] text-zinc-400 leading-snug">
 AI draft — review before sending. Not auto-delivered.
 </p>
 </div>
 )}
 </div>
 )}
 </div>
 );
}

function PaymentChannelButtons({
 quote,
 emailPending,
 whatsappPending,
 onEmail,
 onWhatsApp,
 onCopy,
 compact = false,
}: {
 quote: any;
 emailPending: boolean;
 whatsappPending: boolean;
 onEmail: () => void;
 onWhatsApp: (phone?: string) => void;
 onCopy?: () => void;
 compact?: boolean;
}) {
 const [phoneInput, setPhoneInput] = useState("");
 const { hasRealEmail, hasPhone } = getContactChannels(quote);
 const isPending = emailPending || whatsappPending;

 const baseBtn = compact
 ? "inline-flex items-center justify-center gap-1.5 h-10 px-3 rounded-none text-sm font-medium transition-colors disabled:opacity-50"
 : "inline-flex items-center justify-center gap-2 h-9 px-4 rounded-lg text-sm font-medium transition-colors disabled:opacity-50";

 const copyBtn = onCopy ? (
 <button
 onClick={onCopy}
 className={`${baseBtn} w-full bg-[#EBE9E2] hover:bg-violet-100 text-[#0A0A0A] border border-violet-200`}
 data-testid="button-copy-payment-message"
 >
 <FileText className="w-4 h-4" />
 Copy / send manually
 </button>
 ) : null;

 // If deposit is already paid, the WA button sends the FINAL payment message
 const depositAlreadyPaid = !!quote?.depositPaidAt;
 const waLabel = depositAlreadyPaid ? "Send Final Payment" : "Send WhatsApp Payment";
 const waLabelShort = depositAlreadyPaid ? "Final Payment" : "WhatsApp";

 if (!hasRealEmail && !hasPhone) {
 return (
 <div className="space-y-2">
 <p className="text-xs text-zinc-500">No contact info stored — enter a phone number to send via WhatsApp:</p>
 <input
 type="tel"
 value={phoneInput}
 onChange={e => setPhoneInput(e.target.value)}
 placeholder="e.g. 91234567"
 className="w-full h-9 px-3 border border-zinc-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
 />
 <button
 onClick={() => phoneInput && onWhatsApp(phoneInput)}
 disabled={isPending || !phoneInput.trim()}
 className={`${baseBtn} w-full bg-emerald-600 hover:bg-emerald-700 text-white`}
 data-testid="button-send-whatsapp-override"
 >
 <MessageCircle className="w-4 h-4" />
 {whatsappPending ? "Sending…" : waLabel}
 </button>
 {copyBtn}
 </div>
 );
 }

 if (hasRealEmail && hasPhone) {
 return (
 <div className="space-y-2">
 <div className="flex gap-2">
 <button
 onClick={onEmail}
 disabled={isPending}
 className={`${baseBtn} flex-1 bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50`}
 data-testid="button-send-payment-email"
 >
 <Mail className="w-4 h-4" />
 {emailPending ? "Sending…" : "Email"}
 </button>
 <button
 onClick={() => onWhatsApp()}
 disabled={isPending}
 className={`${baseBtn} flex-1 bg-emerald-600 hover:bg-emerald-700 text-white`}
 data-testid="button-send-payment-whatsapp"
 >
 <MessageCircle className="w-4 h-4" />
 {whatsappPending ? "Sending…" : waLabelShort}
 </button>
 </div>
 {copyBtn}
 </div>
 );
 }

 if (hasRealEmail) {
 return (
 <div className="space-y-2">
 <button
 onClick={onEmail}
 disabled={isPending}
 className={`${baseBtn} w-full bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50`}
 data-testid="button-send-payment-email"
 >
 <Mail className="w-4 h-4" />
 {emailPending ? "Sending…" : "Send Payment Email"}
 </button>
 {copyBtn}
 </div>
 );
 }

 return (
 <div className="space-y-2">
 <button
 onClick={() => onWhatsApp()}
 disabled={isPending}
 className={`${baseBtn} w-full bg-emerald-600 hover:bg-emerald-700 text-white`}
 data-testid="button-send-payment-whatsapp"
 >
 <MessageCircle className="w-4 h-4" />
 {whatsappPending ? "Sending…" : waLabel}
 </button>
 {copyBtn}
 </div>
 );
}

export default function AdminQuoteDetail() {
 const params = useParams();
 const id = params.id!;
 const [, navigate] = useLocation();
 
 const { data: quote, isLoading, isFetching } = useQuote(id);
 const { data: staffList } = useStaffList();
 const { data: teamsList = [] } = useQuery<any[]>({ queryKey: ["/api/teams"] });

 const { data: trackerData } = useQuery<{
 updates: { statusChange: string; photoUrls: string[]; note: string | null; createdAt: string }[];
 }>({
 queryKey: [`/api/public/track/${quote?.referenceNo}`],
 queryFn: () => fetch(`/api/public/track/${quote!.referenceNo}`).then(r => r.json()),
 enabled: !!quote?.referenceNo && ["in_progress", "at_pickup", "in_transit", "at_dropoff", "completed", "final_payment_requested", "final_paid", "closed"].includes(quote?.status ?? ""),
 staleTime: 60_000,
 });

 const workPhotos = (trackerData?.updates ?? [])
 .filter(u => ["in_progress", "at_pickup", "in_transit", "at_dropoff", "completed"].includes(u.statusChange))
 .flatMap(u => u.photoUrls ?? [])
 .filter(Boolean);
 const updateStatus = useUpdateQuoteStatus();
 const requestFinalPayment = useRequestFinalPayment();
 const confirmBooking = useConfirmBooking();
 const editQuote = useEditQuote();
 const closeQuote = useCloseQuote();
 const { toast } = useToast();

 const [selectedAssignee, setSelectedAssignee] = useState(""); // "staff:2" | "team:3"
 const assigningCrew = useRef(false);
 const [isEditing, setIsEditing] = useState(false);
 const [editCustomer, setEditCustomer] = useState<any>({});
 const [editQuoteData, setEditQuoteData] = useState<any>({});
 const [editBaseline,setEditBaseline]=useState<{revision?:string;version:number}>({version:1});
 const [editError,setEditError]=useState("");
 const [lastQuoteSaved,setLastQuoteSaved]=useState("");
 const [editFieldErrors,setEditFieldErrors]=useState<Record<string,string>>({});
 const [workspaceFacts,setWorkspaceFacts]=useState<QuoteWorkspaceFacts>({});
 const [workspaceDecisions,setWorkspaceDecisions]=useState<Record<string,string>>({});
 const [rateReasons,setRateReasons]=useState<Record<string,string>>({});
 const [transportConfirmed,setTransportConfirmed]=useState(false);
 const [workspaceRequirements,setWorkspaceRequirements]=useState<QuoteWorkspaceRequirement[]>([]);
 const [workspaceSendError,setWorkspaceSendError]=useState("");
 const [deliveryOutcome,setDeliveryOutcome]=useState<{quoteId:string;draftSignature?:string;delivery:any}|null>(null);
 const directEditorStarted=useRef<string|null>(null);
 const workspaceRequestKeys=useRef(new Map<string,string>());
 const workspaceSendRetry=useRef<{quoteId:string;draftSignature:string;requestKey:string;body:any}|null>(null);
 const workspaceContextQuery=useQuery<any>({
   queryKey:["/api/admin/quotes",id,"workspace-context"],
   enabled:!!id,
   retry:false,
   refetchOnWindowFocus:false,
   queryFn:async()=>{
     const response=await fetch(`/api/admin/quotes/${id}/workspace-context`,{credentials:"include"});
     if(!response.ok)throw new Error("Could not load quote workspace context");
     return response.json();
   },
 });
 useEffect(()=>{
   if(Array.isArray(workspaceContextQuery.data?.requirements))setWorkspaceRequirements(workspaceContextQuery.data.requirements);
 },[workspaceContextQuery.data]);
 const [showAppointment,setShowAppointment]=useState(()=>window.location.hash==="#staff-scheduling-review");
 const [appointmentDirty,setAppointmentDirty]=useState(false);
 const initialEdit=useRef<any>(null);
 const workspaceServerBaseline=useRef<any>(null);
 const savingEdit=useRef(false);
 // Dispute-protection: when split timing or after-office work is selected, the
 // admin must explicitly confirm the surcharge was added to the quote or waived
 // in writing before the edit can be saved. Tracked separately (not persisted).
 const [surchargeAck, setSurchargeAck] = useState(false);
 const [editItems, setEditItems] = useState<any[]>([]);
 const [detectingItem, setDetectingItem] = useState<number | null>(null);
 // Catalog lookup for item lines — which row's suggestion dropdown is open.
 const [catalogPickerFor, setCatalogPickerFor] = useState<number | null>(null);
 const { data: adminCatalog } = useQuery<CatalogItem[]>({
 queryKey: ["/api/admin/catalog"],
 staleTime: 60_000,
 });
 // Multi-stop relocation (additive) editing state.
 const [editStops, setEditStops] = useState<EditStop[]>([]);
 const [editTotalVolume, setEditTotalVolume] = useState("");
 const [editDistanceKm, setEditDistanceKm] = useState<number | null>(null);
 const [editCalc, setEditCalc] = useState<MultiStopResult | null>(null);
 const [editCalcError, setEditCalcError] = useState<string | null>(null);
 const [editCalcLoading, setEditCalcLoading] = useState(false);
 const draftState=JSON.stringify({customer:editCustomer,data:editQuoteData,items:editItems,stops:editStops,volume:editTotalVolume,distance:editDistanceKm,facts:workspaceFacts,decisions:workspaceDecisions,rateReasons,transportConfirmed});
 if(isEditing&&!initialEdit.current)initialEdit.current={...JSON.parse(draftState),signature:draftState};
 const editDirty=!!initialEdit.current&&draftState!==initialEdit.current.signature;
 const surchargeChanged=!!initialEdit.current&&changedSurcharge(editQuoteData,initialEdit.current.data);
 useEffect(()=>{
  if(deliveryOutcome?.quoteId!==id||!deliveryOutcome.draftSignature||deliveryOutcome.draftSignature===draftState)return;
  const status=String(deliveryOutcome.delivery?.status||"").toLowerCase();
  if(["queued","sending","unknown","pending"].includes(status))return;
  setWorkspaceSendError("");
  if(workspaceSendRetry.current?.quoteId===id)workspaceSendRetry.current=null;
  setDeliveryOutcome(current=>current?.quoteId===id?null:current);
 },[deliveryOutcome,draftState,id]);
 useEffect(()=>{
   if(!isEditing||!editDirty)return;
   const unload=(e:BeforeUnloadEvent)=>{e.preventDefault();e.returnValue="";};
   const navigate=(e:MouseEvent)=>{
     const link=(e.target as HTMLElement)?.closest("a");
     if(link&&link.href&&!link.target&&!e.ctrlKey&&!e.metaKey&&!window.confirm("Discard unsaved quotation changes?"))e.preventDefault();
   };
   window.addEventListener("beforeunload",unload);
   document.addEventListener("click",navigate,true);
   return()=>{window.removeEventListener("beforeunload",unload);document.removeEventListener("click",navigate,true);};
 },[isEditing,editDirty]);
 const calculationState=JSON.stringify([editItems,editStops,editTotalVolume,editDistanceKm,editQuoteData.transportFee,editQuoteData.volumetricFee]);
 const latestCalculationState=useRef(calculationState);
 latestCalculationState.current=calculationState;
 const [lightboxPhoto, setLightboxPhoto] = useState<string | null>(null);
 const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
 // These setters are still called from send-handlers; the values are no longer
 // displayed but the state writes are kept to avoid behavioural drift.
 const [, setWaSentAt] = useState<Date | null>(null);
 const [, setEmailSentAt] = useState<Date | null>(null);
 const [jobMinutes, setJobMinutes] = useState(""); // actual job duration in minutes (for overtime calc)
 const [addChargeNote, setAddChargeNote] = useState(""); // additional charge note
 const [addChargeCustom, setAddChargeCustom] = useState(""); // override amount for non-overtime charges

 const deleteQuoteMutation = useMutation({
 mutationFn: () => apiRequest("DELETE", `/api/admin/quotes/${id}`),
 onSuccess: () => {
 toast({ title: "Case Deleted", description: "The job case has been permanently removed." });
 navigate("/admin");
 },
 onError: (err: any) => {
 toast({ title: "Delete Failed", description: err.message, variant: "destructive" });
 },
 });

 // Multi-day phase tracker — mark dismantle / delivery / install done on
 // their own day. Final-payment button is gated until every applicable
 // phase has a completion entry. Phases derived from selectedServices.
 const togglePhase = useMutation({
 mutationFn: ({ phase, done, note }: { phase: 'dismantle' | 'delivery' | 'install'; done: boolean; note?: string }) =>
 apiRequest("POST", `/api/admin/quotes/${id}/phase`, { phase, done, note }).then(r => r.json()),
 onSuccess: (_d, vars) => {
 queryClient.invalidateQueries({ queryKey: ['/api/quotes/:id', id] });
 queryClient.invalidateQueries({ queryKey: ["/api/quotes"] });
 toast({
 title: vars.done ? `✓ ${vars.phase[0].toUpperCase() + vars.phase.slice(1)} marked done` : "Phase reopened",
 description: vars.done ? "Other phases can still be completed on later days." : "You can re-tick it when the work is done.",
 });
 },
 onError: (err: any) => toast({ title: "Phase update failed", description: err.message, variant: "destructive" }),
 });

 const reopenJob = useMutation({
 mutationFn: (reason?: string) =>
 apiRequest("POST", `/api/admin/quotes/${id}/reopen`, { reason }).then(r => r.json()),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ['/api/quotes/:id', id] });
 queryClient.invalidateQueries({ queryKey: ["/api/quotes"] });
 toast({ title: "✅ Job Reopened", description: "Job is now active and visible to assigned staff." });
 },
 onError: (err: any) => {
 toast({ title: "Failed to reopen", description: err.message, variant: "destructive" });
 },
 });

 // Commercial flow — approve & book without deposit (no upfront payment).
 const approveCommercial = useMutation({
 mutationFn: () =>
 apiRequest("POST", `/api/admin/quotes/${id}/approve-commercial`).then(r => r.json()),
 onSuccess: (data: any) => {
 queryClient.invalidateQueries({ queryKey: ["/api/quotes/:id", id] });
 queryClient.invalidateQueries({ queryKey: ["/api/quotes"] });
 queryClient.invalidateQueries({ queryKey: ["/api/quotes/schedule"] });
 toast({
 title: "Booking Confirmed",
 description: data?.emailSent
 ? "Job is booked. Confirmation email sent to customer (no deposit required)."
 : "Job is booked. No email sent — please share confirmation manually.",
 });
 },
 onError: (err: any) => {
 toast({ title: "Failed to confirm booking", description: err.message, variant: "destructive" });
 },
 });

 // Commercial flow — send Net 30 tax invoice for a completed job.
 const invoiceSubmitting=useRef(false);
 const sendCommercialInvoice = useMutation({
 mutationFn: () =>
 apiRequest("POST", `/api/admin/quotes/${id}/send-invoice`).then(r => r.json()).catch((error:Error)=>{
   try{const payload=JSON.parse(error.message.slice(error.message.indexOf("{")));
     throw Object.assign(new Error(payload.message),{notificationStatus:payload.notificationStatus});
   }catch(parsed:any){if(parsed.notificationStatus)throw parsed;throw error;}
 }),
 onSuccess: (data: any) => {
 queryClient.invalidateQueries({ queryKey: ["/api/quotes/:id", id] });
 queryClient.invalidateQueries({ queryKey: ["/api/quotes"] });
 toast({
 title: data?.emailSent?"Invoice email accepted":"Invoice notification needs review",
 description: data?.warning || `Email provider accepted the Net 30 invoice; delivery is not yet confirmed. Due ${data?.dueDate || "in 30 days"}.`,
 });
 },
 onError: (err: any) => {
 toast({ title: "Invoice notification needs review — quotation edits remain saved", description: err.message, variant: "destructive" });
 },
 });

 const saveAdditionalCharge = useMutation({
 mutationFn: (body: { additionalCharge: string; additionalChargeNote: string }) =>
 apiRequest("PATCH", `/api/quotes/${id}/additional-charges`, body),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ['/api/quotes/:id', id] });
 queryClient.invalidateQueries({ queryKey: ['/api/quotes'] });
 toast({ title: "Saved", description: "Additional charge updated." });
 },
 onError: (err: any) => {
 toast({ title: "Error", description: err.message, variant: "destructive" });
 },
 });

 const sendWhatsAppPayment = useMutation({
 mutationFn: (phone?: string) =>
 apiRequest("POST", `/api/admin/quotes/${id}/send-whatsapp-payment`, phone ? { phone } : undefined),
 onSuccess: async (res) => {
 setWaSentAt(new Date());
 queryClient.invalidateQueries({ queryKey: ['/api/quotes/:id', id] });
 queryClient.invalidateQueries({ queryKey: ['/api/quotes'] });
 let data: any = {};
 try { data = await res.clone().json(); } catch {}
 const isFinal = data?.type === "final";
 toast({
 title: "✅ WhatsApp Sent",
 description: isFinal
 ? "Final payment reminder sent to customer."
 : "Deposit payment reminder sent to customer.",
 });
 },
 onError: (err: any) => {
 let reason = err?.message || "Could not send WhatsApp message.";
 try { reason = JSON.parse(reason.replace(/^\d+:\s*/, "")).message || reason; } catch {}
 toast({ title: "Failed to send", description: reason, variant: "destructive" });
 },
 });

 const resetDeposit = useMutation({
 mutationFn: async () => {
 const res = await apiRequest("POST", `/api/admin/quotes/${id}/reset-deposit`);
 return res.json();
 },
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ['/api/quotes/:id', id] });
 queryClient.invalidateQueries({ queryKey: ['/api/quotes'] });
 toast({ title: "Deposit reset", description: "Status reset to deposit requested. You can now resend the payment link." });
 },
 onError: () => toast({ title: "Reset failed", variant: "destructive" }),
 });

 const resendDepositEmail = useMutation({
 mutationFn: async () => {
 const res = await apiRequest("POST", `/api/admin/quotes/${id}/resend-deposit-email`);
 return res.json();
 },
 onSuccess: (data: any) => {
 setEmailSentAt(new Date());
 const both = data?.emailSent && data?.whatsappSent;
 const title = both
 ? "✅ Sent via WhatsApp + Email"
 : data?.whatsappSent
 ? "✅ WhatsApp Sent"
 : "✅ Email Sent";
 toast({
 title,
 description: data?.message || "Deposit notification sent.",
 });
 },
 onError: (err: any) => {
 let reason = err?.message || "Could not send payment notification.";
 try { reason = JSON.parse(reason.replace(/^\d+:\s*/, "")).message || reason; } catch {}
 toast({ title: "Failed to send", description: reason, variant: "destructive" });
 },
 });

 // ── Dispute-protection: acceptance record, dispute log, refund (Task #34) ──
 const [disputeNote, setDisputeNote] = useState("");
 const [showRefundForm, setShowRefundForm] = useState(false);
 const [refundForm, setRefundForm] = useState({ refundApprovedAmount: "", refundReason: "", refundMethod: "", refundCompletedAt: "", refundInternalNote: "" });

 const { data: disputeEvents = [] } = useQuery<any[]>({
 queryKey: ['/api/admin/quotes', id, 'dispute-events'],
 queryFn: async () => {
 const res = await fetch(`/api/admin/quotes/${id}/dispute-events`, { credentials: "include" });
 return res.json();
 },
 enabled: !!id,
 });

 const addDisputeEvent = useMutation({
 mutationFn: (detail: string) => apiRequest("POST", `/api/admin/quotes/${id}/dispute-events`, { detail }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ['/api/admin/quotes', id, 'dispute-events'] });
 setDisputeNote("");
 toast({ title: "Note added to dispute log" });
 },
 onError: () => toast({ title: "Failed to add note", variant: "destructive" }),
 });

 const refundMutation = useMutation({
 mutationFn: (body: any) => apiRequest("POST", `/api/admin/quotes/${id}/refund`, body),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ['/api/quotes/:id', id] });
 queryClient.invalidateQueries({ queryKey: ['/api/quotes'] });
 queryClient.invalidateQueries({ queryKey: ['/api/admin/quotes', id, 'dispute-events'] });
 setShowRefundForm(false);
 setRefundForm({ refundApprovedAmount: "", refundReason: "", refundMethod: "", refundCompletedAt: "", refundInternalNote: "" });
 toast({ title: "Refund recorded" });
 },
 onError: () => toast({ title: "Failed to record refund", variant: "destructive" }),
 });

 // ── Subcontract state ──────────────────────────────────────────────────────
 const [showSubForm, setShowSubForm] = useState(false);
 const [subForm, setSubForm] = useState({ subcontractorId: "", agreedCost: "", notes: "" });

 const { data: subcontracts = [], refetch: refetchSubcontracts } = useQuery<any[]>({
 queryKey: [`/api/admin/quotes/${id}/subcontracts`],
 queryFn: async () => {
 const res = await fetch(`/api/admin/quotes/${id}/subcontracts`, { credentials: "include" });
 return res.json();
 },
 enabled: !!id,
 });

 const { data: allSubs = [] } = useQuery<any[]>({
 queryKey: ["/api/admin/subcontractors"],
 });

 const assignSubMutation = useMutation({
 mutationFn: (data: any) => apiRequest("POST", `/api/admin/quotes/${id}/subcontracts`, data),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: [`/api/admin/quotes/${id}/subcontracts`] });
 queryClient.invalidateQueries({ queryKey: ["/api/admin/subcontracts/summary"] });
 setShowSubForm(false);
 setSubForm({ subcontractorId: "", agreedCost: "", notes: "" });
 toast({ title: "Subcontractor assigned" });
 },
 onError: () => toast({ title: "Failed to assign", variant: "destructive" }),
 });

 const markSubPaidMutation = useMutation({
 mutationFn: ({ scId, paid }: { scId: number; paid: boolean }) =>
 apiRequest("PATCH", `/api/admin/subcontracts/${scId}`, { paymentStatus: paid ? "paid" : "unpaid" }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: [`/api/admin/quotes/${id}/subcontracts`] });
 queryClient.invalidateQueries({ queryKey: ["/api/admin/subcontracts/summary"] });
 },
 });

 const removeSubMutation = useMutation({
 mutationFn: (scId: number) => apiRequest("DELETE", `/api/admin/subcontracts/${scId}`),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: [`/api/admin/quotes/${id}/subcontracts`] });
 queryClient.invalidateQueries({ queryKey: ["/api/admin/subcontracts/summary"] });
 toast({ title: "Removed" });
 },
 });

 const [showPayNowConfirm, setShowPayNowConfirm] = useState(false);
 const [payNowNote, setPayNowNote] = useState("");
 const [payNowBankChecked,setPayNowBankChecked]=useState(false);
 const [payNowAmount,setPayNowAmount]=useState("");
 const bankRequestKey=useRef(crypto.randomUUID());
 const [showPaymentMessageDialog, setShowPaymentMessageDialog] = useState(false);
 const [showInvoiceDialog, setShowInvoiceDialog] = useState(false);
 const markPayNowPaid = useMutation({
 mutationFn: async () => {
 const res = await apiRequest("POST", `/api/admin/quotes/${id}/mark-paynow-paid`, {
   note:payNowNote.trim(),confirmedReceived:payNowBankChecked,requestKey:bankRequestKey.current,expectedVersion:quote?.version,
   ...(payNowAmount?{amount:Number(payNowAmount)}:{})});
 return await res.json();
 },
 onSuccess: (data: any) => {
 queryClient.invalidateQueries({ queryKey: ['/api/quotes/:id', id] });
 queryClient.invalidateQueries({ queryKey: ['/api/quotes'] });
 setShowPayNowConfirm(false);
 setPayNowNote("");
 setPayNowBankChecked(false);setPayNowAmount("");
 bankRequestKey.current=crypto.randomUUID();
 if(data?.duplicate) {
 toast({title:"Payment already recorded",description:"Existing receipt kept; no new funds or message. For a separate transfer, supply its distinct bank verification reference."});
 } else if (data?.synced) {
 toast({ title: "✅ Status Synced", description: "Deposit was already on record — quote moved forward. No new message sent to customer." });
 } else {
 toast({ title: "Bank payment recorded", description: "Funds saved. Appointment still requires separate staff confirmation. Message delivery is not implied." });
 }
 },
 onError: (err: any) => {
 const msg = err?.message || "Could not confirm payment.";
 toast({ title: "Error", description: msg, variant: "destructive" });
 },
 });

 // Record Payment — log a partial/installment payment against this quote
 const [showRecordPayment, setShowRecordPayment] = useState(false);
 const [payAmount, setPayAmount] = useState("");
 const [payMethod, setPayMethod] = useState("cash");
 const [payNoteText, setPayNoteText] = useState("");
 const [payDate, setPayDate] = useState("");
 const recordPayment = useMutation({
   mutationFn: async () => {
     const res = await apiRequest("POST", `/api/admin/quotes/${id}/payments`, {
       amount: parseFloat(payAmount),
       method: payMethod,
       note: payNoteText.trim() || undefined,
       paidAt: payDate ? new Date(payDate+"+08:00").toISOString() : undefined,
       confirmedReceived:payNowBankChecked,requestKey:bankRequestKey.current,expectedVersion:quote?.version,
     });
     return await res.json();
   },
   onSuccess: () => {
     queryClient.invalidateQueries({ queryKey: ['/api/quotes/:id', id] });
     queryClient.invalidateQueries({ queryKey: ['/api/quotes'] });
     setShowRecordPayment(false);
     setPayAmount(""); setPayNoteText(""); setPayMethod("cash");
     bankRequestKey.current=crypto.randomUUID();setPayNowBankChecked(false);
     setPayDate(new Date().toISOString().slice(0, 10));
     toast({ title: "Payment recorded", description: "The job balance has been updated." });
   },
   onError: (err: any) => {
     toast({ title: "Error", description: err?.message || "Could not record payment.", variant: "destructive" });
   },
 });
 const deletePayment = useMutation({
   mutationFn: async (paymentId: number) => {
     const res = await apiRequest("DELETE", `/api/admin/quotes/${id}/payments/${paymentId}`);
     return await res.json();
   },
   onSuccess: () => {
     queryClient.invalidateQueries({ queryKey: ['/api/quotes/:id', id] });
     queryClient.invalidateQueries({ queryKey: ['/api/quotes'] });
     toast({ title: "Payment removed", description: "The job balance has been updated." });
   },
   onError: (err: any) => {
     toast({ title: "Error", description: err?.message || "Could not remove payment.", variant: "destructive" });
   },
 });

 // Mark final PayNow payment received — confirms customer paid via PayNow/Stripe, closes case, sends WA invoice
 const [showFinalPayConfirm, setShowFinalPayConfirm] = useState(false);
 useEffect(()=>{setPayNowBankChecked(false);},[showPayNowConfirm,showRecordPayment,showFinalPayConfirm]);
 const [finalPayNote, setFinalPayNote] = useState("");
 const collectFinalPayment = useMutation({
 mutationFn: () =>
 apiRequest("POST", `/api/admin/quotes/${id}/collect-final-payment`, { note: finalPayNote.trim(),
   confirmedReceived:payNowBankChecked,requestKey:bankRequestKey.current,expectedVersion:quote?.version }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ['/api/quotes/:id', id] });
 queryClient.invalidateQueries({ queryKey: ['/api/quotes'] });
 setShowFinalPayConfirm(false);
 bankRequestKey.current=crypto.randomUUID();setPayNowBankChecked(false);
 setFinalPayNote("");
 toast({ title: "Final bank payment recorded", description: "Received funds saved. Notification acceptance is not proof of delivery or booking." });
 },
 onError: (err: any) => {
 const msg = err?.message || "Could not confirm final payment.";
 toast({ title: "Error", description: msg, variant: "destructive" });
 },
 });

 useEffect(() => {
 const handler = (e: KeyboardEvent) => { if (e.key === "Escape") setLightboxPhoto(null); };
 window.addEventListener("keydown", handler);
 return () => window.removeEventListener("keydown", handler);
 }, []);

 useEffect(()=>{
  if(!quote||workspaceContextQuery.isLoading||directEditorStarted.current===id||new URLSearchParams(window.location.search).get("edit")!=="1")return;
  if(!canEdit||quote.status==="cancelled")return;
  directEditorStarted.current=id;
  handleStartEdit();
 },[quote,workspaceContextQuery.isLoading,workspaceContextQuery.data,id]);

 if (isLoading) {
 return (
 <div className="min-h-screen pt-14 pb-16 lg:pl-56 bg-[#F5F4F0] flex items-center justify-center">
 <div className="flex flex-col items-center gap-3 text-zinc-400">
 <Loader2 className="w-5 h-5 animate-spin border-2 border-zinc-200 border-t-zinc-700 rounded-full" />
 <p className="text-sm font-medium">Loading details…</p>
 </div>
 </div>
 );
 }
 
 if (!quote) {
 return (
 <div className="min-h-screen pt-14 pb-16 lg:pl-56 bg-[#F5F4F0] flex items-center justify-center">
 <div className="text-center">
 <AlertTriangle className="w-10 h-10 text-zinc-300 mx-auto mb-3" />
 <p className="text-sm font-medium text-zinc-500">Quote not found</p>
 </div>
 </div>
 );
 }

 // ── Multi-day phase tracker ─────────────────────────────────────────
 // Phases applicable to this job are derived from the booked services:
 // selectedServices includes "dismantle" → Dismantle phase
 // selectedServices includes "relocate" → Delivery phase (transport leg)
 // selectedServices includes "install" → Install phase
 // The "Mark Done & Request Final Payment" button is gated until every
 // applicable phase has a completion entry. Jobs with 0 or 1 applicable
 // phases skip the gate entirely (it would just be noise).
 const phaseSelectedServices: string[] = (() => {
 try { return JSON.parse(quote.selectedServices || "[]"); } catch { return []; }
 })();
 const phaseCompletions: Array<{ phase: string; completedAt: string; completedByUserId?: number; note?: string }> =
 Array.isArray((quote as any).phaseCompletions) ? (quote as any).phaseCompletions : [];
 const applicablePhases: Array<{ key: 'dismantle' | 'delivery' | 'install'; label: string }> = [];
 if (phaseSelectedServices.includes("dismantle")) applicablePhases.push({ key: 'dismantle', label: 'Dismantle' });
 if (phaseSelectedServices.includes("relocate")) applicablePhases.push({ key: 'delivery', label: 'Delivery' });
 if (phaseSelectedServices.includes("install")) applicablePhases.push({ key: 'install', label: 'Install' });
 const phaseStatus = (key: 'dismantle' | 'delivery' | 'install') =>
 phaseCompletions.find((c) => c.phase === key);
 const allPhasesDone = applicablePhases.length === 0
 ? true
 : applicablePhases.every((p) => !!phaseStatus(p.key));
 const hasMultiplePhases = applicablePhases.length > 1;
 const finalPaymentBlockedByPhases = hasMultiplePhases && !allPhasesDone;

 // Effective split — small jobs (under the full-payment threshold) are paid in
 // full up front (deposit = total, no balance). Larger jobs keep the usual 50/50,
 // falling back to a computed half when stored amounts are 0 (e.g. manually created jobs).
 const quoteTotal = parseFloat(quote.total || "0");
 const isFullPayQuote = requiresFullUpfront(quoteTotal);

 // Cost-floor / margin guard — warns (never auto-changes) when a job is priced
 // below the safe minimum that still hits the target margin. Works for every
 // quote (customer-created, admin-created, or WhatsApp) since it recomputes from
 // the stored items + total. Volume data is optional — the estimator falls back
 // to per-item time estimates when it's missing.
 const hasPartialWork = (quote.items || []).some(hasPartialWorkScope);
 const needsStaffTimeAssessment = (quote.items || []).some(requiresStaffTimeAssessment);
 const marginItems = (quote.items || [])
   .filter((i: any) => i.serviceType !== 'discount')
   .map((i: any) => ({
     serviceType: i.serviceType,
     quantity: Number(i.quantity) || 1,
     volumeM3: i.volumeM3 != null ? Number(i.volumeM3) : undefined,
     carryOnly: !!i.carryOnly,
   }));
 const marginIsRelocation = marginItems.some((i: any) => i.serviceType === 'relocate') || !!(quote as any).samePropertyMove;
 const marginEval = evaluateJobMargin({
   items: marginItems,
   grandTotal: quoteTotal,
   distanceKm: Number(quote.distanceKm) || 0,
   isRelocation: marginIsRelocation,
   crewSize: Number((quote as any).secondDayCrewSize) || undefined,
 });
 // Job schedule (movers × scheduled hours) drives the overtime allowance: extra
 // time is charged against THIS job's scheduled time, not a flat 2-hour window.
 const jobSchedule = getJobSchedule({
   items: marginItems,
   distanceKm: Number(quote.distanceKm) || 0,
   isRelocation: marginIsRelocation,
   crewSize: Number((quote as any).secondDayCrewSize) || undefined,
 });
 // A sub-threshold job is normally paid in full up front (deposit = total,
 // final = 0). BUT once an admin adds a surcharge / add-on AFTER the customer
 // has already paid, the server re-opens a real balance and records it in
 // finalAmount. When a full-pay quote carries a stored final > 0 we must honor
 // that split so the newly-added amount shows as owing — otherwise the whole
 // job keeps reading as "paid in full up front" and the surcharge disappears.
 const storedFinalAmt = parseFloat(quote.finalAmount || "0");
 const reopenedBalance = isFullPayQuote && storedFinalAmt > 0.005;
 const effectiveDeposit = reopenedBalance
 ? Math.max(0, quoteTotal - storedFinalAmt)
 : (isFullPayQuote
 ? quoteTotal
 : (parseFloat(quote.depositAmount || "0") > 0
 ? parseFloat(quote.depositAmount!)
 : quoteTotal * 0.5));
 const effectiveFinal = reopenedBalance
 ? storedFinalAmt
 : (isFullPayQuote
 ? 0
 : (parseFloat(quote.finalAmount || "0") > 0
 ? parseFloat(quote.finalAmount!)
 : quoteTotal * 0.5));

 // Partial-payment ledger — running paid-so-far / balance-owing
 const quotePaymentsList = ((quote.payments || []) as any[]);
 const paymentSummary = quotePaymentSummary(quote);
 const verifiedPaymentSummary=quotePaymentSummary({...quote,leadIntake:{...quote.leadIntake,settlementLedgerIncludesLegacy:true}});
 const receiptHistoryPending=quote.paymentEvidence?.status==="missing"||
   Boolean(quote.depositPaidAt&&!quote.leadIntake?.settlementLedgerIncludesLegacy&&verifiedPaymentSummary.paid<paymentSummary.paid);
 const paidSoFar = paymentSummary.paid;
 const balanceOwing = paymentSummary.outstanding;
 // Whether there is money still to collect. Drives every "fully paid / no
 // balance to collect" surface below so a re-opened surcharge is surfaced even
 // on a sub-$150 (isFullPayQuote) job instead of being hidden.
 const hasOutstandingBalance = balanceOwing > 0.005;

 const canEdit = ['draft', 'submitted', 'under_review', 'approved', 'deposit_requested', 'deposit_paid', 'booking_requested', 'booked', 'booking_pending', 'assigned', 'in_progress', 'at_pickup', 'in_transit', 'at_dropoff', 'completed', 'job_completed', 'final_payment_requested', 'awaiting_final_payment'].includes(quote.status);
 const rateReasonItems=editItems.flatMap((item,index)=>{
  if(String(item.unitPrice??"").trim()===""||!Number.isFinite(Number(item.unitPrice)))return [];
  const saved=(quote.items||[]).find((entry:any)=>item.id!=null&&String(entry.id)===String(item.id));
  const savedRate=saved?Number(saved.unitPrice):null;
  const selectedCatalog=(adminCatalog||[]).find(entry=>String(entry.id)===String(item.catalogItemId));
  const catalogRate=selectedCatalog?Number(selectedCatalog.basePrice):saved?.catalogItem?.basePrice!=null?Number(saved.catalogItem.basePrice):null;
  const rate=Number(item.unitPrice);
  const serverRequestedReason=workspaceRequirements.some(requirement=>
   /^rateReasons\./i.test(requirement.field)&&Number(requirement.field.match(/^rateReasons\.(\d+)/i)?.[1]??-1)===index);
  if(saved&&rate===savedRate&&!serverRequestedReason)return [];
  if(catalogRate!=null&&rate===catalogRate)return [];
  return saved||catalogRate!=null||serverRequestedReason?[index]:[];
 });
 const editingRelocation=editItems.some(item=>item.serviceType==="relocate");
 const pickupEditStop=editStops.find(stop=>stop.kind==="pickup");
 const destinationEditStop=editStops.find(stop=>stop.kind==="dropoff");
 const existingWorkspaceFactKeys=["customername","jobaddress",...(editingRelocation?["toaddress","floorlevel","haslift","destinationfloor","destinationlift"]:[])];
 const stopRequirementMarkup=(stop:EditStop,field:"address"|"floor"|"hasLift")=>{
  const aliases=field==="address"
   ?stop.kind==="pickup"?["serviceaddress","jobaddress","pickupaddress","fromaddress"]:["dropoffaddress","toaddress","destinationaddress"]
   :field==="floor"
    ?stop.kind==="pickup"?["floorlevel","factsfloorlevel","pickupfloor","floorfrom"]:["destinationfloor","factsdestinationfloor","floorto"]
    :stop.kind==="pickup"?["haslift","factshaslift","pickuphaslift","liftfrom"]:["destinationlift","factsdestinationlift","liftto"];
  const normalized=new Set(aliases);
  return workspaceRequirements.filter(requirement=>normalized.has(requirement.field.replace(/[^a-z0-9]/gi,"").toLowerCase()))
   .map((requirement,index)=><p key={`${requirement.field}-${index}`} className="text-[11px] font-medium text-[#8A5A21]" role="status">{requirement.message}</p>);
 };
 const currentDelivery=deliveryOutcome?.quoteId===id?deliveryOutcome.delivery:null;
 const deliveryStatus=String(currentDelivery?.status||"").toLowerCase();
 const definitiveDeliveryFailure=["failed","blocked"].includes(deliveryStatus)||
  (deliveryStatus==="error"&&(currentDelivery?.retryable===true||currentDelivery?.canRetry===true));
 const retryMatchesCurrentDraft=workspaceSendRetry.current?.quoteId===id&&workspaceSendRetry.current?.draftSignature===draftState;
 const sendRetryAllowed=definitiveDeliveryFailure&&retryMatchesCurrentDraft;
 const sendLocked=["queued","sending","unknown","pending"].includes(deliveryStatus)||
  (!editDirty&&["sent","delivered","read"].includes(deliveryStatus))||
  (!editDirty&&definitiveDeliveryFailure&&!sendRetryAllowed);
 const deliveryStatusMessage=deliveryStatus==="sent"
  ?"Saved. The provider accepted the message; this is not confirmation of customer delivery."
  :deliveryStatus==="delivered"
   ?"Saved. The provider reports the quotation message as delivered."
   :deliveryStatus==="read"
    ?"Saved. The provider reports the quotation message as read."
    :["queued","sending","unknown","pending"].includes(deliveryStatus)
     ?`Send outcome is ${deliveryStatus}; check the saved version and delivery evidence before retrying.`
     :definitiveDeliveryFailure
      ?`Saved. Sending failed${currentDelivery?.reason?`: ${currentDelivery.reason}`:""}.${sendRetryAllowed?" A controlled retry is available.":""}`
      :deliveryStatus==="suppressed"
       ?`Saved, but no message was sent${currentDelivery?.reason?`: ${currentDelivery.reason}`:""}.`
       :deliveryStatus==="not_sent"
        ?`Saved; not sent. ${currentDelivery?.reason||"No delivery attempt was returned."}`
       :deliveryStatus==="error"
        ?`Saved. Sending returned an error${currentDelivery?.reason?`: ${currentDelivery.reason}`:""}; no retry is available until the outcome is confirmed.`
        :"";

 const handleStartEdit = () => {
 setLastQuoteSaved("");
 workspaceServerBaseline.current={customer:quote.customer||{},items:quote.items||[],quote:Object.fromEntries(Object.entries(quote).filter(([key])=>!["customer","items","updates","payments","editRevision"].includes(key)))};
 const savedWorkspaceReview=workspaceReviewForQuote(quote);
 const workspaceContext=workspaceContextQuery.data||{};
 const knownFacts={...(quote.leadIntake as any)?.facts,...savedWorkspaceReview.facts,...workspaceContext.facts};
 initialEdit.current=null;
 setEditFieldErrors({});
 setEditBaseline({revision:(quote as any).editRevision,version:Number(quote.version)});
 setEditError("");
 setEditCustomer({
 name: quote.customer?.name || '',
 email: quote.customer?.email || '',
 phone: quote.customer?.phone || '',
 companyName: quote.customer?.companyName || '',
 companyUen: quote.customer?.companyUen || '',
 billingAddress: quote.customer?.billingAddress || '',
 });
 setEditQuoteData({
 serviceAddress: quote.serviceAddress || '',
 pickupAddress: quote.pickupAddress || '',
 dropoffAddress: quote.dropoffAddress || '',
 transportFee: quote.transportFee || '0',
 // volumetricFee is the per-m³ handling portion that lives INSIDE the
 // transportFee bucket. Carry it in the edit form so a recalc/save keeps it
 // in lockstep with transportFee — otherwise the Transport/Volumetric split
 // goes stale and the breakdown stops summing to the total.
 volumetricFee: (quote as any).volumetricFee || '0',
 notes: workspaceContext.staffNotes??savedWorkspaceReview.staffNotes??(hasGeneratedReviewNotes(quote) ? '' : quote.notes || ''),
 staffTransportAllowance: !!quote.staffTransportAllowance,
 secondDayContinuation: !!quote.secondDayContinuation,
 secondDayHours: quote.secondDayHours ? String(quote.secondDayHours) : '0',
 secondDayCrewSize: Number(quote.secondDayCrewSize) || PricingConfig.secondDay.defaultCrewSize,
 invoiceType: (quote.invoiceType === 'commercial') ? 'commercial' : 'residential',
 billingAddress: quote.billingAddress || '',
 billingCompanyName: quote.billingCompanyName || '',
 billingCompanyUen: quote.billingCompanyUen || '',
 poNumber: quote.poNumber || '',
 goodwillDiscount: quote.goodwillDiscount ? String(quote.goodwillDiscount) : '0',
 goodwillReason: quote.goodwillReason || '',
 // Dispute-protection scope / timing / surcharge fields (Task #34).
 timingMode: (quote as any).timingMode === 'split' ? 'split' : 'continuous',
 dismantleAt: (quote as any).dismantleAt ? formatSingaporeDay((quote as any).dismantleAt,"yyyy-MM-dd") : '',
 dismantleTimeWindow: (quote as any).dismantleTimeWindow || '',
 reinstallAt: (quote as any).reinstallAt ? formatSingaporeDay((quote as any).reinstallAt,"yyyy-MM-dd") : '',
 reinstallTimeWindow: (quote as any).reinstallTimeWindow || '',
 afterOfficeInvolved: !!(quote as any).afterOfficeInvolved,
 afterOfficeSurchargeAmount: (quote as any).afterOfficeSurchargeAmount ? String((quote as any).afterOfficeSurchargeAmount) : '0',
 afterOfficeWaived: !!(quote as any).afterOfficeWaived,
 afterOfficeWaiverReason: (quote as any).afterOfficeWaiverReason || '',
 additionalTripCharge: (quote as any).additionalTripCharge ? String((quote as any).additionalTripCharge) : '0',
 specialRemarks: (quote as any).specialRemarks || '',
 ownMoverInvolved: !!(quote as any).ownMoverInvolved,
 depositRefundable: (quote as any).depositRefundable === true,
 cancellationNoticeHours: (quote as any).cancellationNoticeHours != null ? String((quote as any).cancellationNoticeHours) : '',
 });
 // Seed the multi-stop builder from stored stops; fall back to the legacy
 // single pickup/dropoff so existing relocation quotes edit cleanly.
 const storedStops: QuoteStop[] = Array.isArray((quote as any).stops) ? (quote as any).stops : [];
 if (storedStops.length > 0) {
 setEditStops(storedStops.map((s: any) => ({
 id: s.id || genStopId(),
 kind: s.kind === 'dropoff' ? 'dropoff' : 'pickup',
 address: s.address || '',
 postalCode: s.postalCode || '',
 floor: String(s.floor ?? ''),
 hasLift: s.hasLift ?? null,
 })));
 } else {
 setEditStops([
 { ...makeEditStop('pickup'), address: quote.pickupAddress || quote.serviceAddress || '',floor:String(knownFacts.floorLevel??""),hasLift:knownFacts.hasLift??null },
 { ...makeEditStop('dropoff'), address: quote.dropoffAddress || knownFacts.toAddress || '',floor:String(knownFacts.destinationFloor??""),hasLift:knownFacts.destinationLift??null },
 ]);
 }
 setEditTotalVolume(quote.volumeM3 ? String(quote.volumeM3) : '');
 setEditDistanceKm(quote.distanceKm != null ? Number(quote.distanceKm) : null);
 setEditCalc(null); setEditCalcError(null); setEditCalcLoading(false);
 const savedPendingItems=Array.isArray(workspaceContext.pendingItems)?workspaceContext.pendingItems:
  Array.isArray(savedWorkspaceReview.pendingItems)?savedWorkspaceReview.pendingItems:
  Array.isArray(quote.pendingItems)?quote.pendingItems:Array.isArray(quote.workspace?.pendingItems)?quote.workspace.pendingItems:
  Array.isArray(quote.workspaceResult?.pendingItems)?quote.workspaceResult.pendingItems:[];
 setEditItems((quote.items || []).filter((item: any) => item.serviceType !== 'discount').map((item: any,index:number) => {
 const pending=savedPendingItems.find((entry:any)=>Number(entry.index)===index);
 return fillDetectedAdminRate({
 id:item.id,
 _draftKey:crypto.randomUUID(),
 catalogItemId: item.catalogItemId,
 originalDescription: item.originalDescription ?? item.detectedName ?? "",
 detectedName: item.detectedName ?? null,
 serviceType: item.serviceType,
 quantity: pending?.quantity ? "" : item.quantity,
 unitPrice: pending?.rate ? "" : String(item.unitPrice),
 subtotal: String(item.subtotal),
 remark: item.remark || "",
 // Keep relocation-mode metadata — carry-only lines are legitimately $0
 // labour (they're charged through the volume they add, not per-item work).
 carryOnly: !!item.carryOnly,
 relocateMode: item.relocateMode || null,
 // Per-line volume so the recalc can grow the job volume when items are
 // added — non-dismantle items are charged by volume, not labour.
 volumeM3: item.volumeM3 != null ? Number(item.volumeM3) : null,
 fromStopId: item.fromStopId || null,
 toStopId: item.toStopId || null,
 },adminCatalog||[])}));
 setSurchargeAck(false);
 setWorkspaceFacts({...intakeFactsForQuote(quote),...(savedWorkspaceReview.facts||{}),...(workspaceContext.facts||{})});
 setWorkspaceRequirements(workspaceContext.requirements??intakeRequirementsForQuote(quote));
 setWorkspaceDecisions({...savedWorkspaceReview.decisions,...(workspaceContext.decisions||{})});
 setRateReasons({...savedWorkspaceReview.rateReasons,...(workspaceContext.rateReasons||{})});
 setTransportConfirmed(savedWorkspaceReview.transportConfirmed===true);
 setWorkspaceSendError("");
 setIsEditing(true);
 };

 const updateWorkspaceFact=(field:string,value:string|boolean|null)=>{
  setWorkspaceFacts(current=>({...current,[field]:value}));
  if(field==="customerName")setEditCustomer((current:any)=>({...current,name:String(value??"")}));
  if(field==="jobAddress")setEditQuoteData((current:any)=>({...current,serviceAddress:String(value??"")}));
  if(field==="toAddress"){
   setEditQuoteData((current:any)=>({...current,dropoffAddress:String(value??"")}));
   setEditStops(current=>{const index=current.findIndex(stop=>stop.kind==="dropoff");if(index<0)return current;return current.map((stop,i)=>i===index?{...stop,address:String(value??"")}:stop);});
  }
  if(field==="floorLevel"||field==="hasLift"||field==="destinationFloor"||field==="destinationLift"){
   const kind=field==="floorLevel"||field==="hasLift"?"pickup":"dropoff";
   const stopField=field==="floorLevel"?"floor":field==="destinationFloor"?"floor":"hasLift";
   setEditStops(current=>{const index=current.findIndex(stop=>stop.kind===kind);if(index<0)return current;return current.map((stop,i)=>i===index?{...stop,[stopField]:value}:stop);});
  }
 };

 const handleSaveEdit = async (action:"save"|"send"="save") => {
 if(action==="save"&&!editDirty&&lastQuoteSaved){toast({title:"Draft already saved",description:"No new changes; no message sent."});return;}
 if(savingEdit.current)return;
 savingEdit.current=true;
 setEditError("");
 if(action==="send")setWorkspaceSendError("");
 let requestStarted=false;
 try {
 // Dispute-protection: block the save until the admin confirms the after-office
 // / split-timing surcharge was added to the quote or waived in writing.
 const needsSurchargeAck = surchargeChanged;
 if (needsSurchargeAck && !surchargeAck) {
 savingEdit.current=false;
 toast({
 title: "Confirm the surcharge",
 description: "Split timing or after-office work is selected. Confirm the surcharge was added to the quote, or waived in writing, before saving.",
 variant: "destructive",
 });
 return;
 }
 const changedStops=JSON.stringify(editStops)!==JSON.stringify(initialEdit.current.stops);
 if(changedStops){
 const fields:Record<string,string>={};
 editStops.forEach((stop,index)=>{if(!stop.address.trim())fields[`stops.${index}.address`]=`Enter the address for ${stop.kind} ${index+1}, or remove that stop.`;});
 if(Object.keys(fields).length)throw new QuoteDraftValidation(fields);
 }
 // Unrelated edits leave legacy stops untouched; explicitly edited stops must be complete.
 const cleanStops: QuoteStop[] = editStops
 .filter(s => s.address.trim())
 .map(s => ({
 id: s.id,
 kind: s.kind,
 address: s.address.trim(),
 postalCode: s.postalCode.trim() || null,
 floor: s.floor.trim() || null,
 hasLift: s.hasLift,
 }));
 const validStopIds = new Set(cleanStops.map(s => s.id));
 const firstPickup = cleanStops.find(s => s.kind === 'pickup');
 const firstDropoff = cleanStops.find(s => s.kind === 'dropoff');
 const isReloc = (editItems || []).some((i: any) => i.serviceType === 'relocate');
 const numericErrors:Record<string,string>={};
 editItems.forEach((item,index)=>{
  const quantity=String(item.quantity??"").trim();
  const unitPrice=String(item.unitPrice??"").trim();
  if(quantity&&!/^\d+$/.test(quantity))numericErrors[`items.${index}.quantity`]="Enter a whole quantity, or leave it blank while saving a draft.";
  else if(quantity&&Number(quantity)<1)numericErrors[`items.${index}.quantity`]="Quantity must be at least 1.";
  else if(action==="send"&&!quantity)numericErrors[`items.${index}.quantity`]="Enter a quantity before sending.";
  if(unitPrice&&!/^\d+(\.\d{1,2})?$/.test(unitPrice))numericErrors[`items.${index}.unitPrice`]="Enter a complete unit price, such as 120 or 120.50.";
  else if(action==="send"&&!unitPrice)numericErrors[`items.${index}.unitPrice`]="Enter a unit price before sending.";
  const reasonKey=String(item.id??index);
  if(action==="send"&&rateReasonItems.includes(index)&&String(rateReasons[reasonKey]||"").trim().length<5)
   numericErrors[`items.${index}.rateReason`]="Explain who approved this rate (at least 5 characters). “NA” does not approve a price.";
 });
 if(Object.keys(numericErrors).length)throw new QuoteDraftValidation(numericErrors);
 let payload:ReturnType<typeof quoteDraftPayload>;
 try{
  payload=quoteDraftPayload(editCustomer,editQuoteData,editItems,initialEdit.current.customer,initialEdit.current.data);
 }catch(error){
  if(action==="send"||!(error instanceof QuoteDraftValidation))throw error;
  const same=(value:any,baseline:any)=>JSON.stringify(value??null)===JSON.stringify(baseline??null);
  const appointmentFields=new Set(["scheduledAt","timeWindow","status","timingMode","dismantleAt","dismantleTimeWindow","reinstallAt","reinstallTimeWindow"]);
  const customerUpdates=Object.fromEntries(Object.entries(editCustomer).filter(([key,value])=>!same(value,initialEdit.current.customer[key])));
  const quoteUpdates=Object.fromEntries(Object.entries(editQuoteData).filter(([key,value])=>!appointmentFields.has(key)&&!same(value,initialEdit.current.data[key])));
  const items=editItems.map((item,index)=>{
   const saved=(quote.items||[]).find((entry:any)=>item.id!=null&&String(entry.id)===String(item.id));
   return pendingWorkspaceLine(item,saved);
  });
  payload={customerUpdates,quoteUpdates,items};
 }
 const pendingItems=editItems.flatMap((item,index)=>{
  const pending:{index:number;quantity?:boolean;rate?:boolean}={index};
  if(String(item.quantity??"").trim()==="")pending.quantity=true;
  if(String(item.unitPrice??"").trim()==="")pending.rate=true;
  return pending.quantity||pending.rate?[pending]:[];
 });
 const rateReasonPayload=Object.fromEntries(rateReasonItems
  .map(index=>[String(editItems[index].id??index),String(rateReasons[String(editItems[index].id??index)]||"").trim()])
  .filter(([,reason])=>Boolean(reason)));
 const stopsChanged=JSON.stringify(editStops)!==JSON.stringify(initialEdit.current.stops);
 const items=payload.items.map(item=>({...item,
 ...(stopsChanged?{fromStopId:validStopIds.has(item.fromStopId)?item.fromStopId:null,
 toStopId:validStopIds.has(item.toStopId)?item.toStopId:null}:{})}));
 const pickupFactStop=editStops.find(stop=>stop.kind==="pickup");
 const destinationFactStop=editStops.find(stop=>stop.kind==="dropoff");
 const facts:QuoteWorkspaceFacts={
  ...workspaceFacts,
  customerName:editCustomer.name||workspaceFacts.customerName||"",
  jobAddress:isReloc?pickupFactStop?.address||"":editQuoteData.serviceAddress||editQuoteData.pickupAddress||workspaceFacts.jobAddress||"",
  toAddress:isReloc?destinationFactStop?.address||"":editQuoteData.dropoffAddress||workspaceFacts.toAddress||"",
  floorLevel:isReloc?pickupFactStop?.floor||"":workspaceFacts.floorLevel||"",
  hasLift:isReloc?pickupFactStop?.hasLift??null:workspaceFacts.hasLift??null,
  destinationFloor:isReloc?destinationFactStop?.floor||"":workspaceFacts.destinationFloor||"",
  destinationLift:isReloc?destinationFactStop?.hasLift??null:workspaceFacts.destinationLift??null,
 };
 const quoteUpdates={
  ...payload.quoteUpdates,
  ...(surchargeChanged?{afterOfficeSurchargeApplied:!!editQuoteData.afterOfficeInvolved&&Number(editQuoteData.afterOfficeSurchargeAmount)>0}:{}),
  ...(isReloc && stopsChanged && cleanStops.length > 0
   ? {stops:cleanStops,pickupAddress:firstPickup?.address||editQuoteData.pickupAddress||"",dropoffAddress:firstDropoff?.address||editQuoteData.dropoffAddress||""}
   : {}),
  ...(isReloc&&editDistanceKm!==initialEdit.current.distance&&editDistanceKm!=null?{distanceKm:String(editDistanceKm)}:{}),
  ...(isReloc&&editTotalVolume!==initialEdit.current.volume?{volumeM3:editTotalVolume}:{}),
 };
  const workspaceInput={action,facts,decisions:workspaceDecisions,rateReasons:rateReasonPayload,pendingItems,transportConfirmed,
   baseline:workspaceServerBaseline.current};
 const retryAttempt=action==="send"&&workspaceSendError&&workspaceSendRetry.current?.quoteId===id&&workspaceSendRetry.current?.draftSignature===draftState
  ? workspaceSendRetry.current
  : null;
 const requestSignature=JSON.stringify({quoteId:id,action,customerUpdates:payload.customerUpdates,quoteUpdates,items,facts,decisions:workspaceDecisions,rateReasons:rateReasonPayload,pendingItems,transportConfirmed});
 let requestKey=retryAttempt?.requestKey||workspaceRequestKeys.current.get(requestSignature);
 if(!requestKey){requestKey=crypto.randomUUID();workspaceRequestKeys.current.set(requestSignature,requestKey);}
 const requestBody=retryAttempt?.body||{
  expectedRevision:editBaseline.revision,
  expectedVersion:editBaseline.version,
  customerUpdates:payload.customerUpdates,
  quoteUpdates,
  items,
  workspace:{...workspaceInput,requestKey},
 };
 setEditFieldErrors({});
 requestStarted=true;
 const result:any=await editQuote.mutateAsync({id,...requestBody} as any);
 const savedQuote=result?.quote||result;
 const savedDraft=reconcileWorkspaceDraft(JSON.parse(draftState),savedQuote);
 const savedDraftSignature=JSON.stringify(savedDraft);
 setEditItems(savedDraft.items);
 setRateReasons(savedDraft.rateReasons);
 const operationResult=result?.workspaceResult||savedQuote?.workspaceResult||null;
 if(savedQuote&&typeof savedQuote==="object"){
  queryClient.setQueryData(["/api/quotes/:id",id],savedQuote);
  void queryClient.invalidateQueries({queryKey:["/api/quotes"]});
 }
 if(Array.isArray(operationResult?.requirements))setWorkspaceRequirements(operationResult.requirements);
 if(operationResult?.sendError){
  setWorkspaceSendError(String(operationResult.sendError));
  workspaceSendRetry.current={quoteId:id,draftSignature:savedDraftSignature,requestKey,body:requestBody};
 }
 else if(action==="send")setWorkspaceSendError("");
 setEditBaseline({revision:savedQuote?.editRevision||editBaseline.revision,version:Number(savedQuote?.version||editBaseline.version)});
 initialEdit.current={...savedDraft,signature:savedDraftSignature};
 workspaceServerBaseline.current={customer:savedQuote.customer||{},items:savedQuote.items||[],quote:Object.fromEntries(Object.entries(savedQuote).filter(([key])=>!["customer","items","updates","payments","editRevision","workspaceResult"].includes(key)))};
 void workspaceContextQuery.refetch();
 setLastQuoteSaved(new Date().toLocaleTimeString("en-SG",{timeZone:"Asia/Singapore",hour:"2-digit",minute:"2-digit"}));
 if(action==="send"){
  const delivery=operationResult?.delivery;
  if(!delivery){
   const reason=operationResult?.sendError||
    (operationResult?.requirements?.length
     ?"The quotation was saved, but no message was sent. Resolve the listed review requirements before sending."
     :"The quotation was saved, but no delivery record was returned; no message was sent.");
   setDeliveryOutcome({quoteId:id,draftSignature:savedDraftSignature,delivery:{status:"not_sent",reason}});
   setWorkspaceSendError(reason);
   workspaceSendRetry.current=null;
   workspaceRequestKeys.current.delete(requestSignature);
   toast({title:"Quote saved; not sent",description:reason,variant:"destructive"});
  }else{
   setDeliveryOutcome({quoteId:id,draftSignature:savedDraftSignature,delivery});
   const deliveryStatus=String(delivery.status||"").toLowerCase();
   const canControlledRetry=["failed","blocked"].includes(deliveryStatus)||
    (deliveryStatus==="error"&&(delivery.retryable===true||delivery.canRetry===true));
   if(canControlledRetry){
    const reason=operationResult?.sendError||delivery.reason||"Sending failed.";
    setWorkspaceSendError(reason);
    workspaceSendRetry.current={quoteId:id,draftSignature:savedDraftSignature,requestKey,body:requestBody};
    toast({title:"Quote saved; sending failed",description:`${reason} A controlled retry is available.`,variant:"destructive"});
   }else if(deliveryStatus==="sent"){
    setWorkspaceSendError("");
    workspaceSendRetry.current=null;
    const channel=delivery.attachment==="link_only"?"An approved quotation link was accepted; no PDF was attached.":"The provider accepted the quotation message; customer delivery is not confirmed.";
    toast({title:"Provider accepted the quotation",description:channel});
   }else if(deliveryStatus==="delivered"||deliveryStatus==="read"){
    setWorkspaceSendError("");
    workspaceSendRetry.current=null;
    toast({title:deliveryStatus==="read"?"Quotation read":"Quotation delivered",description:"Provider delivery evidence is available in the status below."});
   }else if(["queued","sending","unknown","pending"].includes(deliveryStatus)){
    const message=`Provider status is ${deliveryStatus}; outcome is pending or uncertain. Do not retry until delivery evidence is reconciled.`;
    setWorkspaceSendError(message);
    workspaceSendRetry.current=null;
    toast({title:"Quote saved; delivery status pending",description:message,variant:"destructive"});
   }else if(deliveryStatus==="suppressed"){
    const reason=delivery.reason||"The message was suppressed and not sent.";
    setWorkspaceSendError(reason);
    workspaceSendRetry.current=null;
    toast({title:"Quote saved; message not sent",description:reason,variant:"destructive"});
   }else{
    const reason=delivery.reason||`Unrecognized delivery status: ${deliveryStatus||"missing"}. Reconcile before attempting another send.`;
    setWorkspaceSendError(reason);
    workspaceSendRetry.current=null;
    toast({title:"Quote saved; delivery needs review",description:reason,variant:"destructive"});
   }
  }
 }else{
  toast({ title: "Draft saved", description: "Changes saved. No customer message sent; appointment unchanged." });
 }
 } catch (err: any) {
 if(err instanceof QuoteDraftValidation)setEditFieldErrors(err.fields);
 else if(err.fieldErrors)setEditFieldErrors(err.fieldErrors);
 if(Array.isArray(err.requirements))setWorkspaceRequirements(err.requirements);
 const changedFields=Array.isArray(err.changedFields)?err.changedFields.filter(Boolean).join(", "):typeof err.changedFields==="string"?err.changedFields:"";
 const errorText=`${err.message||"The quotation was not saved."}${changedFields?` Server changed fields: ${changedFields}.`:""}`;
 const knownRejected=!requestStarted||err instanceof QuoteDraftValidation||[400,401,403,404,409,422].includes(err.status);
 setWorkspaceSendError("");
 setEditError(knownRejected?`${errorText} Nothing was sent; your entered changes are retained.`:
   `${errorText} Save/send outcome could not be verified. Check the saved version and message status before another send.`);
 if(action==="send"&&!knownRejected)setDeliveryOutcome({quoteId:id,draftSignature:draftState,delivery:{status:"unknown",reason:"Response unavailable; reconcile saved version and delivery before retrying."}});
 void workspaceContextQuery.refetch().then(response=>{if(Array.isArray(response.data?.requirements))setWorkspaceRequirements(response.data.requirements);});
 const requiredDetails=Array.isArray(err.requirements)?err.requirements:[];
 toast({ title: action==="send"?"Quote not sent":"Could not save draft",
   description: requiredDetails.length
     ? `${requiredDetails.length} detail${requiredDetails.length===1?" needs":"s need"} review. Use the field links below; your work is retained.`
     : err.message, variant: "destructive" });
 } finally {
 savingEdit.current=false;
 }
 };

 const handleApproveAndRequestDeposit = async () => {
 try {
 await updateStatus.mutateAsync({ id, status: 'deposit_requested', note: 'Quote approved. Deposit requested.' });
 toast({ title: "Deposit Requested", description: "Email sent to customer with payment details." });
 } catch (err: any) {
 toast({ title: "Error", description: err.message, variant: "destructive" });
 }
 };

 const handleApproveCommercialBooking = async () => {
 try {
 await approveCommercial.mutateAsync();
 } catch {
 /* toast handled in mutation */
 }
 };

 const handleSendCommercialInvoice = async () => {
 if(invoiceSubmitting.current || sendCommercialInvoice.data?.warning)return;
 invoiceSubmitting.current=true;
 try {
 await sendCommercialInvoice.mutateAsync();
 } catch {
 /* toast handled in mutation */
 } finally {
 invoiceSubmitting.current=false;
 }
 };
 const invoiceNotificationStatus = !isEditing && (sendCommercialInvoice.isError || sendCommercialInvoice.isSuccess) ? (
 <p role="status" data-testid="invoice-notification-status" className="text-sm mt-2">
 Quotation edits remain saved. {sendCommercialInvoice.isSuccess
 ? `Invoice notification: ${sendCommercialInvoice.data?.notificationStatus||"accepted"}. ${sendCommercialInvoice.data?.emailSent?"Email accepted by the provider; delivery is not yet confirmed.":""} ${sendCommercialInvoice.data?.warning||""}`
 : `Invoice notification: ${(sendCommercialInvoice.error as any)?.notificationStatus||"needs review"} — ${(sendCommercialInvoice.error as Error)?.message}. Do not repeat Save.`}
 </p>
 ) : null;

 const handleConfirmBooking = async () => {
 setShowAppointment(true);
 setTimeout(()=>{
 const panel=document.querySelector('[data-testid="staff-scheduling-review"]');
 panel?.scrollIntoView({behavior:"smooth",block:"center"});
 (panel?.querySelector('[data-testid="schedule-date"]') as HTMLInputElement)?.focus({preventScroll:true});
 },0);
 };

 const handleAssign = async () => {
 if (assigningCrew.current || updateStatus.isPending) return;
 if (!selectedAssignee) return toast({ title: "Select a staff member or team", variant: "destructive" });
 assigningCrew.current = true;
 try {
 if (selectedAssignee === "unassigned") {
 await updateStatus.mutateAsync({ id, status: 'assigned', assignedStaffId: null });
 toast({ title: "Assignment removed", description: "The appointment and payment records are unchanged." });
 return;
 }
 const [type, rawId] = selectedAssignee.split(":");
 const numId = parseInt(rawId);
 if (type === "team") {
 await updateStatus.mutateAsync({ id, status: 'assigned', assignedTeamId: numId });
 toast({ title: "Team assigned", description: "The whole team has been assigned to this job." });
 } else {
 await updateStatus.mutateAsync({ id, status: 'assigned', assignedStaffId: numId });
 toast({ title: "Staff assigned", description: "Staff member assigned to this job." });
 }
 } catch (err: any) {
 toast({ title: "Error", description: err.message, variant: "destructive" });
 } finally {
 assigningCrew.current = false;
 }
 };

 const handleRequestFinalPayment = async () => {
 try {
 const data = await requestFinalPayment.mutateAsync(parseInt(id));

 // Manual-only path — customer has no email or WhatsApp on file. The
 // server still created the Stripe/PayNow link and advanced the status;
 // we auto-copy the link to clipboard and show it in a long-lived toast
 // so the admin can paste it into SMS, iMessage, Telegram, etc.
 if (data?.manualOnly && data?.paymentLink) {
 try { await navigator.clipboard.writeText(data.paymentLink); } catch {}
 toast({
 title: "📋 Link copied — send it manually",
 description:
 `No email or WhatsApp on file. The payment link has been copied to your clipboard — ` +
 `paste it to the customer. Link: ${data.paymentLink}`,
 duration: 20000,
 });
 return;
 }

 const both = data?.emailSent && data?.whatsappSent;
 const title = both
 ? "✅ Sent via WhatsApp + Email"
 : data?.whatsappSent
 ? "✅ WhatsApp Sent"
 : "✅ Final Payment Email Sent";
 toast({
 title,
 description: data?.message || "Final payment notification sent.",
 });
 } catch (err: any) {
 toast({ title: "Failed to send", description: err.message, variant: "destructive" });
 }
 };

 const handleManualClose = async () => {
 const reason = prompt("Reason for manual close (optional):");
 try {
 await closeQuote.mutateAsync({ id, reason: reason || undefined });
 toast({ title: "Case Closed", description: "Case has been manually closed." });
 } catch (err: any) {
 toast({ title: "Error", description: err.message, variant: "destructive" });
 }
 };

 const addEditItem = () => {
 // On relocation jobs default new lines to Relocate — install-typed lines
 // don't count toward the load volume, so a wrong default silently
 // under-prices the volumetric handling charge.
 setEditItems(previous=>[...previous, {
 _draftKey:crypto.randomUUID(),
 originalDescription: '',
 detectedName: '',
 serviceType: previous.some(i=>i.serviceType==="relocate") ? 'relocate' : 'install',
 quantity: 1,
 unitPrice: '',
 subtotal: '0',
 }]);
 };

 const removeEditItem = (i: number) => {
 setEditItems(prev=>prev.filter((_, idx) => idx !== i));
 };

 const updateEditItem = (i: number, field: string, value: any) => {
 setEditItems(prev=>prev.map((item, idx) => {
 if (idx !== i) return item;
 const updated = { ...item, [field]: value };
 if(field==="detectedName")updated.originalDescription=value;
 // A service change is not permission to overwrite an authorised manual rate.
 // Approved catalogue rates are applied only by the explicit catalogue action.
 if(field==="serviceType"&&value!=="relocate"){updated.carryOnly=false;updated.relocateMode=null;}
 if(field==="relocateMode")updated.carryOnly=value==="carry_only";
 updated.subtotal = (Number(updated.unitPrice) * Number(updated.quantity)).toFixed(2);
 return (field==="detectedName"||field==="serviceType")
   ? fillDetectedAdminRate(updated,adminCatalog||[])
   : updated;
 }));
 };

 // Catalog lookup: suggestions for the item description a row is typing.
 const catalogSuggestions = (query: string): CatalogItem[] => {
 const q = query.trim().toLowerCase();
 if (q.length < 2 || !adminCatalog?.length) return [];
 const jobIsReloc = (editItems || []).some((i: any) => i.serviceType === 'relocate');
 return adminCatalog
 .filter(c => c.name.toLowerCase().includes(q))
 // On relocation jobs surface the Relocate rows first so the admin
 // doesn't accidentally pick Install (which skips volume pricing).
 .sort((a, b) => jobIsReloc
 ? Number(b.serviceType === 'relocate') - Number(a.serviceType === 'relocate')
 : 0)
 .slice(0, 8);
 };

 // Apply a picked catalog row to an item line: exact name, its service type,
 // the catalog price AND the item's volume. For relocate rows the catalog
 // basePrice IS the carry-only weight-tier labour ($0 for light items) —
 // that is intentional: non-dismantle items are charged through the VOLUME
 // they add (volumetric handling in the transport bucket), not per-item labour.
 const applyCatalogToItem = (i: number, c: CatalogItem,applyRate=true) => {
 setEditItems(prev => prev.map((item, idx) => {
 if (idx !== i) return item;
 // Relocate rows use the SAME carry rule as the customer engine: normal
 // items are $0 labour (bundled into transport + volume); only special-
 // handling SKUs (piano, PAX, L-sofa…) keep their catalog carry rate.
 const priced = c.serviceType === 'relocate'
 ? effectiveCarryPrice(undefined, undefined, Number(c.basePrice) || 0, (c as any).sku)
 : Number(c.basePrice);
 const unitPrice = applyRate?priced.toFixed(2):item.unitPrice;
 return {
 ...item,
 detectedName: item.detectedName || item.originalDescription || c.name,
 originalDescription: item.originalDescription || item.detectedName || c.name,
 serviceType: applyRate?c.serviceType:item.serviceType,
 catalogItemId: c.id,
 volumeM3: (c as any).volumeM3 != null ? Number((c as any).volumeM3) : (item as any).volumeM3 ?? null,
 unitPrice,
 subtotal: (Number(unitPrice) * Number(item.quantity || 1)).toFixed(2),
 };
 }));
 setCatalogPickerFor(null);
 };

 // AI auto-detect the line type from the typed name, so fees/labour lines
 // don't get an "Installation of …" prefix on the quote/job order. Only the
 // serviceType is changed — the wording the admin typed is left untouched.
 const detectEditItemType = async (i: number) => {
 const name = String(editItems[i]?.detectedName || editItems[i]?.originalDescription || '').trim();
 if (!name) {
 toast({ title: "Type a description first", description: "Enter the line description, then auto-detect.", variant: "destructive" });
 return;
 }
 setDetectingItem(i);
 try {
 const res = await apiRequest("POST", "/api/ai/classify-line", { name });
 const data = await res.json();
 if (data?.serviceType) {
 updateEditItem(i, 'serviceType', data.serviceType);
 toast({ title: "Line type detected", description: data.serviceType === 'fee' ? "Marked as Fee / Charge — shown as typed." : `Marked as ${data.serviceType}.` });
 }
 } catch {
 toast({ title: "Couldn't auto-detect", description: "Set the line type manually.", variant: "destructive" });
 } finally {
 setDetectingItem(null);
 }
 };

 // ── Multi-stop relocation (additive) edit helpers ──
 const editPickupStops = editStops.filter(s => s.kind === 'pickup');
 const editDropoffStops = editStops.filter(s => s.kind === 'dropoff');
 const editIsMultiStop = editPickupStops.length > 1 || editDropoffStops.length > 1;
 const addEditStop = (kind: 'pickup' | 'dropoff') => setEditStops(prev => [...prev, makeEditStop(kind)]);
 const removeEditStop = (stopId: string) => setEditStops(prev => {
 const target = prev.find(s => s.id === stopId);
 if (!target) return prev;
 if (prev.filter(s => s.kind === target.kind).length <= 1) return prev;
 setEditItems(items => items.map(it => ({
 ...it,
 fromStopId: it.fromStopId === stopId ? null : it.fromStopId,
 toStopId: it.toStopId === stopId ? null : it.toStopId,
 })));
 return prev.filter(s => s.id !== stopId);
 });
 const updateEditStop = (stopId: string, field: keyof EditStop, value: string | boolean | null) =>
 setEditStops(prev => prev.map(s => s.id === stopId ? { ...s, [field]: value } : s));

 const calcEditPrice = async () => {
 const snapshot=latestCalculationState.current;
 const pus = editStops.filter(s => s.kind === 'pickup' && s.address.trim());
 const dos = editStops.filter(s => s.kind === 'dropoff' && s.address.trim());
 if (pus.length === 0 || dos.length === 0) {
 toast({ title: "Add addresses first", description: "Enter at least one pick-up and one drop-off address.", variant: "destructive" });
 return;
 }
 setEditCalcLoading(true);
 setEditCalcError(null);
 try {
 quoteDraftPayload({}, {}, editItems, {}, {});
 const waypoints = [...pus, ...dos].map(s => ({
 address: `${s.address}${s.postalCode ? ` ${s.postalCode}` : ""}`.trim(),
 }));
 const res = await apiRequest("POST", "/api/distance", { waypoints });
 const data = await res.json();
 if(!data.routeFound||!Number.isFinite(Number(data.distanceKm))||data.distanceKm==null)
 throw new Error("Distance could not be verified. No logistics changes were applied. Check the addresses or keep the existing authorised logistics charge.");
 const dist = Number(data.distanceKm);
 const extraStops = Math.max(0, pus.length - 1) + Math.max(0, dos.length - 1);
 const labor = editItems
 .filter(i => !isWrappingRollupLine(i.detectedName) && !isWrappingRollupLine(i.originalDescription))
 .reduce((sum, i) => sum + Number(i.unitPrice) * Number(i.quantity), 0);
 // Non-dismantle (carry) items are charged through the VOLUME they add,
 // not per-item labour. So the job volume must grow when items are added:
 // sum the per-line catalog volumes and never price below that — otherwise
 // an added item contributes $0 and the total barely moves.
 // Per-line volumes aren't stored on quote lines — resolve each line's
 // volume from the catalog (by picked id, then exact name) at recalc time.
 const volumeForLine = (i: any): number => {
 if (Number(i.volumeM3) > 0) return Number(i.volumeM3);
 const rows = adminCatalog || [];
 const byId = i.catalogItemId ? rows.find(c => c.id === i.catalogItemId) : undefined;
 if (byId && Number((byId as any).volumeM3) > 0) return Number((byId as any).volumeM3);
 const n = String(i.detectedName || i.originalDescription || '')
 .replace(/\s*\(wrapped\)\s*$/i, '').trim().toLowerCase();
 if (!n) return 0;
 const byName = rows.find(c => c.name.trim().toLowerCase() === n && Number((c as any).volumeM3) > 0);
 return byName ? Number((byName as any).volumeM3) : 0;
 };
 const relocLines = editItems
 .filter(i => !isWrappingRollupLine(i.detectedName) && !isWrappingRollupLine(i.originalDescription))
 .filter(i => i.serviceType === 'relocate');
 const itemsVolume = relocLines.reduce((sum, i) => sum + volumeForLine(i) * (Number(i.quantity) || 1), 0);
 const allLinesResolved = relocLines.length > 0 && relocLines.every(i => volumeForLine(i) > 0);
 const manualVolume = parseFloat(editTotalVolume || "0") || 0;
 // When EVERY relocate line has a known catalog volume, recompute the job
 // volume deterministically from the lines (handles removals too). Otherwise
 // never price below the known line volume, but keep the admin's manual
 // figure if it's larger (it may cover free-text lines the catalog can't).
 const effectiveVolume = allLinesResolved
 ? Number(itemsVolume.toFixed(2))
 : Math.max(manualVolume, Number(itemsVolume.toFixed(2)));
 // The transportFee bucket also carries floor/stairs, wrapping-protection
 // and access-difficulty surcharges. Feed them into the recalculation or
 // they get dropped and the total goes DOWN after a recalc.
 const floors = editStops
 .filter(s => s.address.trim())
 // hasLift null (unanswered) charges the NO-LIFT rate — same rule the
 // server's canonical stop parsing applies (hasLift: !!f.hasLift).
 .map(s => ({ level: parseInt(s.floor, 10) || 0, hasLift: s.hasLift === true }));
 const wrappedUnits = editItems.reduce((sum, i) => {
 if (isWrappingRollupLine(i.detectedName) || isWrappingRollupLine(i.originalDescription)) {
 return sum + (Number(i.quantity) || 0);
 }
 return sum;
 }, 0);
 const result = computeMultiStopRelocationPrice({
 laborSubtotal: labor,
 totalVolumeM3: effectiveVolume,
 distanceKm: dist,
 extraStops,
 samePropertyMove: !!(quote as any).samePropertyMove,
 floors,
 wrappedUnits,
 accessDifficulty: ((quote as any).accessDifficulty as 'easy' | 'medium' | 'hard') || 'easy',
 laborDiscount: Number((quote as any).discount || 0),
 });
 if(latestCalculationState.current!==snapshot)throw new Error("The inputs changed while calculating. No old calculation was applied; calculate again using the current values.");
 setEditDistanceKm(dist);
 if(effectiveVolume!==manualVolume)setEditTotalVolume(effectiveVolume.toFixed(2));
 setEditCalc(result);
 // The transportFee column holds the full logistics bucket; editTotal
 // recomputes from subtotal + transportFee, so this drives the new total.
 // Persist the volumetric portion in lockstep so the Transport/Volumetric
 // display split stays consistent with the new bucket.
 setEditQuoteData((prev: any) => ({ ...prev, transportFee: result.logisticsSubtotal.toFixed(2), volumetricFee: result.volumetricFee.toFixed(2) }));
 if (!data.routeFound) {
 toast({ title: "Distance unavailable", description: "Couldn't compute driving distance — priced without transport. Adjust manually if needed.", variant: "destructive" });
 } else {
 toast({ title: "Price calculated", description: `Logistics S$${result.logisticsSubtotal.toFixed(2)} applied to Transport Fee. You can still override it.` });
 }
 } catch (err: any) {
 setEditCalcError(err?.message || "Could not calculate price.");
 } finally {
 setEditCalcLoading(false);
 }
 };

 // Exclude the "Wrapping Protection" roll-up line — its fee already lives
 // inside the transportFee (logistics) bucket, so counting it here would
 // double-count it and the total would jump the moment Edit is opened.
 const editSubtotal = editItems
 .filter(i => !isWrappingRollupLine(i.detectedName) && !isWrappingRollupLine(i.originalDescription))
 .reduce((sum, i) => sum + Number(i.unitPrice) * Number(i.quantity), 0);
  const editVolume = editItems.some(i => i.serviceType === 'relocate') && adminCatalog
    ? relocationVolumeFromCatalog(editItems, adminCatalog)
    : null;
  // Keep the non-volume logistics unchanged; the server applies the same
  // delta on save. Reopening an already-saved quote therefore previews the
  // missing charge without requiring a route/distance recalculation.
  const editTransportPending = isTransportPricingPending({...quote,transportFee:editQuoteData.transportFee});
  const editTransport = Number(editQuoteData.transportFee || 0) +
    (!editTransportPending && editVolume && editVolume.unresolved.length === 0
      ? editVolume.volumetricFee - Math.min(Number(editQuoteData.volumetricFee || 0), Number(editQuoteData.transportFee || 0))
      : 0);
 // Volumetric is a portion *inside* the transportFee bucket. Clamp it to the
 // bucket so the preview's Transport line (bucket − volumetric) can never go
 // negative and the displayed lines always sum back to the total.
  const editVolumetric = Math.min(
    !editTransportPending && editVolume && editVolume.unresolved.length === 0 ? editVolume.volumetricFee : Number(editQuoteData.volumetricFee || 0),
    editTransport);
  const editDiscount = Number(quote?.discount || 0);
 const editPromoDiscount = Number(quote?.promoDiscount || 0);
 const editGoodwillDiscount = Number(editQuoteData.goodwillDiscount || 0);
 const editSecondDay = calcSecondDayContinuation(!!editQuoteData.secondDayContinuation, editQuoteData.secondDayHours || 0, editQuoteData.secondDayCrewSize).fee;
 const editAfterOffice=editQuoteData.afterOfficeWaived?0:Number(editQuoteData.afterOfficeSurchargeAmount||0);
 const editAdditionalTrip=Number(editQuoteData.additionalTripCharge||0);
 const editTotal = Math.max(0, editSubtotal - editDiscount - editPromoDiscount - editGoodwillDiscount + editTransport + editSecondDay+editAfterOffice+editAdditionalTrip);

 const handlePrintQuote = (forceDocType?: "DELIVERY ORDER") => {
 const q = quote;
 // Formal quotation PDFs and manual quotations use exactly the same saved
 // document template. Existing job-order/invoice/DO controls remain separate.
 if(!forceDocType && q.invoiceType!=="commercial" && ["submitted","under_review","approved","deposit_requested"].includes(q.status)) {
   if(q.termsAcceptedAt && q.termsAcceptedVersion===q.version) {
     window.open(`/api/quotes/${q.id}/quotation.pdf?ref=${encodeURIComponent(q.referenceNo)}&version=${q.version}`,"_blank");
     return;
   }
   const html=renderSavedQuoteDocument(q,{forceDocType:"QUOTATION",origin:window.location.origin,
     paidTotal:quotePaymentSummary(q).paid});
   const popup=window.open("","_blank","width=900,height=700");
   if(popup){popup.document.write(html);popup.document.close();popup.onload=()=>popup.print();}
   return;
 }
 const items = (q.items || []) as any[];
 const services = (() => { try { return JSON.parse(q.selectedServices || "[]"); } catch { return []; } })();
 // Labour overage clause only applies to relocation jobs (where unpacking,
 // re-arranging and on-site decisions commonly extend crew time). Pure
 // installation jobs are charged on agreed scope only.
 const hasRelocation = (items || []).some((i: any) => i.serviceType === 'relocate');
 // Scheduled on-site time for this job, computed with the SAME engine the web
 // estimate uses, so the printed quote shows the included man-hours that the
 // Standard Terms & Conditions below refer to.
 const printSchedule = getJobSchedule({
   items: (items || []).map((i: any) => ({
     serviceType: i.serviceType,
     quantity: Number(i.quantity) || 1,
     volumeM3: i.volumeM3,
     carryOnly: i.carryOnly,
   })),
   totalVolumeM3: Number((q as any).totalVolumeM3) || undefined,
   distanceKm: Number(q.distanceKm) || 0,
   isRelocation: hasRelocation,
   crewSize: Number((q as any).secondDayCrewSize) || undefined,
 });
 const fmtHrs = (n: number) => (n % 1 === 0 ? `${n}` : n.toFixed(1));
 const printManHours = fmtHrs(printSchedule.scheduledHours * printSchedule.crewSize);
 const printCrewRate = printSchedule.overtimePerManPerHour * printSchedule.crewSize;
 // Single shared source of truth for the customer-facing terms — identical
 // wording to the web estimate and the standalone /terms page.
 const quoteTerms = getQuoteTerms({ isRelocation: hasRelocation });
 const scheduledDate = q.scheduledAt ? new Date(q.scheduledAt).toLocaleDateString("en-SG", { weekday: "long", year: "numeric", month: "long", day: "numeric" }) : null;
 const address = (q as any).samePropertyMove
 ? (q.pickupAddress || q.serviceAddress || "—")
 : (q.pickupAddress ? `${q.pickupAddress} → ${q.dropoffAddress}` : (q.serviceAddress || "—"));

 // Escape user-controlled values before interpolation into the printable
 // HTML template (this template is opened via window.open in the admin's
 // browser, so unescaped customer/billing input would be an XSS risk).
 const esc = (v: any) => String(v ?? "")
 .replace(/&/g, "&amp;")
 .replace(/</g, "&lt;")
 .replace(/>/g, "&gt;")
 .replace(/"/g, "&quot;")
 .replace(/'/g, "&#39;");

 const isFullyPaid = !!(q.finalPaidAt) || q.paymentStatus === "paid_in_full";
 const isDepositPaid = !!(q.depositPaidAt) || q.paymentStatus === "deposit_paid";
 const totalAmt = Number(q.total || 0);
 const fullPayDoc = requiresFullUpfront(totalAmt);
 // Full-payment (under-threshold) jobs are always total / 0 — ignore any stale or
 // legacy stored split so the printable doc matches the site-wide rule.
 const depositAmt = fullPayDoc ? totalAmt : (Number(q.depositAmount || 0) > 0 ? Number(q.depositAmount) : Number(splitDepositFinal(totalAmt).depositAmount));
 const balanceAmt = fullPayDoc ? 0 : (Number(q.finalAmount || 0) > 0 ? Number(q.finalAmount) : totalAmt * 0.5);

 // Decide what kind of document this print is. Commercial customers
 // pay against an INVOICE (B2B norm: vendor issues invoice, customer
 // pays per terms). Residential customers receive a QUOTATION first
 // and only get an INVOICE / RECEIPT once the job is done.
 //
 // • QUOTATION — pre-deposit, awaiting customer approval
 // • JOB ORDER — residential, deposit cleared, work scheduled
 // • TAX INVOICE — commercial booked-and-onwards, OR any job that
 // has reached the completion / paid stages
 const isCommercialDoc = (q.invoiceType === "commercial");
 const PRE_BOOKING = ['submitted', 'under_review', 'approved', 'deposit_requested'];
 const COMPLETED = ['job_completed', 'completed', 'final_paid', 'closed', 'final_payment_requested', 'awaiting_final_payment'];
 let docType: "QUOTATION" | "JOB ORDER" | "TAX INVOICE" | "DELIVERY ORDER";
 if (isFullyPaid || COMPLETED.includes(q.status)) docType = "TAX INVOICE";
 else if (isCommercialDoc && !PRE_BOOKING.includes(q.status)) docType = "TAX INVOICE";
 else if (!PRE_BOOKING.includes(q.status)) docType = "JOB ORDER";
 else docType = "QUOTATION";
 // A Delivery Order is an explicit, on-demand document the admin prints to get
 // the customer's sign-off that the items / services were delivered and
 // installed. It is a proof-of-delivery / scope doc — no prices, no payment.
 if (forceDocType === "DELIVERY ORDER") docType = "DELIVERY ORDER";
 const isInvoiceDoc = docType === "TAX INVOICE";
 const isDeliveryOrder = docType === "DELIVERY ORDER";

 // Human-friendly status label for the masthead meta row.
 const statusLabel = (() => {
 if (isFullyPaid) return "PAID";
 if (q.status === "final_payment_requested" || q.status === "awaiting_final_payment") return "FINAL PAYMENT DUE";
 if (q.status === "completed" || q.status === "job_completed") return "COMPLETED";
 if (q.status === "closed") return "CLOSED";
 if (isDepositPaid) return "BOOKED · DEPOSIT IN";
 if (q.status === "booked" || q.status === "scheduled" || q.status === "in_progress" || q.status === "at_pickup" || q.status === "in_transit" || q.status === "at_dropoff") return "BOOKED";
 if (q.status === "booking_pending") return "BOOKING PENDING";
 if (q.status === "deposit_requested") return "DEPOSIT REQUESTED";
 if (q.status === "approved") return "APPROVED";
 if (q.status === "under_review") return "UNDER REVIEW";
 if (q.status === "submitted") return "SUBMITTED";
 if (q.status === "cancelled") return "CANCELLED";
 return String(q.status || "—").toUpperCase().replace(/_/g, " ");
 })();
 const termsLabel = isDeliveryOrder ? "Delivery & Acceptance" : isInvoiceDoc ? "Net 30" : (docType === "JOB ORDER" ? (fullPayDoc ? "Paid in Full" : "50% Deposit Paid") : (fullPayDoc ? "Full Payment" : "50% Deposit"));
 // Stable invoice number: TMG-MOJN5PS9 → INV-MOJN5PS9
 const refTail = String(q.referenceNo || "").replace(/^TMG-?/i, "");
 const invoiceNo = `INV-${refTail || q.id}`;
 // Stable delivery-order number: TMG-MOJN5PS9 → DO-MOJN5PS9
 const deliveryOrderNo = `DO-${refTail || q.id}`;
 // The headline reference shown in the masthead / footer depends on the kind
 // of document being printed.
 const docNo = isInvoiceDoc ? invoiceNo : isDeliveryOrder ? deliveryOrderNo : q.referenceNo;
 const issuedDate = isFullyPaid && q.finalPaidAt
 ? new Date(q.finalPaidAt).toLocaleDateString("en-SG", { year: "numeric", month: "long", day: "numeric" })
 : new Date().toLocaleDateString("en-SG", { year: "numeric", month: "long", day: "numeric" });
 // Net 30 payment terms for commercial invoices
 const dueDate = (() => {
 const base = isFullyPaid && q.finalPaidAt ? new Date(q.finalPaidAt) : new Date();
 base.setDate(base.getDate() + 30);
 return base.toLocaleDateString("en-SG", { year: "numeric", month: "long", day: "numeric" });
 })();

 const html = `<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8" />
 <title>${q.referenceNo}</title>
 <style>
 /* === The Moving Guy Pte Ltd — professional invoice / quotation print template === */
 * { box-sizing: border-box; margin: 0; padding: 0; }
 @page { size: A4; margin: 0; }

 :root {
 --ink: #0a0a0a; /* near-black — headings, total */
 --ink-2: #2a2a2a; /* charcoal — body */
 --muted: #6b7280; /* gray-500 — labels */
 --muted-2: #9ca3af; /* gray-400 — small print */
 --line: #e5e7eb; /* gray-200 — dividers */
 --line-2: #d1d5db; /* gray-300 — strong dividers */
 --bg-soft: #fafafa; /* near-white — page tint */
 --bg-soft-2: #f5f5f7; /* very pale — zebra */
 --accent: #0a0a0a; /* charcoal — primary */
 --accent-2: #1f2937; /* gray-800 — secondary */
 --gold: #b08a3e; /* subtle gold accent */
 --green: #047857;
 --green-soft: #ecfdf5;
 --green-line: #6ee7b7;
 --amber: #b45309;
 --amber-soft: #fef3c7;
 --red: #b91c1c;
 --red-soft: #fee2e2;
 }

 html, body { background: #fff; }
 body {
 font-family: 'Inter', 'Helvetica Neue', 'Segoe UI', system-ui, -apple-system, Arial, sans-serif;
 font-size: 10px;
 line-height: 1.6;
 color: var(--ink-2);
 padding: 0;
 -webkit-font-smoothing: antialiased;
 font-feature-settings: 'tnum' 1, 'lnum' 1, 'ss01' 1;
 }

 /* Editorial inner margins — generous side gutters like a real printed
 letter. Everything sits inside this container; no full-bleed bands.
 On screen these stay generous; @media print collapses them so the
 document fits within a single A4 page without spilling. */
 .doc-body { padding: 18mm 16mm 12mm; }

 /* numerical text */
 .num, td.amount, .totals-row span:last-child, .pay-grid dd {
 font-variant-numeric: tabular-nums;
 font-feature-settings: 'tnum' 1;
 }

 /* ── Letterhead ──────────────────────────────────────────────
 Three-column accounting-stationery letterhead inspired by
 classical invoice templates:
 [ TMG ] [ Company name / tagline / address ] [ Doc meta ]
 Left band: big TMG wordmark vertically centered.
 Center: company name (heading), then tracked subtitle, then
 address lines in muted gray with subtle dot separators.
 Right column: document type wordmark, then reference, then
 a stacked key/value meta block (ISSUED / DUE / TERMS / STATUS). */
 .letterhead {
 display: grid;
 grid-template-columns: 56px 1fr auto;
 gap: 22px; align-items: start;
 padding-bottom: 16px;
 border-bottom: 1.5px solid var(--ink);
 margin-bottom: 22px;
 }
 .lh-mark {
 display: flex; align-items: flex-start; justify-content: flex-start;
 padding-top: 2px;
 }
 .lh-mark .wm {
 font-size: 30px; font-weight: 900; color: var(--ink);
 letter-spacing: -0.025em; line-height: 1;
 font-family: 'Inter', 'Helvetica Neue', sans-serif;
 }
 .lh-mark .wm .dot { color: var(--gold); }
 .lh-brand { display: flex; flex-direction: column; min-width: 0; }
 .lh-coname {
 font-size: 12px; font-weight: 700; color: var(--ink);
 letter-spacing: -0.005em; line-height: 1.2;
 }
 .lh-tag {
 font-size: 7.5px; text-transform: uppercase; letter-spacing: 0.32em;
 color: var(--ink-2); font-weight: 700; margin-top: 4px;
 }
 .lh-addr {
 font-size: 8.5px; color: var(--muted); margin-top: 10px; line-height: 1.7;
 }
 .lh-addr strong { color: var(--ink-2); font-weight: 600; }
 .lh-addr .sep { color: var(--muted-2); padding: 0 4px; }
 .lh-addr .nowrap { white-space: nowrap; }

 .lh-doc { text-align: right; min-width: 210px; }
 .lh-doc .type {
 font-size: 22px; font-weight: 300; color: var(--ink);
 letter-spacing: 0.36em; text-transform: uppercase; line-height: 1;
 font-family: 'Inter', 'Helvetica Neue', sans-serif;
 white-space: nowrap;
 }
 /* Longer titles (e.g. "DELIVERY ORDER") get a tighter size so the right
 column never grows wide enough to squeeze the address / phone line. */
 .lh-doc .type.type-long {
 font-size: 18px; letter-spacing: 0.18em;
 }
 .lh-doc .ref-block { margin-top: 10px; }
 .lh-doc .ref-value {
 font-size: 13px; color: var(--ink); font-weight: 700;
 font-family: 'SF Mono', 'Menlo', 'Consolas', monospace;
 letter-spacing: 0; line-height: 1.1;
 }
 .lh-doc .sub-ref {
 font-size: 8.5px; color: var(--muted); margin-top: 3px;
 font-family: 'SF Mono', 'Menlo', 'Consolas', monospace;
 }
 .lh-doc .meta-grid {
 margin-top: 14px; padding-top: 10px;
 border-top: 0.5px solid var(--line-2);
 display: grid; grid-template-columns: auto auto;
 gap: 4px 14px; justify-content: end;
 font-size: 9px; color: var(--ink-2);
 }
 .lh-doc .meta-grid .k {
 color: var(--muted); text-transform: uppercase; letter-spacing: 0.22em;
 font-size: 7px; font-weight: 700; text-align: right; align-self: center;
 }
 .lh-doc .meta-grid .v {
 font-weight: 600; color: var(--ink); font-size: 9px;
 text-align: right; align-self: center;
 }
 .lh-doc .meta-grid .v.status {
 font-family: 'Inter', 'Helvetica Neue', sans-serif;
 text-transform: uppercase; letter-spacing: 0.14em; font-weight: 800;
 font-size: 8.5px;
 }

 /* ── Parties block (Bill To / Job Details) ─────────────────── */
 .parties {
 display: grid; grid-template-columns: 1fr 1fr; gap: 28px;
 margin-bottom: 18px;
 }
 .party { page-break-inside: avoid; break-inside: avoid; }
 .party-label {
 font-size: 7.5px; font-weight: 700; text-transform: uppercase;
 letter-spacing: 0.32em; color: var(--muted);
 margin-bottom: 8px;
 padding-bottom: 6px;
 border-bottom: 1px solid var(--line);
 }
 .party .name {
 font-size: 13px; font-weight: 700; color: var(--ink);
 letter-spacing: -0.01em; margin-bottom: 4px; line-height: 1.3;
 }
 .party p { font-size: 9.5px; line-height: 1.65; color: var(--ink-2); margin: 0; }
 .party .kv { display: flex; gap: 8px; margin-top: 2px; }
 .party .kv .k {
 color: var(--muted); font-weight: 600; min-width: 64px;
 font-size: 8.5px; text-transform: uppercase; letter-spacing: 0.1em;
 padding-top: 1px;
 }
 .party .kv .v { color: var(--ink-2); flex: 1; font-size: 9.5px; }

 /* ── Items table — editorial, hairline rules only ──────────── */
 table.items { width: 100%; border-collapse: collapse; margin-bottom: 12px; }
 table.items thead th {
 font-size: 7.5px; text-transform: uppercase; letter-spacing: 0.22em;
 color: var(--muted); font-weight: 700; text-align: left;
 padding: 8px 0 8px;
 border-bottom: 1px solid var(--ink);
 }
 table.items thead th:nth-child(1) { padding-left: 0; width: auto; }
 table.items thead th:nth-child(2) { width: 50px; text-align: center; padding: 8px 8px; }
 table.items thead th:nth-child(3) { width: 100px; text-align: right; padding: 8px 8px; }
 table.items thead th:nth-child(4) { width: 110px; text-align: right; padding-right: 0; }
 table.items tbody td {
 padding: 11px 0; font-size: 10px; color: var(--ink-2);
 vertical-align: top; border-bottom: 1px solid var(--line);
 }
 table.items tbody td:nth-child(2) { padding: 11px 8px; text-align: center; color: var(--ink); font-weight: 600; }
 table.items tbody td:nth-child(3) { padding: 11px 8px; text-align: right; font-variant-numeric: tabular-nums; }
 table.items tbody td:nth-child(4) { text-align: right; font-variant-numeric: tabular-nums; color: var(--ink); font-weight: 600; padding-right: 0; }
 table.items tbody td:first-child { color: var(--ink); font-weight: 500; padding-left: 0; }
 table.items tbody tr:last-child td { border-bottom: 1px solid var(--ink); }
 table.items tr { page-break-inside: avoid; break-inside: avoid; }
 table.items thead { display: table-header-group; }
 .item-remark { font-size: 8.5px; color: var(--muted); margin-top: 3px; line-height: 1.5; }

 /* ── Totals ────────────────────────────────────────────────── */
 .totals-wrap { display: flex; justify-content: flex-end; margin-bottom: 14px; }
 .totals {
 width: 320px;
 page-break-inside: avoid; break-inside: avoid;
 }
 .totals-row {
 display: flex; justify-content: space-between; align-items: baseline;
 padding: 5px 0; font-size: 10px; color: var(--muted);
 }
 .totals-row .k { color: var(--muted); }
 .totals-row span:last-child { color: var(--ink); font-variant-numeric: tabular-nums; font-weight: 500; }
 .totals-row.grand {
 margin-top: 8px; padding: 12px 0 0;
 border-top: 1px solid var(--ink);
 font-size: 10px; color: var(--ink-2); font-weight: 600;
 text-transform: uppercase; letter-spacing: 0.22em;
 }
 .totals-row.grand .k { color: var(--ink-2); }
 .totals-row.grand span:last-child {
 font-size: 22px; font-weight: 700; color: var(--ink);
 letter-spacing: -0.015em; text-transform: none;
 font-family: 'Inter', 'Helvetica Neue', sans-serif;
 }
 .amount-due {
 margin-top: 14px; padding: 14px 0 0;
 border-top: 3px double var(--ink);
 display: flex; justify-content: space-between; align-items: baseline;
 }
 .amount-due .lbl-wrap { display: flex; flex-direction: column; }
 .amount-due .lbl { font-size: 8px; text-transform: uppercase; letter-spacing: 0.32em; font-weight: 700; color: var(--gold); }
 .amount-due .amt { font-size: 24px; font-weight: 700; font-variant-numeric: tabular-nums; letter-spacing: -0.02em; color: var(--ink); }
 .amount-due .due-date { font-size: 8.5px; color: var(--muted); margin-top: 4px; letter-spacing: 0.06em; }

 .paid-stamp {
 margin-top: 10px; padding: 14px;
 border: 2px solid var(--green-line);
 background: var(--green-soft);
 border-radius: 6px; text-align: center;
 }
 .paid-stamp .big { font-size: 13px; font-weight: 800; letter-spacing: 0.08em; color: var(--green); text-transform: uppercase; }
 .paid-stamp .sub { font-size: 9.5px; color: var(--green); margin-top: 4px; opacity: 0.85; }
 .paid-split { display: flex; gap: 18px; justify-content: center; margin-top: 8px; font-size: 9.5px; color: var(--green); }

 .deposit-note {
 margin-top: 8px; padding: 8px 12px;
 border: 1px solid var(--amber); background: var(--amber-soft);
 border-radius: 6px; display: flex; justify-content: space-between; align-items: center;
 font-size: 10px; color: var(--amber); font-weight: 600;
 }

 /* ── Payment section ───────────────────────────────────────── */
 /* Right column is sized to hold the PayNow QR (frame + label)
 at a real-world 40 mm — the PayNow merchant guideline for
 reliable phone-camera scanning from paper. The 170 px column
 gives the 150 px QR frame + 8 px padding + 1 px borders
 enough room without clipping. */
 .payment-section {
 margin-top: 14px;
 display: grid; grid-template-columns: 1fr 170px; gap: 24px;
 padding-top: 12px;
 border-top: 1px solid var(--line);
 page-break-inside: avoid; break-inside: avoid;
 page-break-before: avoid; break-before: avoid;
 }
 .payment-section h3 {
 font-size: 7.5px; font-weight: 700; text-transform: uppercase;
 letter-spacing: 0.32em; color: var(--muted);
 padding-bottom: 8px; margin-bottom: 10px;
 border-bottom: 1px solid var(--line);
 }
 .pay-grid {
 display: grid; grid-template-columns: 96px 1fr;
 gap: 6px 12px; font-size: 10px;
 }
 .pay-grid dt {
 color: var(--muted); font-weight: 600; text-transform: uppercase;
 font-size: 8px; letter-spacing: 0.16em; align-self: center;
 }
 .pay-grid dd {
 color: var(--ink); font-weight: 500; font-size: 10.5px;
 font-family: 'SF Mono', 'Menlo', 'Consolas', monospace;
 letter-spacing: 0;
 }
 .pay-note {
 margin-top: 12px; padding-top: 10px; border-top: 1px solid var(--line);
 font-size: 9px; color: var(--muted); line-height: 1.65;
 }
 .pay-note strong { color: var(--ink); font-weight: 600; }
 .qr-block { text-align: center; align-self: start; }
 /* PayNow QR — sized at ~40 mm square, the PayNow merchant
 guideline for reliable phone-camera scanning from paper.
 A white background and generous quiet zone (padding) are
 required for scanners to find the finder patterns.
 The source asset is a clean square raster, so object-fit:
 contain + image-rendering: auto give smooth, undistorted
 downscaling that preserves scannability. */
 .qr-block .qr-frame {
 width: 150px; height: 150px; padding: 10px;
 background: #fff; border: 1px solid var(--line);
 box-sizing: content-box; display: inline-block;
 border-radius: 6px;
 }
 .qr-block img {
 width: 150px; height: 150px; display: block;
 background: #fff; margin: 0; padding: 0; border: 0;
 object-fit: contain;
 image-rendering: auto;
 -webkit-print-color-adjust: exact;
 print-color-adjust: exact;
 }
 .qr-block .qr-label {
 font-size: 9px; color: var(--ink); margin-top: 8px;
 font-weight: 800; text-transform: uppercase; letter-spacing: 0.28em;
 }
 .qr-block .qr-sub {
 font-size: 8.5px; color: var(--muted); margin-top: 3px;
 font-weight: 600; letter-spacing: 0.04em;
 }

 /* ── Terms & Conditions ────────────────────────────────────── */
 .tnc {
 margin-top: 12px;
 padding: 8px 12px 9px;
 border: 1px solid var(--line);
 border-radius: 6px;
 page-break-inside: avoid; break-inside: avoid;
 }
 .tnc h3 {
 font-size: 7px; font-weight: 700; text-transform: uppercase;
 letter-spacing: 0.18em; color: var(--muted);
 padding-bottom: 4px; margin-bottom: 5px;
 border-bottom: 1px solid var(--line);
 display: flex; align-items: baseline; gap: 14px; flex-wrap: wrap;
 }
 .tnc h3 .tnc-title { color: var(--ink-2); font-weight: 800; letter-spacing: 0.22em; }
 .tnc h3 .tnc-ref {
 color: var(--ink); font-weight: 700; letter-spacing: 0.06em;
 font-family: 'SF Mono', 'Menlo', 'Consolas', monospace;
 text-transform: none; font-size: 7.5px;
 }
 .tnc h3 .tnc-ref strong { color: var(--ink); font-weight: 800; }
 .tnc h3 .tnc-link { margin-left: auto; color: var(--muted); font-weight: 600; text-transform: none; letter-spacing: 0.02em; }
 .tnc ol {
 padding-left: 11px;
 column-count: 2; column-gap: 14px; column-rule: 1px solid var(--line);
 }
 .tnc li {
 font-size: 6.2px; color: var(--ink-2); line-height: 1.35;
 margin-bottom: 1.5px; break-inside: avoid;
 }
 .tnc li strong { color: var(--ink); font-weight: 600; }

 /* ── Footer ────────────────────────────────────────────────── */
 .footer {
 margin-top: 12px; padding-top: 10px;
 border-top: 1px solid var(--line);
 display: grid; grid-template-columns: 1fr 240px; gap: 20px;
 align-items: flex-end;
 page-break-inside: avoid; break-inside: avoid;
 }
 .thanks {
 font-size: 11px; font-weight: 700; color: var(--ink);
 margin-bottom: 4px; letter-spacing: -0.01em;
 }
 /* Reference subtitle inside the footer block. Ensures any page
 that carries the footer (commonly the last page when content
 breaks across two A4 pages) clearly identifies the document
 it belongs to — quote/invoice number, customer, issue date. */
 .footer-ref {
 font-size: 8.5px; color: var(--ink-2); margin-bottom: 6px;
 font-family: 'SF Mono', 'Menlo', 'Consolas', monospace;
 letter-spacing: 0;
 }
 .footer-ref strong { color: var(--ink); font-weight: 700; }
 .footer p { font-size: 8px; color: var(--muted); line-height: 1.6; }
 .footer a, .tnc a { color: var(--ink-2); text-decoration: underline; }
 .sig-box {
 position: relative;
 border: 1px solid var(--line); border-radius: 6px;
 padding: 10px 14px 10px; background: #fff;
 min-height: 86px;
 display: flex; flex-direction: column; align-items: stretch; justify-content: flex-end;
 overflow: visible;
 }
 .sig-line { height: 30px; border-bottom: 1px solid var(--line-2); margin-bottom: 6px; }
 .sig-label {
 font-size: 8.5px; color: var(--muted); text-align: left;
 font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em;
 line-height: 1.5;
 max-width: 60%;
 }
 .sig-label .sig-name { display: block; color: var(--ink); font-weight: 700; margin-bottom: 1px; letter-spacing: 0.04em; }
 .sig-label.sig-label-center { text-align: center; max-width: 100%; }

 /* Company rubber stamp — slightly rotated, semi-transparent navy ink.
 All fill/stroke is inline SVG attributes (not CSS) because iOS Safari's
 print engine ignores CSS classes inside SVG. */
 .company-stamp {
 position: absolute;
 top: 0px; right: 4px;
 width: 86px; height: 86px;
 transform: rotate(-6deg);
 opacity: 0.88;
 pointer-events: none;
 }
 .company-stamp svg { width: 100%; height: 100%; display: block; overflow: visible; }

 .badge { display: inline-block; padding: 2px 8px; border-radius: 99px; font-size: 8.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; }
 .badge-paid { background: var(--green-soft); color: var(--green); }
 .badge-partial { background: var(--amber-soft); color: var(--amber); }
 .badge-unpaid { background: var(--red-soft); color: var(--red); }
 .badge-status { background: var(--ink); color: #fff; padding: 3px 10px; }

 /* Running header/footer (kept hidden — Safari/Chrome's own
 print chrome already prints the page URL on every page, which
 contains the quote id and provides cross-page identification.
 A custom position:fixed band caused the masthead to be clipped
 in iOS Safari print preview, so we don't use one anymore.) */
 .print-running-header,
 .print-running-footer { display: none !important; }

 @media print {
 /* A4 with comfortable outer margins. The in-body letterhead is
 the only masthead — Safari/Chrome stamp the page URL and page
 numbers in their own print chrome on every page. */
 @page { size: A4; margin: 14mm 12mm 12mm; }
 html, body { padding: 0; margin: 0; }
 body { padding: 0; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
 .doc-body { padding: 0; }
 button { display: none; }

 /* Compress vertical rhythm just for print so a typical invoice fits one A4. */
 .letterhead { padding-bottom: 10px; margin-bottom: 14px; }
 .parties { margin-bottom: 10px; gap: 20px; }
 table.items { margin-bottom: 8px; }
 table.items tbody td { padding: 6px 0; font-size: 9.5px; }
 table.items tbody td:nth-child(2),
 table.items tbody td:nth-child(3) { padding: 6px 8px; }
 .totals-wrap { margin-bottom: 8px; }
 .totals-row { padding: 3px 0; }
 .totals-row.grand { padding-top: 7px; }
 .amount-due { margin-top: 8px; padding-top: 8px; }
 /* Print column wide enough for the 40 mm QR + padding + borders. */
 .payment-section { margin-top: 8px; padding-top: 7px; gap: 18px; grid-template-columns: 1fr 160px; }
 .payment-section h3 { padding-bottom: 4px; margin-bottom: 6px; }
 .pay-grid { gap: 3px 12px; }
 .pay-note { margin-top: 7px; padding-top: 6px; }
 /* PayNow QR at ~40 mm square — PayNow's recommended print
 size for reliable scanning by a customer's phone camera. */
 .qr-block .qr-frame { width: 140px; height: 140px; padding: 8px; }
 .qr-block img { width: 140px; height: 140px; padding: 0; }
 .qr-block .qr-label { margin-top: 6px; font-size: 8.5px; }
 .tnc { margin-top: 7px; padding: 5px 10px 6px; }
 .tnc h3 { padding-bottom: 3px; margin-bottom: 3px; }
 .tnc ol { column-gap: 12px; }
 .tnc li { font-size: 6px; line-height: 1.3; margin-bottom: 0.5px; }
 .footer { margin-top: 7px; padding-top: 6px; gap: 16px; grid-template-columns: 1fr 200px; }
 .footer p { font-size: 7px; line-height: 1.5; }
 .thanks { font-size: 10px; margin-bottom: 3px; }
 .sig-box { min-height: 58px; padding: 6px 10px; }
 .sig-line { height: 16px; margin-bottom: 4px; }
 .sig-label { font-size: 7.5px; }
 .company-stamp { width: 60px; height: 60px; }
 .card, .tnc, .payment-section, .totals, .footer, table.items tr { page-break-inside: avoid; break-inside: avoid; }
 .totals-wrap { page-break-after: avoid; break-after: avoid; }
 .payment-section { page-break-before: avoid; break-before: avoid; }
 .tnc li { break-inside: avoid; }
 thead { display: table-header-group; }
 }
 /* On-screen toolbar — gives the user a clear way back after the print dialog
    closes. Hidden during the actual print so it never appears in the PDF. */
 .print-toolbar {
   position: sticky; top: 0; left: 0; right: 0; z-index: 9999;
   display: flex; align-items: center; justify-content: space-between;
   gap: 10px; padding: 10px 16px;
   background: #0A0A0A; color: #fff;
   font: 600 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
   letter-spacing: 0.08em; text-transform: uppercase;
   box-shadow: 0 1px 0 rgba(255,255,255,0.06);
 }
 .print-toolbar .pt-title { opacity: 0.65; font-size: 10px; letter-spacing: 0.18em; }
 .print-toolbar .pt-actions { display: flex; gap: 8px; }
 .print-toolbar button {
   appearance: none; border: 1px solid rgba(255,255,255,0.25);
   background: transparent; color: #fff;
   padding: 8px 14px; font: inherit;
   cursor: pointer; transition: background 0.15s ease;
 }
 .print-toolbar button:hover { background: rgba(255,255,255,0.10); }
 .print-toolbar button.pt-primary { background: #fff; color: #0A0A0A; border-color: #fff; }
 .print-toolbar button.pt-primary:hover { background: #EBE9E2; }
 @media print { .print-toolbar { display: none !important; } }
 </style>
</head>
<body>
 <div class="print-toolbar" role="toolbar" aria-label="Document toolbar">
   <span class="pt-title">${esc(docType)} · ${esc(q.referenceNo || "")}</span>
   <span class="pt-actions">
     <button type="button" onclick="window.print()">Print / Save PDF</button>
     <button type="button" class="pt-primary" onclick="window.close(); setTimeout(function(){ try{ history.back(); }catch(e){} }, 100);">Close ✕</button>
   </span>
 </div>
 <div class="doc-body">

 <!-- Letterhead — three-column accounting-stationery masthead -->
 <div class="letterhead">
 <div class="lh-mark"><div class="wm">TMG<span class="dot">.</span></div></div>
 <div class="lh-brand">
 <div class="lh-coname">The Moving Guy Pte Ltd</div>
 <div class="lh-tag">Furniture Installation · Singapore</div>
 <div class="lh-addr">
 <strong>UEN 202424156H</strong><span class="sep">·</span>160 Robinson Road #14-04,<br/>
 Singapore 068914<br/>
 <span class="nowrap">+65 8088 0757</span><br/>
 <span class="nowrap">sales@tmginstall.com<span class="sep">·</span>tmginstall.com</span>
 </div>
 </div>
 <div class="lh-doc">
 <div class="type${docType === "DELIVERY ORDER" ? " type-long" : ""}">${docType}</div>
 <div class="ref-block">
 <div class="ref-value">${esc(docNo)}</div>
 ${(isInvoiceDoc || isDeliveryOrder) ? `<div class="sub-ref">Job Ref · ${esc(q.referenceNo)}</div>` : ""}
 </div>
 <div class="meta-grid">
 <div class="k">Issued</div><div class="v">${esc(issuedDate)}</div>
 ${(isInvoiceDoc && !isFullyPaid) ? `<div class="k">Due</div><div class="v">${esc(dueDate)}</div>` : ""}
 <div class="k">Terms</div><div class="v">${esc(termsLabel)}</div>
 <div class="k">Status</div><div class="v status">${esc(statusLabel)}</div>
 </div>
 </div>
 </div>

 ${(() => {
 const isCommercial = (q.invoiceType === "commercial");
 const billingCompanyName = q.billingCompanyName || q.customer?.companyName || "";
 const billingCompanyUen = q.billingCompanyUen || q.customer?.companyUen || "";
 const billingAddress = q.billingAddress || q.customer?.billingAddress || address || "";
 const showCustomerEmail = q.customer?.email && !q.customer.email.includes("@tmginstall.com");
 const escAddr = (v: any) => esc(v).replace(/\n/g, "<br/>");
 const billToHtml = isCommercial
 ? `
 <p class="name">${esc(billingCompanyName || q.customer?.name || "—")}</p>
 ${billingCompanyUen ? `<p class="kv"><span class="k">UEN</span><span class="v">${esc(billingCompanyUen)}</span></p>` : ""}
 ${billingAddress ? `<p class="kv"><span class="k">Address</span><span class="v">${escAddr(billingAddress)}</span></p>` : ""}
 ${q.customer?.name && billingCompanyName ? `<p class="kv" style="margin-top:6px;"><span class="k">Attn</span><span class="v">${esc(q.customer.name)}</span></p>` : ""}
 ${q.customer?.phone ? `<p class="kv"><span class="k">Phone</span><span class="v">${esc(q.customer.phone)}</span></p>` : ""}
 ${showCustomerEmail ? `<p class="kv"><span class="k">Email</span><span class="v">${esc(q.customer.email)}</span></p>` : ""}
 ${q.poNumber ? `<p class="kv" style="margin-top:6px;"><span class="k">PO No.</span><span class="v">${esc(q.poNumber)}</span></p>` : ""}
 `
 : `
 <p class="name">${esc(q.customer?.name || "—")}</p>
 ${billingAddress ? `<p class="kv"><span class="k">Address</span><span class="v">${escAddr(billingAddress)}</span></p>` : ""}
 ${q.customer?.phone ? `<p class="kv"><span class="k">Phone</span><span class="v">${esc(q.customer.phone)}</span></p>` : ""}
 ${showCustomerEmail ? `<p class="kv"><span class="k">Email</span><span class="v">${esc(q.customer.email)}</span></p>` : ""}
 `;
 return `
 <div class="parties">
 <div class="party">
 <div class="party-label">Billed To${isCommercial ? " · Commercial" : ""}</div>
 ${billToHtml}
 </div>
 <div class="party">
 <div class="party-label">Engagement</div>
 <p class="kv"><span class="k">Service At</span><span class="v">${esc(address)}</span></p>
 ${scheduledDate ? `<p class="kv"><span class="k">Scheduled</span><span class="v">${esc(scheduledDate)}${q.timeWindow ? ` · ${esc(q.timeWindow)}` : ""}</span></p>` : ""}
 ${services.length ? `<p class="kv"><span class="k">Services</span><span class="v">${esc(services.join(", "))}</span></p>` : ""}
 ${customerQuotationNote(q) ? `<p class="kv"><span class="k">Notes</span><span class="v">${esc(customerQuotationNote(q))}</span></p>` : ""}
 </div>
 </div>`;
 })()}

 <table class="items">
 <thead>
 <tr>
 <th>Description</th>
 <th>Qty</th>
 ${isDeliveryOrder ? "" : `<th>Unit Price (S$)</th>
 <th>Amount (S$)</th>`}
 </tr>
 </thead>
 <tbody>
 ${items.length > 0
 ? items.map((item: any) => `
 <tr>
 <td>
 ${esc(formatItemDescription(item, items))}
 ${item.remark ? `<div class="item-remark">${esc(item.remark)}</div>` : ""}
 </td>
 <td>${item.quantity}</td>
 ${isDeliveryOrder ? "" : `<td>${Number(item.unitPrice || 0).toFixed(2)}</td>
 <td>${Number(item.subtotal || 0).toFixed(2)}</td>`}
 </tr>`).join("")
 : `<tr><td colspan="${isDeliveryOrder ? 2 : 4}" style="text-align:center;color:#94a3b8;padding:24px;font-style:italic;">No line items</td></tr>`
 }
 </tbody>
 </table>

 ${isDeliveryOrder ? `
 <div style="margin-top:18px;border:1px solid #d1d5db;background:#fafafa;border-radius:4px;padding:12px 14px;">
 <div style="font-size:8.5px;text-transform:uppercase;letter-spacing:0.28em;font-weight:700;color:#6b7280;">Work Completion Confirmation</div>
 <div style="font-size:11px;color:#374151;line-height:1.6;margin-top:6px;">The work listed above has been completed at the service address according to the scope stated for each item. Please check the received scope against this list and sign below to acknowledge completion in good order.</div>
 </div>
 ` : `
 <div class="totals-wrap">
 <div class="totals">
 ${Number(q.discount || 0) > 0 ? `<div class="totals-row"><span class="k">Discount</span><span>−S$${Number(q.discount).toFixed(2)}</span></div>` : ""}
 ${(Number(q.transportFee || 0) - Number((q as any).volumetricFee || 0)) > 0 ? `<div class="totals-row"><span class="k">Transport</span><span>S$${(Number(q.transportFee || 0) - Number((q as any).volumetricFee || 0)).toFixed(2)}</span></div>` : ""}
 ${Number((q as any).volumetricFee || 0) > 0 ? `<div class="totals-row"><span class="k">Volumetric Handling</span><span>S$${Number((q as any).volumetricFee).toFixed(2)}</span></div>` : ""}
 ${Number(q.promoDiscount || 0) > 0 ? `<div class="totals-row"><span class="k">Promo · ${esc(q.promoCode || "")}</span><span>−S$${Number(q.promoDiscount).toFixed(2)}</span></div>` : ""}
 ${Number((q as any).goodwillDiscount || 0) > 0 ? `<div class="totals-row"><span class="k">Goodwill discount${(q as any).goodwillReason ? ` · ${esc((q as any).goodwillReason)}` : ""}</span><span>−S$${Number((q as any).goodwillDiscount).toFixed(2)}</span></div>` : ""}
 ${(q as any).secondDayContinuation ? `<div class="totals-row"><span class="k">Second-day continuation${Number((q as any).secondDayHours) > 0 ? ` · ${Number((q as any).secondDayCrewSize) || PricingConfig.secondDay.defaultCrewSize} men × ${Number((q as any).secondDayHours)}h` : ""}</span><span>S$${calcSecondDayContinuation(!!(q as any).secondDayContinuation, (q as any).secondDayHours || 0, (q as any).secondDayCrewSize).fee.toFixed(2)}</span></div>` : ""}
 <div class="totals-row grand"><span class="k">Total</span><span>S$${Number(q.total || 0).toFixed(2)}</span></div>
 ${isFullyPaid ? `
 <div class="paid-stamp">
 <div class="big">Paid in Full</div>
 <div class="sub">Both deposit and balance received. Thank you for your business.</div>
 <div class="paid-split">
 <span>Deposit · <strong>S$${depositAmt.toFixed(2)}</strong></span>
 <span>Balance · <strong>S$${balanceAmt.toFixed(2)}</strong></span>
 </div>
 </div>` : isDepositPaid ? `
 <div class="totals-row" style="margin-top:6px;color:var(--green);">
 <span class="k" style="color:var(--green);">Deposit Received</span><span style="color:var(--green);">−S$${depositAmt.toFixed(2)}</span>
 </div>
 <div class="amount-due">
 <div class="lbl-wrap">
 <div class="lbl">Balance Due</div>
 <div class="due-date">on completion${isInvoiceDoc && !isFullyPaid ? ` · by ${esc(dueDate)}` : ""}</div>
 </div>
 <div class="amt">S$${balanceAmt.toFixed(2)}</div>
 </div>` : `
 <div class="amount-due">
 <div class="lbl-wrap">
 <div class="lbl">${isInvoiceDoc ? "Amount Due" : "Total Payable"}</div>
 ${isInvoiceDoc ? `<div class="due-date">By ${esc(dueDate)} · Net 30</div>` : `<div class="due-date">${fullPayDoc ? "Full payment to confirm booking" : "50% deposit to confirm booking"}</div>`}
 </div>
 <div class="amt">S$${Number(q.total || 0).toFixed(2)}</div>
 </div>`}
 </div>
 </div>

 <!-- Payment Details -->
 ${isFullyPaid ? "" : `
 <div class="payment-section">
 <div class="payment-details">
 <h3>Payment Details${isDepositPaid ? ' — Balance Due' : ''}</h3>
 <dl class="pay-grid">
 <dt>Bank</dt><dd>OCBC Bank</dd>
 <dt>Account No.</dt><dd>596-795617-001</dd>
 <dt>Account Name</dt><dd>The Moving Guy Pte. Ltd.</dd>
 <dt>Currency</dt><dd>SGD</dd>
 <dt>PayNow (UEN)</dt><dd>202424156H</dd>
 </dl>
 <div class="pay-note">
 Please include the reference <strong>${esc(isInvoiceDoc ? invoiceNo : q.referenceNo)}</strong> in your payment remarks.
 ${isInvoiceDoc ? `Email remittance advice to <strong>sales@tmginstall.com</strong>.` : ""}
 </div>
 </div>
 <div class="qr-block">
 <div class="qr-frame"><img src="${window.location.origin}/paynow-qr.png" alt="PayNow QR Code" width="150" height="150" /></div>
 <div class="qr-label">Scan to Pay · PayNow</div>
 <div class="qr-sub">UEN 202424156H</div>
 </div>
 </div>`}
 `}

 <!-- Included on-site time (relocation quotes / job orders only) -->
 ${(!isInvoiceDoc && !isDeliveryOrder && hasRelocation) ? `
 <div style="margin-top:18px;border:1px solid #e5e7eb;background:#f9fafb;border-radius:4px;padding:10px 12px;">
 <div style="font-size:11px;color:#374151;line-height:1.5;">
 <strong>Included on-site time:</strong> ${printSchedule.crewSize} mover${printSchedule.crewSize !== 1 ? "s" : ""} × ${fmtHrs(printSchedule.scheduledHours)} hour${fmtHrs(printSchedule.scheduledHours) === "1" ? "" : "s"} = <strong>${printManHours} man-hours</strong>.
 </div>
 <div style="font-size:11px;color:#6b7280;line-height:1.5;margin-top:2px;">
 Extra time beyond this is $${printSchedule.overtimePerManPerHour} per mover, per hour (= $${printCrewRate}/hour for your ${printSchedule.crewSize}-person crew), billed in ${printSchedule.blockMinutes}-minute blocks.
 </div>
 </div>` : ""}

 <!-- Terms & Conditions -->
 <div class="tnc">
 <h3>
 <span class="tnc-title">Terms &amp; Conditions</span>
 <span class="tnc-ref">${isInvoiceDoc ? "Invoice" : isDeliveryOrder ? "Delivery Order" : "Quotation"} <strong>${esc(docNo)}</strong>${(isInvoiceDoc || isDeliveryOrder) ? ` · Job ${esc(q.referenceNo)}` : ""}</span>
 <span class="tnc-link">Full version: <a href="https://tmginstall.com/terms" target="_blank">tmginstall.com/terms</a></span>
 </h3>
 <ol>
 ${isDeliveryOrder ? `
 <li>This Delivery Order records completion of the work listed above according to each item’s stated scope at the service address.</li>
 <li>Please inspect all items on delivery. By signing below, the customer acknowledges receipt and that the work was completed in good order.</li>
 <li>Any defect or shortfall must be reported in writing within <strong>7 days</strong> of the delivery date shown above.</li>
 <li>The Moving Guy Pte Ltd is not liable for pre-existing damage to furniture, walls, or fixtures.</li>
 <li>This document is a delivery acknowledgement only — it is not a tax invoice or a receipt.</li>
 ` : isInvoiceDoc ? `
 <li><strong>Payment Terms:</strong> Net 30 days from invoice date${isFullyPaid ? "" : ` — payment due by <strong>${esc(dueDate)}</strong>`}. Please quote the invoice number <strong>${esc(invoiceNo)}</strong> in the payment remarks.</li>
 <li>Late payments may incur a <strong>1.5% per month</strong> administrative charge on the outstanding balance.</li>
 <li>Goods and services described above have been delivered / completed as agreed. Any defect claim must be raised in writing within <strong>7 days</strong> of completion.</li>
 <li><strong>On-site Charges:</strong> Any additional drilling requested on site is <strong>S$5 per hole</strong>. Wall-anchor / fastening hardware supplied on site is charged at cost.${hasRelocation ? ` For relocation work, extra labour beyond the agreed scope is <strong>S$50/hr per crew member</strong>.` : ""}</li>
 <li>Transport fee applies for locations outside central Singapore or where lift access is unavailable. Long-carry &gt; 30 m or stairs without lift access incurs an additional fee, quoted on site before work proceeds.</li>
 <li>The Moving Guy Pte Ltd is not liable for pre-existing damage to furniture, walls, or fixtures.</li>
 <li>Any additional work not stated in this invoice has been agreed upon separately in writing.</li>
 <li>All prices are in Singapore Dollars (SGD) and are <strong>not subject to GST</strong> (The Moving Guy Pte Ltd is not GST-registered).</li>
 <li>By making payment, the customer is deemed to have read and accepted our full Terms &amp; Conditions at <a href="https://tmginstall.com/terms" target="_blank">tmginstall.com/terms</a>.</li>
 ` : `
 ${quoteTerms.map((t) => `<li><strong>${esc(t.title)}.</strong> ${esc(t.body)}</li>`).join("\n ")}
 <li>All prices are in Singapore Dollars (SGD) and are <strong>not subject to GST</strong> (we are not GST-registered).</li>
 `}
 </ol>
 </div>

 <div class="footer">
 <div>
 <div class="thanks">${isInvoiceDoc ? "Thank you for your business." : isDeliveryOrder ? "Thank you — please retain this for your records." : "We appreciate the opportunity to quote for you."}</div>
 <div class="footer-ref">${isInvoiceDoc ? "Invoice" : isDeliveryOrder ? "Delivery Order" : "Quotation"} <strong>${esc(docNo)}</strong>${(isInvoiceDoc || isDeliveryOrder) ? ` · Job ${esc(q.referenceNo)}` : ""} · For ${esc(q.customer?.name || "—")} · Issued ${esc(issuedDate)}</div>
 <p>Generated ${esc(new Date().toLocaleDateString("en-SG", { year: "numeric", month: "long", day: "numeric" }))} · The Moving Guy Pte Ltd · UEN 202424156H · Vehicle GBM550L<br/>+65 8088 0757 · sales@tmginstall.com · <a href="https://tmginstall.com" target="_blank">tmginstall.com</a> · Terms: <a href="https://tmginstall.com/terms" target="_blank">tmginstall.com/terms</a></p>
 </div>
 <div class="sig-box">
 ${isInvoiceDoc ? `
 <div class="company-stamp" aria-hidden="true">
 <svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
 <defs>
 <!-- Top text path: r=42, sweep=1 (clockwise via top). Glyphs extend
 OUTWARD from the path, sitting in the band r=42..r=49.5. -->
 <path id="tmgStampTopArc" d="M 18,60 A 42,42 0 0 1 102,60" fill="none" />
 <!-- Bottom text path: r=53, sweep=0 = counterclockwise via BOTTOM
 (sweep=1 wrongly went via top, putting text upside-down on top).
 Going left-to-right via bottom, text glyphs sit ABOVE the path
 = toward center, occupying band r=47..r=53. Reads upright. -->
 <path id="tmgStampBottomArc" d="M 7,60 A 53,53 0 0 0 113,60" fill="none" />
 </defs>
 <!-- Outer thick ring -->
 <circle cx="60" cy="60" r="56" fill="none" stroke="#15407a" stroke-width="2.4" />
 <!-- Inner thin ring -->
 <circle cx="60" cy="60" r="39" fill="none" stroke="#15407a" stroke-width="0.9" />
 <!-- Top curved text: company name -->
 <text fill="#15407a" font-family="Helvetica, Arial, sans-serif" font-weight="700" font-size="7.4" letter-spacing="1.3">
 <textPath xlink:href="#tmgStampTopArc" href="#tmgStampTopArc" startOffset="50%" text-anchor="middle">
 THE MOVING GUY PTE LTD
 </textPath>
 </text>
 <!-- Bottom curved text: UEN \u00B7 SINGAPORE -->
 <text fill="#15407a" font-family="Helvetica, Arial, sans-serif" font-weight="700" font-size="6" letter-spacing="1.5">
 <textPath xlink:href="#tmgStampBottomArc" href="#tmgStampBottomArc" startOffset="50%" text-anchor="middle">
 UEN 202424156H \u00B7 SINGAPORE
 </textPath>
 </text>
 <!-- Center block: thin rules safely inside inner ring r=39 -->
 <line x1="32" y1="55" x2="88" y2="55" stroke="#15407a" stroke-width="0.6" />
 <line x1="32" y1="76" x2="88" y2="76" stroke="#15407a" stroke-width="0.6" />
 <text x="60" y="65" text-anchor="middle" fill="#15407a" font-family="Helvetica, Arial, sans-serif" font-weight="800" font-size="8.6" letter-spacing="1.3">AUTHORISED</text>
 <text x="60" y="73" text-anchor="middle" fill="#15407a" font-family="Helvetica, Arial, sans-serif" font-weight="600" font-size="5.4" letter-spacing="1.4">SIGNATORY</text>
 </svg>
 </div>
 <div class="sig-line"></div>
 <div class="sig-label">
 <span class="sig-name">The Moving Guy Pte Ltd</span>Authorised Signatory
 </div>` : `
 <div class="sig-line"></div>
 <div class="sig-label sig-label-center">
 <span class="sig-name">${isDeliveryOrder ? "Received in good order by" : "Customer"}</span>${isDeliveryOrder ? "Name · Signature · Date" : "Signature &amp; Date"}
 </div>`}
 </div>
 </div>

 </div><!-- /.doc-body -->

 <script>window.onload = function() { window.print(); }</script>
</body>
</html>`;

 const win = window.open("", "_blank", "width=900,height=700");
 if (win) {
 win.document.write(html);
 win.document.close();
 }
 };

   if(isEditing)return (
    <div className="min-h-screen pt-14 pb-56 lg:pb-36 lg:pl-56 bg-[#F5F4F0]">
      <div className="max-w-6xl mx-auto p-3 sm:p-6">
        <div className="mb-2 flex items-center justify-between gap-3">
          <button disabled={editQuote.isPending} onClick={()=>{if(!editDirty||window.confirm("Discard unsaved quotation changes?"))setIsEditing(false);}} className="min-h-10 text-sm underline">Back to quote</button>
          <span className="text-xs text-zinc-500">Item and price changes</span>
        </div>
        <details className="mb-2 rounded border border-zinc-200 bg-white p-2 text-xs text-zinc-600">
          <summary className="cursor-pointer">Appointment stays unchanged</summary>
          <p className="mt-2">{quote.scheduledAt?formatSingaporeDay(quote.scheduledAt,"dd MMM yyyy"):"Not confirmed"} {quote.timeWindow||""}. Manage appointment separately after saving or cancelling.</p>
        </details>
        {quote.termsAcceptedAt&&<p className="mb-2 border-l-4 border-amber-500 bg-amber-50 p-2 text-xs">Changes to agreed details or price need customer reacceptance. Existing verified payments and appointments are retained.</p>}
        <QuoteEditingWorkspace reference={quote.referenceNo||String(id)} customer={editCustomer} onCustomerChange={setEditCustomer}
 quoteData={editQuoteData} onQuoteDataChange={setEditQuoteData} items={editItems} onItemChange={updateEditItem}
 rateReasonItems={rateReasonItems} rateReasons={rateReasons} onRateReasonChange={(key,value)=>{
  setRateReasons(current=>({...current,[key]:value}));
  const index=editItems.findIndex((item,i)=>String(item.id??i)===key);
  if(index>=0)setEditFieldErrors(current=>{
   const relevant=[`items.${index}.rateReason`,`rateReasons.${index}`];
   if(!relevant.some(field=>field in current))return current;
   const remaining=Object.fromEntries(Object.entries(current).filter(([field])=>!relevant.includes(field)));
   if(!Object.keys(remaining).length)setEditError("");
   return remaining;
  });
 }}
 onAddItem={addEditItem} onRemoveItem={removeEditItem} catalog={adminCatalog||[]} onCatalogSelect={applyCatalogToItem}
 totals={{subtotal:editSubtotal,discount:editDiscount,promoDiscount:editPromoDiscount,goodwill:editGoodwillDiscount,
 transport:editTransport,secondDay:editSecondDay,additionalTrip:editAdditionalTrip,afterOffice:editAfterOffice,total:editTotal,paid:paidSoFar}}
 pending={editQuote.isPending} sending={editQuote.isPending} calculating={editCalcLoading} dirty={editDirty} totalIsPending={isReviewQuotation(quote)} transportIsPending={editTransportPending} error={editError} sendError={workspaceSendError} fieldErrors={editFieldErrors} requirements={workspaceRequirements} sendStatusMessage={deliveryStatusMessage} deliveryOutcome={currentDelivery} sendLocked={sendLocked} sendRetryAllowed={sendRetryAllowed}
 deliveryContext={workspaceContextQuery.data} deliveryContextLoading={workspaceContextQuery.isLoading} deliveryContextError={workspaceContextQuery.isError}
 onSave={()=>handleSaveEdit("save")} onSaveAndSend={()=>handleSaveEdit("send")}
 surchargeAck={surchargeAck} onSurchargeAckChange={setSurchargeAck} surchargeChanged={surchargeChanged}
 reviewPanel={<><QuoteWorkspaceReview requirements={workspaceRequirements} existingFacts={existingWorkspaceFactKeys} facts={{
 ...workspaceFacts,customerName:editCustomer.name||"",jobAddress:editQuoteData.serviceAddress||editQuoteData.pickupAddress||"",
 toAddress:editingRelocation?destinationEditStop?.address||"":editQuoteData.dropoffAddress||"",floorLevel:pickupEditStop?.floor||"",
 hasLift:pickupEditStop?.hasLift??workspaceFacts.hasLift??null,
 destinationFloor:destinationEditStop?.floor||"",
 destinationLift:destinationEditStop?.hasLift??workspaceFacts.destinationLift??null,
 }} onFactsChange={updateWorkspaceFact}
 decisions={workspaceDecisions} onDecisionChange={(field,value)=>setWorkspaceDecisions(current=>({...current,[field]:value}))}
 transportConfirmed={transportConfirmed} onTransportConfirmedChange={setTransportConfirmed} transportFee={editQuoteData.transportFee}/>
 {workspaceContextQuery.isError&&<div role="alert" className="flex items-center justify-between gap-3 border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900">
 <span>Workspace delivery context could not be loaded. Draft saving remains available; sending stays disabled.</span>
 <button type="button" onClick={()=>workspaceContextQuery.refetch()} className="shrink-0 font-semibold underline">Retry context</button>
 </div>}</>}
 historicalNotes={hasGeneratedReviewNotes(quote)?quote.notes||"":""}
 currentQuoteUrl={`/admin/quotes/${id}`}
 pdfPreviewUrl={`/api/quotes/${quote.id}/quotation.pdf?ref=${encodeURIComponent(quote.referenceNo||"")}&version=${quote.version}`}
 logistics={editItems.some(i=>i.serviceType==="relocate")?<div className="space-y-3" data-testid="edit-logistics">
 <h3 className="font-semibold">Relocation stops and logistics</h3>
 <p className="text-sm text-zinc-500">Saved line rates stay as entered. Catalog volume changes are reconciled when saving.</p>
 {editStops.map(stop=><div key={stop.id} className="border p-3 space-y-2">
 <label className="block text-sm">{stop.kind==="pickup"?"Pickup":"Drop-off"} address
 <input id={`workspace-stop-${stop.id}-address`} aria-label={`${stop.kind} address ${stop.id}`} className="w-full border p-2" value={stop.address} onChange={e=>updateEditStop(stop.id,"address",e.target.value)}/></label>
 {((stop.kind==="pickup"&&stop.id===pickupEditStop?.id)||(stop.kind==="dropoff"&&stop.id===destinationEditStop?.id))&&stopRequirementMarkup(stop,"address")}
 <div className="flex flex-wrap gap-2"><input aria-label={`Postal code ${stop.id}`} placeholder="Postal code" className="border p-2 w-28" value={stop.postalCode} onChange={e=>updateEditStop(stop.id,"postalCode",e.target.value)}/>
 <input id={`workspace-stop-${stop.id}-floor`} aria-label={`Floor ${stop.id}`} placeholder="Floor" className="border p-2 w-24" value={stop.floor} onChange={e=>updateEditStop(stop.id,"floor",e.target.value)}/>
 <select id={`workspace-stop-${stop.id}-lift`} aria-label={`Lift ${stop.id}`} value={stop.hasLift==null?"unknown":String(stop.hasLift)} onChange={e=>updateEditStop(stop.id,"hasLift",e.target.value==="unknown"?null:e.target.value==="true")} className="border p-2">
 <option value="unknown">Lift not specified</option><option value="true">Lift available</option><option value="false">No lift</option></select>
 <button onClick={()=>removeEditStop(stop.id)} className="text-red-700 underline">Remove stop</button></div>
 {((stop.kind==="pickup"&&stop.id===pickupEditStop?.id)||(stop.kind==="dropoff"&&stop.id===destinationEditStop?.id))&&<div className="space-y-1">{stopRequirementMarkup(stop,"floor")}{stopRequirementMarkup(stop,"hasLift")}</div>}
 </div>)}
 <div className="flex flex-wrap gap-3"><button onClick={()=>addEditStop("pickup")} className="underline">Add pickup</button><button onClick={()=>addEditStop("dropoff")} className="underline">Add drop-off</button>
 <button disabled={editCalcLoading} onClick={calcEditPrice} className="border px-3 py-2">{editCalcLoading?"Calculating…":"Calculate logistics"}</button></div>
 {editCalcError&&<p role="alert" className="text-red-700">{editCalcError}</p>}
 <p className="text-xs text-zinc-500">Distance: {editDistanceKm??"not calculated"} km · Volume: {editTotalVolume||"catalog"} m³</p>
 </div>:undefined}/>
 </div></div>);
 return (
 <div className="min-h-screen pt-14 pb-32 lg:pb-16 lg:pl-56 bg-[#F5F4F0] overflow-x-hidden relative">

 {/* Sticky Header */}
 <div className="sticky top-14 z-30 bg-white border-b border-zinc-200 px-3 sm:px-6 py-2 sm:py-3">
 <div className="max-w-5xl mx-auto flex items-center justify-between gap-2">
 <div className="flex items-center gap-2 min-w-0 flex-1">
 <Link
 href="/admin"
 data-testid="link-back-to-admin"
 className="inline-flex items-center justify-center w-10 h-10 shrink-0 rounded-lg text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100 transition-colors"
 >
 <ArrowLeft className="w-4 h-4" />
 </Link>
 <div className="min-w-0 flex-1">
 <div className="flex items-center gap-1.5 mb-0.5 flex-wrap">
 <span className="text-[11px] text-zinc-500 font-mono tracking-wider">{quote.referenceNo}</span>
 <StatusBadge status={quote.superseded ? "superseded" : quote.status} />
 {!TERMINAL_STATUSES_UI.includes(quote.status) && isFetching && (
 <Loader2 className="w-3 h-3 text-zinc-400 animate-spin" />
 )}
 </div>
 <h1 className="text-sm sm:text-base font-semibold text-zinc-900 truncate">{quote.ggv?.jobNo || quote.customer?.name}</h1>
 </div>
 </div>

 {/* Action toolbar — Edit always shown first when allowed so it remains visible
 on narrow iOS screens. Touch targets sized h-10 to meet mobile guidelines. */}
 <div className="flex items-center gap-1.5 shrink-0">
 {canEdit && !isEditing && quote.status !== 'cancelled' && (
 <button
 onClick={handleStartEdit}
 disabled={workspaceContextQuery.isLoading}
 data-testid="button-edit-quote"
 title="Edit quote"
 aria-label="Edit quote"
 className="inline-flex items-center justify-center gap-1.5 h-10 w-10 sm:w-auto sm:px-3 rounded-lg bg-white border border-zinc-300 text-zinc-700 hover:bg-zinc-50 active:bg-zinc-100 text-sm font-medium transition-colors"
 >
 <Edit2 className="w-4 h-4" />
 <span className="hidden sm:inline">Edit</span>
 </button>
 )}
 {['completed', 'final_payment_requested', 'final_paid', 'closed'].includes(quote.status) && (
 <button
 data-testid="button-reopen-job-header"
 disabled={reopenJob.isPending}
 onClick={() => {
 const reason = prompt("Reason for reopening (optional):");
 if (reason === null) return;
 reopenJob.mutate(reason || undefined);
 }}
 title="Reopen job"
 aria-label="Reopen job"
 className="inline-flex items-center justify-center gap-1.5 h-10 w-10 sm:w-auto sm:px-3 rounded-lg bg-amber-50 border border-amber-300 text-amber-700 hover:bg-amber-100 active:bg-amber-200 text-sm font-medium transition-colors disabled:opacity-50"
 >
 {reopenJob.isPending ? (
 <Loader2 className="w-4 h-4 animate-spin" />
 ) : (
 <RotateCcw className="w-4 h-4" />
 )}
 <span className="hidden sm:inline">Reopen</span>
 </button>
 )}
 {quote.status !== "cancelled" && (quote.finalPaidAt || quote.paymentStatus === "paid_in_full" || ["closed", "final_paid"].includes(quote.status)) && (
 <button
 onClick={() => setShowInvoiceDialog(true)}
 data-testid="button-send-invoice"
 title="Send invoice / receipt to customer"
 aria-label="Send invoice"
 className="inline-flex items-center justify-center gap-1.5 h-10 w-10 sm:w-auto sm:px-3 rounded-lg bg-emerald-50 border border-emerald-300 text-emerald-700 hover:bg-emerald-100 active:bg-emerald-200 text-sm font-medium transition-colors"
 >
 <FileText className="w-4 h-4" />
 <span className="hidden sm:inline">Invoice</span>
 </button>
 )}
 <button
 onClick={() => handlePrintQuote()}
 data-testid="button-print-quote"
 title="Print / Download PDF"
 aria-label="Print"
 className="inline-flex items-center justify-center gap-1.5 h-10 w-10 sm:w-auto sm:px-3 rounded-lg bg-white border border-zinc-300 text-zinc-700 hover:bg-zinc-50 active:bg-zinc-100 text-sm font-medium transition-colors"
 >
 <Printer className="w-4 h-4" />
 <span className="hidden sm:inline">Print</span>
 </button>
 {!isReviewQuotation(quote) && quote.invoiceType!=="commercial" && Number(quote.total)>0 && !quote.superseded && quote.status!=="cancelled" && (
 <a href={`/api/quotes/${quote.id}/quotation.pdf?ref=${encodeURIComponent(quote.referenceNo)}&version=${quote.version}`}
 data-testid="download-quotation-pdf" title="Download saved quotation PDF" aria-label="Download quotation PDF"
 className="inline-flex items-center justify-center gap-1.5 h-10 w-10 sm:w-auto sm:px-3 rounded-lg bg-white border border-zinc-300 text-zinc-700 text-sm font-medium">
 <FileText className="w-4 h-4" /> <span className="hidden sm:inline">Quote PDF</span>
 </a>
 )}
 <button
 onClick={() => handlePrintQuote("DELIVERY ORDER")}
 data-testid="button-delivery-order"
 title="Print / Download Delivery Order (no prices)"
 aria-label="Delivery Order"
 className="inline-flex items-center justify-center gap-1.5 h-10 w-10 sm:w-auto sm:px-3 rounded-lg bg-white border border-zinc-300 text-zinc-700 hover:bg-zinc-50 active:bg-zinc-100 text-sm font-medium transition-colors"
 >
 <Truck className="w-4 h-4" />
 <span className="hidden sm:inline">DO</span>
 </button>
 <button
 onClick={() => setShowDeleteConfirm(true)}
 data-testid="button-delete-quote"
 title="Delete quote"
 aria-label="Delete quote"
 className="inline-flex items-center justify-center gap-1.5 h-10 w-10 sm:w-auto sm:px-3 rounded-lg bg-white border border-zinc-300 text-red-600 hover:bg-red-50 active:bg-red-100 text-sm font-medium transition-colors"
 >
 <Trash2 className="w-4 h-4" />
 <span className="hidden sm:inline">Delete</span>
 </button>
 </div>
 </div>
 </div>

 {/* Main Content */}
 <div className="max-w-5xl mx-auto px-3 sm:px-6 py-4 sm:py-6">
 {lastQuoteSaved&&<p role="status" data-testid="quote-saved-status" className="mb-4 border-l-4 border-green-600 bg-green-50 p-3 text-sm">Quote saved at {lastQuoteSaved}. No customer message sent; appointment unchanged.</p>}
 <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-4 sm:gap-6">
 
 {/* Left Column */}
 <div className="space-y-6">
 
 {/* Customer & Service Info */}
 <div className="bg-white border border-zinc-200 rounded-none overflow-hidden">
 <div className="px-5 py-4 border-b border-zinc-100">
 <h2 className="text-sm font-semibold text-zinc-900 flex items-center gap-2">
 <MapPin className="w-4 h-4 text-zinc-400" /> Details
 </h2>
 </div>
 
 {isEditing ? (
 <div className="p-5 space-y-4">
 <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
 <div>
 <label className="text-xs font-medium text-zinc-500 mb-1.5 block">Name</label>
 <input value={editCustomer.name || ''} onChange={e => setEditCustomer({ ...editCustomer, name: e.target.value })}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="input-edit-name" />
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-500 mb-1.5 block">Email</label>
 <input value={editCustomer.email || ''} onChange={e => setEditCustomer({ ...editCustomer, email: e.target.value })}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="input-edit-email" />
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-500 mb-1.5 block">Phone</label>
 <input value={editCustomer.phone || ''} onChange={e => setEditCustomer({ ...editCustomer, phone: e.target.value })}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="input-edit-phone" />
 </div>
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-500 mb-1.5 block">Service Address</label>
 <input value={editQuoteData.serviceAddress || ''} onChange={e => setEditQuoteData({ ...editQuoteData, serviceAddress: e.target.value })}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 data-testid="input-edit-address" />
 </div>
 {/* ── Multi-stop relocation builder (additive) ── */}
 <div className="border border-zinc-200 rounded-lg p-4 space-y-4 bg-zinc-50/50">
 <div className="flex items-center gap-2">
 <Route className="w-4 h-4 text-zinc-500" />
 <span className="text-xs font-semibold uppercase tracking-wider text-zinc-700">Pick-up & Drop-off Stops</span>
 </div>

 {/* Pick-up stops */}
 <div className="space-y-3">
 {editPickupStops.map((s, idx) => (
 <div key={s.id} className="rounded-lg border border-zinc-200 bg-white p-3 space-y-2" data-testid={`edit-stop-pickup-${idx}`}>
 <div className="flex items-center gap-2">
 <div className="w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
 <span className="text-[10px] font-bold text-blue-600">{idx + 1}</span>
 </div>
 <span className="text-xs font-semibold text-zinc-600 uppercase tracking-wide">Pick-up {idx + 1}</span>
 {editPickupStops.length > 1 && (
 <button type="button" data-testid={`button-edit-remove-pickup-${idx}`} onClick={() => removeEditStop(s.id)}
 className="ml-auto w-7 h-7 flex items-center justify-center text-zinc-400 hover:text-red-500 hover:bg-red-50 rounded-md transition-colors">
 <Trash2 className="w-3.5 h-3.5" />
 </button>
 )}
 </div>
 <input value={s.address} onChange={e => updateEditStop(s.id, 'address', e.target.value)}
 data-testid={`input-edit-pickup-address-${idx}`} placeholder="Blk 123 Tampines St 86, Singapore 520123"
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 <div className="grid grid-cols-2 gap-2">
 <input value={s.floor} onChange={e => updateEditStop(s.id, 'floor', e.target.value)}
 placeholder="Floor / Unit e.g. #04-56"
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 <select value={s.hasLift === null ? '' : s.hasLift ? 'yes' : 'no'}
 onChange={e => updateEditStop(s.id, 'hasLift', e.target.value === '' ? null : e.target.value === 'yes')}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-700 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]">
 <option value="">Lift? —</option>
 <option value="yes">Lift available</option>
 <option value="no">No lift</option>
 </select>
 </div>
 </div>
 ))}
 <button type="button" data-testid="button-edit-add-pickup" onClick={() => addEditStop('pickup')}
 className="flex items-center gap-1.5 text-xs text-blue-600 hover:text-blue-700 font-medium">
 <Plus className="w-3.5 h-3.5" /> Add pick-up stop
 </button>
 </div>

 <div className="flex items-center justify-center text-zinc-400">
 <ArrowRight className="w-4 h-4" />
 </div>

 {/* Drop-off stops */}
 <div className="space-y-3">
 {editDropoffStops.map((s, idx) => (
 <div key={s.id} className="rounded-lg border border-zinc-200 bg-white p-3 space-y-2" data-testid={`edit-stop-dropoff-${idx}`}>
 <div className="flex items-center gap-2">
 <div className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center shrink-0">
 <span className="text-[10px] font-bold text-green-600">{String.fromCharCode(65 + idx)}</span>
 </div>
 <span className="text-xs font-semibold text-zinc-600 uppercase tracking-wide">Drop-off {String.fromCharCode(65 + idx)}</span>
 {editDropoffStops.length > 1 && (
 <button type="button" data-testid={`button-edit-remove-dropoff-${idx}`} onClick={() => removeEditStop(s.id)}
 className="ml-auto w-7 h-7 flex items-center justify-center text-zinc-400 hover:text-red-500 hover:bg-red-50 rounded-md transition-colors">
 <Trash2 className="w-3.5 h-3.5" />
 </button>
 )}
 </div>
 <input value={s.address} onChange={e => updateEditStop(s.id, 'address', e.target.value)}
 data-testid={`input-edit-dropoff-address-${idx}`} placeholder="Blk 456 Jurong West Ave 3, Singapore 640456"
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 <div className="grid grid-cols-2 gap-2">
 <input value={s.floor} onChange={e => updateEditStop(s.id, 'floor', e.target.value)}
 placeholder="Floor / Unit e.g. #12-88"
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 <select value={s.hasLift === null ? '' : s.hasLift ? 'yes' : 'no'}
 onChange={e => updateEditStop(s.id, 'hasLift', e.target.value === '' ? null : e.target.value === 'yes')}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-700 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]">
 <option value="">Lift? —</option>
 <option value="yes">Lift available</option>
 <option value="no">No lift</option>
 </select>
 </div>
 </div>
 ))}
 <button type="button" data-testid="button-edit-add-dropoff" onClick={() => addEditStop('dropoff')}
 className="flex items-center gap-1.5 text-xs text-green-600 hover:text-green-700 font-medium">
 <Plus className="w-3.5 h-3.5" /> Add drop-off stop
 </button>
 </div>

 {/* Total volume + Calculate price */}
 <div className="pt-3 border-t border-zinc-200">
 <label className="text-xs font-medium text-zinc-500 mb-1.5 flex items-center gap-1.5">
 <Truck className="w-3 h-3" /> Total load volume (m³) — for transport & handling
 </label>
 <div className="flex gap-2">
 <input type="number" min="0" step="0.1" value={editTotalVolume} onChange={e => setEditTotalVolume(e.target.value)}
 data-testid="input-edit-total-volume" placeholder="e.g. 8.5"
 className="h-9 flex-1 px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 <button type="button" data-testid="button-edit-calculate-price" onClick={calcEditPrice} disabled={editCalcLoading}
 className="h-9 px-4 rounded-lg text-sm font-medium bg-zinc-900 hover:bg-zinc-800 text-white shrink-0 disabled:opacity-60">
 {editCalcLoading ? "Calculating…" : "Calculate price"}
 </button>
 </div>
 {editCalcError && (
 <div className="mt-1.5 flex items-center gap-1.5 text-xs text-red-600">
 <XCircle className="w-3.5 h-3.5 shrink-0" /> {editCalcError}
 </div>
 )}
 {editCalc && !editCalcError && (
 <div className="mt-2 px-3 py-2.5 bg-white rounded-lg border border-zinc-200 space-y-1 text-xs" data-testid="edit-calc-breakdown">
 {editDistanceKm !== null && (
 <div className="flex justify-between text-zinc-500">
 <span>Route distance</span>
 <span className="font-mono">{editDistanceKm.toFixed(1)} km · {editCalc.numTrips} trip{editCalc.numTrips !== 1 ? "s" : ""}</span>
 </div>
 )}
 {editCalc.breakdown.map((b, i) => (
 <div key={i} className="flex justify-between text-zinc-500">
 <span>{b.label}</span>
 <span className="font-mono">${b.amount.toFixed(2)}</span>
 </div>
 ))}
 <div className="flex justify-between font-semibold text-zinc-900 pt-1 border-t border-zinc-200">
 <span>Logistics applied to Transport Fee</span>
 <span className="font-mono">${editCalc.logisticsSubtotal.toFixed(2)}</span>
 </div>
 </div>
 )}
 </div>
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-500 mb-1.5 block">{hasGeneratedReviewNotes(quote)?"Historical intake / retained staff notes — not the current assessment":"Internal Notes"}</label>
 <textarea value={editQuoteData.notes || ''} onChange={e => setEditQuoteData({ ...editQuoteData, notes: e.target.value })}
 rows={3}
 className="w-full p-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors resize-none"
 placeholder="Internal admin notes..." />
 </div>

 {/* ── Invoice / Billing Presentation ──────────────────────── */}
 <div className="border-t border-zinc-200 pt-4 mt-2">
 <div className="flex items-center justify-between mb-3">
 <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-700">Billing & Invoice</h3>
 <div className="inline-flex rounded-lg border border-zinc-300 p-0.5 bg-zinc-50">
 <button type="button"
 onClick={() => setEditQuoteData({ ...editQuoteData, invoiceType: 'residential' })}
 className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${editQuoteData.invoiceType === 'residential' ? 'bg-zinc-900 text-white' : 'text-zinc-600 hover:bg-zinc-100'}`}
 data-testid="button-invoice-type-residential">
 Residential
 </button>
 <button type="button"
 onClick={() => setEditQuoteData({ ...editQuoteData, invoiceType: 'commercial' })}
 className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${editQuoteData.invoiceType === 'commercial' ? 'bg-zinc-900 text-white' : 'text-zinc-600 hover:bg-zinc-100'}`}
 data-testid="button-invoice-type-commercial">
 Commercial
 </button>
 </div>
 </div>

 <div className="space-y-4">
 <div>
 <label className="text-xs font-medium text-zinc-500 mb-1.5 block">
 Billing Address (this quote)
 <span className="text-zinc-400 font-normal"> — overrides customer default. Leave blank to use customer's saved billing address, then service address.</span>
 </label>
 <textarea value={editQuoteData.billingAddress || ''} onChange={e => setEditQuoteData({ ...editQuoteData, billingAddress: e.target.value })}
 rows={2}
 className="w-full p-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors resize-none"
 placeholder="e.g. 160 Robinson Road #14-04, Singapore 068914"
 data-testid="input-billing-address" />
 </div>

 {editQuoteData.invoiceType === 'commercial' && (
 <div className="space-y-3">
 {/* Quick actions to copy company details to/from the saved customer profile,
 so re-invoicing the same company is a one-click operation. */}
 <div className="flex flex-wrap items-center gap-2 p-2.5 bg-blue-50 border border-blue-200 rounded-lg">
 <span className="text-[11px] font-semibold text-blue-900 uppercase tracking-wider mr-1">Company Profile:</span>
 <button
 type="button"
 onClick={() => {
 setEditQuoteData({
 ...editQuoteData,
 billingCompanyName: editCustomer.companyName || editQuoteData.billingCompanyName || '',
 billingCompanyUen: editCustomer.companyUen || editQuoteData.billingCompanyUen || '',
 billingAddress: editCustomer.billingAddress || editQuoteData.billingAddress || '',
 });
 toast({ title: "Loaded from customer profile", description: "Company name, UEN and billing address copied into this quote." });
 }}
 disabled={!editCustomer.companyName && !editCustomer.companyUen && !editCustomer.billingAddress}
 className="text-[11px] font-semibold px-2.5 py-1 rounded-md bg-white border border-blue-300 text-blue-800 hover:bg-blue-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
 data-testid="button-use-customer-profile">
 ↓ Use customer profile
 </button>
 <button
 type="button"
 onClick={() => {
 if (!editQuoteData.billingCompanyName && !editQuoteData.billingCompanyUen && !editQuoteData.billingAddress) {
 toast({ title: "Nothing to save", description: "Fill in the company name, UEN or billing address first.", variant: "destructive" });
 return;
 }
 setEditCustomer({
 ...editCustomer,
 companyName: editQuoteData.billingCompanyName || editCustomer.companyName || '',
 companyUen: editQuoteData.billingCompanyUen || editCustomer.companyUen || '',
 billingAddress: editQuoteData.billingAddress || editCustomer.billingAddress || '',
 });
 toast({ title: "Saved to customer profile", description: "Click Save below to persist. Future invoices for this customer will auto-fill these details." });
 }}
 className="text-[11px] font-semibold px-2.5 py-1 rounded-md bg-zinc-900 text-white hover:bg-zinc-800 transition-colors"
 data-testid="button-save-to-customer-profile">
 ↑ Save to customer profile
 </button>
 <span className="text-[10.5px] text-[#0A0A0A]/80 ml-auto">Next invoice for this customer will start with these details pre-filled.</span>
 </div>

 <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
 <div>
 <label className="text-xs font-medium text-zinc-500 mb-1.5 block">Company Name (this quote)</label>
 <input value={editQuoteData.billingCompanyName || ''} onChange={e => setEditQuoteData({ ...editQuoteData, billingCompanyName: e.target.value })}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 placeholder="ABC Pte Ltd"
 data-testid="input-billing-company-name" />
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-500 mb-1.5 block">UEN (this quote)</label>
 <input value={editQuoteData.billingCompanyUen || ''} onChange={e => setEditQuoteData({ ...editQuoteData, billingCompanyUen: e.target.value })}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 placeholder="202012345A"
 data-testid="input-billing-company-uen" />
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-500 mb-1.5 block">PO Number <span className="text-zinc-400 font-normal">(optional)</span></label>
 <input value={editQuoteData.poNumber || ''} onChange={e => setEditQuoteData({ ...editQuoteData, poNumber: e.target.value })}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 placeholder="PO-2025-001"
 data-testid="input-po-number" />
 </div>
 </div>
 </div>
 )}

 {/* Customer-profile defaults — saved on the customer record so future quotes inherit them. */}
 <div className="border-t border-dashed border-zinc-200 pt-4 mt-2">
 <div className="text-[11px] font-semibold uppercase tracking-wider text-zinc-500 mb-2">
 Customer Profile Defaults
 <span className="text-zinc-400 font-normal normal-case tracking-normal"> — used when this quote leaves the fields above blank, and applied to future quotes for this customer.</span>
 </div>
 <div className="space-y-3">
 <div>
 <label className="text-xs font-medium text-zinc-500 mb-1.5 block">Default Billing Address</label>
 <textarea value={editCustomer.billingAddress || ''} onChange={e => setEditCustomer({ ...editCustomer, billingAddress: e.target.value })}
 rows={2}
 className="w-full p-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors resize-none"
 placeholder="Customer's standard billing address"
 data-testid="input-customer-billing-address" />
 </div>
 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
 <div>
 <label className="text-xs font-medium text-zinc-500 mb-1.5 block">Default Company Name</label>
 <input value={editCustomer.companyName || ''} onChange={e => setEditCustomer({ ...editCustomer, companyName: e.target.value })}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 placeholder="ABC Pte Ltd"
 data-testid="input-customer-company-name" />
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-500 mb-1.5 block">Default UEN</label>
 <input value={editCustomer.companyUen || ''} onChange={e => setEditCustomer({ ...editCustomer, companyUen: e.target.value })}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors"
 placeholder="202012345A"
 data-testid="input-customer-company-uen" />
 </div>
 </div>
 </div>
 </div>
 </div>
 </div>
 </div>
 ) : (
 <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-y-6 gap-x-8">
 <div className="space-y-4">
 <div className="grid grid-cols-[100px_1fr] gap-2 items-center">
 <span className="text-xs text-zinc-500">Customer</span>
 <span className="text-sm font-medium text-zinc-900">{quote.customer?.name}</span>
 </div>
 <div className="grid grid-cols-[100px_1fr] gap-2 items-center">
 <span className="text-xs text-zinc-500">Email</span>
 <a href={`mailto:${quote.customer?.email}`} className="text-sm text-[#0A0A0A] hover:underline">{quote.customer?.email}</a>
 </div>
 <div className="grid grid-cols-[100px_1fr] gap-2 items-center">
 <span className="text-xs text-zinc-500">Phone</span>
 <div className="flex gap-3 items-center">
 <a href={`tel:${quote.customer?.phone}`} className="text-sm text-zinc-900 hover:underline">{quote.customer?.phone}</a>
 <a href={`https://wa.me/${quote.customer?.phone?.replace(/\D/g, '')}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 hover:bg-emerald-100 transition-colors">
 <MessageCircle className="w-3 h-3" /> WhatsApp
 </a>
 </div>
 </div>
 <div className="grid grid-cols-[100px_1fr] gap-2 items-center">
 <span className="text-xs text-zinc-500">Created</span>
 <span className="text-sm text-zinc-900">{format(new Date(quote.createdAt), "MMM d, yyyy h:mm a")}</span>
 </div>
 {(quote.preferredDate || quote.scheduledAt) && (() => {
 const tw = quote.scheduledAt ? quote.timeWindow : quote.preferredTimeWindow;
 const twLabel = tw === "09:00-12:00" ? "Morning (9 AM–12 PM)"
 : tw === "13:00-17:00" ? "Afternoon (1–5 PM)" : tw ?? null;
 const dateLabel = quote.scheduledAt
 ? formatSingaporeDay(quote.scheduledAt, "EEE, MMM d, yyyy")
 : (() => {
 try { return format(new Date(quote.preferredDate + "T12:00:00"), "EEE, MMM d, yyyy"); }
 catch { return quote.preferredDate; }
 })();
 const isFlexible = !quote.scheduledAt && quote.preferredDate?.toLowerCase() === "flexible";
 return (
 <div className="grid grid-cols-[100px_1fr] gap-2 items-start">
 <span className="text-xs text-zinc-500 mt-0.5">{quote.scheduledAt ? "Scheduled" : "Requested"}</span>
 <div className="flex flex-col gap-1">
 <span className="text-sm text-zinc-900 font-medium flex items-center gap-1.5">
 {isFlexible
 ? <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-700 border border-amber-200">Flexible Date</span>
 : dateLabel}
 </span>
 {twLabel && (
 <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold w-fit bg-blue-50 text-[#0A0A0A] border border-blue-200">
 <Clock className="w-3 h-3" /> {twLabel}
 </span>
 )}
 {isFlexible && !twLabel && (
 <span className="text-xs text-zinc-400 italic">No time preference specified</span>
 )}
 </div>
 </div>
 );
 })()}
 </div>
 
 <div className="space-y-4">
 <div className="grid grid-cols-[100px_1fr] gap-2 items-start">
 <span className="text-xs text-zinc-500 mt-0.5">Service At</span>
 <span className="text-sm text-zinc-900 leading-snug">{quote.serviceAddress}</span>
 </div>
 {(quote as any).samePropertyMove && (
 <div className="grid grid-cols-[100px_1fr] gap-2 items-start" data-testid="badge-same-property-move">
 <span className="text-xs text-zinc-500 mt-0.5">Move Type</span>
 <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-amber-50 text-amber-800 text-xs font-semibold rounded-md w-fit border border-amber-200">
 Same-Property Move (no transport)
 </span>
 </div>
 )}
 {(() => {
 const grouped = groupStops((quote as any).stops);
 const hasMulti = !(quote as any).samePropertyMove && (grouped.pickups.length + grouped.dropoffs.length) > 0
 && (grouped.pickups.length > 1 || grouped.dropoffs.length > 1);
 if (!hasMulti) return null;
 return (
 <div className="grid grid-cols-[100px_1fr] gap-2 items-start" data-testid="view-multistop">
 <span className="text-xs text-zinc-500 mt-0.5">Stops</span>
 <div className="space-y-2">
 {grouped.pickups.map((s) => (
 <div key={s.id} className="flex items-start gap-2" data-testid={`view-stop-${s.id}`}>
 <span className="mt-0.5 inline-flex items-center justify-center w-5 h-5 rounded-full bg-blue-100 text-[10px] font-bold text-blue-600 shrink-0">{s.label.replace('Pickup ', '')}</span>
 <span className="text-sm text-zinc-900 leading-snug">{s.address}{s.floor ? `, ${s.floor}` : ''}{s.hasLift != null ? ` (lift: ${s.hasLift ? 'yes' : 'no'})` : ''}</span>
 </div>
 ))}
 {grouped.dropoffs.map((s) => (
 <div key={s.id} className="flex items-start gap-2" data-testid={`view-stop-${s.id}`}>
 <span className="mt-0.5 inline-flex items-center justify-center w-5 h-5 rounded-full bg-green-100 text-[10px] font-bold text-green-600 shrink-0">{s.label.replace('Drop-off ', '')}</span>
 <span className="text-sm text-zinc-900 leading-snug">{s.address}{s.floor ? `, ${s.floor}` : ''}{s.hasLift != null ? ` (lift: ${s.hasLift ? 'yes' : 'no'})` : ''}</span>
 </div>
 ))}
 </div>
 </div>
 );
 })()}
 {quote.pickupAddress && !(groupStops((quote as any).stops).pickups.length > 1 || groupStops((quote as any).stops).dropoffs.length > 1) && (
 <div className="grid grid-cols-[100px_1fr] gap-2 items-start">
 <span className="text-xs text-zinc-500 mt-0.5">{(quote as any).samePropertyMove ? "Property" : "Pickup At"}</span>
 <span className="text-sm text-zinc-900 leading-snug">{quote.pickupAddress}</span>
 </div>
 )}
 {quote.dropoffAddress && !(quote as any).samePropertyMove && !(groupStops((quote as any).stops).pickups.length > 1 || groupStops((quote as any).stops).dropoffs.length > 1) && (
 <div className="grid grid-cols-[100px_1fr] gap-2 items-start">
 <span className="text-xs text-zinc-500 mt-0.5">Dropoff At</span>
 <span className="text-sm text-zinc-900 leading-snug">{quote.dropoffAddress}</span>
 </div>
 )}
 {quote.distanceKm && Number(quote.distanceKm) > 0 && !(quote as any).samePropertyMove && (
 <div className="grid grid-cols-[100px_1fr] gap-2 items-center">
 <span className="text-xs text-zinc-500">Distance</span>
 <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-zinc-100 text-zinc-700 text-xs font-medium rounded-md w-fit border border-zinc-200">
 {Number(quote.distanceKm).toFixed(1)} km
 </span>
 </div>
 )}
 </div>
 </div>
 )}
 </div>

 {/* WhatsApp-origin quotes retain their intake, routing and canonical-item evidence here. */}
 {!isEditing && quote.sourceChannel === "whatsapp" && <WhatsAppSourceOfTruth quote={quote} />}
 {!isEditing && needsWhatsAppScopeReview(quote) && <div className="flex flex-col gap-2 border border-[#D9D3C8] bg-[#F8F5ED] p-4 sm:flex-row sm:items-center sm:justify-between">
 <div><p className="text-xs font-bold text-[#343126]">Scope review</p><p className="mt-1 text-xs text-[#716B5E]">Open the same quote editor to confirm facts, rates and any explicit review decisions.</p></div>
 <Link href={`/admin/quotes/${id}?edit=1`} data-testid="link-open-quote-workspace" className="inline-flex min-h-10 items-center justify-center gap-2 border border-[#51452D] bg-[#51452D] px-3 text-xs font-semibold text-white hover:bg-[#403824]">Open quote editor <ArrowRight className="h-3.5 w-3.5"/></Link>
 </div>}
 {!isEditing && <div className="border border-zinc-200 bg-white p-4 flex items-center justify-between gap-3">
 <div><p className="font-semibold text-sm">Appointment</p><p className="text-sm text-zinc-500">{quote.scheduledAt?formatSingaporeDay(quote.scheduledAt,"dd MMM yyyy"):"Awaiting owner confirmation"} · {quote.timeWindow||quote.preferredTimeWindow||"Time not confirmed"}</p></div>
 <button data-testid="manage-appointment" onClick={handleConfirmBooking} className="border px-3 py-2 text-sm">Manage appointment</button>
 </div>}
 {!isEditing&&showAppointment&&<div role="dialog" aria-modal="true" aria-label="Manage appointment" className="fixed inset-0 z-[60] bg-black/40 p-3 flex items-center justify-center">
 <div className="max-w-3xl w-full max-h-[90dvh] overflow-auto bg-white p-4 sm:p-6">
 <div className="flex items-center justify-between mb-4"><h2 className="font-bold">Manage appointment</h2><button data-testid="close-appointment" onClick={()=>{if(!appointmentDirty||window.confirm("Discard unsaved appointment changes?")){setShowAppointment(false);setAppointmentDirty(false);}}} className="border px-3 py-2">Close</button></div>
 <p className="text-sm text-zinc-500 mb-3">Appointment and billing confirmation is separate from saving quotation items.</p>
 <StaffSchedulingReview key={quote.id} quoteId={Number(quote.id)} version={Number(quote.version)} quote={quote} onDirtyChange={setAppointmentDirty}/>
 </div></div>}
 {invoiceNotificationStatus}

 {/* Photos Box */}
 {!isEditing && quote.detectionPhotoUrl && (
 <div className="bg-white border border-zinc-200 rounded-none overflow-hidden">
 <div className="px-5 py-4 border-b border-zinc-100">
 <h2 className="text-sm font-semibold text-zinc-900 flex items-center gap-2">
 <Camera className="w-4 h-4 text-zinc-400" /> Reference Photos
 </h2>
 </div>
 <div className="p-5">
 <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
 <button 
 type="button" 
 onClick={() => setLightboxPhoto(quote.detectionPhotoUrl)} 
 className="group relative aspect-square rounded-lg overflow-hidden border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
 >
 <img src={quote.detectionPhotoUrl} alt="Customer submitted" className="w-full h-full object-cover" />
 <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
 <span className="text-white text-xs font-medium">View</span>
 </div>
 </button>
 </div>
 </div>
 </div>
 )}

 {/* GoGoVan job value — DISPLAY ONLY. Shown so staff/admin see what the job is
     worth; kept out of the quote total so GGV money (tracked on ggv_jobs) is
     never double-counted in revenue. */}
 {quote.ggv && (
 <div className="bg-emerald-50 border border-emerald-200 rounded-none px-5 py-4">
 <div className="flex items-center justify-between gap-3">
 <div className="min-w-0">
 <p className="text-[11px] font-black uppercase tracking-wide text-emerald-700 flex items-center gap-1.5">
 <Truck className="w-3.5 h-3.5" /> GoGoVan Job Value
 </p>
 {quote.ggv.remarks && <p className="text-[13px] font-bold text-emerald-900 mt-1 leading-snug break-words">{quote.ggv.remarks}</p>}
 <p className="text-[11px] text-emerald-700/70 mt-0.5">Paid via GoGoVan — shown for reference, not added to this job's total.</p>
 </div>
 <span className="text-lg font-bold text-emerald-800 tabular-nums shrink-0">{formatMoney(quote.ggv.actualPrice)}</span>
 </div>
 <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-emerald-800/80">
 {quote.ggv.jobNo && <span>Code: <span className="font-mono font-semibold">{quote.ggv.jobNo}</span></span>}
 {quote.ggv.serviceType && <span>Service: <span className="font-semibold">{quote.ggv.serviceType}</span></span>}
 {Number(quote.ggv.listedPrice || 0) > 0 && <span>Listed: {formatMoney(quote.ggv.listedPrice)}</span>}
 {Number(quote.ggv.deduction || 0) > 0 && <span>Deduction: −{formatMoney(quote.ggv.deduction)}</span>}
 </div>
 </div>
 )}

 {/* Items & Pricing */}
 <div className="bg-white border border-zinc-200 rounded-none overflow-hidden">
 <div className="px-5 py-4 border-b border-zinc-100 flex items-center justify-between">
 <h2 className="text-sm font-semibold text-zinc-900 flex items-center gap-2">
 <Receipt className="w-4 h-4 text-zinc-400" /> Quote Items
 </h2>
 {isEditing && (
 <button onClick={addEditItem} data-testid="button-add-item"
 className="inline-flex items-center gap-2 h-7 px-2.5 rounded-md text-[#0A0A0A] hover:bg-blue-50 text-xs font-medium transition-colors">
 <Plus className="w-3.5 h-3.5" /> Add Item
 </button>
 )}
 </div>

 {isEditing ? (
 <div className="p-5">
 <div className="space-y-3">
 {editItems.map((item, i) => (
 <div key={i} className="flex flex-col sm:flex-row gap-3 p-4 bg-zinc-50 border border-zinc-200 rounded-none">
 <div className="flex-1 space-y-3">
 <div className="flex items-center gap-2">
 <div className="relative flex-1">
 <input value={item.detectedName || item.originalDescription}
 onChange={e => { updateEditItem(i, 'detectedName', e.target.value); setCatalogPickerFor(i); }}
 onFocus={() => setCatalogPickerFor(i)}
 onBlur={() => setTimeout(() => setCatalogPickerFor(prev => prev === i ? null : prev), 150)}
 data-testid={`input-edit-item-desc-${i}`}
 placeholder="Item description — type to search catalog" className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 {catalogPickerFor === i && catalogSuggestions(String(item.detectedName || item.originalDescription || '')).length > 0 && (
 <div className="absolute z-30 left-0 right-0 top-full mt-1 bg-white border border-zinc-300 rounded-lg shadow-lg max-h-64 overflow-auto">
 {catalogSuggestions(String(item.detectedName || item.originalDescription || '')).map(c => (
 <button key={c.id} type="button"
 onMouseDown={e => { e.preventDefault(); applyCatalogToItem(i, c); }}
 data-testid={`option-catalog-${i}-${c.id}`}
 className="w-full flex items-center justify-between gap-2 px-3 py-2 text-left text-sm hover:bg-zinc-50 border-b border-zinc-100 last:border-b-0">
 <span className="min-w-0">
 <span className="block truncate text-zinc-900">{c.name}</span>
 <span className="block text-[11px] uppercase tracking-wide text-zinc-400">{String(c.serviceType).replace('_', ' + ')}</span>
 </span>
 <span className="shrink-0 font-medium text-zinc-700">${Number(c.basePrice).toFixed(2)}</span>
 </button>
 ))}
 </div>
 )}
 </div>
 <button type="button" onClick={() => detectEditItemType(i)} disabled={detectingItem === i}
 data-testid={`button-detect-type-${i}`}
 title="AI: detect if this is a service or a fee"
 className="h-9 shrink-0 inline-flex items-center gap-1 px-2.5 border border-zinc-300 rounded-lg text-xs font-medium text-zinc-700 bg-white hover:bg-violet-50 hover:border-violet-300 disabled:opacity-50 transition-colors">
 <Sparkles className={`w-3.5 h-3.5 text-violet-500 ${detectingItem === i ? 'animate-pulse' : ''}`} />
 {detectingItem === i ? 'Detecting…' : 'Detect'}
 </button>
 </div>
 <div className="grid grid-cols-3 gap-3">
 <select value={item.serviceType} onChange={e => updateEditItem(i, 'serviceType', e.target.value)}
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors">
 <option value="install">Install</option>
 <option value="dismantle">Dismantle</option>
 <option value="relocate">Relocate</option>
 <option value="dispose">Dispose</option>
 <option value="dismantle_install">Dismantle + Install</option>
 <option value="dismantle_dispose">Dismantle + Dispose</option>
 <option value="fee">Fee / Charge (show as typed)</option>
 </select>
 <input type="number" min="1" value={item.quantity} onChange={e => updateEditItem(i, 'quantity', parseInt(e.target.value) || 1)}
 data-testid={`input-edit-item-qty-${i}`} placeholder="Qty" className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors text-center" />
 <div className="relative">
 <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">$</span>
 <input type="number" min="0" step="0.01" value={item.unitPrice} onChange={e => updateEditItem(i, 'unitPrice', e.target.value)}
 className="h-9 w-full pl-6 pr-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 </div>
 </div>
 {/* Multi-stop route tag — only when there are extra stops. */}
 {editIsMultiStop && (
 <div className="flex items-center gap-2">
 <Route className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
 <select value={item.fromStopId || ''} onChange={e => updateEditItem(i, 'fromStopId', e.target.value || null)}
 data-testid={`select-edit-item-from-${i}`}
 className="h-8 flex-1 text-xs border border-zinc-300 rounded-md px-2 bg-white text-zinc-700 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]">
 <option value="">From pick-up…</option>
 {editPickupStops.map((s, pi) => (
 <option key={s.id} value={s.id}>Pickup {pi + 1}</option>
 ))}
 </select>
 <ArrowRight className="w-3 h-3 text-zinc-400 shrink-0" />
 <select value={item.toStopId || ''} onChange={e => updateEditItem(i, 'toStopId', e.target.value || null)}
 data-testid={`select-edit-item-to-${i}`}
 className="h-8 flex-1 text-xs border border-zinc-300 rounded-md px-2 bg-white text-zinc-700 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]">
 <option value="">To drop-off…</option>
 {editDropoffStops.map((s, di) => (
 <option key={s.id} value={s.id}>Drop-off {String.fromCharCode(65 + di)}</option>
 ))}
 </select>
 </div>
 )}
 </div>
 <button onClick={() => removeEditItem(i)} className="inline-flex items-center justify-center w-9 h-9 sm:w-auto sm:px-3 rounded-lg text-red-600 bg-white border border-zinc-300 hover:bg-red-50 hover:border-red-200 transition-colors self-start">
 <Trash2 className="w-4 h-4 sm:mr-1.5" /> <span className="hidden sm:inline text-sm font-medium">Remove</span>
 </button>
 </div>
 ))}
 </div>

 <div className="mt-5 pt-5 border-t border-zinc-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
 <div className="space-y-4">
 <div>
 <label className="text-xs font-medium text-zinc-500 block mb-1.5">Transport Fee</label>
 <div className="relative w-32">
 <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">$</span>
 <input type="number" min="0" step="0.01" value={editQuoteData.transportFee || '0'} onChange={e => setEditQuoteData({ ...editQuoteData, transportFee: e.target.value })}
 className="h-9 w-full pl-6 pr-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 </div>
 </div>
 <label className="flex items-start gap-2.5 cursor-pointer select-none" data-testid="toggle-staff-transport-allowance">
 <input
 type="checkbox"
 checked={!!editQuoteData.staffTransportAllowance}
 onChange={e => setEditQuoteData({ ...editQuoteData, staffTransportAllowance: e.target.checked })}
 className="mt-0.5 w-4 h-4 rounded border-zinc-300 text-[#0A0A0A] focus:ring-[#0A0A0A]"
 />
 <span>
 <span className="block text-sm font-medium text-zinc-900">Pay $8 transport allowance to assigned staff</span>
 <span className="block text-xs text-zinc-500 mt-0.5">Adds $8 to the assigned staff's monthly payslip for this job.</span>
 </span>
 </label>
 <div className="border border-zinc-200 rounded-lg p-3 bg-zinc-50">
 <label className="flex items-start gap-2.5 cursor-pointer select-none" data-testid="toggle-second-day-continuation">
 <input
 type="checkbox"
 checked={!!editQuoteData.secondDayContinuation}
 onChange={e => setEditQuoteData({ ...editQuoteData, secondDayContinuation: e.target.checked })}
 className="mt-0.5 w-4 h-4 rounded border-zinc-300 text-[#0A0A0A] focus:ring-[#0A0A0A]"
 />
 <span>
 <span className="block text-sm font-medium text-zinc-900">Job pushed to a second day (access delay)</span>
 <span className="block text-xs text-zinc-500 mt-0.5">Adds a ${PricingConfig.secondDay.returnFee} return fee + ${PricingConfig.secondDay.perPersonHourlyRate}/hr per mover for Day-2 crew time to the balance. Use when loading-bay parking / lift access forced the job to finish the next day.</span>
 </span>
 </label>
 {editQuoteData.secondDayContinuation && (
 <div className="mt-3 space-y-2">
 <div>
 <label className="text-xs font-medium text-zinc-500 block mb-1.5">Day-2 hours on site</label>
 <div className="relative w-32">
 <input type="number" min="0" step="0.5" value={editQuoteData.secondDayHours || '0'} onChange={e => setEditQuoteData({ ...editQuoteData, secondDayHours: e.target.value })}
 data-testid="input-second-day-hours"
 className="h-9 w-full pl-3 pr-10 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 <span className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 text-xs">hrs</span>
 </div>
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-500 block mb-1.5">Day-2 crew size (movers)</label>
 <div className="relative w-32">
 <input type="number" min="1" step="1" value={editQuoteData.secondDayCrewSize ?? PricingConfig.secondDay.defaultCrewSize} onChange={e => setEditQuoteData({ ...editQuoteData, secondDayCrewSize: Math.max(1, Math.round(Number(e.target.value) || 1)) })}
 data-testid="input-second-day-crew"
 className="h-9 w-full pl-3 pr-10 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 <span className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 text-xs">men</span>
 </div>
 </div>
 {(() => {
 const sd = calcSecondDayContinuation(true, editQuoteData.secondDayHours || 0, editQuoteData.secondDayCrewSize);
 return (
 <p className="text-xs text-zinc-600" data-testid="text-second-day-fee-preview">
 ${sd.returnFee} return + {sd.crewSize} men × {sd.hours}h × ${sd.perPersonHourlyRate}/man = <span className="font-semibold text-zinc-900">${sd.fee.toFixed(2)}</span> added to balance
 </p>
 );
 })()}
 <p className="text-[11px] text-zinc-400">Leave hours at 0 to charge just the ${PricingConfig.secondDay.returnFee} return fee, then enter the actual Day-2 hours once the crew finishes.</p>
 </div>
 )}
 {/* ── Dispute-protection: scope, timing & surcharges (Task #34) ── */}
 <div className="border border-zinc-200 rounded-lg p-3 bg-zinc-50 space-y-3" data-testid="section-scope-timing">
 <p className="text-xs font-semibold text-zinc-700">Scope, timing & surcharges</p>
 {/* Timing mode */}
 <div>
 <label className="text-xs font-medium text-zinc-500 block mb-1.5">Job timing</label>
 <div className="inline-flex rounded-md bg-zinc-100 p-0.5">
 <button type="button" onClick={() => setEditQuoteData({ ...editQuoteData, timingMode: 'continuous' })}
 data-testid="button-timing-continuous"
 className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${editQuoteData.timingMode !== 'split' ? 'bg-zinc-900 text-white' : 'text-zinc-600 hover:bg-zinc-200'}`}>
 One continuous slot
 </button>
 <button type="button" onClick={() => setEditQuoteData({ ...editQuoteData, timingMode: 'split' })}
 data-testid="button-timing-split"
 className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${editQuoteData.timingMode === 'split' ? 'bg-zinc-900 text-white' : 'text-zinc-600 hover:bg-zinc-200'}`}>
 Split (dismantle + reinstall)
 </button>
 </div>
 </div>
 {editQuoteData.timingMode === 'split' && (
 <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
 <div>
 <label className="text-xs font-medium text-zinc-500 block mb-1.5">Dismantle date</label>
 <input type="date" value={editQuoteData.dismantleAt || ''} onChange={e => setEditQuoteData({ ...editQuoteData, dismantleAt: e.target.value })}
 data-testid="input-dismantle-date"
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-500 block mb-1.5">Dismantle time window</label>
 <input type="text" placeholder="e.g. 9am–12pm" value={editQuoteData.dismantleTimeWindow || ''} onChange={e => setEditQuoteData({ ...editQuoteData, dismantleTimeWindow: e.target.value })}
 data-testid="input-dismantle-window"
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-500 block mb-1.5">Reinstall date</label>
 <input type="date" value={editQuoteData.reinstallAt || ''} onChange={e => setEditQuoteData({ ...editQuoteData, reinstallAt: e.target.value })}
 data-testid="input-reinstall-date"
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-500 block mb-1.5">Reinstall time window</label>
 <input type="text" placeholder="e.g. 2pm–5pm" value={editQuoteData.reinstallTimeWindow || ''} onChange={e => setEditQuoteData({ ...editQuoteData, reinstallTimeWindow: e.target.value })}
 data-testid="input-reinstall-window"
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 </div>
 </div>
 )}
 {/* After-office surcharge */}
 <label className="flex items-start gap-2.5 cursor-pointer select-none" data-testid="toggle-after-office">
 <input type="checkbox" checked={!!editQuoteData.afterOfficeInvolved}
 onChange={e => setEditQuoteData({ ...editQuoteData, afterOfficeInvolved: e.target.checked })}
 className="mt-0.5 w-4 h-4 rounded border-zinc-300 text-[#0A0A0A] focus:ring-[#0A0A0A]" />
 <span>
 <span className="block text-sm font-medium text-zinc-900">After-office work involved</span>
 <span className="block text-xs text-zinc-500 mt-0.5">Work expected to run past standard hours; add the surcharge amount below.</span>
 </span>
 </label>
 {editQuoteData.afterOfficeInvolved && (
 <div className="pl-6 space-y-2">
 <div>
 <label className="text-xs font-medium text-zinc-500 block mb-1.5">After-office surcharge</label>
 <div className="relative w-32">
 <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">$</span>
 <input type="number" min="0" step="0.01" value={editQuoteData.afterOfficeSurchargeAmount || '0'} onChange={e => setEditQuoteData({ ...editQuoteData, afterOfficeSurchargeAmount: e.target.value })}
 data-testid="input-after-office-amount"
 className="h-9 w-full pl-6 pr-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 </div>
 </div>
 <label className="flex items-start gap-2.5 cursor-pointer select-none" data-testid="toggle-after-office-waived">
 <input type="checkbox" checked={!!editQuoteData.afterOfficeWaived}
 onChange={e => setEditQuoteData({ ...editQuoteData, afterOfficeWaived: e.target.checked })}
 className="mt-0.5 w-4 h-4 rounded border-zinc-300 text-[#0A0A0A] focus:ring-[#0A0A0A]" />
 <span className="block text-sm font-medium text-zinc-900">Waive this surcharge (charge $0)</span>
 </label>
 {editQuoteData.afterOfficeWaived && (
 <input type="text" placeholder="Reason for waiver (shown on quote)" value={editQuoteData.afterOfficeWaiverReason || ''} onChange={e => setEditQuoteData({ ...editQuoteData, afterOfficeWaiverReason: e.target.value })}
 data-testid="input-after-office-waiver-reason"
 className="h-9 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 )}
 </div>
 )}
 {/* Additional trip charge */}
 <div>
 <label className="text-xs font-medium text-zinc-500 block mb-1.5">Additional trip / manpower charge</label>
 <div className="relative w-32">
 <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">$</span>
 <input type="number" min="0" step="0.01" value={editQuoteData.additionalTripCharge || '0'} onChange={e => setEditQuoteData({ ...editQuoteData, additionalTripCharge: e.target.value })}
 data-testid="input-additional-trip"
 className="h-9 w-full pl-6 pr-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 </div>
 </div>
 {/* Special remarks */}
 <div>
 <label className="text-xs font-medium text-zinc-500 block mb-1.5">Special remarks (shown to customer)</label>
 <textarea value={editQuoteData.specialRemarks || ''} onChange={e => setEditQuoteData({ ...editQuoteData, specialRemarks: e.target.value })}
 data-testid="input-special-remarks" rows={2}
 className="w-full px-3 py-2 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 </div>
 {/* Own mover + deposit refundable + cancellation window */}
 <label className="flex items-start gap-2.5 cursor-pointer select-none" data-testid="toggle-own-mover">
 <input type="checkbox" checked={!!editQuoteData.ownMoverInvolved}
 onChange={e => setEditQuoteData({ ...editQuoteData, ownMoverInvolved: e.target.checked })}
 className="mt-0.5 w-4 h-4 rounded border-zinc-300 text-[#0A0A0A] focus:ring-[#0A0A0A]" />
 <span className="block text-sm font-medium text-zinc-900">Customer's own mover / transport involved</span>
 </label>
 <label className="flex items-start gap-2.5 cursor-pointer select-none" data-testid="toggle-deposit-refundable">
 <input type="checkbox" checked={editQuoteData.depositRefundable === true}
 onChange={e => setEditQuoteData({ ...editQuoteData, depositRefundable: e.target.checked })}
 className="mt-0.5 w-4 h-4 rounded border-zinc-300 text-[#0A0A0A] focus:ring-[#0A0A0A]" />
 <span className="block text-sm font-medium text-zinc-900">Deposit refundable (subject to cancellation policy)</span>
 </label>
 <div>
 <label className="text-xs font-medium text-zinc-500 block mb-1.5">Cancellation notice (hours) — blank uses default</label>
 <input type="number" min="0" step="1" value={editQuoteData.cancellationNoticeHours ?? ''} onChange={e => setEditQuoteData({ ...editQuoteData, cancellationNoticeHours: e.target.value })}
 data-testid="input-cancellation-hours"
 className="h-9 w-32 px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 </div>
 </div>
 {(() => {
 const summary = computeSiteTime((quote.siteVisits as SiteVisit[] | undefined) || []);
 if (summary.days.length === 0) return null;
 const fmt = (iso: string) => new Date(iso).toLocaleTimeString('en-SG', { timeZone: 'Asia/Singapore', hour: 'numeric', minute: '2-digit' });
 return (
 <div className="mt-3 rounded-lg border border-zinc-200 bg-zinc-50 p-3" data-testid="section-site-time-log">
 <p className="text-xs font-semibold text-zinc-700 mb-2">Recorded on-site time (auto-tracked by staff app)</p>
 <div className="space-y-2">
 {summary.days.map((day) => (
 <div key={day.date} className="text-xs text-zinc-600">
 <div className="flex items-center justify-between font-medium text-zinc-800">
 <span>Day {day.dayNumber} · {day.label}</span>
 <span data-testid={`text-admin-site-day-hours-${day.dayNumber}`}>{day.hours.toFixed(2)}h</span>
 </div>
 {day.visits.map((v, i) => (
 <div key={i} className="flex items-center justify-between text-zinc-500 pl-2">
 <span>{fmt(v.arrivedAt)} – {v.open ? 'on site now' : fmt(v.leftAt!)}</span>
 {!v.open && <span>{v.hours.toFixed(2)}h</span>}
 </div>
 ))}
 </div>
 ))}
 </div>
 {summary.spansMultipleDays && (
 <p className="text-[11px] text-zinc-500 mt-2">Day-2 hours ({summary.secondDayHours.toFixed(2)}h) were auto-filled into Second-Day Continuation above when the crew checked out.</p>
 )}
 </div>
 );
 })()}
 {(() => {
 const flags = detectTimingFlags((quote.siteVisits as SiteVisit[] | undefined) || []);
 if (!flags.sameDaySplit && !flags.afterOffice) return null;
 return (
 <div className="mt-3 rounded-lg border border-amber-300 bg-amber-50 p-3 space-y-1.5" data-testid="section-timing-advisory">
 <p className="text-xs font-bold text-amber-800 uppercase tracking-wide">Timing detected — review charges</p>
 {flags.sameDaySplit && (
 <p className="text-xs text-amber-700" data-testid="text-advisory-split">
 Same-day split: the crew left and returned with a gap of {flags.longestGapHours.toFixed(1)}h ({flags.extraTrips} extra trip{flags.extraTrips !== 1 ? 's' : ''}). Consider adding the ${BusinessRulesDefaults.additionalTripCharge.toFixed(2)} mobilisation charge per extra trip (Additional trip charge below).
 </p>
 )}
 {flags.afterOffice && (
 <p className="text-xs text-amber-700" data-testid="text-advisory-afteroffice">
 After-office work detected — the crew worked past standard hours. Consider ticking the After-office surcharge below (+{BusinessRulesDefaults.afterOfficeSurchargePct}% of the total job price).
 </p>
 )}
 </div>
 );
 })()}
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-500 block mb-1.5">Goodwill Discount</label>
 <div className="relative w-32">
 <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">$</span>
 <input
 type="number" min="0" step="0.01"
 value={editQuoteData.goodwillDiscount || '0'}
 onChange={e => setEditQuoteData({ ...editQuoteData, goodwillDiscount: e.target.value })}
 data-testid="input-goodwill-discount"
 className="h-9 w-full pl-6 pr-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 </div>
 <input
 type="text"
 placeholder="Reason (optional, shown to customer)"
 value={editQuoteData.goodwillReason || ''}
 onChange={e => setEditQuoteData({ ...editQuoteData, goodwillReason: e.target.value })}
 data-testid="input-goodwill-reason"
 maxLength={500}
 className="mt-1.5 h-9 w-full sm:w-72 px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors" />
 </div>
 </div>
 
 <div className="text-right w-full sm:w-auto bg-zinc-50 p-4 rounded-none border border-zinc-200">
  {editVolume && editVolume.unresolved.length > 0 && (
    <p className="text-xs text-red-700 mb-2" role="alert">
      Select a relocation catalog item with a known volume for: {editVolume.unresolved.join(", ")}. Save will be blocked until these are resolved.
    </p>
  )}
  {editVolume && editVolume.unresolved.length === 0 && (
    <p className="text-xs text-zinc-600 mb-2">Catalog load: {editVolume.volumeM3.toFixed(2)} m³ · handling included in logistics</p>
  )}
 <div className="flex justify-between sm:justify-end gap-6 text-sm mb-1.5">
 <span className="text-zinc-500">Subtotal</span>
 <span className="font-medium text-zinc-900">${editSubtotal.toFixed(2)}</span>
 </div>
  {editDiscount > 0 && (
  <div className="flex justify-between sm:justify-end gap-6 text-sm mb-1.5">
  <span className="text-zinc-500">Discount</span>
  <span className="font-medium text-green-700">−${editDiscount.toFixed(2)}</span>
  </div>
  )}
 {editPromoDiscount > 0 && (
 <div className="flex justify-between sm:justify-end gap-6 text-sm mb-1.5">
 <span className="text-zinc-500">Promo ({quote?.promoCode})</span>
 <span className="font-medium text-green-700">−${editPromoDiscount.toFixed(2)}</span>
 </div>
 )}
 {editGoodwillDiscount > 0 && (
 <div className="flex justify-between sm:justify-end gap-6 text-sm mb-1.5">
 <span className="text-zinc-500">Goodwill discount</span>
 <span className="font-medium text-green-700">−${editGoodwillDiscount.toFixed(2)}</span>
 </div>
 )}
 {(editTransport - editVolumetric) > 0 && (
 <div className="flex justify-between sm:justify-end gap-6 text-sm mb-3">
 <span className="text-zinc-500">Transport</span>
 <span className="font-medium text-zinc-900">${(editTransport - editVolumetric).toFixed(2)}</span>
 </div>
 )}
 {editVolumetric > 0 && (
 <div className="flex justify-between sm:justify-end gap-6 text-sm mb-3">
 <span className="text-zinc-500">Volumetric Handling</span>
 <span className="font-medium text-zinc-900">${editVolumetric.toFixed(2)}</span>
 </div>
 )}
 {editSecondDay > 0 && (
 <div className="flex justify-between sm:justify-end gap-6 text-sm mb-3">
 <span className="text-zinc-500">Second-day continuation</span>
 <span className="font-medium text-zinc-900">${editSecondDay.toFixed(2)}</span>
 </div>
 )}
 <div className="flex justify-between sm:justify-end gap-6 text-base font-semibold border-t border-zinc-200 pt-2">
 <span className="text-zinc-900">Total</span>
 <span className="text-zinc-900">${editTotal.toFixed(2)}</span>
 </div>
  {quote.depositPaidAt && !quote.finalPaidAt && (
    <p className="text-xs text-zinc-600 mt-2">{paymentSummary.pricingPending ? "Proposed components only; the final price and balance remain pending scope approval." : `After payments already collected, estimated balance: $${Math.max(0, balanceOwing + editTotal - quoteTotal).toFixed(2)}`}</p>
  )}
 </div>
 </div>

 {(editQuoteData.timingMode === 'split' || editQuoteData.afterOfficeInvolved) && (
 <div className="mt-6 border border-amber-300 bg-amber-50 rounded-lg p-3" data-testid="banner-surcharge-ack">
 <div className="flex items-start gap-2">
 <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
 <div className="space-y-2">
 <p className="text-xs font-semibold text-amber-900">
 {editQuoteData.timingMode === 'split' && editQuoteData.afterOfficeInvolved
 ? 'Split timing and after-office work are selected.'
 : editQuoteData.timingMode === 'split'
 ? 'Split timing (dismantle + reinstall on separate days) is selected.'
 : 'After-office work is selected.'}{' '}
 The resulting surcharge must be reflected on this quote, or waived in writing.
 </p>
 <label className="flex items-start gap-2.5 cursor-pointer select-none" data-testid="toggle-surcharge-ack">
 <input type="checkbox" checked={surchargeAck}
 onChange={e => setSurchargeAck(e.target.checked)}
 className="mt-0.5 w-4 h-4 rounded border-amber-400 text-amber-700 focus:ring-amber-600" />
 <span className="text-xs text-amber-900">
 I confirm the after-office / split-timing surcharge has been added to this quote, or waived in writing (waiver reason recorded above).
 </span>
 </label>
 </div>
 </div>
 </div>
 )}

 <div className="mt-6 flex gap-3">
 <button onClick={()=>handleSaveEdit("save")}
 disabled={editQuote.isPending || ((editQuoteData.timingMode === 'split' || editQuoteData.afterOfficeInvolved) && !surchargeAck)}
 data-testid="button-save-edit"
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-50">
 <Save className="w-4 h-4" /> {editQuote.isPending ? "Saving..." : "Save Changes"}
 </button>
 {editError&&<div role="alert" data-testid="edit-save-error" className="text-red-700 text-sm">{editError}<p>Your entered changes have not been discarded.</p>{editError.includes("another window")&&<a className="underline" href={`/admin/quotes/${id}`} target="_blank" rel="noopener noreferrer">Open current saved quotation in another tab — keep this draft here</a>}</div>}
 <button onClick={() => setIsEditing(false)} data-testid="button-cancel-edit"
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50 text-sm font-medium transition-colors">
 Cancel
 </button>
 </div>
 </div>
 ) : (
 <>
 {/* Mobile card layout */}
 <div className="sm:hidden divide-y divide-zinc-100">
 {quote.items?.map((item: any) => (
 <div key={item.id} className="px-4 py-3 flex items-start justify-between gap-3">
 <div className="flex-1 min-w-0">
 <p className="text-sm font-medium text-zinc-900 leading-snug">{item.detectedName || item.originalDescription}</p>
 <p className="text-xs text-zinc-400 mt-0.5 capitalize">
 {formatItemServiceLabel(item, quote.items) || String(item.serviceType).replace('_', ' + ')} · qty {item.quantity} · ${Number(item.unitPrice).toFixed(2)}/ea
 </p>
 {itemRouteLabel((quote as any).stops, item.fromStopId, item.toStopId) && (
 <p className="text-xs text-zinc-500 mt-0.5 inline-flex items-center gap-1" data-testid={`item-route-${item.id}`}>
 <Route className="w-3 h-3" /> {itemRouteLabel((quote as any).stops, item.fromStopId, item.toStopId)}
 </p>
 )}
 {item.remark && (
 <p className="text-xs text-zinc-400 mt-1 italic leading-snug">{item.remark}</p>
 )}
 </div>
 <span className="text-sm font-semibold text-zinc-900 tabular-nums shrink-0">{formatMoney(item.subtotal)}</span>
 </div>
 ))}
 {(!quote.items || quote.items.length === 0) && (
 <div className="px-4 py-8 text-center text-sm text-zinc-400">No items in this quote.</div>
 )}
 </div>

 {/* Desktop table layout */}
 <table className="hidden sm:table table-fixed w-full">
 <thead>
 <tr>
 <th className="px-5 py-3 text-left text-[11px] font-semibold text-zinc-500 uppercase tracking-wider bg-zinc-50 border-b border-zinc-200">Item Details</th>
 <th className="w-16 px-3 py-3 text-center text-[11px] font-semibold text-zinc-500 uppercase tracking-wider bg-zinc-50 border-b border-zinc-200">Qty</th>
 <th className="w-28 px-5 py-3 text-right text-[11px] font-semibold text-zinc-500 uppercase tracking-wider bg-zinc-50 border-b border-zinc-200">Total</th>
 </tr>
 </thead>
 <tbody>
 {quote.items?.map((item: any) => (
 <tr key={item.id} className="hover:bg-zinc-50 transition-colors">
 <td className="px-5 py-3 border-b border-zinc-100">
 <p className="text-sm font-medium text-zinc-900 leading-tight">{item.detectedName || item.originalDescription}</p>
 <p className="text-xs text-zinc-500 mt-0.5 capitalize">{formatItemServiceLabel(item, quote.items) || String(item.serviceType).replace('_', ' + ')} · ${Number(item.unitPrice).toFixed(2)}/ea</p>
 {itemRouteLabel((quote as any).stops, item.fromStopId, item.toStopId) && (
 <p className="text-xs text-zinc-500 mt-0.5 inline-flex items-center gap-1" data-testid={`item-route-desktop-${item.id}`}>
 <Route className="w-3 h-3" /> {itemRouteLabel((quote as any).stops, item.fromStopId, item.toStopId)}
 </p>
 )}
 {item.remark && (
 <p className="text-xs text-zinc-400 mt-0.5 italic leading-snug">{item.remark}</p>
 )}
 </td>
 <td className="px-3 py-3 border-b border-zinc-100 text-center text-sm text-zinc-700">
 {item.quantity}
 </td>
 <td className="px-5 py-3 border-b border-zinc-100 text-right text-sm font-medium text-zinc-900 tabular-nums">
 {formatMoney(item.subtotal)}
 </td>
 </tr>
 ))}
 {(!quote.items || quote.items.length === 0) && (
 <tr>
 <td colSpan={3} className="px-5 py-8 text-center text-sm text-zinc-500 border-b border-zinc-100">
 No items in this quote.
 </td>
 </tr>
 )}
 </tbody>
 </table>
 
 <div className="bg-zinc-50 px-4 sm:px-5 py-4 border-t border-zinc-200">
 <div className="w-full sm:w-64 ml-auto space-y-2">
 <div className="flex justify-between text-sm">
 <span className="text-zinc-500">{isReviewQuotation(quote)?"Known priced components":"Subtotal"}</span>
 <span className="font-medium text-zinc-900 tabular-nums">{formatMoney(isReviewQuotation(quote)?quote.items.reduce((sum:any,item:any)=>sum+Number(item.subtotal||0),0):quote.subtotal||0)}</span>
 </div>
 {quote.items?.some((i: any) => i.serviceType === 'relocate') && (
 <div className="flex items-start gap-1.5 text-xs text-emerald-700 font-medium">
 <span className="mt-0.5">✓</span>
 <span>D&R bundle rate: relocation items priced at 40% off (install + dismantle combined)</span>
 </div>
 )}
 {isTransportPricingPending(quote) && <div className="flex justify-between text-sm" data-testid="transport-pricing-pending"><span className="text-zinc-500">Transport / access</span><span className="font-medium text-amber-800">Pricing pending</span></div>}
 {Number(quote.discount || 0) > 0 && (
 <div className="flex justify-between text-sm">
 <span className="text-zinc-500">Discount</span>
 <span className="font-medium text-green-700 tabular-nums">−{formatMoney(quote.discount)}</span>
 </div>
 )}
 {Number(quote.promoDiscount || 0) > 0 && (
 <div className="flex justify-between text-sm">
 <span className="text-zinc-500">Promo ({quote.promoCode})</span>
 <span className="font-medium text-green-700 tabular-nums">−{formatMoney(quote.promoDiscount)}</span>
 </div>
 )}
 {Number((quote as any).goodwillDiscount || 0) > 0 && (
 <div className="flex justify-between text-sm" data-testid="row-goodwill-discount">
 <span className="text-zinc-500">
 Goodwill discount
 {(quote as any).goodwillReason ? <span className="text-zinc-400"> · {(quote as any).goodwillReason}</span> : null}
 </span>
 <span className="font-medium text-green-700 tabular-nums">−{formatMoney((quote as any).goodwillDiscount)}</span>
 </div>
 )}
 {(Number(quote.transportFee || 0) - Number((quote as any).volumetricFee || 0)) > 0 && (
 <div className="flex justify-between text-sm">
 <span className="text-zinc-500">Transport Fee</span>
 <span className="font-medium text-zinc-900 tabular-nums">{formatMoney(Number(quote.transportFee || 0) - Number((quote as any).volumetricFee || 0))}</span>
 </div>
 )}
 {Number((quote as any).volumetricFee || 0) > 0 && (
 <div className="flex justify-between text-sm">
 <span className="text-zinc-500">Volumetric Handling</span>
 <span className="font-medium text-zinc-900 tabular-nums">{formatMoney((quote as any).volumetricFee)}</span>
 </div>
 )}
 <div className="flex justify-between items-center pt-3 border-t border-zinc-200 mt-2">
 <span className="text-sm font-semibold text-zinc-900">{isReviewQuotation(quote)?"Final quotation total":"Total Due"}</span>
 <span className="text-lg font-bold text-zinc-900 tabular-nums">{isReviewQuotation(quote) ? "Pricing pending" : formatMoney(quote.total)}</span>
 </div>
 </div>
 </div>
 {needsStaffTimeAssessment && (
 <div className="bg-amber-50 border-t border-amber-200 px-4 sm:px-5 py-4 text-sm text-amber-900" data-testid="mixed-scope-time-review">
 <p className="font-semibold">{hasPartialWork ? "Mixed work scope — staff time assessment needed" : "Work scope — staff time assessment needed"}</p>
 <p>The generic per-item crew-hours model does not establish the time for alignment, castor fitting, uncartoning, placement or unspecified manual work. Review the actual work before relying on its time or margin estimate. Saved prices and appointment remain unchanged.</p>
 </div>
 )}
 {paymentSummary.pricingPending && <p className="text-xs text-amber-800 bg-amber-50 border border-amber-200 p-3" data-testid="partial-price-advisory">Scope and final pricing are pending. This labour component is not payable. Deposit, balance and job-margin assessment await a complete quotation.</p>}
 {!paymentSummary.pricingPending && !needsStaffTimeAssessment && marginEval.enabled && marginEval.belowFloor && (
 <div className="bg-red-50 border-t border-red-200 px-4 sm:px-5 py-4" data-testid="banner-margin-warning">
 <div className="flex items-start gap-2.5">
 <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
 <div className="text-sm text-red-800 space-y-1">
 <p className="font-semibold">Pricing warning — below safe minimum</p>
 <p>
 This job is priced at <span className="font-semibold tabular-nums">{formatMoney(marginEval.grandTotal)}</span>, but the safe minimum to hit a {Math.round(marginEval.marginPct * 100)}% margin is <span className="font-semibold tabular-nums">{formatMoney(marginEval.costFloor)}</span> — short by <span className="font-semibold tabular-nums">{formatMoney(marginEval.shortfall)}</span>.
 </p>
 <p className="text-xs text-red-700">
 Estimated cost {formatMoney(marginEval.estimatedCost)} for ~{marginEval.estimatedHours}h of a {marginEval.crewSize}-person crew. Raise the price, or accept knowingly if you have a reason.
 </p>
 </div>
 </div>
 </div>
 )}
 {!paymentSummary.pricingPending && !needsStaffTimeAssessment && marginEval.enabled && !marginEval.belowFloor && marginEval.grandTotal > 0 && (
 <div className="bg-emerald-50 border-t border-emerald-200 px-4 sm:px-5 py-2.5" data-testid="banner-margin-ok">
 <p className="text-xs text-emerald-700 flex items-center gap-1.5">
 <span>✓</span>
 Margin healthy — est. cost {formatMoney(marginEval.estimatedCost)}, ~{Math.round(marginEval.actualMarginPct * 100)}% margin at this price.
 </p>
 </div>
 )}
 </>
 )}
 </div>

 {/* Internal Notes Display (if not editing) */}
 {!isEditing && quote.notes && hasGeneratedReviewNotes(quote) && (
 <details className="bg-amber-50 border border-amber-200 rounded-none p-5" data-testid="historical-intake-notes">
 <summary className="text-xs font-semibold text-amber-800 cursor-pointer">Historical intake notes — not the current assessment</summary>
 <p className="text-xs text-amber-800 mt-2">Original notes, including any staff additions, are retained unchanged. Use the current scope review for outstanding questions.</p>
 <p className="text-sm text-amber-900 whitespace-pre-wrap leading-relaxed mt-2">{quote.notes}</p>
 </details>
 )}
 {!isEditing && quote.notes && !hasGeneratedReviewNotes(quote) && (
 <div className="bg-amber-50 border border-amber-200 rounded-none p-5">
 <h3 className="text-xs font-semibold text-amber-800 mb-2 flex items-center gap-2">
 <AlertTriangle className="w-3.5 h-3.5" /> Internal Notes
 </h3>
 <p className="text-sm text-amber-900 whitespace-pre-wrap leading-relaxed">{quote.notes}</p>
 </div>
 )}

 {/* ── Terms acceptance, dispute log & refund (Task #34) ───────────── */}
 {!isEditing && (
 <div className="bg-white border border-zinc-200 rounded-none overflow-hidden" data-testid="section-dispute-protection">
 <div className="flex items-center justify-between px-5 py-3.5 bg-zinc-50 border-b border-zinc-200">
 <h3 className="text-xs font-semibold text-zinc-600 uppercase tracking-wider flex items-center gap-2">
 <Shield className="w-3.5 h-3.5" /> Terms, Acceptance & Disputes
 </h3>
 <span className="text-[11px] font-medium text-zinc-500" data-testid="text-quote-version">
 v{(quote as any).version || 1}{(quote as any).superseded ? " (superseded)" : ""}
 </span>
 </div>

 <div className="px-5 py-4 space-y-4">
 {/* Acceptance record */}
 <div className="rounded-lg border border-zinc-200 p-3" data-testid="block-acceptance-record">
 <p className="text-xs font-semibold text-zinc-700 mb-1.5">Customer acceptance</p>
 {(quote as any).termsAcceptedAt ? (
 <div className="text-xs text-zinc-600 space-y-0.5" data-testid="text-accepted">
 <p>Accepted <span className="font-medium text-zinc-900">{new Date((quote as any).termsAcceptedAt).toLocaleString('en-SG', { timeZone: 'Asia/Singapore' })}</span></p>
 <p>Version accepted: v{(quote as any).termsAcceptedVersion ?? '—'} · Amount: ${Number((quote as any).termsAcceptedAmount || 0).toFixed(2)}</p>
 {(quote as any).termsAcceptedIp && <p className="text-zinc-400">IP: {(quote as any).termsAcceptedIp}</p>}
 </div>
 ) : (
 <p className="text-xs text-amber-700" data-testid="text-not-accepted">{paymentSummary.pricingPending ? "Scope and final pricing must be completed and approved before payment. Customer acceptance is a separate requirement; acceptance alone cannot make this component payable." : "Not yet accepted by customer. Deposit checkout is blocked until they accept on the quote page."}</p>
 )}
 </div>

 {/* Cancellation request */}
 {(quote as any).cancellationRequestedAt && (
 <div className="rounded-lg border border-amber-200 bg-amber-50 p-3" data-testid="block-cancellation">
 <p className="text-xs font-semibold text-amber-800 mb-1">Cancellation requested</p>
 <p className="text-xs text-amber-900">{new Date((quote as any).cancellationRequestedAt).toLocaleString('en-SG', { timeZone: 'Asia/Singapore' })}</p>
 {(quote as any).cancellationReason && <p className="text-xs text-amber-900 mt-1 whitespace-pre-wrap">Reason: {(quote as any).cancellationReason}</p>}
 </div>
 )}

 {/* Refund record / action */}
 <div className="rounded-lg border border-zinc-200 p-3" data-testid="block-refund">
 <div className="flex items-center justify-between mb-1.5">
 <p className="text-xs font-semibold text-zinc-700">Refund</p>
 <button type="button" data-testid="button-toggle-refund" onClick={() => setShowRefundForm(v => !v)}
 className="text-xs font-medium text-[#0A0A0A] hover:underline">{showRefundForm ? 'Close' : 'Record refund'}</button>
 </div>
 {(quote as any).refundApprovedAmount != null && (
 <div className="text-xs text-zinc-600 space-y-0.5 mb-2" data-testid="text-refund-record">
 <p>Approved: <span className="font-medium text-zinc-900">${Number((quote as any).refundApprovedAmount || 0).toFixed(2)}</span>{(quote as any).refundMethod ? ` · ${(quote as any).refundMethod}` : ''}</p>
 {(quote as any).refundReason && <p>Reason: {(quote as any).refundReason}</p>}
 {(quote as any).refundDueByAt && <p>Due by: {new Date((quote as any).refundDueByAt).toLocaleDateString('en-SG', { timeZone: 'Asia/Singapore' })}</p>}
 {(quote as any).refundCompletedAt && <p className="text-emerald-700">Completed: {new Date((quote as any).refundCompletedAt).toLocaleDateString('en-SG', { timeZone: 'Asia/Singapore' })}</p>}
 </div>
 )}
 {showRefundForm && (
 <div className="space-y-2 pt-2 border-t border-zinc-100">
 <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
 <div>
 <label className="text-[11px] font-medium text-zinc-500 block mb-1">Approved amount</label>
 <div className="relative">
 <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">$</span>
 <input type="number" min="0" step="0.01" value={refundForm.refundApprovedAmount} onChange={e => setRefundForm(f => ({ ...f, refundApprovedAmount: e.target.value }))}
 data-testid="input-refund-amount"
 className="h-8 w-full pl-6 pr-2 border border-zinc-300 rounded-lg text-xs bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]" />
 </div>
 </div>
 <div>
 <label className="text-[11px] font-medium text-zinc-500 block mb-1">Method</label>
 <input type="text" placeholder="PayNow / bank transfer" value={refundForm.refundMethod} onChange={e => setRefundForm(f => ({ ...f, refundMethod: e.target.value }))}
 data-testid="input-refund-method"
 className="h-8 w-full px-2 border border-zinc-300 rounded-lg text-xs bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]" />
 </div>
 </div>
 <div>
 <label className="text-[11px] font-medium text-zinc-500 block mb-1">Reason</label>
 <input type="text" value={refundForm.refundReason} onChange={e => setRefundForm(f => ({ ...f, refundReason: e.target.value }))}
 data-testid="input-refund-reason"
 className="h-8 w-full px-2 border border-zinc-300 rounded-lg text-xs bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]" />
 </div>
 <div>
 <label className="text-[11px] font-medium text-zinc-500 block mb-1">Completed date (leave blank if still processing)</label>
 <input type="date" value={refundForm.refundCompletedAt} onChange={e => setRefundForm(f => ({ ...f, refundCompletedAt: e.target.value }))}
 data-testid="input-refund-completed"
 className="h-8 w-full px-2 border border-zinc-300 rounded-lg text-xs bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]" />
 </div>
 <div>
 <label className="text-[11px] font-medium text-zinc-500 block mb-1">Internal note (not shown to customer)</label>
 <input type="text" value={refundForm.refundInternalNote} onChange={e => setRefundForm(f => ({ ...f, refundInternalNote: e.target.value }))}
 data-testid="input-refund-internal-note"
 className="h-8 w-full px-2 border border-zinc-300 rounded-lg text-xs bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]" />
 </div>
 <button type="button" disabled={refundMutation.isPending || !refundForm.refundApprovedAmount}
 data-testid="button-save-refund"
 onClick={() => refundMutation.mutate({
 refundApprovedAmount: refundForm.refundApprovedAmount,
 refundReason: refundForm.refundReason || undefined,
 refundMethod: refundForm.refundMethod || undefined,
 refundCompletedAt: refundForm.refundCompletedAt ? new Date(`${refundForm.refundCompletedAt}T00:00:00`).toISOString() : undefined,
 refundInternalNote: refundForm.refundInternalNote || undefined,
 })}
 className="h-8 px-3 bg-zinc-900 text-white text-xs font-semibold rounded-lg hover:bg-zinc-800 disabled:opacity-50">
 {refundMutation.isPending ? 'Saving…' : 'Save refund'}
 </button>
 </div>
 )}
 </div>

 {/* Dispute / activity log */}
 <div data-testid="block-dispute-log">
 <p className="text-xs font-semibold text-zinc-700 mb-2">Dispute & activity log</p>
 <div className="space-y-2 max-h-64 overflow-y-auto">
 {disputeEvents.length === 0 ? (
 <p className="text-xs text-zinc-400">No events logged yet.</p>
 ) : (
 disputeEvents.map((ev: any) => (
 <div key={ev.id} className="text-xs border-l-2 border-zinc-200 pl-3 py-0.5" data-testid={`row-dispute-event-${ev.id}`}>
 <div className="flex items-center justify-between">
 <span className="font-medium text-zinc-800">{(ev.eventType || 'event').replace(/_/g, ' ')}</span>
 <span className="text-zinc-400">{ev.createdAt ? new Date(ev.createdAt).toLocaleString('en-SG', { timeZone: 'Asia/Singapore' }) : ''}</span>
 </div>
 {ev.detail && <p className="text-zinc-600 mt-0.5 whitespace-pre-wrap">{ev.detail}</p>}
 {ev.actorType && ev.actorType !== 'system' && <p className="text-zinc-400 mt-0.5">by {ev.actorType}</p>}
 </div>
 ))
 )}
 </div>
 <div className="flex items-center gap-2 mt-3">
 <input type="text" value={disputeNote} onChange={e => setDisputeNote(e.target.value)}
 placeholder="Add a note to the log…" data-testid="input-dispute-note"
 onKeyDown={e => { if (e.key === 'Enter' && disputeNote.trim()) addDisputeEvent.mutate(disputeNote.trim()); }}
 className="h-8 flex-1 px-2 border border-zinc-300 rounded-lg text-xs bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]" />
 <button type="button" disabled={addDisputeEvent.isPending || !disputeNote.trim()}
 data-testid="button-add-dispute-note"
 onClick={() => addDisputeEvent.mutate(disputeNote.trim())}
 className="h-8 px-3 bg-zinc-900 text-white text-xs font-semibold rounded-lg hover:bg-zinc-800 disabled:opacity-50">Add</button>
 </div>
 </div>
 </div>
 </div>
 )}

 {/* ── Subcontractors ─────────────────────────────────────────────── */}
 <div className="bg-white border border-zinc-200 rounded-none overflow-hidden ">
 <div className="flex items-center justify-between px-5 py-3.5 bg-zinc-50 border-b border-zinc-200">
 <h3 className="text-xs font-semibold text-zinc-600 uppercase tracking-wider flex items-center gap-2">
 <Handshake className="w-3.5 h-3.5" /> Subcontractors
 </h3>
 <button
 data-testid="button-add-subcontract"
 onClick={() => setShowSubForm(v => !v)}
 className="flex items-center gap-1.5 text-xs font-medium text-[#0A0A0A] hover:text-[#0A0A0A] transition-colors"
 >
 <Plus className="w-3.5 h-3.5" />
 Assign
 </button>
 </div>

 {/* Add Form */}
 {showSubForm && (
 <div className="px-5 py-4 bg-blue-50 border-b border-blue-100 space-y-3">
 <div>
 <label className="text-xs font-medium text-zinc-600 mb-1 block">Subcontractor</label>
 <select
 data-testid="select-subcontractor"
 value={subForm.subcontractorId}
 onChange={e => setSubForm(f => ({ ...f, subcontractorId: e.target.value }))}
 className="w-full text-sm border border-zinc-300 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
 >
 <option value="">Select subcontractor…</option>
 {(allSubs as any[]).map((s: any) => (
 <option key={s.id} value={s.id}>{s.name} {s.company ? `(${s.company})` : ""}</option>
 ))}
 </select>
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-600 mb-1 block">Agreed Cost (SGD)</label>
 <input
 data-testid="input-subcontract-cost"
 type="number"
 min="0"
 step="0.01"
 value={subForm.agreedCost}
 onChange={e => setSubForm(f => ({ ...f, agreedCost: e.target.value }))}
 placeholder="0.00"
 className="w-full text-sm border border-zinc-300 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
 />
 </div>
 <div>
 <label className="text-xs font-medium text-zinc-600 mb-1 block">Notes (optional)</label>
 <input
 data-testid="input-subcontract-notes"
 type="text"
 value={subForm.notes}
 onChange={e => setSubForm(f => ({ ...f, notes: e.target.value }))}
 placeholder="e.g. Labour only, supply excluded"
 className="w-full text-sm border border-zinc-300 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
 />
 </div>
 <div className="flex gap-2">
 <button
 data-testid="button-confirm-subcontract"
 onClick={() => {
 if (!subForm.subcontractorId || !subForm.agreedCost) return;
 assignSubMutation.mutate({
 subcontractorId: parseInt(subForm.subcontractorId),
 agreedCost: parseFloat(subForm.agreedCost),
 notes: subForm.notes || undefined,
 });
 }}
 disabled={assignSubMutation.isPending || !subForm.subcontractorId || !subForm.agreedCost}
 className="flex-1 bg-[#0A0A0A] hover:bg-black disabled:opacity-50 text-white text-sm font-medium py-2 rounded-lg transition-colors"
 >
 {assignSubMutation.isPending ? "Saving…" : "Confirm"}
 </button>
 <button
 data-testid="button-cancel-subcontract"
 onClick={() => { setShowSubForm(false); setSubForm({ subcontractorId: "", agreedCost: "", notes: "" }); }}
 className="px-4 py-2 text-sm text-zinc-600 hover:text-zinc-900 transition-colors"
 >
 Cancel
 </button>
 </div>
 </div>
 )}

 {/* Subcontract List */}
 <div className="divide-y divide-zinc-100">
 {(subcontracts as any[]).length === 0 ? (
 <p className="text-xs text-zinc-400 px-5 py-4 text-center">No subcontractors assigned to this job.</p>
 ) : (
 (subcontracts as any[]).map((sc: any) => (
 <div key={sc.id} data-testid={`row-subcontract-${sc.id}`} className="flex items-center gap-3 px-5 py-3.5">
 <div className="flex-1 min-w-0">
 <p className="text-sm font-medium text-zinc-900 truncate">{sc.subcontractor?.name || "—"}</p>
 {sc.notes && <p className="text-xs text-zinc-400 truncate">{sc.notes}</p>}
 </div>
 <div className="text-right shrink-0">
 <p className="text-sm font-semibold text-zinc-900">${Number(sc.agreedCost).toFixed(2)}</p>
 <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
 sc.paymentStatus === "paid"
 ? "bg-emerald-100 text-emerald-700"
 : "bg-amber-100 text-amber-700"
 }`}>
 {sc.paymentStatus === "paid" ? "Paid" : "Unpaid"}
 </span>
 </div>
 <div className="flex items-center gap-1 shrink-0">
 <button
 data-testid={`button-toggle-subpaid-${sc.id}`}
 title={sc.paymentStatus === "paid" ? "Mark unpaid" : "Mark paid"}
 onClick={() => markSubPaidMutation.mutate({ scId: sc.id, paid: sc.paymentStatus !== "paid" })}
 disabled={markSubPaidMutation.isPending}
 className="p-1.5 rounded-lg text-zinc-400 hover:text-emerald-600 hover:bg-emerald-50 transition-colors"
 >
 <CheckCircle2 className="w-4 h-4" />
 </button>
 <button
 data-testid={`button-remove-subcontract-${sc.id}`}
 title="Remove"
 onClick={() => { if (confirm("Remove this subcontractor from the job?")) removeSubMutation.mutate(sc.id); }}
 disabled={removeSubMutation.isPending}
 className="p-1.5 rounded-lg text-zinc-400 hover:text-red-600 hover:bg-red-50 transition-colors"
 >
 <Trash2 className="w-3.5 h-3.5" />
 </button>
 </div>
 </div>
 ))
 )}
 </div>

 {/* Cost summary */}
 {(subcontracts as any[]).length > 0 && (() => {
 const totalSubCost = (subcontracts as any[]).reduce((s: number, sc: any) => s + Number(sc.agreedCost), 0);
 const jobTotal = Number(quote.totalAmount || 0);
 const net = jobTotal - totalSubCost;
 return (
 <div className="px-5 py-3 bg-zinc-50 border-t border-zinc-200 flex items-center justify-between text-xs text-zinc-500">
 <span>Sub costs: <strong className="text-zinc-800">${totalSubCost.toFixed(2)}</strong></span>
 <span>Net profit: <strong className={net >= 0 ? "text-emerald-700" : "text-red-600"}>${net.toFixed(2)}</strong></span>
 </div>
 );
 })()}
 </div>
 
 </div>
 
 {/* Right Column (Action Panel) */}
 <div className="space-y-5 lg:sticky lg:top-28 lg:self-start">

 <AiEmailDrafter quote={quote} />

 {!paymentSummary.pricingPending && (
 <div className="bg-white border border-zinc-200 rounded-none overflow-hidden ">
 <div className="bg-zinc-50 px-5 py-4 border-b border-zinc-200">
 <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-3">Job Pipeline</p>
 <div className="space-y-4 relative before:absolute before:inset-0 before:ml-[11px] before:-translate-x-px before:h-full before:w-0.5 before:bg-zinc-200">
 {/* Status Timeline */}
 {[
 { id: "quote", label: "Quote Requested", done: true, active: quote.status === 'submitted' || quote.status === 'under_review' },
 { id: "approved", label: "Quote Approved", done: !['submitted', 'under_review', 'cancelled'].includes(quote.status), active: quote.status === 'approved' },
 { id: "deposit", label: "Deposit Paid", done: paymentSummary.initialCollected, active: quote.status === 'deposit_requested' },
 { id: "booked", label: "Booked & Assigned", done: ['booked', 'assigned', 'in_progress', 'at_pickup', 'in_transit', 'at_dropoff', 'completed', 'final_payment_requested', 'final_paid', 'closed'].includes(quote.status), active: quote.status === 'deposit_paid' || quote.status === 'booking_pending' || quote.status === 'booked' || quote.status === 'assigned' },
 { id: "completed", label: "Job Completed", done: ['completed', 'final_payment_requested', 'final_paid', 'closed'].includes(quote.status), active: ['in_progress', 'at_pickup', 'in_transit', 'at_dropoff'].includes(quote.status) },
 { id: "paid", label: "Final Payment", done: !!quote.finalPaidAt || quote.status === 'closed', active: quote.status === 'completed' || quote.status === 'final_payment_requested' },
 ].map((step, i) => (
 <div key={step.id} className="relative flex items-center gap-3">
 <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 z-10 ${
 step.done ? 'bg-[#0A0A0A] text-white' : 
 step.active ? 'bg-white border-2 border-blue-600 text-[#0A0A0A]' : 
 'bg-zinc-100 border border-zinc-300 text-transparent'
 }`}>
 {step.done && <CheckCircle2 className="w-3.5 h-3.5" />}
 {!step.done && step.active && <div className="w-2 h-2 rounded-full bg-[#0A0A0A]" />}
 </div>
 <span className={`text-sm ${step.active ? 'font-semibold text-zinc-900' : step.done ? 'font-medium text-zinc-700' : 'text-zinc-400'}`}>
 {step.label}
 </span>
 </div>
 ))}
 </div>
 </div>

 {/* Action Buttons based on status */}
 <div className="p-5 space-y-4">
 
 {['submitted', 'under_review'].includes(quote.status) && (
 (quote as any).invoiceType === 'commercial' ? (
 <div className="space-y-2">
 <div className="rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2 text-xs text-indigo-800">
 <span className="font-semibold">Commercial customer</span> — no deposit collected. Booking is confirmed on approval; a Net 30 invoice is sent after job completion.
 </div>
 <button onClick={handleApproveCommercialBooking} disabled={approveCommercial.isPending}
 data-testid="button-approve-commercial-booking"
 className="inline-flex items-center justify-center w-full gap-2 h-9 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-50">
 <CalendarCheck className="w-4 h-4" />
 {approveCommercial.isPending ? "Confirming…" : "Approve & Book Job"}
 </button>
 </div>
 ) : (
 <div className="space-y-2">
 <button onClick={handleApproveAndRequestDeposit} disabled={updateStatus.isPending}
 className="inline-flex items-center justify-center w-full gap-2 h-9 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-50">
 <CheckCircle2 className="w-4 h-4" /> Approve & Request Deposit
 </button>
 <button
 onClick={() => setShowPayNowConfirm(true)}
 data-testid="button-mark-deposit-already-paid"
 title="Customer already paid via PayNow — record it without sending the deposit request message"
 className="inline-flex items-center justify-center w-full gap-2 h-9 px-4 rounded-lg bg-white border border-emerald-300 text-emerald-700 hover:bg-emerald-50 text-sm font-medium transition-colors">
 <QrCode className="w-4 h-4" /> Customer Already Paid Deposit (PayNow)
 </button>
 </div>
 )
 )}

 {quote.status === 'deposit_requested' && (
 <div className="space-y-3">
 <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 text-sm text-center">
 <p className="font-semibold text-orange-800">Awaiting Deposit</p>
 <p className="text-orange-700 mt-0.5">{formatMoney(effectiveDeposit)}</p>
 </div>
 {/* PayNow QR reference for admin */}
 <div className="border border-zinc-200 rounded-lg p-3 space-y-2 bg-zinc-50">
 <p className="text-[11px] font-semibold text-zinc-500 uppercase tracking-wide text-center">Customer PayNow Details</p>
 <div className="flex items-center gap-3">
 <img
 src="/paynow-qr.png"
 alt="PayNow QR"
 data-testid="img-admin-paynow-qr"
 className="w-16 h-16 rounded object-contain bg-white p-1 border border-zinc-200 shrink-0"
 />
 <div className="text-xs text-zinc-600 space-y-0.5">
 <p><span className="font-semibold">UEN:</span> 202424156H</p>
 <p><span className="font-semibold">Name:</span> TMG Install by The Moving Guy Pte Ltd</p>
 <p className="text-emerald-700 font-semibold">Amount: {formatMoney(effectiveDeposit)}</p>
 <p className="text-zinc-400 mt-1 leading-tight">Customer should WhatsApp receipt screenshot after transfer</p>
 </div>
 </div>
 </div>
 <button
 onClick={() => setShowPayNowConfirm(true)}
 data-testid="button-mark-paynow-paid"
 className="inline-flex items-center justify-center w-full gap-2 h-9 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium transition-colors disabled:opacity-50">
 <QrCode className="w-4 h-4" /> Mark PayNow Received
 </button>
 <PaymentChannelButtons
 quote={quote}
 emailPending={resendDepositEmail.isPending}
 whatsappPending={sendWhatsAppPayment.isPending}
 onEmail={() => resendDepositEmail.mutate()}
 onWhatsApp={(phone) => sendWhatsAppPayment.mutate(phone)}
 onCopy={() => setShowPaymentMessageDialog(true)}
 />
 </div>
 )}

 {quote.status === 'deposit_paid' && (
 <div className="space-y-3">
 <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-sm text-center">
 <p className="font-semibold text-emerald-800 flex justify-center items-center gap-1.5"><CheckCircle2 className="w-4 h-4" /> Deposit Paid</p>
 </div>
 <button onClick={handleConfirmBooking} disabled={confirmBooking.isPending}
 className="inline-flex items-center justify-center w-full gap-2 h-9 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-50">
 <CalendarCheck className="w-4 h-4" /> Confirm Booking
 </button>
 </div>
 )}

 {false && ['submitted', 'under_review', 'approved', 'deposit_requested'].includes(quote.status) && (
 <ScheduleEditor
 quoteId={quote.id}
 scheduledAt={quote.scheduledAt}
 timeWindow={quote.timeWindow}
 preferredDate={quote.preferredDate}
 preferredTimeWindow={quote.preferredTimeWindow}
 currentStatus={quote.status}
 />
 )}

 {['deposit_paid', 'booking_pending', 'booked', 'assigned', 'in_progress', 'at_pickup', 'in_transit', 'at_dropoff'].includes(quote.status) && (
 <div className="space-y-4">
 {false && <ScheduleEditor
 quoteId={quote.id}
 scheduledAt={quote.scheduledAt}
 timeWindow={quote.timeWindow}
 preferredDate={quote.preferredDate}
 preferredTimeWindow={quote.preferredTimeWindow}
 currentStatus={quote.status}
 />}
 
 <div className="space-y-2">
 <label className="text-xs font-medium text-zinc-500">Assign Staff or Team</label>
 <select value={selectedAssignee} onChange={e => setSelectedAssignee(e.target.value)}
 data-testid="select-assignee"
 className="h-10 w-full px-3 border border-zinc-300 rounded-lg text-sm bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A] focus:border-[#0A0A0A] transition-colors">
 <option value="">Select...</option>
 <option value="unassigned">Unassign staff / team</option>
 {teamsList.length > 0 && (
 <optgroup label="Teams">
 {teamsList.map((t: any) => (
 <option key={`team:${t.id}`} value={`team:${t.id}`}>{t.name}</option>
 ))}
 </optgroup>
 )}
 <optgroup label="Staff">
 {staffList?.map((s: any) => (
 <option key={`staff:${s.id}`} value={`staff:${s.id}`}>{s.name}</option>
 ))}
 </optgroup>
 </select>
 <button onClick={handleAssign} disabled={updateStatus.isPending || !selectedAssignee}
 data-testid="button-update-assignment"
 className="inline-flex items-center justify-center w-full gap-2 h-10 px-4 rounded-lg bg-white border border-zinc-300 text-zinc-700 hover:bg-zinc-50 text-sm font-medium transition-colors disabled:opacity-50">
 <UserPlus className="w-4 h-4" /> Update Assignment
 </button>
 </div>

 {(quote as any).assignedTeam && (
 <div className="flex items-center gap-3 p-3 bg-indigo-50 rounded-lg border border-indigo-100">
 <div className="w-8 h-8 rounded-full bg-indigo-200 flex items-center justify-center text-indigo-700">
 <Users className="w-4 h-4" />
 </div>
 <div>
 <p className="text-sm font-semibold text-indigo-900">{(quote as any).assignedTeam.name}</p>
 <p className="text-xs text-indigo-700">Team Assigned</p>
 </div>
 </div>
 )}
 
 {quote.assignedStaff && !(quote as any).assignedTeam && (
 <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg border border-blue-100">
 <div className="w-8 h-8 rounded-full bg-blue-200 flex items-center justify-center text-[#0A0A0A] font-bold">{quote.assignedStaff.name[0]}</div>
 <div>
 <p className="text-sm font-semibold text-blue-900">{quote.assignedStaff.name}</p>
 <p className="text-xs text-[#0A0A0A]">Staff Assigned</p>
 </div>
 </div>
 )}

 {/* Request deposit for manual jobs that skipped the normal approval flow */}
 {!paymentSummary.initialCollected && (
 <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 space-y-2">
 <p className="text-xs font-semibold text-amber-800">Deposit not yet received</p>
 <PaymentChannelButtons
 quote={quote}
 emailPending={resendDepositEmail.isPending}
 whatsappPending={sendWhatsAppPayment.isPending}
 onEmail={() => resendDepositEmail.mutate()}
 onWhatsApp={(phone) => sendWhatsAppPayment.mutate(phone)}
 onCopy={() => setShowPaymentMessageDialog(true)}
 />
 <button
 onClick={() => setShowPayNowConfirm(true)}
 data-testid="button-mark-deposit-received"
 className="inline-flex items-center justify-center w-full gap-2 h-9 px-4 rounded-lg bg-white border border-amber-300 text-amber-800 hover:bg-amber-50 text-sm font-medium transition-colors">
 <QrCode className="w-4 h-4" /> Mark Deposit Received (PayNow)
 </button>
 </div>
 )}

 {/* Re-collect deposit — for cases where previous payment needs to be reset (e.g. test mode) */}
 {quote.depositPaidAt && (
 <div className="border border-zinc-200 rounded-lg p-3 space-y-2">
 <p className="text-xs font-semibold text-zinc-500">Need to re-collect deposit?</p>
 <p className="text-xs text-zinc-400">Use this if the previous payment was a test or failed. This will reset the deposit status and let you send a new payment link.</p>
 <button
 data-testid="button-reset-deposit"
 onClick={() => resetDeposit.mutate()}
 disabled={resetDeposit.isPending}
 className="inline-flex items-center justify-center w-full gap-2 h-9 px-4 rounded-lg bg-white border border-zinc-300 text-zinc-700 hover:bg-zinc-50 text-sm font-medium transition-colors disabled:opacity-50">
 {resetDeposit.isPending ? (
 "Resetting…"
 ) : (
 <>
 <RotateCcw className="w-3.5 h-3.5" />
 Reset & Re-send Deposit Link
 </>
 )}
 </button>
 </div>
 )}

 {hasMultiplePhases && (
 <div className="pt-2 border-t border-zinc-100">
 <div className="rounded-lg border border-zinc-200 bg-zinc-50 p-3 space-y-2">
 <div className="flex items-center justify-between">
 <p className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Multi-Day Job Progress</p>
 <p className="text-[10px] text-zinc-500">
 {applicablePhases.filter(p => !!phaseStatus(p.key)).length} / {applicablePhases.length} done
 </p>
 </div>
 <div className="space-y-1.5">
 {applicablePhases.map((p) => {
 const done = phaseStatus(p.key);
 return (
 <div key={p.key} className="flex items-center justify-between gap-2 bg-white rounded border border-zinc-200 px-2.5 py-2">
 <div className="flex items-center gap-2 min-w-0">
 {done ? (
 <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
 ) : (
 <div className="w-4 h-4 rounded-full border-2 border-zinc-300 shrink-0" />
 )}
 <div className="min-w-0">
 <p className={`text-sm font-medium ${done ? 'text-zinc-500 line-through' : 'text-zinc-800'}`}>{p.label}</p>
 {done && (
 <p className="text-[10px] text-zinc-400">
 Done {new Date(done.completedAt).toLocaleDateString("en-SG", { day: 'numeric', month: 'short' })}
 </p>
 )}
 </div>
 </div>
 {done ? (
 <button
 onClick={() => togglePhase.mutate({ phase: p.key, done: false })}
 disabled={togglePhase.isPending}
 data-testid={`button-undo-phase-${p.key}`}
 className="text-[10px] uppercase tracking-wide text-zinc-400 hover:text-zinc-700 disabled:opacity-50 px-2 py-1"
 >
 Undo
 </button>
 ) : (
 <button
 onClick={() => togglePhase.mutate({ phase: p.key, done: true })}
 disabled={togglePhase.isPending}
 data-testid={`button-mark-phase-${p.key}`}
 className="text-xs font-medium px-2.5 py-1.5 rounded bg-zinc-900 text-white hover:bg-zinc-800 disabled:opacity-50 shrink-0"
 >
 Mark Done
 </button>
 )}
 </div>
 );
 })}
 </div>
 {!allPhasesDone && (
 <p className="text-[11px] text-zinc-500 pt-1">
 Tick each phase as it's completed across the different days. Final payment can be requested once all phases are done.
 </p>
 )}
 </div>
 </div>
 )}

 <div className="pt-2 border-t border-zinc-100 space-y-2">
 {!quote.finalPaidAt && (!isFullPayQuote || hasOutstandingBalance) && (
 <button
 onClick={handleRequestFinalPayment}
 disabled={requestFinalPayment.isPending || finalPaymentBlockedByPhases}
 data-testid="button-mark-done-request-final"
 title={finalPaymentBlockedByPhases ? "Tick all phases above before requesting final payment" : undefined}
 className="inline-flex items-center justify-center w-full gap-2 h-9 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
 >
 <CheckCircle2 className="w-4 h-4" />
 {requestFinalPayment.isPending
 ? "Sending…"
 : finalPaymentBlockedByPhases
 ? `Waiting on ${applicablePhases.filter(p => !phaseStatus(p.key)).map(p => p.label).join(" + ")}`
 : "Mark Done & Request Final Payment"}
 </button>
 )}
 {!quote.finalPaidAt && (!isFullPayQuote || hasOutstandingBalance) && (
 <button
 onClick={() => setShowFinalPayConfirm(true)}
 data-testid="button-mark-final-received-manual"
 className="inline-flex items-center justify-center w-full gap-2 h-9 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium transition-colors">
 <QrCode className="w-4 h-4" /> Mark Final Payment Already Received
 </button>
 )}
 {/* Copy-message button is residential-only — commercial jobs skip the
     deposit/final 50-50 flow and use a Net-30 invoice instead, so the
     payment-message endpoint would generate an incorrect deposit message
     for commercial in-progress jobs. Full-payment jobs are already paid in
     full up front, so there is no further payment message to send. */}
 {!quote.finalPaidAt && (!isFullPayQuote || hasOutstandingBalance) && (quote as any).invoiceType !== 'commercial' && (
 <button
 onClick={() => setShowPaymentMessageDialog(true)}
 data-testid="button-copy-customer-message-assigned"
 title="Copy the ready-made payment message — paste it to the customer on any channel (SMS, iMessage, Telegram, personal WhatsApp). Use this when they replied on another platform."
 className="inline-flex items-center justify-center w-full gap-2 h-9 px-4 rounded-lg bg-[#EBE9E2] hover:bg-violet-100 text-[#0A0A0A] border border-violet-200 text-sm font-medium transition-colors"
 >
 <Copy className="w-4 h-4" />
 Copy / send manually
 </button>
 )}
 {(quote.finalPaidAt || isFullPayQuote) && !hasOutstandingBalance && (
 <div className="flex items-center gap-2 p-3 bg-emerald-50 rounded-lg border border-emerald-200">
 <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
 <p className="text-xs text-emerald-700 font-medium">{isFullPayQuote ? "Paid in full up front — no balance to collect. Use " : "Customer has fully paid — use "}<strong>Reopen</strong> in the header first if job needs to be redone, or <strong>Manual Close</strong> to close the case now.</p>
 </div>
 )}
 </div>
 </div>
 )}

 {['in_progress', 'at_pickup', 'in_transit', 'at_dropoff'].includes(quote.status) && (
 <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-center gap-3">
 <Zap className="w-5 h-5 text-blue-500 shrink-0" />
 <p className="text-sm font-medium text-blue-800">
 {quote.status === 'at_pickup' && 'Field team at pickup address, loading items.'}
 {quote.status === 'in_transit' && 'Items loaded — field team in transit to dropoff.'}
 {quote.status === 'at_dropoff' && 'Field team at dropoff address, unloading.'}
 {quote.status === 'in_progress' && 'Job currently in progress by field team.'}
 </p>
 </div>
 )}

 {quote.status === 'completed' && (
 (quote as any).invoiceType === 'commercial' ? (
 <div className="space-y-2">
 <div className="rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2 text-xs text-indigo-800">
 <span className="font-semibold">Commercial job complete</span> — send the Net 30 tax invoice to the customer.
 </div>
 <button onClick={handleSendCommercialInvoice} disabled={sendCommercialInvoice.isPending||!!sendCommercialInvoice.data?.warning}
 data-testid="button-send-commercial-invoice"
 className="inline-flex items-center justify-center w-full gap-2 h-10 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-50">
 <DollarSign className="w-4 h-4" />
 {sendCommercialInvoice.isPending ? "Sending Invoice…" : "Send Invoice (Net 30)"}
 </button>
 </div>
 ) : (isFullPayQuote && !hasOutstandingBalance) ? (
 <div className="flex items-center gap-2 p-3 bg-emerald-50 rounded-lg border border-emerald-200">
 <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
 <p className="text-xs text-emerald-700 font-medium">Paid in full up front — no balance to collect. Use <strong>Manual Close</strong> to close the case.</p>
 </div>
 ) : (
 <div className="space-y-2">
 <button
 onClick={handleRequestFinalPayment}
 disabled={requestFinalPayment.isPending || finalPaymentBlockedByPhases}
 data-testid="button-request-final-payment"
 title={finalPaymentBlockedByPhases ? "Tick all job phases before requesting final payment" : undefined}
 className="inline-flex items-center justify-center w-full gap-2 h-10 px-4 rounded-lg bg-[#0A0A0A] hover:bg-black text-white text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
 >
 <DollarSign className="w-4 h-4" />
 {finalPaymentBlockedByPhases
 ? `Waiting on ${applicablePhases.filter(p => !phaseStatus(p.key)).map(p => p.label).join(" + ")}`
 : "Request Final Payment (Stripe / PayNow)"}
 </button>
 <button
 onClick={() => setShowPaymentMessageDialog(true)}
 data-testid="button-copy-customer-message-completed"
 title="Copy the ready-made final-payment message — paste it on any channel the customer prefers."
 className="inline-flex items-center justify-center w-full gap-2 h-9 px-4 rounded-lg bg-[#EBE9E2] hover:bg-violet-100 text-[#0A0A0A] border border-violet-200 text-sm font-medium transition-colors"
 >
 <Copy className="w-4 h-4" />
 Copy / send manually
 </button>
 </div>
 )
 )}

 {quote.status === 'final_payment_requested' && (
 <div className="space-y-3">
 <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 text-sm text-center">
 <p className="font-semibold text-orange-800">Awaiting Final Payment</p>
 <p className="text-orange-700 mt-0.5">{formatMoney(effectiveFinal)}</p>
 </div>
 <button
 onClick={() => setShowFinalPayConfirm(true)}
 data-testid="button-mark-final-paid"
 className="inline-flex items-center justify-center w-full gap-2 h-9 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium transition-colors">
 <QrCode className="w-4 h-4" /> Mark PayNow Payment Received
 </button>
 <PaymentChannelButtons
 quote={quote}
 emailPending={requestFinalPayment.isPending}
 whatsappPending={sendWhatsAppPayment.isPending}
 onEmail={() => handleRequestFinalPayment()}
 onWhatsApp={(phone) => sendWhatsAppPayment.mutate(phone)}
 onCopy={() => setShowPaymentMessageDialog(true)}
 />
 </div>
 )}

 {['closed', 'final_paid'].includes(quote.status) && (
 <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
 <div className="flex items-start gap-3">
 <BadgeCheck className="w-6 h-6 text-emerald-500 shrink-0 mt-0.5" />
 <div className="flex-1 min-w-0">
 <p className="font-semibold text-emerald-800 text-sm">Case Closed</p>
 <p className="text-xs text-emerald-700 mt-0.5">Fully paid — job marked complete</p>
 </div>
 </div>
 <div className="mt-3 pt-3 border-t border-emerald-200">
 <p className="text-xs text-emerald-700 mb-2">Job not done yet? Reopen to reassign staff.</p>
 <button
 data-testid="button-reopen-job"
 disabled={reopenJob.isPending}
 onClick={() => {
 const reason = prompt("Reason for reopening (optional):");
 if (reason === null) return; // cancelled
 reopenJob.mutate(reason || undefined);
 }}
 className="w-full flex items-center justify-center gap-2 h-8 px-3 rounded-lg bg-white border border-emerald-300 text-emerald-700 hover:bg-emerald-100 text-xs font-medium transition-colors disabled:opacity-50"
 >
 {reopenJob.isPending ? (
 <Loader2 className="w-3.5 h-3.5 animate-spin" />
 ) : (
 <RotateCcw className="w-3.5 h-3.5" />
 )}
 Reopen Job
 </button>
 </div>
 </div>
 )}

 {quote.status === 'cancelled' && (
 <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
 <XCircle className="w-8 h-8 text-red-500 mx-auto mb-2" />
 <p className="font-semibold text-red-800 text-sm">Job Cancelled</p>
 </div>
 )}

 {/* Manual Close (always available unless terminal) */}
 {!['closed', 'cancelled', 'final_paid'].includes(quote.status) && (
 <div className="pt-4 mt-2 border-t border-zinc-100">
 <button onClick={handleManualClose} data-testid="button-manual-close"
 className="inline-flex items-center justify-center w-full gap-2 h-8 px-3 rounded-lg text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900 text-xs font-medium transition-colors">
 <XCircle className="w-3.5 h-3.5" /> Manual Close / Cancel
 </button>
 </div>
 )}

 </div>
 </div>

 )}
 {/* Payment Summary */}
 <div className="bg-white border border-zinc-200 rounded-none overflow-hidden ">
 <div className="px-5 py-4 border-b border-zinc-100">
 <h3 className="text-sm font-semibold text-zinc-900">Payment Status</h3>
 </div>
 <div className="p-5 space-y-3">
 {paymentSummary.pricingPending ? <p className="text-sm text-amber-800" data-testid="payment-pricing-pending">Pricing pending — no deposit or balance is due from this incomplete quotation. Existing payment evidence is retained below.</p> : <>
 <div className={`flex items-center justify-between p-3 rounded-lg border ${verifiedPaymentSummary.paid>0 ? 'bg-emerald-50 border-emerald-200' : 'bg-zinc-50 border-zinc-200'}`}>
 <div className="flex items-center gap-2">
 <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${verifiedPaymentSummary.paid>0 ? 'bg-emerald-500 text-white' : 'bg-zinc-200 text-zinc-500'}`}>
 {verifiedPaymentSummary.paid>0 ? '✓' : '1'}
 </div>
 <span className={`text-sm font-medium ${verifiedPaymentSummary.paid>0 ? 'text-emerald-800' : 'text-zinc-700'}`}>Verified payments recorded</span>
 </div>
 <span className={`text-sm font-semibold tabular-nums ${verifiedPaymentSummary.paid>0 ? 'text-emerald-800' : 'text-zinc-900'}`} data-testid="payment-status-received">
 {formatMoney(verifiedPaymentSummary.paid)}
 </span>
 </div>
 
 <div className={`flex items-center justify-between p-3 rounded-lg border ${verifiedPaymentSummary.settled&&!receiptHistoryPending ? 'bg-emerald-50 border-emerald-200' : 'bg-zinc-50 border-zinc-200'}`}>
 <div className="flex items-center gap-2">
 <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${verifiedPaymentSummary.settled&&!receiptHistoryPending ? 'bg-emerald-500 text-white' : 'bg-zinc-200 text-zinc-500'}`}>
 {verifiedPaymentSummary.settled&&!receiptHistoryPending ? '✓' : '2'}
 </div>
 <span className="text-sm font-medium text-zinc-700">{receiptHistoryPending?"Balance pending bank review":"Outstanding against quotation"}</span>
 </div>
 <span className="text-sm font-semibold tabular-nums text-zinc-900" data-testid="payment-status-outstanding">
 {receiptHistoryPending?"Not confirmed":formatMoney(verifiedPaymentSummary.outstanding)}
 </span>
 </div>

 {!!quote.leadIntake?.paymentCollectionHold&&<p className="text-xs text-amber-800" data-testid="payment-collection-hold">Collection held for staff review. This is not a payment request; do not pay again.</p>}
 {Number(quote.additionalCharge || 0) > 0 && (
 <div className="flex items-center justify-between p-3 rounded-lg border bg-amber-50 border-amber-200">
 <div className="flex items-center gap-2">
 <div className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold bg-amber-400 text-white">!</div>
 <div>
 <span className="text-sm font-medium text-amber-800">Additional Charge</span>
 {quote.additionalChargeNote && <p className="text-xs text-amber-700 mt-0.5">{quote.additionalChargeNote}</p>}
 </div>
 </div>
 <span className="text-sm font-semibold tabular-nums text-amber-900" data-testid="text-additional-charge">
 {formatMoney(quote.additionalCharge)}
 </span>
 </div>
 )}

 {!!quote.secondDayContinuation && (
 <div className="flex items-center justify-between p-3 rounded-lg border bg-indigo-50 border-indigo-200">
 <div className="flex items-center gap-2">
 <div className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold bg-indigo-400 text-white">2</div>
 <div>
 <span className="text-sm font-medium text-indigo-800">Second-Day Continuation</span>
 <p className="text-xs text-indigo-700 mt-0.5">${PricingConfig.secondDay.returnFee} return + {Number(quote.secondDayCrewSize) || PricingConfig.secondDay.defaultCrewSize} men × {Number(quote.secondDayHours) || 0}h × ${PricingConfig.secondDay.perPersonHourlyRate}/man · already included in total &amp; balance</p>
 </div>
 </div>
 <span className="text-sm font-semibold tabular-nums text-indigo-900" data-testid="text-second-day-charge">
 {formatMoney(calcSecondDayContinuation(true, quote.secondDayHours || 0, quote.secondDayCrewSize).fee)}
 </span>
 </div>
 )}
 </>}
 </div>
 </div>

 {/* Payments — partial-payment ledger */}
 <div className="bg-white border border-zinc-200 rounded-none overflow-hidden">
 <div className="px-5 py-4 border-b border-zinc-100 flex items-center justify-between">
 <h3 className="text-sm font-semibold text-zinc-900">Payments</h3>
 {!paymentSummary.pricingPending && !quote.finalPaidAt && quote.paymentStatus !== 'paid_in_full' && (
 <button
 onClick={() => { setPayAmount(balanceOwing > 0 ? balanceOwing.toFixed(2) : ""); setShowRecordPayment(true); }}
 data-testid="button-record-payment"
 className="h-8 px-3 bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-semibold uppercase tracking-wide rounded-none flex items-center gap-1.5 transition-colors"
 >
 <Plus className="w-3.5 h-3.5" /> Record Payment
 </button>
 )}
 </div>
 <div className="p-5 space-y-3">
 <div className="grid grid-cols-2 gap-3">
 <div className="p-3 rounded-lg border bg-emerald-50 border-emerald-200">
 <div className="text-[10px] font-semibold text-emerald-700 uppercase tracking-wide">{quote.paymentEvidence?.status==="missing"?"Historical paid summary · evidence pending":"Paid so far"}</div>
 <div className="text-lg font-bold tabular-nums text-emerald-800" data-testid="text-paid-so-far">{formatMoney(paidSoFar)}</div>
 </div>
 <div className={`p-3 rounded-lg border ${balanceOwing > 0 ? 'bg-amber-50 border-amber-200' : 'bg-zinc-50 border-zinc-200'}`}>
 <div className={`text-[10px] font-semibold uppercase tracking-wide ${balanceOwing > 0 ? 'text-amber-700' : 'text-zinc-500'}`}>{paymentSummary.pricingPending ? "Amount due" : "Balance owing"}</div>
 <div className={`text-lg font-bold tabular-nums ${balanceOwing > 0 ? 'text-amber-900' : 'text-zinc-700'}`} data-testid="text-balance-owing">{paymentSummary.pricingPending ? "Pricing pending" : formatMoney(balanceOwing)}</div>
 </div>
 </div>
 {balanceOwing <= 0 && (quote.finalPaidAt || quote.paymentStatus === 'paid_in_full') && (
 <div className="flex items-center gap-2 text-sm font-semibold text-emerald-700" data-testid="status-paid-in-full">
 <CheckCircle2 className="w-4 h-4" /> {quote.paymentEvidence?.status==="missing"?"Payment evidence needs reconciliation":"Paid in full"}
 </div>
 )}
 {quotePaymentsList.length > 0 ? (
 <div className="divide-y divide-zinc-100 border-t border-zinc-100 pt-1">
 {quotePaymentsList.map((p: any) => (
 <div key={p.id} className="flex items-center justify-between py-2" data-testid={`row-payment-${p.id}`}>
 <div className="min-w-0">
 <div className="text-sm font-semibold text-zinc-900 tabular-nums">{formatMoney(p.amount)} <span className="text-xs font-medium text-zinc-500 uppercase">· {String(p.method || 'cash').replace('_', ' ')}</span></div>
 <div className="text-[11px] text-zinc-500">{p.paidAt ? new Date(p.paidAt).toLocaleDateString('en-SG', { day: 'numeric', month: 'short', year: 'numeric' }) : ''}{p.note ? ` — ${p.note}` : ''}</div>
 </div>
 <button
 onClick={() => { if (confirm('Remove this payment? The balance will be updated.')) deletePayment.mutate(p.id); }}
 disabled={deletePayment.isPending}
 data-testid={`button-delete-payment-${p.id}`}
 className="text-zinc-400 hover:text-red-600 p-1 disabled:opacity-50 transition-colors"
 title="Remove payment"
 >
 <Trash2 className="w-4 h-4" />
 </button>
 </div>
 ))}
 </div>
 ) : (
 <p className="text-xs text-zinc-500" data-testid="payment-evidence-warning">
 {quote.paymentEvidence?.status==="verified_legacy"
 ? "Historical payment is supported by a verified settlement audit, but has no receipt row. Booking confirmation will reconcile that same payment once; do not collect it again."
 : quote.paymentEvidence?.status==="missing"
 ? quote.paymentEvidence.reason
 : "No received-payment ledger entries recorded."}
 </p>
 )}
 <PaymentEvidenceCorrection quote={quote}/>
 {paidSoFar>Number(quote.total)+.005&&<p className="text-amber-700 text-sm">
   Received funds exceed the quote by {formatMoney(paidSoFar-Number(quote.total))}. Staff reconciliation/refund review is needed; this is not extra quoted revenue.
 </p>}
 {quote.paymentEvidence?.status==="missing"&&<button className="mt-2 underline text-sm"
   onClick={()=>setShowPayNowConfirm(true)}>Record funds verified in the bank — repair receipt history</button>}
 </div>
 </div>

 {/* Overtime / Additional Charges Calculator — relocation jobs only */}
 {['in_progress', 'at_pickup', 'in_transit', 'at_dropoff', 'completed', 'final_payment_requested', 'final_paid', 'closed'].includes(quote.status) &&
 (quote.items || []).some((item: any) => item.serviceType === 'relocate') && (
 <div className="bg-white border border-zinc-200 rounded-none overflow-hidden ">
 <div className="px-5 py-4 border-b border-zinc-100 flex items-center gap-2">
 <Timer className="w-4 h-4 text-amber-500" />
 <h3 className="text-sm font-semibold text-zinc-900">Overtime / Additional Charges</h3>
 </div>
 <div className="p-5 space-y-4">
 <p className="text-xs text-zinc-500">This job is scheduled for <strong>{jobSchedule.crewSize} mover{jobSchedule.crewSize !== 1 ? 's' : ''} × {jobSchedule.scheduledHours}h</strong> ({jobSchedule.scheduledMinutes} min). Overtime beyond that is <strong>${jobSchedule.overtimePerManPerHour}/mover/hr</strong> = ${jobSchedule.ratePerBlock}/{jobSchedule.blockMinutes} min block — <strong>no cap</strong>.</p>

 {/* Overtime calculator */}
 <div className="space-y-2">
 <label className="text-xs font-medium text-zinc-600">Actual job duration (minutes)</label>
 <div className="flex gap-2 items-center">
 <input
 type="number"
 min="0"
 step="5"
 placeholder="e.g. 120"
 value={jobMinutes}
 onChange={e => setJobMinutes(e.target.value)}
 data-testid="input-job-minutes"
 className="flex-1 h-9 px-3 text-sm border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
 />
 {jobMinutes && Number(jobMinutes) > 0 && (
 <div className="text-sm font-semibold text-amber-700 tabular-nums whitespace-nowrap">
 {(() => {
 const { blocks, charge, ratePerBlock } = calcOvertimeCharge(Number(jobMinutes), { includedMinutes: jobSchedule.scheduledMinutes, crewSize: jobSchedule.crewSize });
 return charge > 0
 ? `${blocks} block${blocks !== 1 ? 's' : ''} × $${ratePerBlock} = $${charge.toFixed(2)}`
 : 'No overtime';
 })()}
 </div>
 )}
 </div>
 {jobMinutes && Number(jobMinutes) > 0 && calcOvertimeCharge(Number(jobMinutes), { includedMinutes: jobSchedule.scheduledMinutes, crewSize: jobSchedule.crewSize }).charge > 0 && (
 <button
 data-testid="button-use-overtime"
 onClick={() => {
 const { blocks, charge, ratePerBlock } = calcOvertimeCharge(Number(jobMinutes), { includedMinutes: jobSchedule.scheduledMinutes, crewSize: jobSchedule.crewSize });
 setAddChargeCustom(charge.toFixed(2));
 setAddChargeNote(`Overtime: ${blocks} block${blocks !== 1 ? 's' : ''} × $${ratePerBlock} (job was ${jobMinutes} min vs ${jobSchedule.scheduledMinutes} min scheduled)`);
 }}
 className="text-xs text-[#0A0A0A] hover:underline"
 >
 → Use this amount
 </button>
 )}
 </div>

 <div className="border-t border-zinc-100 pt-4 space-y-3">
 <div className="space-y-1">
 <label className="text-xs font-medium text-zinc-600">Charge amount ($)</label>
 <input
 type="number"
 min="0"
 step="0.01"
 placeholder="0.00"
 value={addChargeCustom}
 onChange={e => setAddChargeCustom(e.target.value)}
 data-testid="input-additional-charge-amount"
 className="w-full h-9 px-3 text-sm border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
 />
 </div>
 <div className="space-y-1">
 <label className="text-xs font-medium text-zinc-600">Note (optional)</label>
 <input
 type="text"
 placeholder="Reason for charge…"
 value={addChargeNote}
 onChange={e => setAddChargeNote(e.target.value)}
 data-testid="input-additional-charge-note"
 className="w-full h-9 px-3 text-sm border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
 />
 </div>
 <button
 data-testid="button-save-additional-charge"
 disabled={saveAdditionalCharge.isPending}
 onClick={() => saveAdditionalCharge.mutate({
 additionalCharge: addChargeCustom || '0',
 additionalChargeNote: addChargeNote,
 })}
 className="w-full h-9 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-sm font-semibold transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
 >
 {saveAdditionalCharge.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
 Save Additional Charge
 </button>
 {Number(quote.additionalCharge || 0) > 0 && (
 <button
 data-testid="button-clear-additional-charge"
 onClick={() => { saveAdditionalCharge.mutate({ additionalCharge: '0', additionalChargeNote: '' }); setAddChargeCustom(''); setAddChargeNote(''); }}
 className="w-full text-xs text-zinc-400 hover:text-zinc-600 underline"
 >
 Clear additional charge
 </button>
 )}
 </div>
 </div>
 </div>
 )}

 {/* Work Photos */}
 {workPhotos.length > 0 && (
 <div className="bg-white border border-zinc-200 rounded-none overflow-hidden ">
 <div className="px-5 py-4 border-b border-zinc-100">
 <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
 <Camera className="w-3.5 h-3.5" /> Work Photos
 </p>
 </div>
 <div className="p-4">
 <div className="grid grid-cols-3 gap-2">
 {workPhotos.map((url, i) => (
 <button
 key={i}
 type="button"
 data-testid={`img-work-photo-${i}`}
 onClick={() => setLightboxPhoto(url)}
 className="group relative aspect-square rounded-lg overflow-hidden border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
 >
 <img src={url} alt={`Work photo ${i + 1}`} className="w-full h-full object-cover" />
 <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
 <span className="text-white text-xs font-medium">View</span>
 </div>
 </button>
 ))}
 </div>
 </div>
 </div>
 )}

 {/* Customer Acknowledgment (completion sign-off) */}
 {quote.completionSignatureUrl && (
 <div className="bg-white border border-zinc-200 rounded-none overflow-hidden ">
 <div className="px-5 py-4 border-b border-zinc-100">
 <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
 <PenLine className="w-3.5 h-3.5" /> Customer Acknowledgment
 </p>
 </div>
 <div className="p-4 space-y-3">
 <div className="grid grid-cols-2 gap-3">
 <div>
 <p className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">Signed By</p>
 <p className="text-sm font-bold text-[#0A0A0A] mt-0.5" data-testid="text-signed-name">
 {quote.completionSignedName || "—"}
 </p>
 </div>
 <div>
 <p className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">Signed At</p>
 <p className="text-sm font-bold text-[#0A0A0A] mt-0.5" data-testid="text-signed-at">
 {quote.completionSignedAt ? new Date(quote.completionSignedAt).toLocaleString("en-SG", { dateStyle: "medium", timeStyle: "short" }) : "—"}
 </p>
 </div>
 </div>
 <div>
 <p className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider mb-1.5">Signature</p>
 <div className="border border-zinc-200 rounded-lg bg-white p-2 inline-block">
 <img
 src={quote.completionSignatureUrl}
 alt="Customer signature"
 className="max-h-32 w-auto"
 data-testid="img-signature"
 />
 </div>
 </div>
 </div>
 </div>
 )}

 </div>
 </div>
 </div>

 {/* Mobile floating action bar — primary action pinned to bottom, hidden on lg */}
 {!isEditing && !paymentSummary.pricingPending && (() => {
 const s = quote.status;
 if (['submitted', 'under_review'].includes(s)) {
 if ((quote as any).invoiceType === 'commercial') return (
 <div className="lg:hidden fixed bottom-16 left-0 right-0 z-30 px-4 pb-2 pt-1 bg-white border-t border-zinc-200 shadow-[0_-4px_16px_rgba(0,0,0,0.08)]">
 <button onClick={handleApproveCommercialBooking} disabled={approveCommercial.isPending}
 data-testid="button-approve-commercial-booking-mobile"
 className="w-full inline-flex items-center justify-center gap-2 h-11 rounded-none bg-[#0A0A0A] hover:bg-black text-white text-sm font-semibold transition-colors disabled:opacity-50">
 <CalendarCheck className="w-4 h-4" />
 {approveCommercial.isPending ? "Confirming…" : "Approve & Book Job (Commercial)"}
 </button>
 </div>
 );
 return (
 <div className="lg:hidden fixed bottom-16 left-0 right-0 z-30 px-4 pb-2 pt-1 bg-white border-t border-zinc-200 shadow-[0_-4px_16px_rgba(0,0,0,0.08)] space-y-1.5">
 <button onClick={handleApproveAndRequestDeposit} disabled={updateStatus.isPending}
 className="w-full inline-flex items-center justify-center gap-2 h-11 rounded-none bg-[#0A0A0A] hover:bg-black text-white text-sm font-semibold transition-colors disabled:opacity-50">
 <CheckCircle2 className="w-4 h-4" /> Approve & Request Deposit
 </button>
 <button
 onClick={() => setShowPayNowConfirm(true)}
 data-testid="button-mark-deposit-already-paid-mobile"
 className="w-full inline-flex items-center justify-center gap-2 h-9 rounded-none bg-white border border-emerald-300 text-emerald-700 text-xs font-semibold transition-colors">
 <QrCode className="w-3.5 h-3.5" /> Record funds verified in bank
 </button>
 </div>
 );
 }
 if (s === 'deposit_paid') return (
 <div className="lg:hidden fixed bottom-16 left-0 right-0 z-30 px-4 pb-2 pt-1 bg-white border-t border-zinc-200 shadow-[0_-4px_16px_rgba(0,0,0,0.08)]">
 <button onClick={handleConfirmBooking} disabled={confirmBooking.isPending}
 className="w-full inline-flex items-center justify-center gap-2 h-11 rounded-none bg-[#0A0A0A] hover:bg-black text-white text-sm font-semibold transition-colors disabled:opacity-50">
 <CalendarCheck className="w-4 h-4" /> Confirm Booking
 </button>
 </div>
 );
 if (['deposit_paid', 'booked', 'assigned', 'in_progress', 'at_pickup', 'in_transit', 'at_dropoff', 'completed'].includes(s)) {
 if ((quote as any).invoiceType === 'commercial' && s === 'completed') return (
 <div className="lg:hidden fixed bottom-16 left-0 right-0 z-30 px-4 pb-2 pt-1 bg-white border-t border-zinc-200 shadow-[0_-4px_16px_rgba(0,0,0,0.08)]">
 <button onClick={handleSendCommercialInvoice} disabled={sendCommercialInvoice.isPending||!!sendCommercialInvoice.data?.warning}
 data-testid="button-send-commercial-invoice-mobile"
 className="w-full inline-flex items-center justify-center gap-2 h-11 rounded-none bg-[#0A0A0A] hover:bg-black text-white text-sm font-semibold transition-colors disabled:opacity-50">
 <DollarSign className="w-4 h-4" />
 {sendCommercialInvoice.isPending ? "Sending Invoice…" : "Send Invoice (Net 30)"}
 </button>
 </div>
 );
 // Full-payment jobs are already paid in full up front — no final payment
 // to collect, so the mobile action bar has nothing to show here.
 if (isFullPayQuote && !hasOutstandingBalance) return null;
 return (
 <div className="lg:hidden fixed bottom-16 left-0 right-0 z-30 px-4 pb-2 pt-1 bg-white border-t border-zinc-200 shadow-[0_-4px_16px_rgba(0,0,0,0.08)]">
 <button
 onClick={handleRequestFinalPayment}
 disabled={requestFinalPayment.isPending || finalPaymentBlockedByPhases}
 title={finalPaymentBlockedByPhases ? "Tick all job phases before requesting final payment" : undefined}
 className="w-full inline-flex items-center justify-center gap-2 h-11 rounded-none bg-[#0A0A0A] hover:bg-black text-white text-sm font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
 >
 <CheckCircle2 className="w-4 h-4" />
 {finalPaymentBlockedByPhases
 ? `Waiting on ${applicablePhases.filter(p => !phaseStatus(p.key)).map(p => p.label).join(" + ")}`
 : "Mark Done & Request Final Payment"}
 </button>
 </div>
 );
 }
 if (s === 'deposit_requested') return (
 <div className="lg:hidden fixed bottom-16 left-0 right-0 z-30 px-4 pb-2 pt-1 bg-white border-t border-zinc-200 shadow-[0_-4px_16px_rgba(0,0,0,0.08)]">
 <div className="flex items-center gap-2">
 <button
 onClick={() => setShowPayNowConfirm(true)}
 data-testid="button-mark-paynow-paid-mobile"
 className="flex-1 inline-flex items-center justify-center gap-1.5 h-10 px-3 rounded-none bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold transition-colors">
 <QrCode className="w-4 h-4" /> PayNow Received
 </button>
 <div className="flex-1">
 <PaymentChannelButtons
 quote={quote}
 emailPending={resendDepositEmail.isPending}
 whatsappPending={sendWhatsAppPayment.isPending}
 onEmail={() => resendDepositEmail.mutate()}
 onWhatsApp={(phone) => sendWhatsAppPayment.mutate(phone)}
 onCopy={() => setShowPaymentMessageDialog(true)}
 compact
 />
 </div>
 </div>
 </div>
 );
 return null;
 })()}

 {/* Payment-message snippet dialog (manual fallback when WhatsApp delivery fails) */}
 <PaymentMessageDialog
 open={showPaymentMessageDialog}
 onClose={() => setShowPaymentMessageDialog(false)}
 fetchUrl={`/api/admin/quotes/${id}/payment-message`}
 />

 {/* Invoice / receipt sharing dialog (only available once paid in full) */}
 <InvoiceMessageDialog
 open={showInvoiceDialog}
 onClose={() => setShowInvoiceDialog(false)}
 fetchUrl={`/api/admin/quotes/${id}/invoice-message`}
 />

 {/* PayNow Confirmation Modal */}
 {showPayNowConfirm && (
 <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" data-testid="modal-paynow-confirm">
 <div className="bg-white rounded-none w-full max-w-md overflow-hidden">
 <div className="px-6 py-4 border-b border-zinc-100 flex items-center gap-3 bg-emerald-50">
 <QrCode className="w-5 h-5 text-emerald-600" />
 <h2 className="text-base font-semibold text-emerald-800">Record verified bank funds</h2>
 </div>
 <div className="p-6 space-y-4">
 <div className="bg-zinc-50 border border-zinc-200 rounded-lg px-4 py-3 space-y-1 text-sm">
 <div className="flex justify-between">
 <span className="text-zinc-500">Reference</span>
 <span className="font-bold font-mono text-zinc-900">{quote?.referenceNo}</span>
 </div>
 <div className="flex justify-between">
 <span className="text-zinc-500">Customer</span>
 <span className="font-semibold text-zinc-900">{quote?.customer?.name}</span>
 </div>
 <div className="flex justify-between">
 <span className="text-zinc-500">Deposit Amount</span>
 <span className="font-bold text-emerald-700">{formatMoney(effectiveDeposit)}</span>
 </div>
 </div>
 <div>
 <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wide mb-1.5">
 Bank reference / verification note
 </label>
 <input
 type="text"
 value={payNowNote}
 onChange={e => setPayNowNote(e.target.value)}
 placeholder="e.g. PayNow ref #12345678, received 11:30am"
 data-testid="input-paynow-note"
 className="w-full h-9 px-3 border border-zinc-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-400 transition-colors"
 />
 </div>
 <p className="text-xs text-zinc-500 leading-relaxed">
 This records funds actually received, not a payment request. A screenshot, sent request or accepted WhatsApp message does not prove payment. It does not book an appointment.
 </p>
 <label className="block text-sm">Actual SGD amount received (leave blank for the remaining initial payment)
   <input className="w-full border p-2" type="number" min="0.01" step="0.01" value={payNowAmount}
     onChange={e=>setPayNowAmount(e.target.value)} data-testid="bank-received-amount"/></label>
 <label className="flex gap-2 text-sm"><input type="checkbox" checked={payNowBankChecked}
   onChange={e=>setPayNowBankChecked(e.target.checked)} data-testid="bank-funds-verified"/>
   I checked the company bank account and verified these funds were received.</label>
 </div>
 <div className="px-6 pb-6 flex gap-3">
 <button
 onClick={() => { setShowPayNowConfirm(false); setPayNowNote(""); }}
 className="flex-1 h-10 border border-zinc-200 rounded-lg text-sm font-medium text-zinc-700 hover:bg-zinc-50 transition-colors"
 >
 Cancel
 </button>
 <button
 onClick={() => markPayNowPaid.mutate()}
 disabled={markPayNowPaid.isPending||!payNowBankChecked||payNowNote.trim().length<3}
 data-testid="button-confirm-paynow"
 className="flex-1 h-10 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-50 transition-colors"
 >
 {markPayNowPaid.isPending
 ? <><Loader2 className="w-4 h-4 animate-spin" /> Confirming…</>
 : <><CheckCircle2 className="w-4 h-4" /> Confirm Received</>}
 </button>
 </div>
 </div>
 </div>
 )}

 {/* Record Payment Modal — log a partial/installment payment */}
 {showRecordPayment && (
 <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" data-testid="modal-record-payment">
 <div className="bg-white rounded-none w-full max-w-md overflow-hidden">
 <div className="px-6 py-4 border-b border-zinc-100 flex items-center gap-3 bg-zinc-50">
 <Wallet className="w-5 h-5 text-zinc-700" />
 <h2 className="text-base font-semibold text-zinc-900">Record Payment</h2>
 </div>
 <div className="p-6 space-y-4">
 <div className="bg-zinc-50 border border-zinc-200 rounded-lg px-4 py-3 flex justify-between text-sm">
 <span className="text-zinc-500">Balance owing</span>
 <span className="font-bold tabular-nums text-amber-900">{formatMoney(balanceOwing)}</span>
 </div>
 <div>
 <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wide mb-1.5">Amount (S$)</label>
 <input type="number" min="0" step="0.01" value={payAmount} onChange={e => setPayAmount(e.target.value)} placeholder="0.00" data-testid="input-payment-amount" className="w-full h-9 px-3 border border-zinc-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-zinc-400" />
 </div>
 <div className="grid grid-cols-2 gap-3">
 <div>
 <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wide mb-1.5">Method</label>
 <select value={payMethod} onChange={e => setPayMethod(e.target.value)} data-testid="select-payment-method" className="w-full h-9 px-3 border border-zinc-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-zinc-400 bg-white">
 <option value="cash">Cash</option>
 <option value="paynow">PayNow</option>
 <option value="bank_transfer">Bank Transfer</option>
 <option value="card">Card</option>
 <option value="cheque">Cheque</option>
 <option value="other">Other</option>
 </select>
 </div>
 <div>
 <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wide mb-1.5">Date received</label>
 <input type="datetime-local" aria-label="Verified bank receipt time in Singapore, optional" value={payDate} onChange={e => setPayDate(e.target.value)} data-testid="input-payment-date" className="w-full h-9 px-3 border border-zinc-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-zinc-400" />
 <p className="text-xs text-zinc-500">Only enter the Singapore bank receipt time if verified. Otherwise the receipt records when staff verified it, not an invented historic bank time.</p>
 </div>
 </div>
 <div>
 <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wide mb-1.5">Receipt reference / verification note</label>
 <input type="text" value={payNoteText} onChange={e => setPayNoteText(e.target.value)} placeholder="e.g. cash on site, balance next week" data-testid="input-payment-note" className="w-full h-9 px-3 border border-zinc-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-zinc-400" />
 <label className="flex gap-2 mt-2 text-sm"><input type="checkbox" checked={payNowBankChecked}
   onChange={e=>setPayNowBankChecked(e.target.checked)}/>I verified funds actually received, not a request, screenshot or customer claim.</label>
 </div>
 </div>
 <div className="px-6 pb-6 flex gap-3">
 <button onClick={() => setShowRecordPayment(false)} data-testid="button-cancel-payment" className="flex-1 h-10 border border-zinc-200 rounded-lg text-sm font-medium text-zinc-700 hover:bg-zinc-50 transition-colors">Cancel</button>
 <button onClick={() => recordPayment.mutate()} disabled={recordPayment.isPending || !payNowBankChecked||payNoteText.trim().length<3||!payAmount || parseFloat(payAmount) <= 0} data-testid="button-save-payment" className="flex-1 h-10 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-50 transition-colors">
 {recordPayment.isPending ? <><Loader2 className="w-4 h-4 animate-spin" /> Saving…</> : <><CheckCircle2 className="w-4 h-4" /> Save Payment</>}
 </button>
 </div>
 </div>
 </div>
 )}

 {/* Mark PayNow Final Payment Received Modal */}
 {showFinalPayConfirm && (
 <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" data-testid="modal-collect-final">
 <div className="bg-white rounded-none w-full max-w-md overflow-hidden">
 <div className="px-6 py-4 border-b border-zinc-100 flex items-center gap-3 bg-emerald-50">
 <QrCode className="w-5 h-5 text-emerald-600" />
 <h2 className="text-base font-semibold text-emerald-800">Mark PayNow Payment Received</h2>
 </div>
 <div className="p-6 space-y-4">
 <div className="bg-zinc-50 border border-zinc-200 rounded-lg px-4 py-3 space-y-1 text-sm">
 <div className="flex justify-between">
 <span className="text-zinc-500">Reference</span>
 <span className="font-bold font-mono text-zinc-900">{quote?.referenceNo}</span>
 </div>
 <div className="flex justify-between">
 <span className="text-zinc-500">Customer</span>
 <span className="font-semibold text-zinc-900">{quote?.customer?.name}</span>
 </div>
 {quote?.depositPaidAt && (
 <div className="flex justify-between">
 <span className="text-zinc-500">Deposit Paid</span>
 <span className="text-emerald-700 font-medium">{formatMoney(effectiveDeposit)} ✓</span>
 </div>
 )}
 <div className="flex justify-between border-t border-zinc-200 pt-1 mt-1">
 <span className="text-zinc-700 font-semibold">Balance Due</span>
 <span className="font-bold text-emerald-700 text-base">{formatMoney(effectiveFinal)}</span>
 </div>
 </div>
 <div>
 <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wide mb-1.5">
 PayNow Reference <span className="text-zinc-400 font-normal">(optional)</span>
 </label>
 <input
 type="text"
 value={finalPayNote}
 onChange={e => setFinalPayNote(e.target.value)}
 placeholder="e.g. PayNow ref #98765, received 2:15pm"
 data-testid="input-final-pay-note"
 className="w-full h-9 px-3 border border-zinc-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-400 transition-colors"
 />
 </div>
 <p className="text-xs text-zinc-500 leading-relaxed">
 Record only funds verified in the company bank account. This is not a payment request, booking confirmation or proof that a notification was delivered.
 </p>
 <label className="flex gap-2 text-sm"><input type="checkbox" checked={payNowBankChecked}
   onChange={e=>setPayNowBankChecked(e.target.checked)}/>I checked the company bank account and verified the final funds were received.</label>
 </div>
 <div className="px-6 pb-6 flex gap-3">
 <button
 onClick={() => { setShowFinalPayConfirm(false); setFinalPayNote(""); }}
 className="flex-1 h-10 border border-zinc-200 rounded-lg text-sm font-medium text-zinc-700 hover:bg-zinc-50 transition-colors"
 >
 Cancel
 </button>
 <button
 onClick={() => collectFinalPayment.mutate()}
 disabled={collectFinalPayment.isPending||!payNowBankChecked||finalPayNote.trim().length<3}
 data-testid="button-confirm-final-pay"
 className="flex-1 h-10 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-50 transition-colors"
 >
 {collectFinalPayment.isPending
 ? <><Loader2 className="w-4 h-4 animate-spin" /> Processing…</>
 : <><CheckCircle2 className="w-4 h-4" /> Confirm & Close Case</>}
 </button>
 </div>
 </div>
 </div>
 )}

 {/* Delete Confirmation Modal */}
 {showDeleteConfirm && (
 <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" data-testid="modal-delete-confirm">
 <div className="bg-white rounded-none w-full max-w-md overflow-hidden">
 <div className="px-6 py-4 border-b border-zinc-100 flex items-center gap-3 bg-red-50">
 <AlertOctagon className="w-5 h-5 text-red-600" />
 <h2 className="text-base font-semibold text-red-700">Delete Job Case</h2>
 </div>
 <div className="p-6">
 <p className="text-sm text-zinc-600">
 Are you sure you want to permanently delete <strong>{quote.referenceNo}</strong> for <strong>{quote.customer?.name}</strong>?
 This action cannot be undone.
 </p>
 </div>
 <div className="px-6 py-4 border-t border-zinc-100 flex justify-end gap-3 bg-zinc-50">
 <button
 onClick={() => setShowDeleteConfirm(false)}
 disabled={deleteQuoteMutation.isPending}
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50 text-sm font-medium transition-colors"
 >
 Cancel
 </button>
 <button
 onClick={() => deleteQuoteMutation.mutate()}
 disabled={deleteQuoteMutation.isPending}
 className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm font-medium transition-colors disabled:opacity-50"
 >
 {deleteQuoteMutation.isPending ? "Deleting..." : "Yes, Delete"}
 </button>
 </div>
 </div>
 </div>
 )}

 {/* Lightbox */}
 {lightboxPhoto && (
 <div
 className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 "
 onClick={() => setLightboxPhoto(null)}
 >
 <button
 onClick={() => setLightboxPhoto(null)}
 className="absolute top-6 right-6 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 transition-colors flex items-center justify-center text-white"
 >
 <X className="w-5 h-5" />
 </button>
 <img
 src={lightboxPhoto}
 alt="Enlarged reference"
 className="max-w-full max-h-[90vh] rounded-lg object-contain"
 onClick={e => e.stopPropagation()}
 />
 </div>
 )}
 </div>
 );
}
