import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  const [path] = useLocation();
  return (
    <div data-page-not-found={path} className="min-h-screen w-full flex items-center justify-center bg-gray-50">
      <Card className="w-full max-w-md mx-4">
        <CardContent className="pt-6">
          <div className="flex mb-4 gap-2">
            <AlertCircle className="h-8 w-8 text-red-500" />
            <h1 className="text-2xl font-bold text-gray-900">404 Page Not Found</h1>
          </div>

          <p className="mt-4 text-sm text-gray-600">
            We couldn’t find this page. The link may be incorrect, or the page may have moved.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button asChild className="bg-black text-white hover:bg-black/90"><Link href="/">Back to homepage</Link></Button>
            <Button asChild variant="outline"><Link href="/estimate">Get a quotation</Link></Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
