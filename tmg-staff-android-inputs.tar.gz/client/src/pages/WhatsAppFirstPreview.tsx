import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";

export default function WhatsAppFirstPreview() {
  const [step, setStep] = useState(0);
  const [scenario, setScenario] = useState("routine");
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    const controller = new AbortController();
    setBusy(true); setError("");
    fetch(`/api/whatsapp-first/preview?step=${step}&scenario=${scenario}`, { credentials: "include", signal: controller.signal })
      .then(async r => { const value = await r.json(); if (!r.ok) throw new Error(value.message); return value; })
      .then(setData).catch(e => { if (e.name !== "AbortError") setError(e.message); })
      .finally(() => { if (!controller.signal.aborted) setBusy(false); });
    return () => controller.abort();
  }, [step, scenario]);
  const labels = ["Prepare quotation", "Accept quote & terms", "Request date/time", "Payment screenshot", "Verify test payment · still pending staff"];
  return <main className="min-h-screen bg-[#F5F4F0] p-5 pt-28 pb-28 text-black">
    <div className="max-w-5xl mx-auto space-y-5">
      <a className="text-sm underline" href="/admin/ai/whatsapp">Back to WhatsApp operations</a>
      <h1 className="text-2xl font-bold">WhatsApp-first quotation & booking preview</h1>
      <div className="border border-amber-500 bg-amber-50 p-4 rounded-xl text-sm" data-testid="non-sending-banner">
        Non-sending preview. Catalog prices and calculations are real; delivery, acceptance, capacity and payments are simulated. No customer, quote, reservation or booking is saved.
      </div>
      <div className="flex flex-wrap gap-2">
        <Button variant={scenario === "routine" ? "default" : "outline"} onClick={() => { setScenario("routine"); setStep(0); }}>Routine S$220 unit</Button>
        <Button variant={scenario === "complex" ? "default" : "outline"} onClick={() => { setScenario("complex"); setStep(0); }}>Extra visits & unboxing review</Button>
      </div>
      <div className="flex flex-wrap gap-2">{labels.map((label, index) =>
        <Button key={label} disabled={busy || scenario === "complex" && index > 0} variant={step === index ? "default" : "outline"}
          onClick={() => setStep(index)} data-testid={`preview-step-${index}`}>{index + 1}. {label}</Button>)}</div>
      {error && <p role="alert" className="text-red-700">{error}</p>}
      {busy && <p>Calculating preview…</p>}
      {data && <div className="grid gap-5 lg:grid-cols-2">
        <section className="bg-white border rounded-xl p-5 space-y-3" aria-label="Conversation preview">
          <h2 className="font-bold">Conversation · {data.state.stage.replaceAll("_", " ")}</h2>
          {data.transcript.map((message: any, i: number) => <div key={i} className={`rounded-lg p-3 text-sm whitespace-pre-wrap ${message.from === "customer" ? "bg-stone-100" : "bg-emerald-50"}`}>
            <p className="font-bold mb-1">{message.from}</p>{message.text}
          </div>)}
        </section>
        <section id="quotation" className="bg-white border rounded-xl overflow-hidden" aria-label="Quotation preview">
          <div className="bg-black text-white p-5"><p className="text-2xl font-black">TMG INSTALL</p><p>Quotation · TMG-PREVIEW · Version 1</p></div>
          <div className="p-5 space-y-4 text-sm">
            <p className="font-bold text-amber-700">{scenario === "complex" ? "REVIEW DRAFT — NOT FIXED OR PAYABLE" : "NON-SENDING PREVIEW — NOT AN ISSUED DOCUMENT"}</p>
            <p>Preview Customer<br />Preview address — not a real booking</p>
            {data.facts && typeof data.facts === "object" && Object.keys(data.facts).length > 0 && <div className="border border-amber-200 bg-amber-50/60 p-3" data-testid="preview-extracted-facts">
              <h3 className="font-bold text-amber-950">Extracted scope facts · review evidence</h3>
              <dl className="mt-2 grid gap-x-4 gap-y-2 sm:grid-cols-2">
                {Object.entries(data.facts).map(([key, value]) => <div key={key} className="border-t border-amber-200/70 pt-1.5">
                  <dt className="text-[10px] font-semibold uppercase tracking-wide text-amber-800">{key.replace(/([A-Z])/g, " $1").replace(/_/g, " ")}</dt>
                  <dd className="mt-0.5 whitespace-pre-wrap break-words text-xs text-zinc-800">{Array.isArray(value) ? value.map(v => typeof v === "object" ? JSON.stringify(v) : String(v)).join(", ") : value && typeof value === "object" ? JSON.stringify(value) : String(value ?? "Not recorded")}</dd>
                </div>)}
              </dl>
              {data.facts.extraVisits != null && <p className="mt-2 border-t border-amber-200 pt-2 text-xs font-bold text-amber-950">Crew visit count: {Number(data.facts.extraVisits) + 1} total ({data.facts.extraVisits} extra visit{Number(data.facts.extraVisits) === 1 ? "" : "s"} + initial visit)</p>}
              {Array.isArray(data.missingCharges) && data.missingCharges.length > 0 && <div className="mt-2 border-t border-amber-200 pt-2"><p className="text-xs font-bold text-red-800">Unpriced scope requiring accountable decision</p><ul className="mt-1 list-disc pl-4 text-xs text-red-800">{data.missingCharges.map((charge: string, index: number) => <li key={`${charge}-${index}`}>{charge}</li>)}</ul></div>}
            </div>}
            <p>{data.quotation.quantity} × {data.quotation.name}<br />Installation labour: S${data.quotation.labour.toFixed(2)}</p>
            {data.quotation.fees.map((line: any) => <p key={line.label}>{line.label}: S${line.amount.toFixed(2)}</p>)}
            {scenario === "routine" && <div className="border-t pt-3"><p className="font-bold">Calculated total: S${data.quotation.total.toFixed(2)}</p><p>Current required payment: S${data.quotation.dueNow.toFixed(2)}</p><p>Remaining: S${data.quotation.remaining.toFixed(2)}</p></div>}
            <p>{data.quotation.exclusions}</p>
            <p className="text-xs text-stone-600">{data.quotation.source}. Production quotation links open the existing branded TMG quote and current acceptance/payment flow.</p>
            <h3 className="font-bold">Action evidence (simulation only)</h3>
            <ul className="list-disc pl-4">{data.actionsLog.map((line: string, i: number) => <li key={i}>{line}</li>)}</ul>
          </div>
        </section>
      </div>}
    </div>
  </main>;
}
