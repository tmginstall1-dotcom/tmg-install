import { useParams, useLocation } from "wouter";
import {isReviewQuotation,isUnpricedReviewItem,isTransportPricingPending} from "@shared/quotation-document-notes";
import EditorialPaperStack from "@/components/EditorialPaperStack";
import { useQuote, useRescheduleBooking } from "@/hooks/use-quotes";
import {formatSingaporeDay} from "@/lib/singapore-calendar";
import { useSEO } from "@/hooks/use-seo";
import { StatusBadge } from "@/components/shared/StatusBadge";
import {
  CheckCircle2, CreditCard, CalendarDays, Receipt, Clock, MapPin,
  RefreshCw, AlertCircle, MessageCircle, Loader2, ArrowRight, Package, Check,
  Mail, MailWarning, ShieldCheck, Info, Image, ZoomIn,
} from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import { format, differenceInHours } from "date-fns";
import { useState, useEffect, useRef } from "react";
import { formatItemServiceLabel } from "@/lib/itemLabel";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import { SlotPicker, type SlotAvailability } from "@/components/SlotPicker";
import { groupStops, itemRouteLabel } from "@/lib/stops";
import { requiresFullUpfront } from "@shared/pricing";
import { quotePaymentSummary } from "@shared/paymentState";
import {FinancialBasisNotice} from "@/components/FinancialBasisNotice";
import { QuoteTermsBlock } from "@/components/shared/QuoteTermsBlock";
import { QuoteScheduleNote } from "@/components/shared/QuoteScheduleNote";
import { OfferValidityStatusNotice } from "@/components/OfferValidity";
import { termsAcceptedForCurrentVersion } from "@shared/businessRules";
import { api } from "@shared/routes";

interface PublicBusinessRules {
  clauses: { title: string; body: string }[];
  policyText: string;
  depositPct: number;
  fullPaymentThreshold: number;
  depositRefundableDefault: boolean;
  cancellationWindowHours: number;
  cancellationAdminFee: number;
  rescheduleFee: number;
  refundProcessingDays: number;
  workingHoursStart: string;
  workingHoursEnd: string;
  afterOfficeCutoff: string;
  afterOfficeSurchargePct: number;
  additionalTripCharge: number;
  drillingPerHoleRate: number;
}

const WHATSAPP_HREF = "https://wa.me/6580880757?text=hi";
const WHATSAPP_DISPLAY = "+65 8088 0757";

/* ─────────────────── Editorial primitives (mirror homepage) ───────────────────
   Inlined here so the quote page matches the editorial language of "/"
   without coupling the two files: signature install-green ACCENT,
   AccentSquare, DotGrid backdrop, Tag chip. Same tokens as LandingCinematic.
   ────────────────────────────────────────────────────────────────────────── */
const ACCENT = "#2af56a";
const INK = "#0a0a0a";
const PAPER = "#fafaf7";

function AccentSquare({ className = "" }: { className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={`inline-block w-[10px] h-[10px] shrink-0 ${className}`}
      style={{ background: ACCENT }}
    />
  );
}

function DotGrid({ opacity = 0.55, size = 32 }: { opacity?: number; size?: number }) {
  return (
    <div
      aria-hidden="true"
      className="absolute inset-0 pointer-events-none"
      style={{
        opacity,
        backgroundImage: "radial-gradient(circle, rgba(10,10,10,0.22) 1px, transparent 1px)",
        backgroundSize: `${size}px ${size}px`,
      }}
    />
  );
}

function Tag({
  children,
  accent = false,
  className = "",
}: {
  children: React.ReactNode;
  accent?: boolean;
  className?: string;
}) {
  return (
    <span
      className={`inline-flex items-center px-2 py-[4px] text-[10px] tracking-[0.2em] uppercase font-bold leading-none ${className}`}
      style={accent ? { background: ACCENT, color: INK } : { background: INK, color: PAPER }}
    >
      {children}
    </span>
  );
}

function formatMoney(amount: string | number | null | undefined) {
  return new Intl.NumberFormat("en-SG", { style: "currency", currency: "SGD" }).format(Number(amount || 0));
}

function getTodayPlus1() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d.toISOString().split("T")[0];
}

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1], delay },
});

export default function QuoteStatus() {
  const params = useParams();
  const id = params.id!;
  const refNo = new URLSearchParams(window.location.search).get("ref") ?? undefined;
  const { data: quote, isLoading } = useQuote(id, refNo);
  useSEO({
    title: quote ? `Quote ${quote.referenceNo} | TMG Install` : "Your Quote | TMG Install",
    description: "View your furniture installation quote status, pay your deposit, and manage your booking with TMG Install.",
    canonical: `https://tmginstall.com/quotes/${id}`,
    noIndex: true,
  });
  const { toast } = useToast();

  const rescheduleMutation = useRescheduleBooking();

  const { data: slotAvailability = null } = useQuery<SlotAvailability>({
    queryKey: ["/api/slots/availability"],
    queryFn: () => fetch("/api/slots/availability").then(r => r.json()),
  });

  const { data: businessRules } = useQuery<PublicBusinessRules>({
    queryKey: ["/api/business-rules"],
    queryFn: () => fetch("/api/business-rules").then(r => r.json()),
  });

  const [showReschedule, setShowReschedule] = useState(false);
  const [rescheduleDate, setRescheduleDate] = useState("");
  const [rescheduleTime, setRescheduleTime] = useState("");
  const [checkoutLoading, setCheckoutLoading] = useState(false);
  const [accepting, setAccepting] = useState(false);
  const acceptanceRef = useRef<HTMLDivElement>(null);
  const [verifying, setVerifying] = useState(false);
  const [paymentVerified, setPaymentVerified] = useState(false);
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);

  // Fetch job updates (arrival + completion photos) via the public tracker API
  const { data: trackerData } = useQuery<{
    updates: { statusChange: string; photoUrls: string[]; note: string | null; createdAt: string }[];
  }>({
    queryKey: [`/api/public/track/${quote?.referenceNo}`],
    queryFn: () => fetch(`/api/public/track/${quote!.referenceNo}`).then(r => r.json()),
    enabled: !!quote?.referenceNo && ["in_progress", "at_pickup", "in_transit", "at_dropoff", "completed", "final_payment_requested", "final_paid", "closed"].includes(quote?.status ?? ""),
    staleTime: 60_000,
  });

  const workPhotos = (trackerData?.updates ?? [])
    .filter(u => ["in_progress", "at_pickup", "in_transit", "at_dropoff", "completed"].includes(u.statusChange))
    .flatMap(u => u.photoUrls ?? [])
    .filter(Boolean);

  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    const sessionId = p.get("session_id");
    if (p.get("payment_success") === "1" && sessionId) {
      setVerifying(true);
      // Remove transient payment params but preserve ?ref= so unauthenticated quote access stays valid
      p.delete("payment_success");
      p.delete("session_id");
      const cleanSearch = p.toString() ? `?${p.toString()}` : "";
      window.history.replaceState({}, "", window.location.pathname + cleanSearch);
      apiRequest("POST", `/api/quotes/${id}/verify-payment`, { session_id: sessionId, referenceNo: refNo })
        .then(() => {
          setPaymentVerified(true);
          queryClient.invalidateQueries({ queryKey: [`/api/quotes/${id}`] });
          toast({ title: "Payment confirmed!", description: "Your payment has been received." });
        })
        .catch(() => {
          toast({ title: "Could not confirm payment", description: "Please contact us on WhatsApp if your payment was charged.", variant: "destructive" });
        })
        .finally(() => setVerifying(false));
    }
  }, []);

  const handleStripeCheckout = async (type: "deposit" | "final") => {
    if (offerValidityBlocksAction) {
      toast({ title: "Staff review needed", description: "Please contact our team to review this quotation before accepting or making a new payment.", variant: "destructive" });
      return;
    }
    setCheckoutLoading(true);
    try {
      const res = await apiRequest("GET", `/api/quotes/${id}/checkout?type=${type}&ref=${encodeURIComponent(quote.referenceNo)}&version=${quote.version}`);
      const data = await res.json();
      if (data.url) window.location.href = data.url;
      else toast({ title: "Payment unavailable", description: "Could not create payment link. Please contact us.", variant: "destructive" });
    } catch (e: any) {
      if (typeof e?.message === "string" && e.message.includes("TERMS_NOT_ACCEPTED")) {
        toast({ title: "Please accept the terms first", description: "Tick the acceptance box below to continue to payment.", variant: "destructive" });
        acceptanceRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      } else {
        toast({ title: "Error", description: "Could not start payment. Please try again.", variant: "destructive" });
      }
    } finally {
      setCheckoutLoading(false);
    }
  };

  const handleAcceptTerms = async () => {
    if (!quote) return;
    if (offerValidityBlocksAction) {
      toast({ title: "Staff review needed", description: "Please contact our team to review this quotation before accepting it.", variant: "destructive" });
      return;
    }
    setAccepting(true);
    try {
      await apiRequest("POST", `/api/quotes/${id}/accept-terms`, { referenceNo: quote.referenceNo, version: quote.version });
      await queryClient.invalidateQueries({ queryKey: [api.quotes.get.path, id] });
      toast({ title: "Terms accepted", description: "Your existing payments and balance are unchanged. Staff will separately confirm the appointment." });
    } catch (e: any) {
      await queryClient.invalidateQueries({ queryKey: [api.quotes.get.path, id] });
      toast({ title: "Could not record acceptance", description: "Please refresh and review the current quotation before accepting. Your payments have not changed.", variant: "destructive" });
    } finally {
      setAccepting(false);
    }
  };

  const handleReschedule = async () => {
    if (!rescheduleDate || !rescheduleTime) return toast({ title: "Please select a new date and time slot", variant: "destructive" });
    try {
      await rescheduleMutation.mutateAsync({ id, scheduledAt: new Date(rescheduleDate).toISOString(), timeWindow: rescheduleTime, referenceNo: quote?.referenceNo });
      setShowReschedule(false);
      toast({ title: "Reschedule Requested", description: "Pending admin confirmation. You'll receive a confirmation email." });
    } catch (e: any) {
      toast({ title: "Reschedule Failed", description: e.message, variant: "destructive" });
    }
  };

  const canReschedule = (() => {
    if (quote?.status !== "booked") return false;
    if ((quote?.rescheduledCount || 0) >= 1) return false;
    if (!quote?.scheduledAt) return false;
    return differenceInHours(new Date(quote.scheduledAt), new Date()) >= 48;
  })();

  const rescheduleBlockedReason = (() => {
    if (quote?.status !== "booked") return null;
    if ((quote?.rescheduledCount || 0) >= 1) return "You've already used your 1 complimentary reschedule. Further rescheduling incurs a S$30 fee — please contact us on WhatsApp.";
    if (!quote?.scheduledAt) return null;
    if (differenceInHours(new Date(quote.scheduledAt), new Date()) < 48)
      return "Reschedule requests must be made at least 48 hours before your appointment. A S$30 fee applies for late rescheduling — please contact us on WhatsApp.";
    return null;
  })();

  // Threshold is the source of truth for which payment scheme applies. Display
  // amounts fall back to the total for legacy/manual full-pay rows that may have
  // stored depositAmount = 0.
  const isFullPay = requiresFullUpfront(Number(quote?.total || 0));
  const termsAccepted = quote ? termsAcceptedForCurrentVersion(quote as any) : false;
  const payment = quotePaymentSummary(quote);
  const pendingCustomerEstimate = isReviewQuotation(quote);
  const offerValidityStatus = quote?.offerValidity?.status as string | undefined;
  const offerValidityBlocksAction = Boolean(quote?.offerValidity) &&
    !termsAccepted &&
    ["expired", "review", "withdrawn", "superseded", "draft"].includes(offerValidityStatus || "");
  const hasInitialPayment = payment.initialCollected;
  const initialPaymentOutstanding = payment.initialDue > 0.005;
  const showInitialPaymentAction =
    initialPaymentOutstanding
    && ["approved", "deposit_requested", "booking_requested", "booked", "assigned"].includes(quote?.status || "");
  // Full-payment jobs always show/charge the full total — never a stale or legacy
  // stored split (the backend charges the total via depositPaidFallback).
  const depositDisplay = payment.initialDue;
  const statusMessages: Record<string, string> = {
    submitted: "Your quote request has been received and is being reviewed.",
    under_review: "Our team is reviewing your quote.",
    approved: isFullPay ? "Your quote is approved! Awaiting payment request from our team." : "Your quote is approved! Awaiting deposit request from our team.",
    deposit_requested: initialPaymentOutstanding
      ? (isFullPay ? "Please complete the required full payment. Staff separately confirm the appointment date and time." : "Please pay the required deposit. Staff separately confirm the appointment date and time.")
      : "Verified initial payment recorded. Check any remaining balance below; staff separately confirm the appointment date and time.",
    deposit_paid: isFullPay ? "Payment received! Our team will reach out shortly to confirm your appointment." : "Deposit received! Our team will reach out shortly to confirm your appointment.",
    booking_requested: "Your booking request has been received. We'll confirm your slot shortly.",
    booked: initialPaymentOutstanding
      ? isFullPay
        ? "Your booking is scheduled. Please complete payment to confirm it."
        : "Your appointment is scheduled. Please pay the required deposit under your quote terms."
      : isFullPay
        ? "Your payment is complete. Check your appointment details; staff must confirm the date and time."
        : "Your deposit is paid. Check your appointment details; staff must confirm the date and time.",
    assigned: "A team member has been assigned to your job.",
    in_progress: "Your job is currently in progress.",
    at_pickup: "Our movers have arrived at your pickup address and are loading your items.",
    in_transit: "Your items are loaded — our movers are on the way to your dropoff address.",
    at_dropoff: "Our movers have arrived at your dropoff address and are unloading.",
    completed: payment.settled ? "Your job is complete. Thank you — your payment is fully settled." : "Your job is complete. Please make the final payment.",
    final_payment_requested: payment.settled ? "Your payment is fully settled — nothing further is due." : "Please complete your final payment.",
    final_paid: "Final payment received. Your case is closing.",
    closed: "Your case is closed. Thank you for choosing TMG Install.",
    cancelled: "This quote has been cancelled.",
  };

  // ── Loading ──────────────────────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="min-h-screen pt-32 flex items-center justify-center bg-[#f1efe7]">
        <div className="w-10 h-10 border-2 border-black border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!quote) {
    return (
      <div className="min-h-screen pt-32 text-center px-4 bg-[#f1efe7]">
        <p className="text-xs font-semibold tracking-widest uppercase text-black/40 mb-4" style={{ letterSpacing: "0.15em" }}>Error</p>
        <h2 className="text-3xl font-bold text-black">Quote not found</h2>
        <p className="mt-2 text-black/50">The reference number may be invalid.</p>
      </div>
    );
  }

  return (
    <>
    <div className="relative z-10 min-h-screen pt-20 pb-24 text-black" style={{ background: "#f1efe7" }}>

      {/* Payment verification overlay */}
      {verifying && (
        <div className="fixed inset-0 z-50 bg-[#f1efe7]/95 backdrop-blur-sm flex items-center justify-center">
          <div className="border border-black/15 bg-[rgba(250,250,247,0.92)] p-10 text-center shadow-[0_8px_48px_rgba(0,0,0,0.08)]">
            <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-black" />
            <p className="font-bold text-lg text-black">Confirming your payment…</p>
            <p className="text-black/50 text-sm mt-1">Please wait a moment.</p>
          </div>
        </div>
      )}

      <div className="max-w-5xl mx-auto px-4 sm:px-6">
        {(quote.leadIntake as any)?.quoteFixed === false && <div role="alert" className="mb-6 border border-amber-500 bg-amber-50 p-4">
          Review draft only. Scope and charges are incomplete; the displayed amounts are not an all-in fixed quotation and payment or booking is not available.
        </div>}

        {/* Payment verified banner */}
        {paymentVerified && (
          <motion.div {...fadeUp()} className="mb-8 flex items-center gap-3 border border-black/12 border-l-[3px] px-5 py-4 bg-black/[0.02]" style={{ borderLeftColor: ACCENT }}>
            <CheckCircle2 className="w-5 h-5 text-black shrink-0" />
            <div>
              <p className="font-bold text-black text-sm flex items-center gap-2"><AccentSquare /> Payment received</p>
              {isFullPay ? (
                <p className="text-xs text-black/50 mt-0.5">Your full payment has been confirmed. Thank you for choosing TMG Install!</p>
              ) : quote && ["final_paid", "closed", "completed", "in_progress", "at_pickup", "in_transit", "at_dropoff", "assigned"].includes(quote.status) ? (
                <p className="text-xs text-black/50 mt-0.5">Your final payment has been confirmed. Thank you for choosing TMG Install!</p>
              ) : (
                <p className="text-xs text-black/50 mt-0.5">Your deposit has been received. Any appointment date and time still need staff confirmation.</p>
              )}
            </div>
          </motion.div>
        )}

        {/* ═══ HEADER ═══ */}
        <motion.div {...fadeUp()} className="relative mb-12 border-b border-black/10 pb-10 overflow-hidden">
          <DotGrid opacity={0.35} />
          <div className="relative">
            <p className="text-[10px] font-semibold tracking-widest uppercase text-black/35 mb-3 flex items-center gap-2" style={{ letterSpacing: "0.18em" }}>
              <AccentSquare /> TMG Install · Quote Reference
            </p>
            <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
              <div>
                <div className="flex items-center gap-3 mb-3 flex-wrap">
                  <h1 className="font-heading text-4xl sm:text-5xl font-black text-black tracking-tight">
                    {quote.referenceNo}
                  </h1>
                  <Tag accent>SG</Tag>
                </div>
                {termsAccepted&&["submitted","under_review","approved","deposit_requested"].includes(quote.status)?
                  <Tag>Quote accepted</Tag>:
                  offerValidityStatus==="expired"?<Tag>Offer expired</Tag>:
                  offerValidityStatus==="valid"&&["submitted","under_review"].includes(quote.status)?<Tag>Quotation issued</Tag>:
                  <StatusBadge status={quote.status==="deposit_requested"&&isFullPay?"payment_requested":quote.status} className="text-xs px-3 py-1" />}
                  <OfferValidityStatusNotice offerValidity={quote.offerValidity} className="mt-3 max-w-xl" />
                  {offerValidityBlocksAction && (
                    <p className="mt-2 max-w-xl text-[11px] leading-relaxed text-black/55" data-testid="text-offer-staff-review-next-step">
                      Please contact our team for staff review. We will confirm whether an updated quotation is needed.
                    </p>
                  )}
                {!isReviewQuotation(quote) && quote.invoiceType!=="commercial" && Number(quote.total)>0 && !quote.superseded && quote.status!=="cancelled" && (
                  <a className="inline-flex ml-3 mt-2 underline text-sm" data-testid="download-quotation-pdf"
                    href={`/api/quotes/${quote.id}/quotation.pdf?ref=${encodeURIComponent(quote.referenceNo)}&version=${quote.version}`}>
                    Download quotation PDF
                  </a>
                )}
                {quote.requiresManualReview && quote.items?.some((item:any)=>item.remark?.startsWith("Pending item review:") && Number(item.subtotal)===0) && (
                  <p className="text-sm text-black/50 max-w-md leading-relaxed mt-4" data-testid="text-custom-review">
                    Custom work is pending staff review, not free. The amount shown covers priced items and estimated charges only; the complete quotation will follow after review.
                  </p>
                )}
                {statusMessages[quote.status] && (
                  <p className="text-sm text-black/50 max-w-md leading-relaxed mt-4">
                    {termsAccepted&&["submitted","under_review","approved","deposit_requested"].includes(quote.status)
                      ? "Your quotation has been accepted. Payment and appointment status are shown separately."
                      : offerValidityStatus==="valid"&&["submitted","under_review"].includes(quote.status)
                        ? "Your quotation is ready for review and acceptance. Staff separately confirm appointments."
                        : statusMessages[quote.status]}
                  </p>
                )}
              </div>
              <div className="hidden sm:block shrink-0 self-end">
                <EditorialPaperStack size="sm" />
              </div>
            </div>
          </div>
        </motion.div>

        {/* ═══ PAYMENT GUIDE — shown only when the initial payment is still due ══════════ */}
        {quote.status === "deposit_requested" && initialPaymentOutstanding && (
          <motion.div {...fadeUp(0.02)} className="mb-8 border-2 border-black overflow-hidden">
            <div className="bg-black text-white px-5 py-3.5 flex items-center gap-3">
              <CreditCard className="w-5 h-5 text-white flex-shrink-0" />
              <div>
                <p className="font-black text-sm uppercase tracking-wide" style={{ letterSpacing: "0.1em" }}>
                  Payment options for your quotation
                </p>
                <p className="text-white/60 text-xs mt-0.5">Follow the steps below to complete your {isFullPay ? "payment" : "deposit"}</p>
              </div>
            </div>
            <div className="bg-[rgba(250,250,247,0.88)] px-5 py-5">
              <div className="space-y-4">
                {/* Step 1 */}
                <div className="flex items-start gap-4">
                  <div className="w-7 h-7 rounded-full bg-black text-white text-xs font-black flex items-center justify-center flex-shrink-0 mt-0.5">1</div>
                  <div>
                    <p className="font-bold text-sm text-black">Review your quotation</p>
                    <p className="text-xs text-black/55 mt-0.5 leading-relaxed">
                      Check the itemised work, total and terms below before making payment.
                    </p>
                  </div>
                </div>
                {/* Step 2 — direct page payment */}
                <div className="flex items-start gap-4">
                  <div className="w-7 h-7 rounded-full bg-amber-500 text-white text-xs font-black flex items-center justify-center flex-shrink-0 mt-0.5">2</div>
                  <div>
                    <p className="font-bold text-sm text-black flex items-center gap-1.5">
                      <CreditCard className="w-4 h-4 text-amber-500 flex-shrink-0" />
                      Pay from this page
                    </p>
                    <p className="text-xs text-black/55 mt-0.5 leading-relaxed">
                      Use the <span className="font-semibold text-black">{isFullPay ? "Pay In Full Now" : "Pay Deposit Now"}</span> button or the PayNow details in your payment summary.
                    </p>
                  </div>
                </div>
                {/* Step 3 */}
                <div className="flex items-start gap-4">
                  <div className="w-7 h-7 rounded-full bg-black text-white text-xs font-black flex items-center justify-center flex-shrink-0 mt-0.5">3</div>
                  <div>
                    <p className="font-bold text-sm text-black">If you received a payment email</p>
                    <p className="text-xs text-black/55 mt-0.5 leading-relaxed">
                      You may use its secure link. No email is needed to use the payment options on this page.
                    </p>
                  </div>
                </div>
                {/* Step 4 */}
                <div className="flex items-start gap-4">
                  <div className="w-7 h-7 rounded-full bg-black text-white text-xs font-black flex items-center justify-center flex-shrink-0 mt-0.5">4</div>
                  <div>
                    <p className="font-bold text-sm text-black flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                      Pay securely under your quote terms
                    </p>
                    <p className="text-xs text-black/55 mt-0.5 leading-relaxed">
                      Payment alone does not confirm a booking. Staff must separately confirm the appointment date and time.
                    </p>
                  </div>
                </div>
              </div>
              {/* Tip */}
              <div className="mt-5 border border-black/10 bg-black/[0.02] px-4 py-3 flex items-start gap-2.5">
                <Info className="w-4 h-4 text-black/40 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-black/50 leading-relaxed">
                  <span className="font-bold text-black">Need help?</span> Review the Payment Summary below or contact us on WhatsApp. An email may not have been sent for this quotation.
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* ═══ WHAT HAPPENS NEXT — submitted / under_review ══════════════════ */}
        {["submitted", "under_review"].includes(quote.status) && !termsAccepted &&
          !["valid","expired"].includes(offerValidityStatus||"") && (
          <motion.div {...fadeUp(0.02)} className="mb-8 border border-black/12 overflow-hidden">
            <div className="bg-black text-white px-5 py-3.5 flex items-center gap-3">
              <Clock className="w-4 h-4 text-white/70 flex-shrink-0" />
              <div>
                <p className="font-black text-sm uppercase tracking-wide" style={{ letterSpacing: "0.1em" }}>
                  What happens next
                </p>
                <p className="text-white/55 text-xs mt-0.5">Your quote is in — here's what to expect</p>
              </div>
            </div>
            <div className="bg-[rgba(250,250,247,0.88)] px-5 py-5 space-y-4">
              {[
                {
                  num: 1,
                  done: true,
                  color: "bg-emerald-500",
                  title: "Quote submitted ✓",
                  desc: `Received at ${new Date(quote.createdAt || Date.now()).toLocaleTimeString("en-SG", { hour: "2-digit", minute: "2-digit" })} — reference ${quote.referenceNo}`,
                },
                {
                  num: 2,
                  done: quote.status === "under_review",
                  color: "bg-black",
                  title: "Our team reviews the enquiry",
                  desc: "We confirm missing scope, pricing and access details. Staff separately confirm appointment dates and times.",
                },
                {
                  num: 3,
                  done: false,
                  color: "bg-black/20",
                  title: pendingCustomerEstimate ? "Complete quotation after review" : isFullPay ? "Full-payment link after approval" : "Deposit link after approval",
                  desc: pendingCustomerEstimate
                    ? "Your custom work needs staff pricing. This partial estimate is not a payment request."
                    : isFullPay
                      ? "We may send a full-payment link after you accept the confirmed quote. Staff separately confirm any appointment."
                      : "We may send a 50% deposit link after you accept the confirmed quote. Staff separately confirm any appointment.",
                },
                {
                  num: 4,
                  done: false,
                  color: "bg-black/20",
                  title: "Appointment confirmed by staff",
                  desc: "Our team checks availability and confirms the date and time with you. Payment alone does not book an appointment.",
                },
              ].map(({ num, done, color, title, desc }) => (
                <div key={num} className="flex items-start gap-4">
                  <div className={`w-7 h-7 rounded-full ${color} text-white text-xs font-black flex items-center justify-center flex-shrink-0 mt-0.5`}>
                    {done && num === 1 ? <Check className="w-3.5 h-3.5" /> : num}
                  </div>
                  <div>
                    <p className={`font-bold text-sm ${done ? "text-black" : "text-black/40"}`}>{title}</p>
                    <p className="text-xs text-black/45 mt-0.5 leading-relaxed">{desc}</p>
                  </div>
                </div>
              ))}
              <div className="pt-3 border-t border-black/8 flex items-center gap-3">
                <a
                  href={`https://wa.me/6580880757?text=Hi%2C+I+just+submitted+quote+reference+${quote.referenceNo}+and+have+a+question.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.08em] text-black border border-black/15 px-3 py-2 hover:bg-black hover:text-white transition-colors"
                >
                  <MessageCircle className="w-3.5 h-3.5" /> Questions? WhatsApp us
                </a>
                <span className="text-xs text-black/35">We typically respond within 30 min during business hours.</span>
              </div>
            </div>
          </motion.div>
        )}

        {/* ═══ APPROVED — prompt to watch for deposit link ════════════════════ */}
        {quote.status === "approved" && (
          <motion.div {...fadeUp(0.02)} className="mb-8 flex items-start gap-3.5 border border-black/12 bg-black/[0.015] px-5 py-4">
            <Mail className="w-4 h-4 text-black/40 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold text-black mb-0.5">Your quote is approved — {isFullPay ? "payment link coming" : "deposit link coming"}</p>
              <p className="text-xs text-black/55 leading-relaxed">
                Our team will send a {isFullPay ? "payment link" : "deposit payment link"} to your registered email shortly. Check your inbox and your Junk / Spam / Promotions folder.
              </p>
              <div className="flex items-center gap-1.5 mt-2.5">
                <MailWarning className="w-3.5 h-3.5 text-amber-500" />
                <p className="text-[11px] font-semibold text-amber-700">
                  Payment emails can end up in Junk, Spam, or Promotions — always check those folders.
                </p>
              </div>
            </div>
          </motion.div>
        )}

        <div className="grid md:grid-cols-[2fr_1fr] gap-8 items-start">

          {/* ═══ LEFT COLUMN ═══ */}
          <div className="space-y-6">

            {/* Itemised Breakdown */}
            <motion.div {...fadeUp(0.05)} className="border border-black/12 shadow-[0_4px_24px_rgba(0,0,0,0.05)]">
              <div className="px-6 py-4 border-b border-black/8 flex items-center gap-2">
                <Package className="w-4 h-4 text-black/40" />
                <p className="text-[10px] font-semibold tracking-widest uppercase text-black/60" style={{ letterSpacing: "0.15em" }}>
                  <span className="inline-flex items-center gap-2"><AccentSquare /> Itemised Breakdown</span>
                </p>
              </div>
              <div className="px-6 py-5 space-y-0">
                {quote.items?.map((item: any) => (
                  <div key={item.id} className="flex justify-between items-start py-3 border-b border-black/6 last:border-0">
                    <div>
                      <p className="font-semibold text-sm text-black">{item.detectedName || item.originalDescription}</p>
                      <p className="text-xs text-black/40 mt-0.5 capitalize">{formatItemServiceLabel(item, quote.items) || item.serviceType} · Qty {item.quantity}</p>
                      {item.remark && <p className="text-xs text-black/55 mt-0.5">{item.remark}</p>}
                      {itemRouteLabel((quote as any).stops, item.fromStopId, item.toStopId) && (
                        <p className="text-xs text-black/55 mt-0.5" data-testid={`tracking-item-route-${item.id}`}>{itemRouteLabel((quote as any).stops, item.fromStopId, item.toStopId)}</p>
                      )}
                    </div>
                    <p className="font-bold text-sm text-black tabular-nums">{isUnpricedReviewItem(quote,item) ? "Pending review" : formatMoney(item.subtotal)}</p>
                  </div>
                ))}
                {(!quote.items || quote.items.length === 0) && (
                  <p className="text-black/40 text-sm text-center py-4">No items</p>
                )}
              </div>
              <div className="px-6 pb-5 pt-3 border-t border-black/8 space-y-2">
                <div className="flex justify-between text-xs text-black/45">
                  <span>{pendingCustomerEstimate?"Known priced components":"Subtotal"}</span>
                  <span className="tabular-nums">{pendingCustomerEstimate && Number(quote.subtotal)===0 ? "Pricing pending" : formatMoney(quote.subtotal)}</span>
                </div>
                 {Number(quote.discount || 0) > 0 && (
                   <div className="flex justify-between text-xs font-semibold text-emerald-700">
                     <span>Discount</span>
                     <span className="tabular-nums">−{formatMoney(quote.discount)}</span>
                   </div>
                 )}
                {Number((quote as any).volumetricFee || 0) > 0 ? (
                  <>
                    {(Number(quote.transportFee || 0) - Number((quote as any).volumetricFee || 0)) > 0 && (
                      <div className="flex justify-between text-xs text-black/45">
                        <span>Transport</span>
                        <span className="tabular-nums">{formatMoney(Number(quote.transportFee || 0) - Number((quote as any).volumetricFee || 0))}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-xs text-black/45">
                      <span>Volumetric Handling</span>
                      <span className="tabular-nums">{formatMoney((quote as any).volumetricFee)}</span>
                    </div>
                  </>
                ) : (
                  <div className="flex justify-between text-xs text-black/45">
                    <span>Transport</span>
                    <span className="tabular-nums">{isTransportPricingPending(quote)?"Pricing pending":formatMoney(quote.transportFee)}</span>
                  </div>
                )}
                {Number(quote.promoDiscount || 0) > 0 && (
                  <div className="flex justify-between text-xs font-semibold text-emerald-700">
                    <span>Promo code ({quote.promoCode})</span>
                    <span className="tabular-nums">−{formatMoney(quote.promoDiscount)}</span>
                  </div>
                )}
                {Number((quote as any).goodwillDiscount || 0) > 0 && (
                  <div className="flex justify-between text-xs font-semibold text-emerald-700">
                    <span>Goodwill discount{(quote as any).goodwillReason ? ` (${(quote as any).goodwillReason})` : ""}</span>
                    <span className="tabular-nums">−{formatMoney((quote as any).goodwillDiscount)}</span>
                  </div>
                )}
                <div className="flex justify-between font-black text-base text-black pt-2 border-t border-black/10">
                  <span className="uppercase tracking-wide text-sm" style={{ letterSpacing: "0.08em" }}>{pendingCustomerEstimate?"Final quotation total":"Total"}</span>
                  <span className="tabular-nums">{pendingCustomerEstimate ? "Pricing pending" : formatMoney(quote.total)}</span>
                </div>
              </div>
            </motion.div>

            {/* Standard Terms & Conditions */}
            <motion.div {...fadeUp(0.1)} className="border border-black/12 shadow-[0_4px_24px_rgba(0,0,0,0.05)]">
              <div className="px-6 py-4 border-b border-black/8">
                <p className="text-[10px] font-semibold tracking-widest uppercase text-black/60" style={{ letterSpacing: "0.15em" }}>
                  <span className="inline-flex items-center gap-2"><AccentSquare /> Standard Terms &amp; Conditions</span>
                </p>
              </div>
              <div className="px-6 py-5">
                {(quote.items?.some((i: any) => i.serviceType === "relocate") || !!(quote as any).samePropertyMove) && (
                  <QuoteScheduleNote
                    items={(quote.items || []).filter((i: any) => i.serviceType !== "discount").map((i: any) => ({ serviceType: i.serviceType, quantity: Number(i.quantity) || 1, volumeM3: i.volumeM3 != null ? Number(i.volumeM3) : undefined, carryOnly: !!i.carryOnly }))}
                    distanceKm={(quote as any).samePropertyMove ? 0 : (Number((quote as any).distanceKm) || 0)}
                    isRelocation={quote.items?.some((i: any) => i.serviceType === "relocate") || !!(quote as any).samePropertyMove}
                    crewSize={Number((quote as any).secondDayCrewSize) || undefined}
                    className="mb-4"
                  />
                )}
                <QuoteTermsBlock
                  heading={false}
                  savedTerms={quote.offerTerms}
                  isRelocation={quote.items?.some((i: any) => i.serviceType === "relocate") || !!(quote as any).samePropertyMove}
                />
              </div>
            </motion.div>

            {/* Details */}
            <motion.div {...fadeUp(0.1)} className="border border-black/12 shadow-[0_4px_24px_rgba(0,0,0,0.05)]">
              <div className="px-6 py-4 border-b border-black/8 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-black/40" />
                <p className="text-[10px] font-semibold tracking-widest uppercase text-black/60" style={{ letterSpacing: "0.15em" }}>
                  <span className="inline-flex items-center gap-2"><AccentSquare /> Job Details</span>
                </p>
              </div>
              <div className="px-6 py-5 grid sm:grid-cols-2 gap-5">
                <div>
                  <p className="text-[10px] text-black/35 font-semibold uppercase mb-1.5" style={{ letterSpacing: "0.12em" }}>Name</p>
                  <p className="font-semibold text-sm text-black">{quote.customer?.name}</p>
                </div>
                <div>
                  <p className="text-[10px] text-black/35 font-semibold uppercase mb-1.5" style={{ letterSpacing: "0.12em" }}>Contact</p>
                  <p className="font-semibold text-sm text-black">{quote.customer?.phone}</p>
                </div>
                <div className="sm:col-span-2">
                  <p className="text-[10px] text-black/35 font-semibold uppercase mb-1.5" style={{ letterSpacing: "0.12em" }}>Service Address</p>
                  <p className="font-semibold text-sm text-black">{quote.serviceAddress}</p>
                </div>
                {(() => {
                  const grouped = groupStops((quote as any).stops);
                  if (grouped.all.length > 2) {
                    return grouped.all.map((s) => (
                      <div key={s.id} data-testid={`tracking-stop-${s.id}`}>
                        <p className="text-[10px] text-black/35 font-semibold uppercase mb-1.5" style={{ letterSpacing: "0.12em" }}>{s.label}</p>
                        <p className="font-semibold text-sm text-black">
                          {s.address}
                          {s.floor ? `, ${s.floor}` : ""}
                          {s.hasLift === false ? " (no lift)" : ""}
                        </p>
                      </div>
                    ));
                  }
                  return (
                    <>
                      {quote.pickupAddress && (
                        <div>
                          <p className="text-[10px] text-black/35 font-semibold uppercase mb-1.5" style={{ letterSpacing: "0.12em" }}>Pickup</p>
                          <p className="font-semibold text-sm text-black">{quote.pickupAddress}</p>
                        </div>
                      )}
                      {quote.dropoffAddress && (
                        <div>
                          <p className="text-[10px] text-black/35 font-semibold uppercase mb-1.5" style={{ letterSpacing: "0.12em" }}>Dropoff</p>
                          <p className="font-semibold text-sm text-black">{quote.dropoffAddress}</p>
                        </div>
                      )}
                    </>
                  );
                })()}
              </div>

              {/* Slot held (submitted / deposit_requested) */}
              {quote.preferredDate && ["submitted", "deposit_requested"].includes(quote.status) && (
                <div className="mx-6 mb-5 border border-black/12 bg-amber-50/60 p-4">
                  <p className="text-[10px] font-semibold tracking-widest uppercase text-amber-700/70 mb-3" style={{ letterSpacing: "0.15em" }}>
                    Date / time preference — awaiting staff confirmation
                  </p>
                  <div className="flex items-center gap-2 font-bold text-sm text-black">
                    <CalendarDays className="w-4 h-4 text-amber-600/60" />
                    {format(new Date(quote.preferredDate + "T12:00:00"), "EEEE, MMMM d, yyyy")}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-black/60 mt-1.5">
                    <Clock className="w-4 h-4 text-black/30" />
                    {quote.preferredTimeWindow}
                  </div>
                  <p className="text-xs text-black/40 mt-2">This is not a confirmed appointment. Our team will check availability and confirm the date and time with you. Payment does not confirm an appointment.</p>
                </div>
              )}

              {/* Confirmed appointment */}
              {quote.scheduledAt && ["deposit_paid", "booked", "assigned", "in_progress", "at_pickup", "in_transit", "at_dropoff", "completed", "final_payment_requested"].includes(quote.status) && (
                <div className="mx-6 mb-5 border border-black/12 bg-black/[0.025] p-4">
                  <p className="text-[10px] font-semibold tracking-widest uppercase text-black/40 mb-3" style={{ letterSpacing: "0.15em" }}>
                  <span className="inline-flex items-center gap-2"><AccentSquare /> Confirmed Appointment</span>
                </p>
                  <div className="flex items-center gap-2 font-bold text-sm text-black">
                    <CalendarDays className="w-4 h-4 text-black/40" />
                    {formatSingaporeDay(quote.scheduledAt, "EEEE, MMMM d, yyyy")}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-black/60 mt-1.5">
                    <Clock className="w-4 h-4 text-black/40" />
                    {quote.timeWindow}
                  </div>
                </div>
              )}

              {/* Pending booking */}
              {quote.status === "booking_requested" && quote.scheduledAt && (
                <div className="mx-6 mb-5 border border-black/12 bg-black/[0.025] p-4">
                  <p className="text-[10px] font-semibold tracking-widest uppercase text-black/40 mb-3" style={{ letterSpacing: "0.15em" }}>
                  <span className="inline-flex items-center gap-2"><AccentSquare /> Pending Confirmation</span>
                </p>
                  <div className="flex items-center gap-2 font-bold text-sm text-black">
                    <CalendarDays className="w-4 h-4 text-black/40" />
                    {formatSingaporeDay(quote.scheduledAt, "EEEE, MMMM d, yyyy")}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-black/60 mt-1.5">
                    <Clock className="w-4 h-4 text-black/40" />
                    {quote.timeWindow}
                  </div>
                  <p className="text-xs text-black/40 mt-2">Our team will confirm within 24 hours.</p>
                </div>
              )}

              {/* Reschedule */}
              {quote.status === "booked" && (
                <div className="mx-6 mb-5">
                  {rescheduleBlockedReason ? (
                    <div className="border border-black/12 bg-black/[0.02] p-4 flex items-start gap-3">
                      <AlertCircle className="w-4 h-4 text-black/40 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs text-black/60">{rescheduleBlockedReason}</p>
                        <a href={WHATSAPP_HREF} target="_blank" rel="noreferrer"
                          className="text-xs font-bold text-black underline mt-1.5 inline-flex items-center gap-1 hover:no-underline">
                          <MessageCircle className="w-3 h-3" /> Contact on WhatsApp
                        </a>
                      </div>
                    </div>
                  ) : canReschedule && !showReschedule ? (
                    <button onClick={() => setShowReschedule(true)} data-testid="button-reschedule"
                      className="flex items-center gap-1.5 text-xs font-semibold text-black/50 hover:text-black transition-colors border border-black/15 px-4 py-2 hover:border-black/30">
                      <RefreshCw className="w-3.5 h-3.5" /> Request Reschedule (1 free)
                    </button>
                  ) : null}

                  {showReschedule && canReschedule && (
                    <div className="mt-4 border border-black/10">
                      <div className="px-4 py-3 border-b border-black/8 bg-black/[0.02] flex items-center gap-2">
                        <CalendarDays className="w-3.5 h-3.5 text-black/40" />
                        <p className="text-[10px] font-black uppercase tracking-[0.18em] text-black/40">Choose New Date & Time</p>
                      </div>
                      <div className="p-4 space-y-4">
                        {/* Policy note */}
                        <div className="border border-amber-200 bg-amber-50/60 px-3 py-2.5">
                          <p className="text-[10px] font-black uppercase tracking-wider text-amber-700 mb-1">Reschedule Policy</p>
                          <p className="text-xs text-black/55 leading-relaxed">
                            1 complimentary reschedule, min. <strong>48 hours</strong> notice required. Late or subsequent requests incur a <strong>S$30 fee</strong> — contact us on WhatsApp.
                          </p>
                        </div>

                        <SlotPicker
                          date={rescheduleDate}
                          time={rescheduleTime}
                          onDateChange={d => { setRescheduleDate(d); setRescheduleTime(""); }}
                          onTimeChange={setRescheduleTime}
                          availability={slotAvailability}
                          minDate={getTodayPlus1()}
                        />

                        {rescheduleDate && rescheduleTime && (
                          <div className="border-l-2 border-emerald-500 bg-emerald-50/60 px-3 py-2.5 flex items-start gap-2">
                            <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                            <p className="text-xs text-black/60">
                              {new Date(rescheduleDate + "T12:00:00").toLocaleDateString("en-SG", { weekday: "long", day: "numeric", month: "short", year: "numeric" })},{" "}
                              {rescheduleTime === "09:00-12:00" ? "9am – 12pm" : "1pm – 5pm"}
                            </p>
                          </div>
                        )}

                        <div className="flex gap-2">
                          <button onClick={handleReschedule}
                            disabled={rescheduleMutation.isPending || !rescheduleDate || !rescheduleTime}
                            data-testid="button-confirm-reschedule"
                            className="flex-1 h-11 bg-black text-white text-xs font-bold uppercase tracking-widest disabled:opacity-40 hover:bg-black/85 transition-colors"
                            style={{ letterSpacing: "0.12em" }}>
                            {rescheduleMutation.isPending ? "Sending…" : "Submit Reschedule"}
                          </button>
                          <button onClick={() => { setShowReschedule(false); setRescheduleDate(""); setRescheduleTime(""); }}
                            className="h-11 px-5 border border-black/15 text-xs font-bold hover:border-black/30 transition-colors">
                            Cancel
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </motion.div>

            {/* ─── Work Photos — arrival + completion shots ─── */}
            {workPhotos.length > 0 && (
              <motion.div {...fadeUp(0.12)} className="border border-black/12 shadow-[0_4px_24px_rgba(0,0,0,0.05)] overflow-hidden">
                <div className="px-6 py-4 border-b border-black/8 flex items-center gap-2">
                  <Image className="w-4 h-4 text-black/40" />
                  <p className="text-[10px] font-semibold tracking-widest uppercase text-black/60" style={{ letterSpacing: "0.15em" }}>
                  <span className="inline-flex items-center gap-2"><AccentSquare /> Work Photos</span>
                </p>
                  <span className="ml-auto text-[10px] text-black/30 font-semibold">{workPhotos.length} photo{workPhotos.length !== 1 ? "s" : ""}</span>
                </div>
                <div className="p-4">
                  <div className="grid grid-cols-3 gap-2">
                    {workPhotos.map((url, i) => (
                      <button
                        key={i}
                        data-testid={`img-work-photo-${i}`}
                        onClick={() => setLightboxUrl(url)}
                        className="relative group aspect-square overflow-hidden border border-black/10 focus:outline-none"
                      >
                        <img
                          src={url}
                          alt={`Work photo ${i + 1}`}
                          className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                          <ZoomIn className="w-5 h-5 text-white opacity-0 group-hover:opacity-100 transition-opacity drop-shadow" />
                        </div>
                      </button>
                    ))}
                  </div>
                  <p className="text-[10px] text-black/35 mt-3">
                    Tap any photo to view full size. These are proof-of-work photos taken by the installer on arrival and completion.
                  </p>
                </div>
              </motion.div>
            )}

          </div>

          {/* ═══ RIGHT SIDEBAR ═══ */}
          <div className="space-y-4">

            {/* Scope, Timing & Terms — plain-language policy summary */}
            {businessRules && (
              <motion.div {...fadeUp(0.12)} className="border border-black/12" data-testid="card-quote-terms">
                <div className="px-5 py-4 border-b border-black/8 flex items-center justify-between gap-2">
                  <p className="text-[10px] font-semibold tracking-widest uppercase text-black/40" style={{ letterSpacing: "0.15em" }}>
                    <span className="inline-flex items-center gap-2"><AccentSquare /> Scope, Timing & Terms</span>
                  </p>
                  {termsAccepted && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide text-emerald-600">
                      <Check className="w-3.5 h-3.5" /> Accepted
                    </span>
                  )}
                </div>
                <div className="px-5 py-4 space-y-3">
                  {(quote as any).timingMode === "split" && (
                    <div className="bg-black/[0.03] border border-black/10 px-3 py-2.5 text-[11px] text-black/70 leading-relaxed" data-testid="text-split-timing">
                      <span className="font-semibold text-black">Split timing:</span> this job is scheduled across two separate visits.
                      {(quote as any).dismantleAt && <> Dismantle on {format(new Date((quote as any).dismantleAt), "MMM d, yyyy")}{(quote as any).dismantleTimeWindow ? ` (${(quote as any).dismantleTimeWindow})` : ""}.</>}
                      {(quote as any).reinstallAt && <> Reinstall on {format(new Date((quote as any).reinstallAt), "MMM d, yyyy")}{(quote as any).reinstallTimeWindow ? ` (${(quote as any).reinstallTimeWindow})` : ""}.</>}
                    </div>
                  )}
                  {(quote as any).afterOfficeSurchargeApplied && !(quote as any).afterOfficeWaived && (
                    <div className="bg-black/[0.03] border border-black/10 px-3 py-2.5 text-[11px] text-black/70 leading-relaxed" data-testid="text-after-office">
                      <span className="font-semibold text-black">After-office work:</span> part of this job runs past {businessRules.afterOfficeCutoff}, so an after-office surcharge of {formatMoney((quote as any).afterOfficeSurchargeAmount)} applies (already included in your total).
                    </div>
                  )}
                  {(quote as any).afterOfficeWaived && (
                    <div className="bg-black/[0.03] border border-black/10 px-3 py-2.5 text-[11px] text-black/70 leading-relaxed">
                      <span className="font-semibold text-black">After-office surcharge waived.</span>{(quote as any).afterOfficeWaiverReason ? ` ${(quote as any).afterOfficeWaiverReason}` : ""}
                    </div>
                  )}
                  {(quote as any).specialRemarks && (
                    <div className="bg-black/[0.03] border border-black/10 px-3 py-2.5 text-[11px] text-black/70 leading-relaxed" data-testid="text-special-remarks">
                      <span className="font-semibold text-black">Special remarks:</span> {(quote as any).specialRemarks}
                    </div>
                  )}
                  <ol className="space-y-2 list-decimal pl-4">
                    {businessRules.clauses.map((c, i) => (
                      <li key={i} className="text-[11px] text-black/55 leading-relaxed">
                        <span className="font-semibold text-black/80">{c.title}.</span> {c.body}
                      </li>
                    ))}
                  </ol>
                </div>
              </motion.div>
            )}

            {/* Payment Summary — black card */}
            <motion.div {...fadeUp(0.15)} className="bg-black text-white shadow-[0_8px_40px_rgba(0,0,0,0.18)] overflow-hidden">
              <div className="px-6 py-5 border-b border-white/10">
                <p className="text-[10px] font-semibold tracking-widest uppercase text-white/40" style={{ letterSpacing: "0.18em" }}>
                  <span className="inline-flex items-center gap-2"><AccentSquare /> {pendingCustomerEstimate ? "Price review summary" : "Payment Summary"}</span>
                </p>
              </div>
              <div className="px-6 py-5 space-y-3">
                <div className="flex justify-between text-sm text-white/60">
                  <span>{pendingCustomerEstimate?"Known priced components":"Subtotal"}</span>
                  <span className="tabular-nums">{pendingCustomerEstimate && Number(quote.subtotal)===0 ? "Pricing pending" : formatMoney(quote.subtotal)}</span>
                </div>
                 {Number(quote.discount || 0) > 0 && (
                   <div className="flex justify-between text-sm font-semibold text-emerald-400">
                     <span>Discount</span>
                     <span className="tabular-nums">−{formatMoney(quote.discount)}</span>
                   </div>
                 )}
                {Number((quote as any).volumetricFee || 0) > 0 ? (
                  <>
                    {(Number(quote.transportFee || 0) - Number((quote as any).volumetricFee || 0)) > 0 && (
                      <div className="flex justify-between text-sm text-white/60">
                        <span>Transport</span>
                        <span className="tabular-nums">{formatMoney(Number(quote.transportFee || 0) - Number((quote as any).volumetricFee || 0))}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm text-white/60">
                      <span>Volumetric Handling</span>
                      <span className="tabular-nums">{formatMoney((quote as any).volumetricFee)}</span>
                    </div>
                  </>
                ) : (
                  <div className="flex justify-between text-sm text-white/60">
                    <span>Transport</span>
                    <span className="tabular-nums">{isTransportPricingPending(quote)?"Pricing pending":formatMoney(quote.transportFee)}</span>
                  </div>
                )}
                {Number((quote as any).additionalTripCharge || 0) > 0 && (
                  <div className="flex justify-between text-sm text-white/60">
                    <span>Additional Trip</span>
                    <span className="tabular-nums">{formatMoney((quote as any).additionalTripCharge)}</span>
                  </div>
                )}
                {Number((quote as any).afterOfficeSurchargeAmount || 0) > 0 && !(quote as any).afterOfficeWaived && (
                  <div className="flex justify-between text-sm text-white/60">
                    <span>After-Office Surcharge</span>
                    <span className="tabular-nums">{formatMoney((quote as any).afterOfficeSurchargeAmount)}</span>
                  </div>
                )}
                {(quote as any).afterOfficeWaived && Number((quote as any).afterOfficeSurchargeAmount || 0) > 0 && (
                  <div className="flex justify-between text-sm text-emerald-400">
                    <span>After-Office Surcharge (waived)</span>
                    <span className="tabular-nums">{formatMoney(0)}</span>
                  </div>
                )}
                {Number(quote.promoDiscount || 0) > 0 && (
                  <div className="flex justify-between text-sm font-semibold text-emerald-400">
                    <span>Promo ({quote.promoCode})</span>
                    <span className="tabular-nums">−{formatMoney(quote.promoDiscount)}</span>
                  </div>
                )}
                {Number((quote as any).goodwillDiscount || 0) > 0 && (
                  <div className="flex justify-between text-sm font-semibold text-emerald-400">
                    <span>Goodwill discount{(quote as any).goodwillReason ? ` (${(quote as any).goodwillReason})` : ""}</span>
                    <span className="tabular-nums">−{formatMoney((quote as any).goodwillDiscount)}</span>
                  </div>
                )}
                <div className="flex justify-between border-t border-white/15 pt-3 text-white font-black text-lg">
                  <span className="text-sm uppercase tracking-wide" style={{ letterSpacing: "0.08em" }}>{pendingCustomerEstimate ? "Priced portion only" : "Total"}</span>
                  <span className="tabular-nums">{pendingCustomerEstimate && Number(quote.total)===0 ? "Pricing pending" : formatMoney(quote.total)}</span>
                </div>
                {pendingCustomerEstimate ? (
                  <p className="text-xs text-white/60" data-testid="text-pending-price-payment">Complete pricing is pending staff review. This partial estimate is not a payment request; any date/time still requires staff confirmation.</p>
                ) : isFullPay ? (
                  <div className="flex justify-between text-xs text-white/40">
                    <span>Full payment remaining</span>
                    <span className="tabular-nums">{formatMoney(depositDisplay)}</span>
                  </div>
                ) : (
                  <>
                    <div className="flex justify-between text-xs text-white/40">
                      <span>Deposit due now</span>
                      <span className="tabular-nums">{payment.reconciliationRequired?"Held for reconciliation":formatMoney(payment.initialDue)}</span>
                    </div>
                    <div className="flex justify-between text-xs text-white/40">
                      <span>Balance Due</span>
                      <span className="tabular-nums" data-testid="customer-balance-due">{payment.reconciliationRequired?"Reconciliation required":formatMoney(payment.outstanding)}</span>
                    </div>
                  </>
                )}
                <div className="flex justify-between text-xs text-white/60">
                  <span>Net received — whole job</span>
                  <span className="tabular-nums" data-testid="customer-paid-total">{formatMoney(payment.financial.netReceived)}</span>
                </div>
                <FinancialBasisNotice quote={quote} />
                {isFullPay && !pendingCustomerEstimate && (
                  <div className="flex justify-between text-xs text-white/60">
                    <span>Balance Due</span>
                    <span className="tabular-nums" data-testid="customer-balance-due">{payment.reconciliationRequired?"Reconciliation required":formatMoney(payment.outstanding)}</span>
                  </div>
                )}
              </div>

              {/* Acceptance is independent of whether any further payment is due. */}
              {!pendingCustomerEstimate && Number(quote.total)>0 &&
                (!quote.superseded || (quote.leadIntake as any)?.reacceptanceRequiredVersion===quote.version) &&
                !["cancelled","closed"].includes(quote.status) && (
                <div className="px-6 pb-6 border-t border-white/10 pt-5 space-y-4">
                  {/* Terms acceptance gate — required before payment */}
                  <div ref={acceptanceRef} className="scroll-mt-24">
                    {termsAccepted ? (
                      <div className="flex items-start gap-2 bg-white/5 border border-white/10 px-3 py-2.5">
                        <ShieldCheck className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                        <p className="text-[11px] text-white/60 leading-relaxed" data-testid="text-terms-accepted">
                          You accepted this quote and its terms{(quote as any).termsAcceptedAt ? ` on ${format(new Date((quote as any).termsAcceptedAt), "MMM d, yyyy 'at' h:mm a")}` : ""}.
                        </p>
                      </div>
                    ) : (
                      <div className="bg-amber-400/10 border border-amber-400/30 px-3 py-3 space-y-3">
                        <div className="flex items-start gap-2">
                          <AlertCircle className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                          <p className="text-[11px] text-white/80 leading-relaxed font-semibold">
                            Please review and accept current quotation version {quote.version}. This does not charge you or confirm an appointment.
                          </p>
                        </div>
                        <label className="flex items-start gap-2.5 cursor-pointer" data-testid="checkbox-accept-terms">
                          <input
                            type="checkbox"
                            checked={termsAccepted}
                            onChange={() => { if (!termsAccepted && !accepting) handleAcceptTerms(); }}
                            disabled={accepting || offerValidityBlocksAction}
                            className="mt-0.5 w-4 h-4 accent-[#2af56a] shrink-0"
                          />
                          <span className="text-[11px] text-white/70 leading-relaxed">
                            I have read and accept this quote, its scope and timing, and the terms shown above
                            (deposit, cancellation and refund policy).
                          </span>
                        </label>
                        {accepting && <p className="text-[10px] text-white/40">Recording your acceptance…</p>}
                        {offerValidityBlocksAction && <p className="text-[10px] leading-relaxed text-amber-200">Staff review is needed before this quotation can be accepted.</p>}
                      </div>
                    )}
                  </div>
                  <p className="text-[11px] text-white/60" data-testid="acceptance-payment-unchanged">Payment received and balance remain unchanged. Do not pay again merely to accept this quotation.</p>
                </div>
              )}
              {showInitialPaymentAction && (
                <div className="px-6 pb-6 border-t border-white/10 pt-5 space-y-4">
                  <div>
                    <p className="text-xs text-white/50 mb-1">{isFullPay ? "Full Payment Required" : "Deposit Required"}</p>
                    <p className="text-2xl font-black mb-4 tabular-nums">{formatMoney(depositDisplay)}</p>
                    <button onClick={() => handleStripeCheckout("deposit")} disabled={checkoutLoading || !termsAccepted || offerValidityBlocksAction} data-testid="button-pay-deposit"
                      className="w-full bg-white text-black font-bold py-3.5 text-sm uppercase tracking-widest flex items-center justify-center gap-2 disabled:opacity-60 hover:bg-white/90 transition-colors"
                      style={{ letterSpacing: "0.12em" }}>
                      {checkoutLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <CreditCard className="w-4 h-4" />}
                      {checkoutLoading ? "Opening Checkout…" : (isFullPay ? "Pay In Full Now" : "Pay Deposit Now")}
                    </button>
                    {!termsAccepted && !offerValidityBlocksAction && (
                      <p className="text-[10px] text-white/40 text-center mt-2">Accept the terms above to enable payment.</p>
                    )}
                    {offerValidityBlocksAction && <p className="text-[10px] text-amber-200/80 text-center mt-2">Staff review is needed before a new payment can be made.</p>}
                  </div>
                  {/* PayNow QR alternative — also gated behind terms acceptance
                      so NO payment path (Stripe or PayNow) is usable until the
                      customer has accepted the current quote version. */}
                  {termsAccepted && !offerValidityBlocksAction && (
                    <div className="border-t border-white/10 pt-4">
                      <p className="text-[10px] font-semibold tracking-widest uppercase text-white/30 mb-3" style={{ letterSpacing: "0.15em" }}>
                        Or Pay via PayNow
                      </p>
                      <div className="flex flex-col items-center gap-3 bg-white/5 border border-white/10 p-4">
                        <img
                          src="/paynow-qr.png"
                          alt="PayNow QR Code"
                          data-testid="img-paynow-qr"
                          className="w-36 h-36 object-contain bg-white p-2"
                        />
                        <div className="text-center">
                          <p className="text-xs font-bold text-white/80">Scan with any banking app</p>
                          <p className="text-[10px] text-white/40 mt-1">UEN: 202424156H · TMG Install by The Moving Guy Pte Ltd</p>
                          <p className="text-[10px] text-white/40 mt-0.5">Add your ref no. <span className="font-semibold text-white/60">{quote.referenceNo}</span> in remarks</p>
                        </div>
                      </div>
                      <p className="text-[10px] text-white/30 text-center mt-2">
                        After PayNow transfer, WhatsApp us at {WHATSAPP_DISPLAY} with your receipt.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Deposit paid fallback — no preferred slot set (rare) */}
              {quote.status === "deposit_paid" && !quote.preferredDate && (
                <div className="px-6 pb-5 border-t border-white/10 pt-5 text-center">
                  <Clock className="w-6 h-6 mx-auto mb-2 text-white/40" />
                  <p className="font-bold text-sm">{isFullPay ? "Payment Received in Full" : "Deposit Received"}</p>
                  <p className="text-xs text-white/40 mt-1">Our team will contact you shortly to schedule your appointment.</p>
                </div>
              )}

              {/* Booking pending */}
              {quote.status === "booking_requested" && (
                <div className="px-6 pb-6 border-t border-white/10 pt-5 text-center">
                  <Clock className="w-6 h-6 mx-auto mb-2 text-white/40" />
                  <p className="font-bold text-sm">Booking Pending</p>
                  <p className="text-xs text-white/40 mt-1">We'll confirm your slot within 24 hours</p>
                </div>
              )}

              {/* Confirmed booking */}
              {["deposit_paid", "booked", "assigned", "in_progress", "at_pickup", "in_transit", "at_dropoff"].includes(quote.status) && quote.scheduledAt && (
                <div className="px-6 pb-6 border-t border-white/10 pt-5">
                  <p className="text-xs text-white/40 mb-3 uppercase tracking-widest" style={{ letterSpacing: "0.15em" }}>Confirmed</p>
                  <p className="font-bold text-sm flex items-center gap-2">
                    <CalendarDays className="w-4 h-4 text-white/50" />
                    {formatSingaporeDay(quote.scheduledAt, "MMM d, yyyy")}
                  </p>
                  <p className="font-bold text-sm flex items-center gap-2 mt-1.5 text-white/70">
                    <Clock className="w-4 h-4 text-white/40" />
                    {quote.timeWindow}
                  </p>
                </div>
              )}

              {/* Pay Final — only for jobs that still owe a balance (skip full-payment jobs) */}
              {payment.outstanding > 0.005 && ["completed", "final_payment_requested"].includes(quote.status) && (
                <div className="px-6 pb-6 border-t border-white/10 pt-5">
                  <p className="text-xs text-white/50 mb-1">Balance Due</p>
                  <p className="text-2xl font-black mb-4 tabular-nums">{formatMoney(payment.outstanding)}</p>
                  <button onClick={() => handleStripeCheckout("final")} disabled={checkoutLoading} data-testid="button-pay-final"
                    className="w-full bg-white text-black font-bold py-3.5 text-sm uppercase tracking-widest flex items-center justify-center gap-2 disabled:opacity-60 hover:bg-white/90 transition-colors"
                    style={{ letterSpacing: "0.12em" }}>
                    {checkoutLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <CreditCard className="w-4 h-4" />}
                    {checkoutLoading ? "Opening Checkout…" : "Pay Final Balance"}
                  </button>
                </div>
              )}

              {/* Closed */}
              {["closed", "final_paid"].includes(quote.status) && (
                <div className="px-6 pb-6 border-t border-white/10 pt-5 text-center">
                  <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-white/50" />
                  <p className="font-bold text-sm">All Paid — Case Closed</p>
                  <p className="text-xs text-white/40 mt-1">Thank you for choosing TMG Install</p>
                </div>
              )}
            </motion.div>

            {/* WhatsApp Contact — premium */}
            <motion.div {...fadeUp(0.2)} className="border border-black/12">
              <div className="px-5 py-4 border-b border-black/8">
                <p className="text-[10px] font-semibold tracking-widest uppercase text-black/40" style={{ letterSpacing: "0.15em" }}>
                  Need Help?
                </p>
              </div>
              <div className="px-5 py-4">
                <p className="text-xs text-black/50 mb-4 leading-relaxed">
                  Our team typically replies within minutes on WhatsApp for urgent assistance.
                </p>
                <a
                  href={WHATSAPP_HREF}
                  target="_blank"
                  rel="noopener noreferrer"
                  data-testid="link-whatsapp"
                  className="group flex items-center justify-between w-full px-5 py-4 bg-black text-white hover:bg-black/85 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <SiWhatsapp className="w-5 h-5 text-[#25D366]" />
                    <div>
                      <p className="text-[10px] font-semibold tracking-widest uppercase text-white/50 mb-0.5" style={{ letterSpacing: "0.15em" }}>
                        WhatsApp
                      </p>
                      <p className="font-bold text-sm text-white">Contact Us</p>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-white/40 group-hover:text-white/70 group-hover:translate-x-0.5 transition-all" />
                </a>
              </div>
            </motion.div>

          </div>
        </div>

      </div>
    </div>

    {/* ─── Photo Lightbox ─── */}
    {lightboxUrl && (
      <div
        className="fixed inset-0 z-50 tmg-scrim flex items-center justify-center p-4"
        onClick={() => setLightboxUrl(null)}
        data-testid="lightbox-overlay"
      >
        <button
          onClick={() => setLightboxUrl(null)}
          className="absolute top-4 right-4 text-white/60 hover:text-white text-sm font-bold bg-white/10 hover:bg-white/20 rounded-full w-9 h-9 flex items-center justify-center transition-colors"
          aria-label="Close"
        >
          ✕
        </button>
        <img
          src={lightboxUrl}
          alt="Work photo"
          className="max-w-full max-h-[90vh] object-contain shadow-2xl"
          onClick={e => e.stopPropagation()}
        />
      </div>
    )}
    </>
  );
}
