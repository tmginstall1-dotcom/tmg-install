import { useState, useEffect, useRef, useMemo, useCallback, useId, type MouseEvent } from "react";
import {enquiryRequestIdentity,clearEnquiryRequestIdentity,savePendingEnquiryDraft,readPendingEnquiryDraft,clearPendingEnquiryDraft,recoverEnquiryForm,sameEnquiryForm,retainEnquiryIdentity} from "@/lib/enquiry-request";
import { createPortal } from "react-dom";
import { usePromoBar } from "@/hooks/use-promo-bar";
import { useLocation } from "wouter";
import { usePageTracker, trackEvent } from "@/hooks/use-tracker";
import { trackPixelEvent, reportEstimateLead } from "@/lib/metaPixel";
import { useSEO } from "@/hooks/use-seo";
import { useQuery } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Wrench, Scissors, Truck, MapPin, Search, Plus, Minus, Trash2, 
  ChevronRight, ChevronLeft, Check, ClipboardList, Camera, X, 
  Loader2, AlertCircle, Star, Package, ArrowRight, Navigation, Tag,
  CalendarDays, Clock, MessageCircle
} from "lucide-react";
import { SlotPicker, type SlotAvailability } from "@/components/SlotPicker";
import type { CatalogItem, QuoteStop } from "@shared/schema";
import { groupStops, countExtraStops, genStopId } from "@/lib/stops";
import { computePricing, PricingConfig, computeDRPrice, computeReinstallOnlyPrice, effectiveCarryPrice, requiresSpecialHandling, requiresFullUpfront, relocationBundleBlocksPromo, type PricingCatalogEntry } from "@shared/pricing";
import { buildHandoffWaUrl, type HandoffPayload } from "@shared/whatsapp-handoff";
import { estimatePhotoEnquiryUrl } from "@shared/estimate-photo-enquiry";
import {
  LEAD_INTENT_OPTIONS, URGENCY_OPTIONS, SITE_TYPE_OPTIONS,
  ROOM_TYPE_OPTIONS, MANUALS_OPTIONS,
  leadIntentLabel, leadIntentLabels, primaryLeadIntent, urgencyLabel, itemCountLabel, siteTypeLabel, type LeadIntentValue,
} from "@shared/lead-intent";
import { estimateLandingContext } from "@shared/service-landings";
import {
  FURNITURE_CATEGORY_OPTIONS,
  classifyFurnitureLead,
  furnitureCatalogSearchMatches,
  furnitureNeedsSpecificationReview,
  type FurnitureCategory,
  type FurnitureLeadRouting,
} from "@shared/furnitureTaxonomy";
import { adMeasurementConsent, getLeadAttribution, setAdMeasurementConsent, trackFunnelEvent } from "@/lib/leadAttribution";
import { reportLeadConversion } from "@/lib/googleAds";
import { QuoteTermsBlock } from "@/components/shared/QuoteTermsBlock";
import { QuoteScheduleNote } from "@/components/shared/QuoteScheduleNote";
import { useToast } from "@/hooks/use-toast";

/* ─────────────────── Editorial primitives (mirror homepage) ───────────────────
   Inlined here so the estimate wizard matches the editorial language of "/"
   without coupling files: signature install-green ACCENT, AccentSquare,
   DotGrid backdrop. Same tokens as LandingCinematic + QuoteStatus.
   ────────────────────────────────────────────────────────────────────────── */
const EST_ACCENT = "#2af56a";

function EstAccentSquare({ className = "" }: { className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={`inline-block w-[10px] h-[10px] shrink-0 ${className}`}
      style={{ background: EST_ACCENT }}
    />
  );
}

function EstDotGrid({ opacity = 0.4, size = 28 }: { opacity?: number; size?: number }) {
  return (
    <div
      aria-hidden="true"
      className="absolute inset-0 pointer-events-none"
      style={{
        opacity,
        backgroundImage: "radial-gradient(circle, rgba(10,10,10,0.22) 1px, transparent 1px)",
        backgroundSize: `${size}px ${size}px`,
      }}
    />
  );
}

type ServiceType = "install" | "dismantle" | "relocate" | "dispose" | "dismantle_dispose";

interface LineItem {
  id: string;
  catalogItemId?: number;
  sku: string;
  name: string;
  category: string;
  serviceType: ServiceType;
  quantity: number;
  unitPrice: number;
  volumeM3?: number;
  isCustom: boolean;
  // Relocation sub-mode: full = dismantle + move + reinstall; carry = move as-is
  relocateMode?: 'full' | 'carry' | 'reinstall_only';
  carryPrice?: number;   // carry-only catalog price
  fullPrice?: number;    // dismantle + install combined price
  wrap?: boolean;        // customer opted into bubble-wrap protection ($10/unit)
  requiresReview?: boolean; // AI could not safely map this item to a priced row
  detectionToken?: string;
  details?: string;
  dimensions?: string;
  productLink?: string;
  photo?: string;
  // Multi-stop relocation — which pickup this item comes from / drop-off it
  // goes to (references a stop id). Undefined = use the default first stop.
  fromStopId?: string;
  toStopId?: string;
}

interface Floor {
  level: string;
  hasLift: boolean;
}

// Multi-stop relocation — an EXTRA pickup or drop-off beyond the primary
// pickup + primary drop-off the wizard already collects. Additive: when the
// list is empty the quote stays a single-leg relocation.
interface ExtraStop {
  id: string;
  kind: "pickup" | "dropoff";
  address: string;
  lat?: number;
  lng?: number;
  floor: string;
  hasLift: boolean;
}

interface CatalogGroup {
  name: string;
  category: string;
  categories?: string[];
  entries: { id: number; sku: string; serviceType: ServiceType; basePrice: string; volumeM3?: number }[];
}

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function createRequestUuid() {
  const bytes = new Uint8Array(16);
  if (typeof crypto !== "undefined" && typeof crypto.getRandomValues === "function") {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
  }
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

function isHttpProductLink(value: string) {
  try {
    const parsed = new URL(value);
    return (parsed.protocol === "http:" || parsed.protocol === "https:") && !!parsed.hostname;
  } catch {
    return false;
  }
}

function isValidQuantityDraft(value: string) {
  const quantity = Number(value);
  return /^\d{1,4}$/.test(value) && Number.isInteger(quantity) && quantity >= 1 && quantity <= 9999;
}

async function compressReviewPhoto(file: File): Promise<string> {
  if (!["image/jpeg", "image/png"].includes(file.type)) {
    throw new Error("Choose a JPEG or PNG photo.");
  }
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      URL.revokeObjectURL(url);
      try {
        let scale = Math.min(1, 1200 / Math.max(image.width, image.height));
        while (scale > 0.12) {
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(image.width * scale));
          canvas.height = Math.max(1, Math.round(image.height * scale));
          const context = canvas.getContext("2d");
          if (!context) { reject(new Error("Could not prepare that photo. Please try another image.")); return; }
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL("image/jpeg", 0.72);
          if (dataUrl.length <= 700000) { resolve(dataUrl); return; }
          scale *= 0.78;
        }
        reject(new Error("That photo is too large to attach. Try a smaller image."));
      } catch {
        reject(new Error("Could not prepare that photo. Please try another image."));
      }
    };
    image.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Could not read that photo. Choose a JPEG or PNG image.")); };
    image.src = url;
  });
}

// ── Singapore Address Autocomplete ──────────────────────────────────────────

interface AddressSuggestion {
  address: string;
  lat: number;
  lng: number;
}

function useAddressSuggestions(query: string) {
  const [suggestions, setSuggestions] = useState<AddressSuggestion[]>([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (!query || query.length < 3) { setSuggestions([]); return; }
    setLoading(true);
    const t = setTimeout(async () => {
      try {
        // Goes through our backend proxy — OneMap's CORS policy blocks direct
        // browser calls, so calling onemap.gov.sg from the page silently
        // returned zero suggestions. The /api/onemap/search route forwards
        // the query server-side and returns the raw OneMap JSON shape.
        const res = await fetch(`/api/onemap/search?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        function toTitle(s: string): string {
          return s.toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
        }
        const results = (data.results || []).slice(0, 6).map((r: any) => {
          const parts: string[] = [];
          if (r.BLK_NO && r.BLK_NO !== "NIL") parts.push(r.BLK_NO);
          if (r.ROAD_NAME && r.ROAD_NAME !== "NIL") parts.push(toTitle(r.ROAD_NAME));
          if (r.BUILDING && r.BUILDING !== "NIL") parts.push(toTitle(r.BUILDING));
          parts.push(`Singapore ${r.POSTAL}`);
          return {
            address: parts.join(", "),
            lat: parseFloat(r.LATITUDE),
            lng: parseFloat(r.LONGITUDE),
          };
        });
        setSuggestions(results);
      } catch { setSuggestions([]); }
      setLoading(false);
    }, 350);
    return () => clearTimeout(t);
  }, [query]);
  return { suggestions, loading };
}

function AddressInput({ value, onSelect, placeholder, label, required }: {
  value: string;
  onSelect: (address: string, lat?: number, lng?: number) => void;
  placeholder?: string; label: string; required?: boolean;
}) {
  const inputId=useId();
  const [show, setShow] = useState(false);
  const [rect, setRect] = useState<{ left: number; top: number; width: number } | null>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { suggestions, loading } = useAddressSuggestions(value);

  // Recompute dropdown position relative to input
  const updateRect = useCallback(() => {
    const el = inputRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    setRect({ left: r.left, top: r.bottom, width: r.width });
  }, []);

  useEffect(() => {
    if (!show) return;
    updateRect();
    window.addEventListener("scroll", updateRect, true);
    window.addEventListener("resize", updateRect);
    return () => {
      window.removeEventListener("scroll", updateRect, true);
      window.removeEventListener("resize", updateRect);
    };
  }, [show, updateRect, suggestions.length]);

  // Outside-click / outside-touch closes dropdown
  useEffect(() => {
    function handler(e: Event) {
      const target = e.target as Node;
      if (wrapRef.current?.contains(target)) return;
      if (dropdownRef.current?.contains(target)) return;
      setShow(false);
    }
    document.addEventListener("mousedown", handler);
    document.addEventListener("touchstart", handler);
    return () => {
      document.removeEventListener("mousedown", handler);
      document.removeEventListener("touchstart", handler);
    };
  }, []);

  return (
    <div ref={wrapRef} className="relative">
      <label htmlFor={inputId} className="text-[10px] font-black uppercase tracking-[0.15em] text-black/40 block mb-2">{label}{required && <span className="text-black ml-1">*</span>}</label>
      <div className="relative">
        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-black/30 pointer-events-none" />
        <input
          id={inputId}
          ref={inputRef}
          required={required}
          value={value}
          onChange={e => { onSelect(e.target.value); setShow(true); updateRect(); }}
          onFocus={() => { setShow(true); updateRect(); }}
          placeholder={placeholder || "Start typing an address…"}
          data-testid={`input-address-${label.toLowerCase().replace(/\s+/g, "-")}`}
          className="w-full pl-9 pr-4 py-3 bg-white border border-black/10 focus:border-black outline-none transition-all text-sm"
        />
        {loading && <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-black/30 pointer-events-none" />}
      </div>
      {show && suggestions.length > 0 && rect && typeof document !== "undefined" && createPortal(
        <div
          ref={dropdownRef}
          style={{
            position: "fixed",
            left: rect.left,
            top: rect.top + 2,
            width: rect.width,
            zIndex: 9999,
            maxHeight: "50vh",
            overflowY: "auto",
            WebkitOverflowScrolling: "touch",
          }}
          className="bg-white border border-black/15 shadow-lg"
        >
          {suggestions.map((s, i) => (
            <button
              key={i}
              type="button"
              onMouseDown={(e) => { e.preventDefault(); onSelect(s.address, s.lat, s.lng); setShow(false); }}
              className="w-full text-left px-4 py-3 hover:bg-slate-50 active:bg-slate-100 text-sm text-black border-b border-black/10 last:border-0 transition-colors"
            >{s.address}</button>
          ))}
        </div>,
        document.body
      )}
    </div>
  );
}

// ── Catalog grouping ────────────────────────────────────────────────────────

function groupCatalog(items: CatalogItem[]): CatalogGroup[] {
  const map: Record<string, CatalogGroup> = {};
  items.forEach(item => {
    const key = item.name.toLowerCase().trim();
    if (!map[key]) map[key] = { name: item.name, category: item.category || "", categories: [], entries: [] };
    const itemCategory = (item.category || "").trim();
    if (itemCategory && !map[key].categories!.includes(itemCategory)) map[key].categories!.push(itemCategory);
    // Deduplicate by serviceType — keep only first entry per service type
    const alreadyHasType = map[key].entries.some(e => e.serviceType === item.serviceType);
    if (!alreadyHasType) {
      map[key].entries.push({
        id: item.id,
        sku: item.sku || "",
        serviceType: item.serviceType as ServiceType,
        basePrice: item.basePrice,
        volumeM3: item.volumeM3 ? parseFloat(item.volumeM3) : undefined,
      });
    }
  });
  return Object.values(map);
}

function serviceBadge(s: ServiceType) {
  const labels: Record<ServiceType, string> = {
    install: "Install", dismantle: "Dismantle", relocate: "Relocate",
    dispose: "Dispose", dismantle_dispose: "Dismantle + Dispose",
  };
  return <span className="text-[10px] font-black uppercase tracking-[0.08em] px-2 py-0.5 border border-black/20 text-black/60">{labels[s] ?? s}</span>;
}

// ── Main Wizard ─────────────────────────────────────────────────────────────

const STEPS = [
  { num: 1, label: "Services" },
  { num: 2, label: "Address" },
  { num: 3, label: "Items" },
  { num: 4, label: "Schedule" },
  { num: 5, label: "Review" },
];

const TIME_SLOTS = [
  { value: "09:00-12:00", label: "Morning", time: "9am – 12pm" },
  { value: "13:00-17:00", label: "Afternoon", time: "1pm – 5pm" },
];

const CATEGORY_GROUPS: { label: string; match: string[] | null }[] = [
  { label: "All", match: null },
  { label: "Beds", match: ["beds", "mattress"] },
  { label: "Bedroom", match: ["bedroom"] },
  { label: "Wardrobes", match: ["wardrobe", "bedroom storage"] },
  { label: "Sofas", match: ["sofa", "living room"] },
  { label: "Dining", match: ["dining"] },
  { label: "Office", match: ["office", "workstation", "meeting pod"] },
  { label: "Salon", match: ["salon"] },
  { label: "Entertainment", match: ["entertainment"] },
  { label: "Appliances", match: ["appliance"] },
  { label: "IKEA", match: ["ikea"] },
  { label: "Storage", match: ["storage", "shelving", "racking"] },
  { label: "Wall Hanging", match: ["wall", "mirror", "art"] },
];

function toDateStr(y: number, m: number, d: number) {
  return `${y}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

export default function EstimateWizard() {
  const [, setLocation] = useLocation();
  usePageTracker("/estimate");
  useSEO({
    title: "Get an Instant Quote | Furniture Installation Singapore — TMG Install",
    description: "Use our online quote wizard to request an itemised estimate for furniture installation, dismantling, or relocation anywhere in Singapore.",
    canonical: "https://tmginstall.com/estimate",
  });
  const [step, setStep] = useState<1 | 2 | 3 | 4 | 5>(1);
  const previousStep=useRef(step);
  useEffect(()=>{
    if(previousStep.current===step)return;
    previousStep.current=step;
    const seek=()=>{
      const heading=document.querySelector<HTMLElement>(`[data-estimate-step="${step}"] [data-estimate-step-heading]`);
      if(!heading)return;
      heading.focus({preventScroll:false});
      observer.disconnect();
    };
    // AnimatePresence keeps the old step mounted during its exit. Wait for the
    // requested step, not an arbitrary timer that can focus the old heading.
    const observer=new MutationObserver(seek);
    observer.observe(document.body,{childList:true,subtree:true});
    seek();
    return()=>observer.disconnect();
  },[step]);
  const wizardStartFired = useRef(false);
  useEffect(() => {
    if (wizardStartFired.current) return;
    wizardStartFired.current = true;
    trackEvent("wizard_start", "/estimate");
    trackPixelEvent("InitiateCheckout");
  }, []);

  // Resume from abandoned lead link (?resume=TOKEN)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const resumeToken = params.get("resume");
    if (!resumeToken) return;
    fetch(`/api/partial-leads/resume/${resumeToken}`)
      .then(r => r.ok ? r.json() : null)
      .then(lead => {
        if (!lead) return;
        setPartialLeadToken(resumeToken);
        setCaptureShown(true);
        if (lead.email) setCaptureEmail(lead.email);
        if (lead.name) setCaptureName(lead.name);
        if (lead.services && Array.isArray(lead.services)) {
          // Normalize on resume: if Relocation is present, drop redundant Install/Dismantle
          // (legacy partial leads may have stored conflicting selections before this UX fix).
          const raw = lead.services as ServiceType[];
          const normalized = raw.includes("relocate")
            ? raw.filter(s => s !== "install" && s !== "dismantle")
            : raw;
          setServices(normalized);
        }
        if (lead.serviceAddress) setServiceAddress(lead.serviceAddress);
        if (lead.pickupAddress) setPickupAddress(lead.pickupAddress);
        if (lead.dropoffAddress) setDropoffAddress(lead.dropoffAddress);
        setStep(3);
      })
      .catch(() => {});
  }, []);

  // Step 1
  const [services, setServices] = useState<ServiceType[]>(() => {
    // Pre-select a service when arriving from a landing-page intent card
    // (e.g. /estimate?service=dismantle&intent=furniture_dismantling).
    // Invalid values are ignored.
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const svc = params.get("service");
      if (svc === "install" || svc === "dismantle" || svc === "relocate") {
        return [svc];
      }
      // Intent-style params from service pages — map to the base service.
      if (svc === "office" || svc === "taobao") return ["install"];
      // No valid ?service= — fall back to the ?intent= mapping if present.
      const intent = params.get("intent");
      const opt = LEAD_INTENT_OPTIONS.find(o => o.value === intent);
      if (opt) {
        const base = opt.services[0] === "dismantle_dispose" ? "dismantle" : opt.services[0];
        if (base === "install" || base === "dismantle" || base === "relocate") return [base];
      }
    }
    return [];
  });
  // Lead intent (job type) — refines the broad service selection for lead
  // quality / Ads analysis. Optional; preselected from ?intent= (preferred)
  // or the legacy ?service= values.
  const [leadIntents, setLeadIntents] = useState<LeadIntentValue[]>(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const intent = params.get("intent");
      const opt = LEAD_INTENT_OPTIONS.find(o => o.value === intent);
       if (opt) return [opt.value];
      const svc = params.get("service");
       if (svc === "office") return ["office_furniture_install"];
       if (svc === "taobao") return ["taobao_flatpack_install"];
       if (svc === "dismantle") return ["furniture_dismantling"];
       if (svc === "relocate") return ["relocation_dr"];
    }
    return [];
  });
  // `leadIntent` remains the primary value for legacy analytics and server
  // consumers; `leadIntents` preserves the complete chip selection.
  const leadIntent = primaryLeadIntent(leadIntents) as LeadIntentValue | "";
  const leadIntentText = leadIntentLabels(leadIntents);
  // Lead-quality fields (all optional — captured on the review step)
  const [urgency, setUrgency] = useState("");
  const [siteType, setSiteType] = useState(() =>
    typeof window === "undefined" ? "" : estimateLandingContext(window.location.search).siteType || "");
  const [leadNotes, setLeadNotes] = useState("");
  const [roomType, setRoomType] = useState("");
  const [productLink, setProductLink] = useState("");
  const [cartonCount, setCartonCount] = useState("");
  const [manualsAvailable, setManualsAvailable] = useState<"" | "yes" | "no" | "unsure">("");
  const [manualCategoryHint, setManualCategoryHint] = useState<FurnitureCategory | "">("");
  const [wallMounting, setWallMounting] = useState(false);
  const [drillingRequired, setDrillingRequired] = useState(false);
  const [dismantleRequired, setDismantleRequired] = useState(false);
  const [reinstallRequired, setReinstallRequired] = useState(false);
  const [disposalRequired, setDisposalRequired] = useState(false);
  const [officeSeatCount, setOfficeSeatCount] = useState("");
  const [floorPlanAvailable, setFloorPlanAvailable] = useState(false);
  const [afterHoursRequired, setAfterHoursRequired] = useState(false);
  const [partitionsRequired, setPartitionsRequired] = useState(false);
  const [pedestalsRequired, setPedestalsRequired] = useState(false);
  const [cableManagementRequired, setCableManagementRequired] = useState(false);
  // Review-step funnel event — fires once per wizard session when the
  // customer reaches Step 5 (non-conversion, analysis only).
  const reviewViewedFired = useRef(false);
  useEffect(() => {
    if (step !== 5 || reviewViewedFired.current) return;
    reviewViewedFired.current = true;
    trackFunnelEvent("estimate_review_viewed", {
      lead_intent: leadIntentText || undefined,
      services: services.join(","),
    });
  }, [step, leadIntentText, services]);
  const [disposalMode, setDisposalMode] = useState<"dispose" | "dismantle_dispose">("dismantle_dispose");
  // Step 2
  const [serviceAddress, setServiceAddress] = useState("");
  const [pickupAddress, setPickupAddress] = useState("");
  const [pickupLatLng, setPickupLatLng] = useState<{ lat: number; lng: number } | null>(null);
  const [dropoffAddress, setDropoffAddress] = useState("");
  const [dropoffLatLng, setDropoffLatLng] = useState<{ lat: number; lng: number } | null>(null);
  // Same-Property Move — items shifted within the SAME address (between rooms,
  // floors of the same condo, during renovation). When true: only pickupAddress
  // is collected (used as both pickup & dropoff on the server), no distance is
  // calculated, no transport fee is charged, but the $39.90 mobilisation fee
  // still applies and Carry-Handling ($20/m³) still applies for carry items.
  const [samePropertyMove, setSamePropertyMove] = useState(false);
  const [distanceKm, setDistanceKm] = useState(0);
  const [distanceLoading, setDistanceLoading] = useState(false);
  const [distanceError, setDistanceError] = useState("");
  // Default to ground floor (level 0) so we never auto-add a floor surcharge
  // before the customer has actually told us about lift/stairs/floor.
  const [floors, setFloors] = useState<Floor[]>([{ level: "0", hasLift: true }]);
  const [accessDifficulty, setAccessDifficulty] = useState<"easy" | "medium" | "hard">("easy");
  // Tracks whether the customer has explicitly answered the access questions.
  // When false, any computed floor/access fee is shown as an *estimate* and
  // we surface a "confirmed on-site" caveat in the review summary.
  const [accessAnswered, setAccessAnswered] = useState(false);
  const [stairsAnswer, setStairsAnswer] = useState<"no" | "yes" | "unsure" | null>(null);
  // Multi-stop relocation — EXTRA pickups / drop-offs beyond the primary pair.
  // Empty = single-leg (legacy behaviour, no stops[] persisted). Stable ids for
  // the primary pickup / drop-off so line items can reference them across the
  // grouped stop list (Pickup 1 / Drop-off A).
  const [extraStops, setExtraStops] = useState<ExtraStop[]>([]);
  const [primaryPickupStopId,setPrimaryPickupStopId] = useState(() => genStopId());
  const [primaryDropoffStopId,setPrimaryDropoffStopId] = useState(() => genStopId());
  // Step 3
  const [items, setItems] = useState<LineItem[]>([]);
  const requestedItemCount = items.reduce((sum,item)=>sum+item.quantity,0);
  const itemCountRange = requestedItemCount >= 7 ? "7_plus" : requestedItemCount >= 4 ? "4_6" : requestedItemCount >= 2 ? "2_3" : requestedItemCount === 1 ? "1" : "";
  const [customName, setCustomName] = useState("");
  const [customQuantity, setCustomQuantity] = useState("1");
  const [customDimensions, setCustomDimensions] = useState("");
  const [customDetails, setCustomDetails] = useState("");
  const [customLink, setCustomLink] = useState("");
  const [customPhoto, setCustomPhoto] = useState("");
  const [customService, setCustomService] = useState<ServiceType | "">("");
  const [customError, setCustomError] = useState("");
  const [customItemQuantityDrafts, setCustomItemQuantityDrafts] = useState<Record<string, string>>({});
  const [photoConversionsPending, setPhotoConversionsPending] = useState(0);
  const photoConversionsLock = useRef(0);
  const [catalogVisibleCount, setCatalogVisibleCount] = useState(24);

  // Item reconciliation: when Relocation gets selected, install/dismantle line
  // items in the cart become redundant (Relocation already covers them as a
  // bundle). Drop them so the cart total reflects the user's intent and
  // matches what Step 1 visually communicates.
  useEffect(() => {
    if (services.includes("relocate")) {
      setItems(prev => {
        const filtered = prev.filter(i => i.serviceType !== "install" && i.serviceType !== "dismantle");
        return filtered.length === prev.length ? prev : filtered;
      });
    }
  }, [services]);

  const [catalogSearch, setCatalogSearch] = useState("");
  const [catalogFocused, setCatalogFocused] = useState(false);
  const [activeCategory, setActiveCategory] = useState("All");
  const [pasteText, setPasteText] = useState("");
  const [showPaste, setShowPaste] = useState(false);
  const { toast } = useToast();
  const [photoDetecting, setPhotoDetecting] = useState(false);
  const [photoError, setPhotoError] = useState("");
  const [detectedPhotos, setDetectedPhotos] = useState<{ thumbnail: string; names: string[]; count: number }[]>([]);
  const [photoRouting, setPhotoRouting] = useState<FurnitureLeadRouting | null>(null);
  const [detectingProgress, setDetectingProgress] = useState<{ current: number; total: number } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  // Step 4: Schedule
  const [slotDateStr, setSlotDateStr] = useState("");               // "yyyy-MM-dd"
  const [slotTime, setSlotTime] = useState("");
  const [scheduleError, setScheduleError] = useState("");
  // Step 5: Review / Contact
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const submitLockRef = useRef(false);
  const requestIdentityRef = useRef<{ fingerprint: string; id: string } | null>(null);
  const pendingEnquiryRef=useRef<{body:any;form:any;uncertain?:boolean}|null>(null);
  const [retryStorageWarning,setRetryStorageWarning]=useState("");
  const enquiryForm=()=>recoverEnquiryForm({body:{},form:{name,email,phone,services,items,serviceAddress,pickupAddress,dropoffAddress,
    samePropertyMove,floors,accessDifficulty,slotDateStr,slotTime,leadNotes,promoCode,promoDiscount,promoStatus,leadIntents,urgency,siteType,roomType,
    productLink,cartonCount,manualsAvailable,manualCategoryHint,officeSeatCount,wallMounting,drillingRequired,dismantleRequired,
    reinstallRequired,disposalRequired,floorPlanAvailable,afterHoursRequired,partitionsRequired,pedestalsRequired,
    cableManagementRequired,disposalMode,accessAnswered,stairsAnswer,extraStops,primaryPickupStopId,primaryDropoffStopId,
    detectedPhotos,photoRouting}});
  useEffect(()=>{
    let store:Storage|undefined;
    try{store=window.sessionStorage;}catch{}
    const saved=readPendingEnquiryDraft(store);
    if(!saved)return;
    saved.form=recoverEnquiryForm(saved);
    // A reload cannot establish whether the previous POST committed.
    saved.uncertain=true;
    pendingEnquiryRef.current=saved;
    const f=saved.form;
    setLeadIntents(f.leadIntents);setUrgency(f.urgency);setSiteType(f.siteType);setRoomType(f.roomType);
    setProductLink(f.productLink);setCartonCount(f.cartonCount);setManualsAvailable(f.manualsAvailable);
    setManualCategoryHint(f.manualCategoryHint);setOfficeSeatCount(f.officeSeatCount);setWallMounting(f.wallMounting);
    setDrillingRequired(f.drillingRequired);setDismantleRequired(f.dismantleRequired);setReinstallRequired(f.reinstallRequired);
    setDisposalRequired(f.disposalRequired);setFloorPlanAvailable(f.floorPlanAvailable);setAfterHoursRequired(f.afterHoursRequired);
    setPartitionsRequired(f.partitionsRequired);setPedestalsRequired(f.pedestalsRequired);setCableManagementRequired(f.cableManagementRequired);
    setDisposalMode(f.disposalMode);setAccessAnswered(f.accessAnswered);setStairsAnswer(f.stairsAnswer);
    setExtraStops(f.extraStops);setPrimaryPickupStopId(f.primaryPickupStopId);setPrimaryDropoffStopId(f.primaryDropoffStopId);
    setDetectedPhotos(f.detectedPhotos);setPhotoRouting(f.photoRouting);
    setServices(saved.form.services);setItems(saved.form.items);setStep(5);
    setName(saved.form.name||"");setEmail(saved.form.email||"");setPhone(saved.form.phone||"");
    setServiceAddress(saved.form.serviceAddress||"");setPickupAddress(saved.form.pickupAddress||"");
    setDropoffAddress(saved.form.dropoffAddress||"");setSamePropertyMove(!!saved.form.samePropertyMove);
    if(Array.isArray(saved.form.floors))setFloors(saved.form.floors);
    if(["easy","medium","hard"].includes(saved.form.accessDifficulty))setAccessDifficulty(saved.form.accessDifficulty);
    setSlotDateStr(saved.form.slotDateStr||"");setSlotTime(saved.form.slotTime||"");
    setLeadNotes(saved.form.leadNotes||"");setPromoCode(saved.form.promoCode||"");
    const savedPromoDiscount=Number(saved.form.promoDiscount);
    const hasSavedPromo=!!saved.form.promoCode&&Number.isFinite(savedPromoDiscount)&&savedPromoDiscount>0;
    setPromoDiscount(hasSavedPromo?savedPromoDiscount:0);
    setPromoStatus(hasSavedPromo?"restored":"idle");
    setSubmitError("Your unsent enquiry details were restored. Retry the same details first; they may already have been saved.");
  },[]);
  useEffect(()=>{
    let timer:ReturnType<typeof setTimeout>;
    const reveal=()=>{
      const focused=document.activeElement;
      if(!(focused instanceof HTMLElement)||focused===document.body)return;
      const bar=document.getElementById("estimate-step-actions");
      if(!bar)return;
      const viewport=window.visualViewport;
      const top=viewport?.offsetTop||0;
      const bottom=Math.min(top+(viewport?.height||window.innerHeight),bar.getBoundingClientRect().top)-16;
      const rect=focused.getBoundingClientRect();
      if(rect.bottom>bottom||rect.top<top+12)focused.scrollIntoView({block:"center",behavior:"auto"});
    };
    const onFocus=()=>{requestAnimationFrame(reveal);clearTimeout(timer);timer=setTimeout(reveal,350);};
    document.addEventListener("focusin",onFocus);
    window.visualViewport?.addEventListener("resize",onFocus);
    return()=>{clearTimeout(timer);document.removeEventListener("focusin",onFocus);
      window.visualViewport?.removeEventListener("resize",onFocus);};
  },[]);
  const [submitError, setSubmitError] = useState("");
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  // Promo code state
  const [promoInput, setPromoInput] = useState("");
  const [promoCode, setPromoCode] = useState<string | null>(null);
  const [promoDiscount, setPromoDiscount] = useState(0);
  const [promoStatus, setPromoStatus] = useState<"idle" | "validating" | "valid" | "restored" | "invalid">("idle");
  const [promoMessage, setPromoMessage] = useState("");

  // Partial lead capture (abandoned wizard recovery)
  const [showCaptureModal, setShowCaptureModal] = useState(false);
  const [showContactEditor, setShowContactEditor] = useState(false);
  const [captureEmail, setCaptureEmail] = useState("");
  const [captureName, setCaptureName] = useState("");
  const [captureSaving, setCaptureSaving] = useState(false);
  const [partialLeadToken, setPartialLeadToken] = useState<string | null>(null);
  const [captureShown, setCaptureShown] = useState(false);
  const [measurementConsent, setMeasurementConsent] = useState(() => adMeasurementConsent()==="granted");
  const [photoHandoffPending, setPhotoHandoffPending] = useState(false);
  const [photoHandoffError, setPhotoHandoffError] = useState("");
  const [photoHandoffContinueUrl, setPhotoHandoffContinueUrl] = useState("");
  const [photoHandoffHasReference, setPhotoHandoffHasReference] = useState(false);
  const photoHandoffWindow = useRef<Window | null>(null);

  const { visible: promoVisible, promo: promoBarData } = usePromoBar();

  const isRelocation = services.includes("relocate");
  const leadRouting = classifyFurnitureLead({
    itemText: items.map(item => item.name),
    customerNotes: leadNotes,
    selectedJobType: leadIntents.join(" "),
    selectedServices: [
      ...services,
      ...(dismantleRequired ? ["dismantle"] : []),
      ...(reinstallRequired ? ["dismantle_install"] : []),
    ],
    roomType,
    siteType,
    sellerProductLink: productLink,
    manualCategoryHint: manualCategoryHint || undefined,
    officeSeatCount: officeSeatCount ? Number(officeSeatCount) : undefined,
  });

  // Fetch catalog — short stale time so price changes apply quickly
  const { data: catalogRaw } = useQuery<CatalogItem[]>({
    queryKey: ["/api/catalog"],
    queryFn: () => fetch("/api/catalog").then(r => r.json()),
    staleTime: 30_000,
    gcTime: 10 * 60_000,
  });

  // Fetch slot availability (blocked + held + capacities)
  const { data: slotAvailability } = useQuery<SlotAvailability>({
    queryKey: ["/api/slots/availability"],
    queryFn: () => fetch("/api/slots/availability").then(r => r.json()),
  });

  const isSlotTaken = (dateStr: string, timeSlot: string) => {
    if (!slotAvailability || !dateStr) return false;
    const blockedDay = slotAvailability.blocked.some(b => b.date === dateStr && (b.timeSlot === null || b.timeSlot === timeSlot));
    const heldSlot = slotAvailability.held.some(h => h.date === dateStr && h.timeSlot === timeSlot);
    return blockedDay || heldSlot;
  };

  const catalogGroups = useMemo(() => groupCatalog(catalogRaw || []), [catalogRaw]);

  // ── Timeline / manpower estimator (large jobs, ≥50 total units) ───────────
  // Per-unit labour MAN-MINUTES for INSTALL by item family (single-person
  // equivalent — i.e. how many minutes one technician would need). Adding a
  // second crew member halves wall-clock time but keeps the man-minute total
  // the same, which is what we sum up for crew/day sizing.
  //
  // These are honest field averages from TMG jobs — they include the actual
  // mechanical work only (unboxing, fastening, levelling). Setup, breaks,
  // packaging removal, on-site coordination and customer Q&A are added back
  // separately as a 20% overhead, and we use 7 productive hours per crew per
  // day (not 8) to reflect lunch + 2 short breaks.
  const perUnitInstallMinutes = (item: LineItem): number => {
    const n = item.name.toLowerCase();
    if (/auditorium|theatre|theater|cinema|lecture/.test(n)) return 15;   // ~4 seats / man-hour
    if (/\bpax\b|wardrobe|closet/.test(n)) return 210;                    // 3.5 man-hours per PAX (real)
    if (/king\s*bed|queen\s*bed/.test(n)) return 90;
    if (/double\s*bed|super\s*single|single\s*bed|bed\s*frame/.test(n)) return 75;
    if (/dining\s*table|conference\s*table|kitchen\s*island/.test(n)) return 75;
    if (/office\s*desk|study\s*desk/.test(n)) return 50;
    if (/sofa|couch|sectional|chaise|recliner/.test(n)) return 50;
    if (/bookshelf|cabinet|shelving|kitchen\s*rack|tv\s*console/.test(n)) return 40;
    if (/dining\s*chair|stool/.test(n)) return 8;
    if (/ergonomic|office\s*chair|task\s*chair/.test(n)) return 10;
    if (/mattress/.test(n)) return 12;
    return 35; // generic furniture install
  };
  const itemLabourMinutes = (item: LineItem): number => {
    const inst = perUnitInstallMinutes(item);
    let perUnit = inst;
    if (item.serviceType === "dismantle") perUnit = Math.round(inst * 0.7);
    else if (item.serviceType === "dispose") perUnit = Math.round(inst * 0.6);
    else if (item.serviceType === "dismantle_dispose") perUnit = Math.round(inst * 1.1);
    else if (item.serviceType === "relocate") {
      // Carry-only ≈ lift, walk, place. D&R = dismantle + pack + carry + reinstall.
      // Reinstall-only (already dismantled) ≈ carry + assembly at destination.
      perUnit = item.relocateMode === "carry" ? Math.round(inst * 0.6)
        : item.relocateMode === "reinstall_only" ? Math.round(inst * 1.3)
        : Math.round(inst * 2.0);
    }
    return perUnit * item.quantity;
  };
  const timelinePlan = useMemo(() => {
    const totalUnits = items.reduce((s, i) => s + i.quantity, 0);
    if (totalUnits < 50) return null;
    const rawManMinutes = items.reduce((s, i) => s + itemLabourMinutes(i), 0);
    // 20% overhead for setup, breaks, packaging removal, coordination,
    // customer Q&A, navigating between rooms/units on multi-unit sites.
    const overheadMultiplier = 1.20;
    const totalManMinutes = Math.round(rawManMinutes * overheadMultiplier);
    const totalManHours = Math.ceil(totalManMinutes / 60);
    // Recommended crew sizing — scales with job size to stay within reason.
    let crewSize = 3;
    if (totalUnits >= 300) crewSize = 8;
    else if (totalUnits >= 200) crewSize = 6;
    else if (totalUnits >= 100) crewSize = 4;
    // 7 productive hours/day after lunch + breaks (8h shift, 1h non-productive).
    const hoursPerDayPerCrew = 7;
    const days = Math.max(1, Math.ceil(totalManHours / (crewSize * hoursPerDayPerCrew)));
    return { totalUnits, totalManHours, crewSize, days };
  }, [items]);

  // Familiar category-group chips stay compact. The native select below
  // exposes every exact public category that isn't already in those groups.
  const publicCategories = useMemo(
    () => Array.from(new Set((catalogRaw || []).map(item => (item.category || "").trim()).filter(Boolean))).sort((a, b) => a.localeCompare(b)),
    [catalogRaw],
  );
  const additionalCategories = useMemo(
    () => publicCategories.filter(category => !CATEGORY_GROUPS.slice(1).some(group =>
      group.match?.some(keyword => category.toLowerCase().includes(keyword)),
    )),
    [publicCategories],
  );

  const filteredGroups = useMemo(() => {
    let groups = catalogGroups;
    if (!catalogSearch.trim() && activeCategory !== "All") {
      if (activeCategory.startsWith("exact:")) {
        const exactCategory = activeCategory.slice("exact:".length);
          groups = groups.filter(g => (g.categories || [g.category]).some(category => category.trim() === exactCategory));
      } else {
        const categoryGroup = CATEGORY_GROUPS.find(group => group.label === activeCategory);
        if (categoryGroup?.match) {
          groups = groups.filter(group => (group.categories || [group.category]).some(category => categoryGroup.match!.some(keyword => category.toLowerCase().includes(keyword))));
        }
      }
    }
    if (!catalogSearch.trim()) return groups;
    const q = catalogSearch.trim();
    return groups.filter(g =>
      furnitureCatalogSearchMatches(q, [
        g.name,
        g.category,
        ...(g.categories || []),
        ...g.entries.map(e => e.sku),
      ])
    );
  }, [catalogSearch, catalogGroups, activeCategory]);

  const showCatalogResults = catalogFocused || catalogSearch.trim().length > 0;
  const showAllCatalog = activeCategory === "All" && !catalogSearch.trim();
  const visibleCatalogGroups = showAllCatalog ? filteredGroups.slice(0, catalogVisibleCount) : filteredGroups;
  const activeCategoryLabel = activeCategory.startsWith("exact:") ? activeCategory.slice("exact:".length) : activeCategory;

  // ── Multi-stop relocation derived state ──────────────────────────────────
  // The primary pickup / drop-off plus any EXTRA stops, assembled into the
  // canonical ordered list (all pickups first, then all drop-offs) so the
  // shared groupStops/labelForStop helpers number them as Pickup 1/2…,
  // Drop-off A/B…. Empty unless the customer added at least one extra stop.
  // Extra stops only count when this is a true different-address relocation.
  // For non-relocation services or Same-Property Moves they must be ignored
  // entirely (no floor surcharges, no stop fee, not persisted) even if the
  // customer added some and then toggled the mode.
  const activeExtraStops = useMemo(
    () => (isRelocation && !samePropertyMove) ? extraStops : [],
    [isRelocation, samePropertyMove, extraStops],
  );
  const extraPickups = useMemo(() => activeExtraStops.filter(s => s.kind === "pickup"), [activeExtraStops]);
  const extraDropoffs = useMemo(() => activeExtraStops.filter(s => s.kind === "dropoff"), [activeExtraStops]);

  const allStops = useMemo<QuoteStop[]>(() => {
    if (!isRelocation || samePropertyMove || extraStops.length === 0) return [];
    const list: QuoteStop[] = [];
    list.push({
      id: primaryPickupStopId, kind: "pickup", address: pickupAddress,
      postalCode: null, floor: floors[0]?.level ?? null, hasLift: floors[0]?.hasLift ?? null,
    });
    extraPickups.forEach(s => list.push({
      id: s.id, kind: "pickup", address: s.address,
      postalCode: null, floor: s.floor || null, hasLift: s.hasLift,
    }));
    list.push({
      id: primaryDropoffStopId, kind: "dropoff", address: dropoffAddress,
      postalCode: null, floor: floors[1]?.level ?? null, hasLift: floors[1]?.hasLift ?? null,
    });
    extraDropoffs.forEach(s => list.push({
      id: s.id, kind: "dropoff", address: s.address,
      postalCode: null, floor: s.floor || null, hasLift: s.hasLift,
    }));
    return list;
  }, [isRelocation, samePropertyMove, extraStops, extraPickups, extraDropoffs, pickupAddress, dropoffAddress, floors, primaryPickupStopId, primaryDropoffStopId]);

  const isMultiStop = allStops.length > 2;
  const extraStopCount = isMultiStop ? countExtraStops(allStops) : 0;
  const stopGroups = useMemo(() => groupStops(allStops), [allStops]);

  function addExtraStop(kind: "pickup" | "dropoff") {
    setExtraStops(prev => [...prev, { id: genStopId(), kind, address: "", floor: "0", hasLift: true }]);
  }
  function updateExtraStop(id: string, patch: Partial<ExtraStop>) {
    setExtraStops(prev => prev.map(s => s.id === id ? { ...s, ...patch } : s));
  }
  function removeExtraStop(id: string) {
    setExtraStops(prev => prev.filter(s => s.id !== id));
    // Clear any item tags that pointed at the removed stop so we never persist a
    // dangling reference.
    setItems(prev => prev.map(i => ({
      ...i,
      fromStopId: i.fromStopId === id ? undefined : i.fromStopId,
      toStopId: i.toStopId === id ? undefined : i.toStopId,
    })));
  }

  // ── Auto-calculate route distance when relocation addresses are set ──
  // Single-leg: pickup → drop-off. Multi-stop: the full chain (all pickups in
  // order, then all drop-offs) via the /api/distance `waypoints` field, which
  // sums the whole route.

  useEffect(() => {
    if (!isRelocation) return;
    const multi = isMultiStop;
    const waypoints = [
      { address: pickupAddress, lat: pickupLatLng?.lat, lng: pickupLatLng?.lng },
      ...extraPickups.map(s => ({ address: s.address, lat: s.lat, lng: s.lng })),
      { address: dropoffAddress, lat: dropoffLatLng?.lat, lng: dropoffLatLng?.lng },
      ...extraDropoffs.map(s => ({ address: s.address, lat: s.lat, lng: s.lng })),
    ];
    // Don't fire until every leg has an address.
    if (waypoints.some(w => !w.address)) return;
    setDistanceLoading(true);
    setDistanceError("");
    const timer = setTimeout(async () => {
      try {
        const res = await fetch("/api/distance", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(multi ? { waypoints } : {
            pickupAddress,
            dropoffAddress,
            pickupLat: pickupLatLng?.lat,
            pickupLng: pickupLatLng?.lng,
            dropoffLat: dropoffLatLng?.lat,
            dropoffLng: dropoffLatLng?.lng,
          }),
        });
        const data = await res.json();
        setDistanceKm(data.distanceKm ?? 0);
        if (!data.routeFound) setDistanceError(data.error || "Could not calculate distance");
      } catch {
        setDistanceKm(0);
        setDistanceError("Distance service unavailable");
      } finally {
        setDistanceLoading(false);
      }
    }, 600);
    return () => clearTimeout(timer);
  }, [pickupAddress, dropoffAddress, pickupLatLng, dropoffLatLng, isRelocation, isMultiStop, extraPickups, extraDropoffs]);

  // ── Pricing computation (central engine) ──────────────────────────────────

  const catalogEntries = useMemo<PricingCatalogEntry[]>(() =>
    (catalogRaw || []).map(c => ({
      name: c.name,
      serviceType: c.serviceType as ServiceType,
      basePrice: parseFloat(c.basePrice),
    })),
    [catalogRaw]
  );

  const pricingResult = useMemo(() => computePricing({
    // The pricing engine has intentional generic fallbacks for known catalogue
    // families. Unverified/customer-entered rows must never reach those rules.
    items: items.filter(i => !i.isCustom && !i.requiresReview && i.catalogItemId != null).map(i => ({
      name: i.name,
      serviceType: i.serviceType,
      quantity: i.quantity,
      unitPrice: i.unitPrice,
      volumeM3: i.volumeM3,
      carryOnly: i.relocateMode === 'carry',
      sku: i.sku,
      wrap: i.wrap === true,
    })),
    needsRelocation: isRelocation,
    // Floor / stairs and access-difficulty surcharges only apply to RELOCATIONS
    // (carrying items up and down floors during a move). Installation and other
    // non-relocation jobs are priced flat regardless of floor, so we omit both
    // here. This keeps the live customer estimate in lockstep with the server,
    // which likewise ignores floor / access for non-relocation quotes — so an
    // install customer never sees a floor charge that would never be billed.
    floors: isRelocation
      ? [
          ...floors.map(f => ({ level: parseInt(f.level) || 0, hasLift: f.hasLift })),
          ...activeExtraStops.map(s => ({ level: parseInt(s.floor) || 0, hasLift: s.hasLift })),
        ]
      : [],
    accessDifficulty: isRelocation ? accessDifficulty : "easy",
    // Same-Property Moves don't have travel distance — force to 0 so the
    // engine's "transport fee" branch is skipped and we don't trip the
    // "distance calculation failed" admin-review warning.
    distanceKm: samePropertyMove ? 0 : distanceKm,
    // Per-extra-stop fee for multi-stop relocations (0 for single-leg).
    extraStops: extraStopCount,
    catalogEntries,
    samePropertyMove: isRelocation && samePropertyMove,
  }), [items, isRelocation, samePropertyMove, floors, activeExtraStops, extraStopCount, accessDifficulty, distanceKm, catalogEntries]);

  const hasUnpricedItems = items.some(item => item.isCustom || item.requiresReview || item.catalogItemId == null);
  const hasKnownPricedItems = items.some(item => !item.isCustom && !item.requiresReview && item.catalogItemId != null);
  const subtotal = pricingResult.laborSubtotal;
  const total = pricingResult.grandTotal;
  const deposit = pricingResult.depositAmount;
  const finalAmt = pricingResult.finalAmount;

  // Per-item relocation mode = at least one relocate item with full D&R or
  // reinstall-only (already dismantled) — priced per item, NO time cap applies
  const hasDRMode = isRelocation && items.some(i => i.serviceType === 'relocate' && (i.relocateMode === 'full' || i.relocateMode === 'reinstall_only'));
  // No-stacking rule: shared helper, identical to the server. A relocate item
  // with any mode other than 'carry' (including unset, which the submit payload
  // normalizes to 'full') is on the D&R bundle rate and CANNOT take a promo
  // code on top. Carry-only relocations get no bundle discount, so they may
  // still use a promo. This stays in lockstep with the server so the UI never
  // shows a promo as applied that the server will silently strip.
  const promoBlockedByRelocation = relocationBundleBlocksPromo(
    items.filter(item => !item.isCustom && !item.requiresReview && item.catalogItemId != null),
  );
  // Promo discount applied to the grand total (which already includes the $60 callout fee)
  const grandTotalAfterPromo = Math.max(0, total - promoDiscount);
  // Small jobs are paid IN FULL up front (no 50/50 split). Larger jobs keep the
  // usual 50% deposit + 50% balance.
  const fullUpfront = requiresFullUpfront(grandTotalAfterPromo);
  const effectiveDeposit = fullUpfront
    ? Math.round(grandTotalAfterPromo * 100) / 100
    : Math.round(grandTotalAfterPromo * 0.5 * 100) / 100;
  const effectiveFinal = Math.round((grandTotalAfterPromo - effectiveDeposit) * 100) / 100;

  const applyPromo = useCallback(async (code: string) => {
    const trimmed = code.trim().toUpperCase();
    if (!trimmed) return;
    // No-stacking rule: the relocation D&R bundle rate is already a discount,
    // so promo codes can't be combined with it. Block the apply up front with a
    // clear message instead of round-tripping to the server.
    if (promoBlockedByRelocation) {
      setPromoCode(null);
      setPromoDiscount(0);
      setPromoStatus("invalid");
      setPromoMessage("Promo codes can't be combined with relocation (dismantle & reinstall) bundle pricing — the bundle rate already includes a discount.");
      return;
    }
    setPromoStatus("validating");
    setPromoMessage("");
    try {
      const res = await fetch("/api/promo/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: trimmed, orderTotal: total, hasRelocationBundle: promoBlockedByRelocation }),
      });
      const data = await res.json();
      if (data.valid) {
        setPromoCode(trimmed);
        setPromoDiscount(data.discount);
        setPromoStatus("valid");
        setPromoMessage(data.message);
      } else {
        setPromoCode(null);
        setPromoDiscount(0);
        setPromoStatus("invalid");
        setPromoMessage(data.message || "Invalid code");
      }
    } catch {
      setPromoStatus("invalid");
      setPromoMessage("Could not validate code. Try again.");
    }
  }, [total, promoBlockedByRelocation]);

  const removePromo = useCallback(() => {
    setPromoCode(null);
    setPromoDiscount(0);
    setPromoStatus("idle");
    setPromoMessage("");
    setPromoInput("");
  }, []);

  // No-stacking rule: if the cart turns into a relocation D&R bundle AFTER a
  // promo was already applied (e.g. the customer switches an item to dismantle
  // & reinstall), drop the promo automatically and explain why. This keeps the
  // UI in sync with the server, which voids the promo on D&R jobs regardless.
  useEffect(() => {
    if (promoBlockedByRelocation && promoDiscount > 0) {
      setPromoCode(null);
      setPromoDiscount(0);
      setPromoStatus("invalid");
      setPromoMessage("Promo removed — promo codes can't be combined with relocation (dismantle & reinstall) bundle pricing, which already includes a discount.");
    }
  }, [promoBlockedByRelocation, promoDiscount]);

  // ── Catalog add ───────────────────────────────────────────────────────────

  const addCatalogGroup = (group: CatalogGroup, qty: number = 1, detectionToken?: string) => {
    if (furnitureNeedsSpecificationReview(group.name)) {
      setItems(previous => [...previous, ...services.map(serviceType => ({
        id: uid(), sku: "", category: group.category, name: group.name, serviceType, quantity: qty, unitPrice: 0,
        isCustom: true, requiresReview: true, detectionToken,
      }))]);
      return;
    }
    // Fixed-price add-ons (professional-electrician power / data points, etc.)
    // are priced INDEPENDENTLY of the customer's move-service selection. If they
    // fell through the normal service-matching path below, a customer who picked
    // e.g. "Relocate" would find no matching install/dismantle variant, so the
    // point would drop to a $0 custom line and the pricing engine would
    // re-estimate it at install × relocate-multiplier (~$225) instead of the
    // firm catalog rate ($150 / $25). Always add these at their catalog
    // basePrice using the item's own service type, as a firm (non-custom) line.
    const isFixedAddon = (group.category || "").toLowerCase().includes("electrical")
      || group.entries.some(e => (e.sku || "").toUpperCase().startsWith("EPOINT"));
    if (isFixedAddon && group.entries.length > 0) {
      const entry = group.entries.find(e => e.serviceType === 'install') || group.entries[0];
      setItems(prev => {
        const existing = prev.find(i => i.catalogItemId === entry.id);
        if (existing) return prev.map(i => i.catalogItemId === entry.id ? { ...i, quantity: i.quantity + qty, detectionToken: i.detectionToken || detectionToken } : i);
        return [...prev, {
          id: uid(), catalogItemId: entry.id, sku: entry.sku, name: group.name,
          category: group.category, serviceType: entry.serviceType, quantity: qty,
          unitPrice: parseFloat(entry.basePrice), volumeM3: entry.volumeM3, isCustom: false, detectionToken,
        }];
      });
      setCatalogSearch("");
      setCatalogFocused(false);
      return;
    }
    // Auto-fallback: items that can't actually be dismantled (mattresses,
    // boxes, plants, etc.) only ship with a plain "dispose" SKU. If the
    // customer picked "Dismantle + Dispose" mode and this group has no
    // dismantle_dispose variant, treat their request as plain "Dispose"
    // so the flat catalog rate is used instead of an inflated AI estimate.
    const groupHasDD = group.entries.some(e => e.serviceType === 'dismantle_dispose');
    const groupHasDispose = group.entries.some(e => e.serviceType === 'dispose');
    const effectiveServices: ServiceType[] = (services.includes('dismantle_dispose') && !groupHasDD && groupHasDispose)
      ? (Array.from(new Set(services.map(s => s === 'dismantle_dispose' ? 'dispose' : s))) as ServiceType[])
      : services;
    const relevant = group.entries.filter(e => effectiveServices.includes(e.serviceType));
    setItems(prev => {
      let updated = [...prev];
      if (relevant.length === 0) {
        // No matching service variants — add as custom for each selected service
        effectiveServices.forEach(st => {
          updated.push({ id: uid(), sku: "", name: group.name, category: group.category, serviceType: st, quantity: qty, unitPrice: 0, isCustom: true, requiresReview: true, detectionToken, ...(st === 'relocate' ? { relocateMode: 'full' as const } : {}) });
        });
      } else {
        // For relocation: show as a SINGLE line with a full/carry toggle
        const relocateEntry = relevant.find(e => e.serviceType === 'relocate');
        if (relocateEntry && services.length === 1 && services[0] === 'relocate') {
          const carryPrice = parseFloat(relocateEntry.basePrice);
          const installEntry = group.entries.find(e => e.serviceType === 'install');
          const dismantleEntry = group.entries.find(e => e.serviceType === 'dismantle');
          const fullPrice = computeDRPrice(
            installEntry ? parseFloat(installEntry.basePrice) : undefined,
            dismantleEntry ? parseFloat(dismantleEntry.basePrice) : undefined,
            carryPrice,
          );
          const existing = updated.find(i => i.catalogItemId === relocateEntry.id);
          if (existing) {
            updated = updated.map(i => i.catalogItemId === relocateEntry.id ? { ...i, quantity: i.quantity + qty, detectionToken: i.detectionToken || detectionToken } : i);
          } else {
            updated.push({
              id: uid(), catalogItemId: relocateEntry.id, sku: relocateEntry.sku,
              name: group.name, category: group.category, serviceType: 'relocate',
              quantity: qty, unitPrice: fullPrice, volumeM3: relocateEntry.volumeM3, isCustom: false,
              relocateMode: 'full', carryPrice, fullPrice, detectionToken,
            });
          }
        } else {
          // Non-relocate, or mixed services: add one line per service type
          // For relocate entries: always apply D&R bundle formula floored at carry × 1.30 (see computeDRPrice)
          relevant.forEach(entry => {
            const existing = updated.find(i => i.catalogItemId === entry.id);
            let unitPrice = parseFloat(entry.basePrice);
            if (entry.serviceType === 'relocate') {
              const installEntry = group.entries.find(e => e.serviceType === 'install');
              const dismantleEntry = group.entries.find(e => e.serviceType === 'dismantle');
              unitPrice = computeDRPrice(
                installEntry ? parseFloat(installEntry.basePrice) : undefined,
                dismantleEntry ? parseFloat(dismantleEntry.basePrice) : undefined,
                parseFloat(entry.basePrice),
              );
            }
            if (existing) {
              updated = updated.map(i => i.catalogItemId === entry.id ? { ...i, quantity: i.quantity + qty, detectionToken: i.detectionToken || detectionToken } : i);
            } else {
              updated.push({ id: uid(), catalogItemId: entry.id, sku: entry.sku, name: group.name, category: group.category, serviceType: entry.serviceType, quantity: qty, unitPrice, volumeM3: entry.volumeM3, isCustom: false, detectionToken, ...(entry.serviceType === 'relocate' ? { relocateMode: 'full' as const } : {}) });
            }
          });
          // Preserve requested work even when this catalogue row has no
          // matching service variant. It must be reviewed, never omitted.
          effectiveServices.filter(st => !relevant.some(entry => entry.serviceType === st)).forEach(st => {
            updated.push({ id: uid(), sku: "", name: group.name, category: group.category, serviceType: st, quantity: qty, unitPrice: 0, isCustom: true, requiresReview: true, detectionToken, ...(st === "relocate" ? { relocateMode: "full" as const } : {}) });
          });
        }
      }
      return updated;
    });
    setCatalogSearch("");
    setCatalogFocused(false);
  };

  // ── Paste parsing ─────────────────────────────────────────────────────────

  // Lines that are clearly NOT items — stop headers, addresses, phones, etc.
  // Customers often paste a whole moving brief (pick-up / drop-off blocks with
  // postal codes and unit numbers), so we filter those out instead of turning
  // every line into a $0 "custom" item.
  const isNonItemLine = (s: string): boolean => {
    const lc = s.toLowerCase();
    // Stop / section headers on their own line: "Pick-up", "Drop-off:", "To:", etc.
    if (/^(pick[\s-]*up|pickup|drop[\s-]*off|dropoff|deliver(y|ies)?|collect(ion)?|destination|origin|address|location|unit|floor|level|from|to|stop)\s*[:#.-]*\s*$/i.test(s)) return true;
    // Singapore postal code (6 digits, often in parentheses) → address line
    if (/\b\d{6}\b/.test(s)) return true;
    // Unit number like #11-3227, #04-131
    if (/#\s*\d{1,3}\s*-\s*\d{1,4}/.test(s)) return true;
    // Block / Blk + number → address line
    if (/\b(blk|block)\b\s*\.?\s*\d+/i.test(lc)) return true;
    // Phone numbers (SG 8-digit starting 6/8/9, or with +65)
    if (/(\+?65[\s-]?)?\b[689]\d{3}[\s-]?\d{4}\b/.test(s)) return true;
    return false;
  };

  // Backstop for an address with NO postal code / unit number — a house or block
  // number paired with a street/estate name. Run on the item name AFTER the
  // quantity is stripped so a genuine item like "Road bike x1" → "Road bike"
  // (no digit) is kept, while "294 Choa Chu Kang Avenue 2" is dropped.
  const looksLikeStreetAddress = (s: string): boolean =>
    /\d/.test(s) && /\b(jalan|jln|lorong|lor|road|rd|avenue|ave|street|st|lane|ln|drive|dr|crescent|cres|close|walk|terrace|ter|boulevard|bukit|bkt|tanjong|kampong|kampung|geylang|hougang|yishun|tampines|bedok|jurong|woodlands|sengkang|punggol|serangoon)\b/i.test(s.toLowerCase());

  const applyPaste = () => {
    const lines = pasteText.trim().split("\n").filter(l => l.trim());
    const newItems: LineItem[] = [];
    let skipped = 0, matchedCount = 0, customCount = 0;
    lines.forEach(line => {
      // Strip leading list markers: bullets (•, -, *, –, ·, ●…), "1." / "2)" numbering,
      // and emoji keycap digits (1️⃣ 2️⃣ …) used to label pick-up / drop-off stops.
      let t = line.trim();
      t = t.replace(/^[\u0030-\u0039]\uFE0F?\u20E3\s*/, "");      // emoji keycap digit
      t = t.replace(/^[\s•\-*–·▪◦●○»>~]+/, "");                    // bullets / dashes
      t = t.replace(/^\d+\s*[.)]\s+/, "");                          // "1. " / "2) " numbering
      t = t.trim();

      // Drop blank lines and anything that is clearly an address / header / phone.
      if (!t || !/[a-z]/i.test(t) || isNonItemLine(t)) { skipped++; return; }

      // Quantity: prefer an explicit "x N" / "× N" anywhere (take the last one,
      // so "Toyogo boxes x8 (6big, 2small)" → qty 8, name "Toyogo boxes"); else
      // a leading count like "6 cardboxes".
      let qty = 1, itemName = t;
      const xMatches = Array.from(t.matchAll(/(?:^|\s)[x×]\s*(\d+)(?!\d)/gi));
      if (xMatches.length) {
        const last = xMatches[xMatches.length - 1];
        qty = parseInt(last[1]) || 1;
        itemName = t.slice(0, last.index).trim();
      } else {
        const frontM = t.match(/^(\d+)\s+(.+)$/);
        if (frontM) { qty = parseInt(frontM[1]) || 1; itemName = frontM[2].trim(); }
      }
      // Clean a trailing descriptive parenthetical ("(6big, 2small)", "(1 ikea)")
      // and dangling punctuation so the catalog match works on the bare name.
      itemName = itemName.replace(/\s*\([^)]*\)\s*$/, "").replace(/[,;:.\s]+$/, "").trim();
      if (!itemName || looksLikeStreetAddress(itemName)) { skipped++; return; }

      const lc = itemName.toLowerCase();
      const lcK = lc.replace(/[^a-z0-9]+/g, "");
      let matched = catalogGroups.find(g => {
        const gn = g.name.toLowerCase();
        const gnK = gn.replace(/[^a-z0-9]+/g, "");
        return gn.includes(lc) || lc.includes(gn) || gn.split(" ").slice(0, 2).join(" ") === lc.split(" ").slice(0, 2).join(" ") ||
          (lcK.length >= 5 && gnK.length >= 5 && (gnK.includes(lcK) || lcK.includes(gnK)));
      });
      // Second chance (runs ONLY on a direct miss): strip well-known
      // appliance/furniture BRAND words and singularise, then re-run the SAME
      // strict substring matcher. We deliberately AVOID a loose word-overlap
      // score here — substring containment keeps genuinely-custom lines (e.g.
      // "Gaming desk") as custom instead of auto-pricing them, while still
      // resolving colloquial phrasings like "Decathlon chairs" → a chair,
      // "Tefal pots" → "Pots & Pans", or "Bagpack" → "Backpack".
      if (!matched) {
        const singular = (s: string) => s.replace(/\b([a-z]{4,})s\b/g, "$1");
        const norm = lc
          // Only unambiguous appliance/kitchenware brand tokens — deliberately
          // NOT common English words (e.g. "sharp", "prism") that could strip
          // meaning from a genuine custom line.
          .replace(/\b(decathlon|mayer|zojirushi|aerogaz|sterra|lagourmet|corelle|corell|tefal|philips|panasonic|xiaomi|europace|khind|toshiba|kdk)\b/g, " ")
          .replace(/\bbagpack\b/g, "backpack")
          .replace(/\s+/g, " ").trim();
        const normS = singular(norm);
        const normK = normS.replace(/[^a-z0-9]+/g, "");
        if (normS && normS !== lc) {
          matched = catalogGroups.find(g => {
            const gnS = singular(g.name.toLowerCase());
            const gnK = gnS.replace(/[^a-z0-9]+/g, "");
            return gnS.includes(normS) || normS.includes(gnS) ||
              (normK.length >= 5 && gnK.length >= 5 && (gnK.includes(normK) || normK.includes(gnK)));
          });
        }
      }
      if (matched) {
        matchedCount++;
        // Same dismantle_dispose → dispose fallback as addCatalogGroup, so
        // pasted "1 mattress" doesn't get tagged as Dismantle + Dispose.
        const groupHasDD = matched.entries.some(e => e.serviceType === 'dismantle_dispose');
        const groupHasDispose = matched.entries.some(e => e.serviceType === 'dispose');
        const effectiveServices: ServiceType[] = (services.includes('dismantle_dispose') && !groupHasDD && groupHasDispose)
          ? (Array.from(new Set(services.map(s => s === 'dismantle_dispose' ? 'dispose' : s))) as ServiceType[])
          : services;
        const relevant = matched.entries.filter(e => effectiveServices.includes(e.serviceType));
        const missingServices = effectiveServices.filter(st => !relevant.some(entry => entry.serviceType === st));
        relevant.forEach(entry => {
          newItems.push({ id: uid(), catalogItemId: entry.id, sku: entry.sku, name: matched.name, category: matched.category, serviceType: entry.serviceType, quantity: qty, unitPrice: parseFloat(entry.basePrice), volumeM3: entry.volumeM3, isCustom: false, ...(entry.serviceType === 'relocate' ? { relocateMode: 'full' as const } : {}) });
        });
        missingServices.forEach(st => newItems.push({
          id: uid(), sku: "", name: matched!.name, category: matched!.category,
          serviceType: st, quantity: qty, unitPrice: 0, isCustom: true, requiresReview: true,
          ...(st === "relocate" ? { relocateMode: "full" as const } : {}),
        }));
        if (missingServices.length) customCount += missingServices.length;
      } else {
        customCount++;
        services.forEach(st => {
          newItems.push({ id: uid(), sku: "", name: itemName, category: "Custom — review", serviceType: st, quantity: qty, unitPrice: 0, isCustom: true, requiresReview: true, ...(st === 'relocate' ? { relocateMode: 'full' as const } : {}) });
        });
      }
    });
    setItems(prev => [...prev, ...newItems]);
    setPasteText("");
    setShowPaste(false);

    const added = matchedCount + customCount;
    if (added === 0) {
      toast({
        title: "No items found",
        description: "We couldn't pick out any items from that text — it looked like addresses or notes. Try pasting one item per line, e.g. \"Computer table x1\".",
        variant: "destructive",
      });
    } else {
      const bits: string[] = [];
      if (customCount > 0) bits.push(`${customCount} not in our catalog (we'll price ${customCount === 1 ? "it" : "them"} for you)`);
      if (skipped > 0) bits.push(`${skipped} address/header line${skipped === 1 ? "" : "s"} skipped`);
      toast({
        title: `Added ${added} item${added === 1 ? "" : "s"}`,
        description: bits.length ? bits.join(" · ") : undefined,
      });
    }
  };

  // ── Photo AI detection ────────────────────────────────────────────────────

  // Compress image via canvas and return { base64, thumbnail, mimeType }
  async function compressImage(file: File, maxPx = 1024, thumbPx = 320): Promise<{ base64: string; thumbnail: string; mimeType: string }> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(url);
        // Full size for detection (max 1024px)
        const scale = Math.min(1, maxPx / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext("2d")!.drawImage(img, 0, 0, canvas.width, canvas.height);
        const full = canvas.toDataURL("image/jpeg", 0.8);

        // Thumbnail for storing in DB (max 320px)
        const tScale = Math.min(1, thumbPx / Math.max(img.width, img.height));
        const tCanvas = document.createElement("canvas");
        tCanvas.width = Math.round(img.width * tScale);
        tCanvas.height = Math.round(img.height * tScale);
        tCanvas.getContext("2d")!.drawImage(img, 0, 0, tCanvas.width, tCanvas.height);
        const thumb = tCanvas.toDataURL("image/jpeg", 0.7);

        resolve({ base64: full.split(",")[1], thumbnail: thumb, mimeType: "image/jpeg" });
      };
      img.onerror = reject;
      img.src = url;
    });
  }

  // Shared matching logic
  const stem = (w: string) => w.length > 4 && w.endsWith("s") ? w.slice(0, -1) : w;
  const stripParens = (s: string) => s.replace(/\s*\(.*?\)/g, "").trim();
  // Category families — if detected name belongs to one family and catalog name belongs to another,
  // they can never match (prevents e.g. "kitchen island" matching "pax wardrobe" on "ikea" alone)
  const CATEGORY_FAMILIES: string[][] = [
    ["wardrobe", "pax", "closet"],
    ["cabinet", "cupboard", "sideboard", "credenza"],
    ["island", "kitchen island"],
    ["sofa", "couch", "sectional", "chaise"],
    ["treadmill", "elliptical", "rowing machine"],
    ["piano"],
    ["pool table", "billiard", "foosball"],
    ["pod", "phone booth"],
  ];
  // Synonym normalisation — collapse common alternate phrasings to the
  // canonical token used in catalog names so the fuzzy matcher hits the
  // intended entry. Currently: theatre/theater/cinema/lecture-hall seating
  // → "auditorium chair", which targets the Round 24 catalog row.
  const normaliseSynonyms = (s: string): string => {
    let out = s;
    out = out.replace(/\b(theatre|theater|cinema)\s+(seat|seats|seating|chair|chairs)\b/gi, "auditorium chair");
    out = out.replace(/\blecture\s*(hall|theatre|theater|room)?\s*(seat|seats|seating|chair|chairs)\b/gi, "auditorium chair");
    out = out.replace(/\bauditorium\s+(seat|seats|seating)\b/gi, "auditorium chair");
    return out;
  };
  const matchScore = (det: string, cat: string): number => {
    const d = normaliseSynonyms(det.toLowerCase()), c = cat.toLowerCase();
    const dC = stripParens(d), cC = stripParens(c);
    if (d === c) return 100;
    if (dC === cC) return 90;
    if (c.includes(d) || d.includes(c)) return 80;
    if (cC.includes(dC) || dC.includes(cC)) return 75;
    const dK = dC.replace(/[^a-z0-9]+/g, ""), cK = cC.replace(/[^a-z0-9]+/g, "");
    if (dK.length >= 5 && cK.length >= 5 && (cK.includes(dK) || dK.includes(cK))) return 72;
    // Hard veto: if detected and catalog belong to different exclusive category families, score 0
    for (const family of CATEGORY_FAMILIES) {
      const detHas = family.some(kw => d.includes(kw));
      const catHas = family.some(kw => c.includes(kw));
      if (detHas !== catHas) return 0;
    }
    // IKEA model → map to specific catalog entry
    const ikeaModel = d.match(/\b(pax|kallax|billy|malm|hemnes|besta|micke|lack|alex|poäng|kivik|ivar|trofast|stuva|vittsjo|lillångén|lillangen|godmorgon|kleppstad|vadholma|stenstorp|förhöja|forhoja|råskog|raskog|norden|tornviken|friheten|ektorp|vimle|klippan|strandmon|eket|ekedalen|ingatorp|lisabo|brimnes|slattum|tarva|neiden|nordli|koppang|songesand|fjallbo|fjällbo|bekant|trotten|idasen|idåsen|lagkapten|linnmon|markus|flintan|platsa)\b/i);
    if (ikeaModel && c.includes(ikeaModel[1].toLowerCase())) return 70;
    // IKEA kitchen island models → map to "ikea kitchen island" entries
    const isIkeaIsland = /\b(vadholma|stenstorp|norden|tornviken)\b/i.test(d);
    if (isIkeaIsland && c.includes("kitchen island")) return 65;
    // IKEA trolley models → map to "ikea kitchen trolley" entries
    const isIkeaTrolley = /\b(råskog|raskog|förhöja|forhoja)\b/i.test(d);
    if (isIkeaTrolley && c.includes("trolley")) return 65;
    const dWords = dC.split(/\s+/).filter(w => w.length > 3).map(stem);
    const cWords = cC.split(/\s+/).filter(w => w.length > 3).map(stem);
    const overlap = dWords.filter(w => cWords.some(cw => cw.includes(w) || w.includes(cw)));
    if (overlap.length >= 2) return 60;
    if (overlap.length >= 1) return 40;
    return 0;
  };
  const bestCatalogMatch = (detectedName: string) => {
    let best: { group: typeof catalogGroups[0]; score: number } | null = null;
    for (const g of catalogGroups) {
      const score = matchScore(detectedName, g.name);
      if (score > 0 && (!best || score > best.score)) best = { group: g, score };
    }
    return best && best.score >= 40 ? best.group : null;
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    const invalidFiles = selectedFiles.filter(file => !["image/jpeg", "image/png"].includes(file.type));
    const remainingPhotoSlots = Math.max(0, 10 - detectedPhotos.length);
    const supportedFiles = selectedFiles.filter(file => ["image/jpeg", "image/png"].includes(file.type));
    const files = supportedFiles.slice(0, remainingPhotoSlots);
    if (!files.length) {
      setPhotoError(remainingPhotoSlots === 0
        ? "A maximum of 10 photos can be attached to one request. Remove a photo before adding another."
        : "Choose a JPEG or PNG photo to continue.");
      return;
    }
    if (fileInputRef.current) fileInputRef.current.value = "";

    setPhotoDetecting(true);
    setPhotoError(invalidFiles.length || supportedFiles.length > remainingPhotoSlots
      ? `${invalidFiles.length ? "Only JPEG or PNG photos are accepted. " : ""}${supportedFiles.length > remainingPhotoSlots ? "A maximum of 10 photos can be attached to one request. " : ""}Scanning the supported photos below.`
      : "");

    let anyDetected = false;
    let emptyCount = 0; // photos processed OK but with no furniture found
    let failedCount = 0; // photos that could not be read/scanned at all

    for (let i = 0; i < files.length; i++) {
      setDetectingProgress({ current: i + 1, total: files.length });
      let thumbnailForThisPhoto: string | null = null;
      try {
        const { base64, thumbnail, mimeType } = await compressImage(files[i], 1536);
        thumbnailForThisPhoto = thumbnail;
        const res = await fetch("/api/catalog/detect-items", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            imageBase64: base64,
            mimeType,
            filename: files[i].name,
            selectedJobType: leadIntents.join(" ") || undefined,
            selectedServices: services,
            roomType: roomType || undefined,
            siteType: siteType || undefined,
            sellerProductLink: productLink.trim() || undefined,
            customerNotes: leadNotes.trim() || pasteText.trim() || undefined,
            manualCategoryHint: manualCategoryHint || undefined,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || "Detection failed");
        if (data.leadRouting) setPhotoRouting(data.leadRouting);
        if (data.needsClarification) {
          emptyCount++;
          setDetectedPhotos(prev => [...prev, { thumbnail, names: [], count: 0 }]);
          setPhotoError(data.clarificationMessage || "Please confirm the exact furniture item before we calculate a price.");
          continue;
        }

        const detected: { name: string; quantity: number; catalogGroup?: CatalogGroup; requiresReview?: boolean }[] = data.detected || [];
        const detectionToken = typeof data.detectionToken === "string" ? data.detectionToken : undefined;
        if (detected.length === 0) {
          // Still show the photo in the grid (with a 0 badge) so every
          // selected photo visibly "arrives" — previously these were
          // silently dropped, which looked like only one photo uploaded.
          emptyCount++;
          setDetectedPhotos(prev => [...prev, { thumbnail, names: [], count: 0 }]);
          continue;
        }

        anyDetected = true;
        // Aggregate detections per photo: if the AI emits multiple raw
        // entries that all map to the SAME catalog group — either a
        // legitimate "qty 2" of the same item it split into two lines, or
        // a mis-split pattern (e.g. a wide sliding wardrobe split into
        // "3-door wardrobe + swing door cabinet") — we merge them into one
        // catalog row with the SUMMED quantity. This keeps the cart and
        // the "items detected" badge consistent with what the customer
        // actually sees, without dropping any unit they paid for.
        type Agg =
          | { kind: "catalog"; group: CatalogGroup; qty: number; displayName: string; detectionToken?: string }
          | { kind: "custom"; name: string; qty: number; detectionToken?: string; photo?: string };
        const aggMap = new Map<string, Agg>();

        detected.forEach(({ name, quantity, catalogGroup: serverGroup, requiresReview }) => {
          // Never price a fuzzy/uncertain result, even if the server also found
          // a possible catalog group. Keep it as a TBC review line instead.
          const matched = requiresReview ? null : serverGroup;
          const qty = quantity || 1;
          if (matched) {
            const key = `g:${matched.name.toLowerCase()}`;
            const prev = aggMap.get(key);
            if (prev && prev.kind === "catalog") {
              prev.qty += qty;
            } else {
              aggMap.set(key, { kind: "catalog", group: matched, qty, displayName: matched.name, detectionToken });
            }
          } else {
            const key = `c:${name.toLowerCase()}`;
            const prev = aggMap.get(key);
            if (prev && prev.kind === "custom") {
              prev.qty += qty;
            } else {
              aggMap.set(key, { kind: "custom", name, qty, detectionToken, photo: thumbnail });
            }
          }
        });

        const nameList: string[] = [];
        aggMap.forEach((agg) => {
          if (agg.kind === "catalog") {
            addCatalogGroup(agg.group, agg.qty, agg.detectionToken);
            nameList.push(agg.qty > 1 ? `${agg.displayName} ×${agg.qty}` : agg.displayName);
          } else {
            services.forEach(st => {
              setItems(prev => [...prev, {
                id: uid(), sku: "", name: agg.name, category: "Custom",
                serviceType: st, quantity: agg.qty, unitPrice: 0, isCustom: true,
                requiresReview: true,
                detectionToken: agg.detectionToken,
                photo: agg.photo,
                ...(st === 'relocate' ? { relocateMode: 'full' as const } : {}),
              }]);
            });
            nameList.push(agg.qty > 1 ? `${agg.name} ×${agg.qty}` : agg.name);
          }
        });

        setDetectedPhotos(prev => [...prev, { thumbnail, names: nameList, count: nameList.length }]);
      } catch (err: any) {
        console.error("Photo detection error:", err);
        failedCount++;
        // Keep the photo visible in the grid even when the scan failed,
        // so the customer can see it arrived (and remove/retry it).
        // If the file couldn't even be read/compressed, fall back to a
        // neutral placeholder tile so the photo count still matches what
        // the customer selected.
        const t = thumbnailForThisPhoto
          ?? "data:image/svg+xml," + encodeURIComponent(
            '<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><rect width="80" height="80" fill="#eee"/><text x="40" y="46" font-size="26" text-anchor="middle" fill="#999">!</text></svg>',
          );
        setDetectedPhotos(prev => [...prev, { thumbnail: t, names: [], count: 0 }]);
        // continue processing remaining photos
      }
    }

    const problemParts: string[] = [];
    if (emptyCount > 0) problemParts.push(`${emptyCount} photo${emptyCount > 1 ? "s" : ""} had no furniture detected`);
    if (failedCount > 0) problemParts.push(`${failedCount} photo${failedCount > 1 ? "s" : ""} couldn't be scanned (photo unreadable or connection issue)`);

    if (!anyDetected) {
      setPhotoError(
        failedCount > 0 && emptyCount === 0
          ? "We couldn't scan the photos — please check your connection and try again, or add items manually."
          : "No furniture detected in the photos — try clearer shots or add items manually.",
      );
    } else if (problemParts.length > 0) {
      setPhotoError(`${problemParts.join("; ")} — try again with clearer shots, or add those items manually.`);
    }
    setPhotoDetecting(false);
    setDetectingProgress(null);
  };

  const addCustomItem = () => {
    if (photoConversionsLock.current > 0) {
      setCustomError("Wait for the selected photo to finish preparing before adding this item.");
      return;
    }
    const description = customName.trim();
    const serviceType = (customService && services.includes(customService) ? customService : services[0]) || "";
    const quantity = Number(customQuantity);
    if (!description) { setCustomError("Add an item name so the team knows what to review."); return; }
    if (description.length > 300) { setCustomError("Item name must be 300 characters or fewer."); return; }
    if (!serviceType) { setCustomError("Choose the service needed for this item."); return; }
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 9999) { setCustomError("Quantity must be between 1 and 9,999."); return; }
    if (customDimensions.length > 300 || customDetails.length > 2000) { setCustomError("Dimensions are limited to 300 characters and details to 2,000."); return; }
    const link = customLink.trim();
    if (link && (!isHttpProductLink(link) || link.length > 2000)) { setCustomError("Use a valid HTTP or HTTPS product link up to 2,000 characters."); return; }
    setItems(prev => [...prev, {
      id: uid(), sku: "", name: description, category: "Custom — review",
      serviceType: serviceType as ServiceType, quantity, unitPrice: 0, isCustom: true, requiresReview: true,
      details: customDetails.trim() || undefined, dimensions: customDimensions.trim() || undefined,
      productLink: link || undefined, photo: customPhoto || undefined,
      ...(serviceType === "relocate" ? { relocateMode: "full" as const } : {}),
    }]);
    setCustomError("");
    setCustomName("");
    setCustomQuantity("1");
    setCustomDimensions("");
    setCustomDetails("");
    setCustomLink("");
    setCustomPhoto("");
  };

  const prepareCustomPhoto = async (file: File, onReady: (dataUrl: string) => void) => {
    photoConversionsLock.current += 1;
    setPhotoConversionsPending(photoConversionsLock.current);
    try {
      const dataUrl = await compressReviewPhoto(file);
      onReady(dataUrl);
      setCustomError("");
    } catch (error) {
      setCustomError(error instanceof Error ? error.message : "Could not prepare that photo. Please try another image.");
    } finally {
      photoConversionsLock.current -= 1;
      setPhotoConversionsPending(photoConversionsLock.current);
    }
  };

  // ── Submit ────────────────────────────────────────────────────────────────

  const handleSubmit = async () => {
    const invalidCustom = items.find(item => {
      if (!item.isCustom && !item.requiresReview && item.catalogItemId != null) return false;
      const quantityDraft = customItemQuantityDrafts[item.id];
      return !item.name.trim() || item.name.length > 300
        || !Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 9999
        || (quantityDraft !== undefined && !isValidQuantityDraft(quantityDraft))
        || (item.details?.length || 0) > 2000 || (item.dimensions?.length || 0) > 300
        || (!!item.productLink && (!isHttpProductLink(item.productLink.trim()) || item.productLink.length > 2000))
        || (!!item.photo && (!/^data:image\/(?:jpeg|png);base64,/i.test(item.photo) || item.photo.length > 700000));
    });
    if (invalidCustom) {
      setSubmitError(`Please check the name, quantity, details, link or photo for “${invalidCustom.name || "custom item"}” before submitting.`);
      return;
    }
    if (!!slotDateStr !== !!slotTime) {
      setSubmitError("Choose both a preferred date and time, or clear both to send your request without a schedule preference.");
      return;
    }
    if (photoDetecting || distanceLoading || promoStatus === "validating") {
      setSubmitError("Please wait for the current estimate calculation to finish, then submit again.");
      return;
    }
    if (photoConversionsLock.current > 0) {
      setSubmitError("Please wait for the custom-item photo to finish preparing before submitting.");
      return;
    }
    if (submitLockRef.current) return;
    submitLockRef.current = true;
    setIsSubmitting(true);
    setSubmitError("");
    try {
      const body = {
        customer: { name: name.trim(), email: email.trim().toLowerCase(), phone: phone.trim() },
        selectedServices: services,
        serviceAddress: isRelocation ? pickupAddress : serviceAddress,
        pickupAddress: isRelocation ? pickupAddress : undefined,
        // Same-Property Move: pickup == dropoff (same address). Send pickup as
        // dropoff too so the backend's relocation persistence logic still works
        // unmodified, and the printed invoice doesn't show a blank destination.
        dropoffAddress: isRelocation ? (samePropertyMove ? pickupAddress : dropoffAddress) : undefined,
        accessDifficulty: isRelocation ? accessDifficulty : undefined,
        // Multi-stop: include every stop's floor so the server's floor-surcharge
        // recompute sees all locations, not just the primary pickup/drop-off.
        floorsInfo: isRelocation
          ? JSON.stringify([
              ...floors,
              ...activeExtraStops.map(s => ({ level: s.floor || "0", hasLift: s.hasLift })),
            ])
          : undefined,
        samePropertyMove: isRelocation && samePropertyMove ? true : undefined,
        // Multi-stop relocation — only sent when the customer added extra stops.
        // Single-leg quotes omit stops[] entirely (legacy behaviour preserved).
        stops: isMultiStop ? allStops : undefined,
        items: items.filter(i => !i.isCustom && !i.requiresReview && i.catalogItemId != null).map(i => ({
          catalogItemId: i.catalogItemId,
          quantity: i.quantity,
          serviceType: i.serviceType,
          unitPrice: i.unitPrice,
          itemName: i.name,
          sku: i.sku,
          relocateMode: i.serviceType === 'relocate' ? (i.relocateMode || 'full') : undefined,
          wrap: i.wrap === true ? true : undefined,
          requiresReview: i.requiresReview === true ? true : undefined,
          detectionToken: i.detectionToken,
          // Per-item from/to tagging — default to the first pickup / drop-off
          // when the customer didn't pick one. Only sent for multi-stop quotes.
          fromStopId: isMultiStop ? (i.fromStopId || primaryPickupStopId) : undefined,
          toStopId: isMultiStop ? (i.toStopId || primaryDropoffStopId) : undefined,
        })),
        customItems: items.filter(i => i.isCustom || i.requiresReview || i.catalogItemId == null).map(i => ({
          description: i.name.trim(),
          quantity: i.quantity,
          serviceType: i.serviceType,
          details: i.details?.trim() || undefined,
          dimensions: i.dimensions?.trim() || undefined,
          productLink: i.productLink?.trim() || undefined,
          photo: i.photo || undefined,
          detectionToken: i.detectionToken || undefined,
        })),
        logisticsFee: pricingResult.logisticsSubtotal,
        discount: pricingResult.discountAmount,
        distanceKm: samePropertyMove ? 0 : (distanceKm > 0 ? distanceKm : undefined),
        detectedPhotoUrl: detectedPhotos.find(photo => /^data:image\/(?:jpeg|png);base64,/i.test(photo.thumbnail) && photo.thumbnail.length <= 700000)?.thumbnail || undefined,
        detectedPhotos: detectedPhotos
          .map(photo => photo.thumbnail)
          .filter(photo => /^data:image\/(?:jpeg|png);base64,/i.test(photo) && photo.length <= 700000)
          .slice(0, 10),
        preferredDate: slotDateStr || undefined,
        preferredTimeWindow: slotTime || undefined,
        promoCode: promoBlockedByRelocation ? undefined : (promoCode || undefined),
        promoDiscount: !promoBlockedByRelocation && promoDiscount > 0 ? promoDiscount : undefined,
        // Lead-quality metadata for Ads analysis — intent, urgency, and
        // UTM/GCLID attribution captured on first page load.
        leadMeta: (() => {
          const attr = getLeadAttribution();
          return {
            leadIntent: leadIntent || undefined,
            leadIntents: leadIntents.length ? leadIntents : undefined,
            originatingServicePage: estimateLandingContext(window.location.search).originatingServicePage,
            urgency: urgency || undefined,
            itemCountRange: itemCountRange || undefined,
            siteType: siteType || undefined,
            leadNotes: leadNotes.trim() || undefined,
            roomType: roomType || undefined,
            productLink: productLink.trim() || undefined,
            cartonCount: cartonCount ? Number(cartonCount) : undefined,
            manualsAvailable: manualsAvailable || undefined,
            wallMounting: wallMounting || undefined,
            drillingRequired: drillingRequired || undefined,
            dismantleRequired: dismantleRequired || undefined,
            reinstallRequired: reinstallRequired || undefined,
            disposalRequired: disposalRequired || undefined,
            officeSeatCount: officeSeatCount ? Number(officeSeatCount) : undefined,
            floorPlanAvailable: floorPlanAvailable || undefined,
            afterHoursRequired: afterHoursRequired || undefined,
            partitionsRequired: partitionsRequired || undefined,
            pedestalsRequired: pedestalsRequired || undefined,
            cableManagementRequired: cableManagementRequired || undefined,
            manualCategoryHint: manualCategoryHint || undefined,
            photoDetectedCategory: photoRouting?.category,
            detectedCategory: leadRouting.category,
            serviceIntent: leadRouting.serviceIntent,
            jobPriority: leadRouting.priority,
            recommendedSalesPath: leadRouting.recommendedSalesPath,
            detectionConfidence: photoRouting?.confidence || leadRouting.confidence,
            detectionNeedsReview: photoRouting?.requiresReview ?? leadRouting.requiresReview,
            ...attr,
          };
        })(),
      };
      // Funnel-analysis event (non-conversion): the lead is prepared and about
      // to be submitted. Fired regardless of the fetch outcome.
      trackFunnelEvent("estimate_lead_prepared", {
        channel: "quote_form",
        lead_intent: leadIntentText || undefined,
        urgency: urgency || undefined,
        item_count_range: itemCountRange || undefined,
        site_type: siteType || undefined,
        services: services.join(","),
        estimated_total: grandTotalAfterPromo > 0 ? Math.round(grandTotalAfterPromo * 100) / 100 : undefined,
      });
      let requestStore:Storage|undefined;
      try{requestStore=window.sessionStorage;}catch{}
      const form=enquiryForm();
      if(pendingEnquiryRef.current && !sameEnquiryForm(form,pendingEnquiryRef.current.form)) {
        setSubmitError("Your previous enquiry may already have been saved. Retry its restored details before changing this request, to avoid creating a duplicate.");
        return;
      }
      const submission=pendingEnquiryRef.current?.body??body;
      requestIdentityRef.current=await enquiryRequestIdentity(submission,requestStore,requestIdentityRef.current,createRequestUuid);
      if(!pendingEnquiryRef.current) {
        pendingEnquiryRef.current={body:submission,form};
        if(!savePendingEnquiryDraft(requestStore,submission,form))
          setRetryStorageWarning("Your retry details could not be saved on this device. Keep this page open and retry here; reloading may lose your photos and enquiry details.");
      }
      const res = await fetch("/api/quotes/wizard", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...submission, requestId: requestIdentityRef.current!.id }),
      });
      if (!res.ok) {
        // A definite validation rejection is not an ambiguous committed save.
        // Keep entered fields editable instead of trapping the user in a retry.
        if(!retainEnquiryIdentity(res.status,!!pendingEnquiryRef.current?.uncertain)) {
          pendingEnquiryRef.current=null;
          clearPendingEnquiryDraft(requestStore);
          clearEnquiryRequestIdentity(requestStore);
          requestIdentityRef.current=null;
        }
        const text = await res.text();
        let parsed: any;
        try { parsed = JSON.parse(text); } catch { parsed = null; }
        const detail = parsed?.message || parsed?.error ||
          (res.status === 413 ? "Your photos are too large. Remove or reduce a photo, then retry." :
            res.status === 429 ? "Too many requests. Please wait a moment, then retry your saved draft." :
            res.status >= 500 ? "The estimate service is unavailable. Your entries are still here; please retry." :
            "We couldn't submit your request. Check the entered details and retry.");
        throw new Error(typeof detail === "string" ? detail : "We couldn't submit your request. Please retry.");
      }
      const quote = await res.json();
      clearEnquiryRequestIdentity(requestStore);
      clearPendingEnquiryDraft(requestStore);
      pendingEnquiryRef.current=null;

      // Google Ads conversion tracking — fires on successful estimate submission only.
      // Lead conversion (NOT a purchase): TMG customers don't pay on the website;
      // payment is collected later after admin review. Once-only guard keyed by the
      // quote reference / id prevents double-counting if this branch ever re-runs.
      try {
        const conversionTxnId: string = quote?.referenceNo || (quote?.id != null ? String(quote.id) : "");
        if (typeof window !== "undefined" && typeof (window as any).gtag === "function") {
          // Safety guard: do NOT fire any Google Ads lead conversion unless we
          // have a real backend-issued identifier (referenceNo or numeric id).
          // Without it we cannot dedupe in Google Ads, so skip entirely.
          if (!conversionTxnId) {
            if (import.meta.env.DEV) {
              console.log("[gads] estimate lead conversion SKIPPED — no quote referenceNo or id in response");
            }
          } else {
            const queued = reportLeadConversion("quote_form", undefined, conversionTxnId, quote?.total);
            if (queued && import.meta.env.DEV) {
              console.log("[gads] estimate lead conversion fired", { txn: conversionTxnId });
            }
          }
        }
      } catch (_) {}
      trackEvent("wizard_submit", "/estimate");
      try {
        reportEstimateLead(quote?.id, {
          content_name: "Estimate Submitted",
          value: typeof quote?.total === "number" ? quote.total : undefined,
          currency: "SGD",
        });
      } catch (_) {}

      // Mark partial lead as completed so no re-engagement email is sent
      if (partialLeadToken) {
        fetch(`/api/partial-leads/${partialLeadToken}/complete`, { method: "POST" }).catch(() => {});
      }

      setLocation(`/quotes/${quote.id}?ref=${encodeURIComponent(quote.referenceNo)}`);
    } catch (err: any) {
      if(pendingEnquiryRef.current) {
        pendingEnquiryRef.current.uncertain=true;
        let store:Storage|undefined;try{store=window.sessionStorage;}catch{}
        if(!savePendingEnquiryDraft(store,pendingEnquiryRef.current.body,pendingEnquiryRef.current.form,true))
          setRetryStorageWarning("Your retry details could not be saved on this device. Keep this page open and retry here; do not reload.");
      }
      setSubmitError(err.message || "Failed to submit. Please try again.");
    } finally {
      submitLockRef.current = false;
      setIsSubmitting(false);
    }
  };

  // ── Navigation guards ─────────────────────────────────────────────────────

  const canNext = () => {
    if (photoDetecting || distanceLoading || promoStatus === "validating" || photoConversionsPending > 0) return false;
    if (step === 1) return services.length > 0;
    if (step === 2) {
      if (!isRelocation) return serviceAddress.length > 2;
      // Same-Property Move only needs the pickup address (it IS the address)
      if (samePropertyMove) return pickupAddress.length > 2;
      // Every added extra stop must have a real address before we can advance,
      // otherwise the server's stop validation would reject the submission late.
      if (extraStops.some(s => s.address.trim().length < 3)) return false;
      return pickupAddress.length > 2 && dropoffAddress.length > 2;
    }
    if (step === 3) return items.length > 0;
    if (step === 4) return true;
    return false;
  };

  const goNext = () => setStep(s => {
    // Funnel-analysis event (non-conversion): which step was just completed.
    trackFunnelEvent("estimate_step_completed", {
      step: s,
      lead_intent: leadIntentText || undefined,
      services: services.join(","),
    });
    return Math.min(s + 1, 5) as 1 | 2 | 3 | 4 | 5;
  });

  const next = () => {
    // The save-progress modal previously interrupted Step 3 → 4 (before
    // scheduling). That broke the user's flow at the highest-intent moment.
    // It's now an explicit, optional secondary action triggered from a small
    // inline link on Step 3 — `next()` just advances the wizard.
    if (step === 4) {
      if (!!slotDateStr !== !!slotTime) {
        setScheduleError("Choose both a preferred date and time, or clear the preference to continue without one.");
        return;
      }
      if (slotDateStr && slotTime && isSlotTaken(slotDateStr, slotTime)) {
        setScheduleError("That preferred time is unavailable. Choose another time or clear the preference to continue.");
        return;
      }
      setScheduleError("");
    }
    goNext();
  };

  const saveCaptureAndNext = async (skip = false) => {
    setShowCaptureModal(false);
    // Carry whatever the user typed in the modal forward — so Step 5 doesn't ask again.
    if (captureEmail.trim() && !email) setEmail(captureEmail.trim());
    if (captureName.trim() && !name) setName(captureName.trim());
    if (!skip && captureEmail.trim()) {
      setCaptureSaving(true);
      try {
        const res = await fetch("/api/partial-leads", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: captureEmail.trim(),
            name: captureName.trim() || undefined,
            services,
            serviceAddress: isRelocation ? pickupAddress : serviceAddress,
            pickupAddress: isRelocation ? pickupAddress : undefined,
            dropoffAddress: isRelocation ? dropoffAddress : undefined,
            items: items.map(i => ({ name: i.name, quantity: i.quantity, serviceType: i.serviceType })),
          }),
        });
        if (res.ok) {
          const { token } = await res.json();
          setPartialLeadToken(token);
        }
      } catch { /* non-fatal */ }
      setCaptureSaving(false);
    }
    goNext();
  };

  const back = () => setStep(s => Math.max(s - 1, 1) as 1 | 2 | 3 | 4 | 5);

  function handlePhotoWhatsAppClick(event: MouseEvent<HTMLAnchorElement>) {
    if (!measurementConsent) return;
    event.preventDefault();
    if (photoHandoffPending) return;

    const originalUrl = estimatePhotoEnquiryUrl(services, leadIntentText);
    const popup = window.open("about:blank", "_blank");
    photoHandoffWindow.current = popup;
    setPhotoHandoffError("");
    setPhotoHandoffContinueUrl("");
    setPhotoHandoffHasReference(false);
    setPhotoHandoffPending(true);

    void (async () => {
      try {
        const response = await fetch("/api/enquiry-handoff", {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ attribution: getLeadAttribution() }),
        });
        if (!response.ok) throw new Error("Attribution handoff was unavailable.");
        const body = await response.json() as { reference?: string };
        if (!body.reference) throw new Error("No enquiry reference was returned.");
        const waUrl = new URL(originalUrl);
        const originalMessage = waUrl.searchParams.get("text") || "";
        waUrl.searchParams.set("text", `${originalMessage}\n\nEnquiry reference: ${body.reference}`);
        const destination = waUrl.toString();
        if (photoHandoffWindow.current && !photoHandoffWindow.current.closed) {
          photoHandoffWindow.current.location.href = destination;
          photoHandoffWindow.current = null;
        } else {
          setPhotoHandoffContinueUrl(destination);
          setPhotoHandoffHasReference(true);
          setPhotoHandoffError("Your enquiry reference is ready, but the WhatsApp window could not open automatically.");
        }
      } catch {
        if (photoHandoffWindow.current && !photoHandoffWindow.current.closed) photoHandoffWindow.current.close();
        photoHandoffWindow.current = null;
        setPhotoHandoffContinueUrl(originalUrl);
        setPhotoHandoffError("Attribution handoff failed. You can continue to WhatsApp without attribution; your original message is unchanged.");
      } finally {
        setPhotoHandoffPending(false);
      }
    })();
  }

  function continuePhotoWhatsAppWithoutAttribution() {
    if (!photoHandoffContinueUrl) return;
    window.open(photoHandoffContinueUrl, "_blank", "noopener,noreferrer");
    setPhotoHandoffContinueUrl("");
    setPhotoHandoffError("");
  }

  // ── Render ────────────────────────────────────────────────────────────────

  const photoAlternative = (
    <aside aria-label="Quote from photos" className="mb-5 border border-black/15 bg-white/60 px-4 py-3">
      <p className="text-[10px] font-black uppercase tracking-[0.14em] text-black/50 mb-1">Prefer to share photos?</p>
      {/* The existing delegated contact-click tracker owns this link.
          No form submission, handoff write or extra conversion handler. */}
      <a
        href={estimatePhotoEnquiryUrl(services, leadIntentText)}
        target="_blank"
        rel="noopener noreferrer"
        data-testid="link-whatsapp-photos"
        onClick={handlePhotoWhatsAppClick}
        aria-busy={measurementConsent && photoHandoffPending}
        className="inline-flex min-h-[44px] items-center gap-2 text-sm font-bold text-black underline underline-offset-4 hover:text-black/65 transition-colors"
      >
        <MessageCircle className="h-5 w-5 shrink-0" />
        {measurementConsent && photoHandoffPending ? "Preparing WhatsApp enquiry…" : "Send photos for a quote on WhatsApp"}
      </a>
      <p className="text-xs leading-relaxed text-black/60">
        You can skip the form and share photos or product links for a team-reviewed estimate.
      </p>
      <label className="mt-3 flex items-start gap-2 text-xs leading-relaxed text-black/65">
        <input
          type="checkbox"
          className="mt-0.5"
          checked={measurementConsent}
          onChange={event => {
            setAdMeasurementConsent(event.target.checked);
            setMeasurementConsent(adMeasurementConsent()==="granted");
          }}
        />
        <span>Optional: allow advertising attribution for enquiry measurement. No contact details are sent to Google Ads, and this does not affect your quote request.</span>
      </label>
      {photoHandoffError && (
        <div className="mt-3 border border-black/15 bg-white p-3 text-left text-xs" role="alert">
          <p>{photoHandoffError}</p>
          {photoHandoffContinueUrl && (
            <button
              type="button"
              className="mt-2 font-semibold underline underline-offset-2"
              onClick={continuePhotoWhatsAppWithoutAttribution}
            >
              {photoHandoffHasReference ? "Continue to WhatsApp with enquiry reference" : "Continue to WhatsApp without attribution"}
            </button>
          )}
        </div>
      )}
    </aside>
  );

  return (
    <>
    <div className={`relative z-10 min-h-screen pb-20 text-black ${promoVisible ? "pt-[84px] sm:pt-24" : "pt-16"}`} style={{ background: "#f1efe7" }}>
      {/* Trust microbar — editorial style (matches homepage) */}
      <div className="hidden sm:block bg-black/[0.025] border-b border-black/10 py-2.5">
        <div className="max-w-2xl mx-auto px-4">
          <div className="flex items-center justify-center gap-3 sm:gap-4 flex-wrap">
            <span className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-[0.18em] text-black/55">
              <EstAccentSquare /> Itemised quote based on scope and access
            </span>
            <span className="hidden sm:inline-block w-px h-3 bg-black/15" />
            <span className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-[0.18em] text-black/55">
              <EstAccentSquare /> Itemised estimate
            </span>
            <span className="hidden sm:inline-block w-px h-3 bg-black/15" />
            <span className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-[0.18em] text-black/55">
              <EstAccentSquare /> Photo-Based Quote
            </span>
            <span className="hidden sm:inline-block w-px h-3 bg-black/15" />
            <span className="hidden sm:flex items-center gap-1.5 text-[10px] font-black uppercase tracking-[0.18em] text-black/55">
              <EstAccentSquare /> Island-Wide
            </span>
          </div>
        </div>
      </div>

      {/* Step indicator */}
      <div className={`sticky z-40 bg-[#f1efe7]/95 backdrop-blur border-b border-black/15 ${promoVisible ? "top-[84px] sm:top-24" : "top-16"}`}>
        <div className="max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-1 sm:gap-2">
            {STEPS.map((s, i) => (
              <div key={s.num} className="flex min-w-0 items-center gap-1 sm:gap-2 flex-1">
                <div className="relative shrink-0">
                  <div className={`w-6 h-6 sm:w-7 sm:h-7 flex items-center justify-center text-xs font-black transition-all ${
                    step > s.num ? "bg-black text-white" :
                    step === s.num ? "bg-black text-white" :
                    "bg-black/[0.05] text-black/25"
                  }`}>
                    {step > s.num ? <Check className="w-3.5 h-3.5" /> : s.num}
                  </div>
                  {s.num === 3 && items.length > 0 && step <= 3 && (
                    <div data-testid="badge-items-count" className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-black text-white text-[9px] font-black flex items-center justify-center rounded-full" aria-label={`${items.length} items added`}>
                      {items.length}
                    </div>
                  )}
                </div>
                <span className={`min-w-0 text-[8px] sm:text-[10px] font-black uppercase tracking-normal sm:tracking-[0.12em] leading-tight transition-colors ${step === s.num ? "text-black" : "text-black/40"}`}>{s.label}</span>
                {i < STEPS.length - 1 && <div className={`flex-1 h-px transition-colors ${step > s.num ? "bg-black/30" : "bg-black/[0.08]"}`} />}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className={`max-w-2xl mx-auto px-4 ${step === 1 ? "pt-3 sm:pt-8" : "pt-8"}`}>
        {step !== 1 && photoAlternative}
        <AnimatePresence mode="wait">
          <motion.div key={step} data-estimate-step={step} initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -24 }} transition={{ duration: 0.25 }}>

            {/* ── STEP 1: Select Services ── */}
            {step === 1 && (
              <div className="space-y-4 sm:space-y-6">
                <div className="relative overflow-hidden -mx-4 px-4 pb-2">

                  <EstDotGrid opacity={0.32} />

                  <div className="relative">

                    <p className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-black/45 mb-2">

                      <EstAccentSquare /> Step 1 of 5

                    </p>

                    <h2 data-estimate-step-heading tabIndex={-1} className="font-heading text-2xl sm:text-4xl font-black uppercase tracking-[-0.02em] text-black mb-1 focus-visible:outline focus-visible:outline-2">What do you need done?</h2>

                    <p className="text-xs sm:text-sm text-black/55">Choose the work to start an estimate. We confirm the scope and price in a formal quotation after review.</p>

                  </div>

                </div>
                <div className="grid grid-cols-1 gap-3">
                  {(() => {
                    const relocateActive = services.includes("relocate");
                    const cards = [
                      {
                        type: "install" as ServiceType,
                        icon: <Wrench className="w-6 h-6" />,
                        label: "Installation",
                        desc: "Assemble and install new furniture at your location",
                        priceHint: "Itemised quote",
                        // Disabled when Relocation is selected (Relocation already includes install)
                        coveredByRelocate: true,
                      },
                      {
                        type: "dismantle" as ServiceType,
                        icon: <Scissors className="w-6 h-6" />,
                        label: "Dismantling",
                        desc: "Carefully take apart existing furniture (no transport)",
                        priceHint: "Itemised quote",
                        coveredByRelocate: true,
                      },
                      {
                        type: "relocate" as ServiceType,
                        icon: <Truck className="w-6 h-6" />,
                        label: "Relocation / Move",
                        desc: "Complete door-to-door bundle — pick this if you're moving furniture from one place to another",
                        priceHint: "Itemised quote",
                        coveredByRelocate: false,
                        isBundle: true,
                        bundleItems: ["Dismantle at origin", "Transport in our van", "Reinstall at new home"],
                      },
                    ] as const;
                    return cards.map(card => {
                      const { type, icon, label, desc, priceHint, coveredByRelocate } = card;
                      const isBundle = "isBundle" in card && card.isBundle;
                      const bundleItems = "bundleItems" in card ? card.bundleItems : undefined;
                      const active = services.includes(type);
                      // Disabled (covered) when relocate is on and this card is install/dismantle
                      const isCovered = relocateActive && coveredByRelocate;
                      const handleClick = () => {
                        if (isCovered) return; // ignore — visually shown as already included
                        if (type === "relocate" && !active) {
                          // Selecting Relocation auto-clears Install/Dismantle (they're bundled in)
                          setServices(prev => [...prev.filter(s => s !== "install" && s !== "dismantle"), "relocate"]);
                        } else {
                          setServices(prev => active ? prev.filter(s => s !== type) : [...prev, type]);
                        }
                      };
                      return (
                        <button
                          key={type}
                          type="button"
                          data-testid={`service-${type}`}
                          onClick={handleClick}
                          aria-pressed={active || isCovered}
                          disabled={isCovered}
                          aria-disabled={isCovered}
                          tabIndex={isCovered ? -1 : 0}
                          className={`group relative border p-3 sm:p-5 text-left transition-all duration-150 ${
                            isCovered
                              ? "border-black/15 bg-[rgba(250,250,247,0.88)] cursor-default"
                              : active
                                ? "border-black border-l-[3px] bg-[rgba(250,250,247,0.92)]"
                                : "border-black/12 bg-[rgba(250,250,247,0.85)] hover:border-black/35"
                          }`}
                          style={active ? { borderLeftColor: EST_ACCENT, borderLeftWidth: 3 } : undefined}
                        >
                          <div className="flex items-start gap-4">
                            <div className={`w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center flex-shrink-0 transition-colors ${
                              isCovered
                                ? "text-black"
                                : active ? "bg-black text-white" : "bg-black/[0.05] text-black/50"
                            }`}
                            style={isCovered ? { background: EST_ACCENT } : undefined}
                            >
                              {isCovered ? <Check className="w-5 h-5 sm:w-6 sm:h-6" /> : icon}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <p className={`font-black text-base uppercase tracking-[0.04em] ${isCovered ? "text-black/55 line-through decoration-2 decoration-black/30" : ""}`}>{label}</p>
                                {isBundle && !isCovered && (
                                  <span className="text-[10px] font-black px-2 py-0.5 tracking-[0.18em] uppercase text-black" style={{ background: EST_ACCENT }}>ALL-IN-ONE BUNDLE</span>
                                )}
                                {!isCovered && (
                                  <span className="text-[10px] font-black px-2 py-0.5 tracking-[0.18em] uppercase bg-black/[0.05] text-black/55">{priceHint}</span>
                                )}
                                {isCovered && (
                                  <span className="text-[10px] font-black px-2 py-0.5 tracking-[0.18em] uppercase text-black" style={{ background: EST_ACCENT }}>INCLUDED IN RELOCATION</span>
                                )}
                              </div>
                              <p className={`text-xs sm:text-sm mt-0.5 ${isCovered ? "text-black/45" : "text-black/45"}`}>{desc}</p>

                              {/* Bundle includes — only on the Relocation card */}
                              {isBundle && bundleItems && (
                                <div className="mt-3 pt-3 border-t border-black/10">
                                  <p className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.18em] text-black/55 mb-2"><EstAccentSquare /> What's included</p>
                                  <div className="flex flex-wrap gap-1.5">
                                    {bundleItems.map(b => (
                                      <span key={b} className="inline-flex items-center gap-1.5 text-[11px] font-semibold px-2 py-1 border border-black/15 bg-[rgba(250,250,247,0.7)] text-black">
                                        <Check className="w-3 h-3" style={{ color: EST_ACCENT === "#2af56a" ? "#0a8a3c" : EST_ACCENT }} /> {b}
                                      </span>
                                    ))}
                                  </div>
                                  <p className="text-[11px] text-black/50 mt-2 leading-relaxed">
                                    <span className="font-bold">Don't add Dismantle or Installation separately</span> — they're already bundled in at a discount.
                                  </p>
                                </div>
                              )}
                            </div>
                            {!isCovered && (
                              <div className={`w-5 h-5 border flex items-center justify-center shrink-0 mt-1 transition-all ${
                                active ? "bg-black border-black" : "border-black/20"
                              }`}>
                                {active && <Check className="w-3 h-3 text-white" />}
                              </div>
                            )}
                          </div>
                        </button>
                      );
                    });
                  })()}

                  {/* ── Disposal card (special — has sub-mode toggle) ── */}
                  {(() => {
                    const disposalActive = services.includes("dispose") || services.includes("dismantle_dispose");
                    const toggleDisposal = () => {
                      if (disposalActive) {
                        setServices(prev => prev.filter(s => s !== "dispose" && s !== "dismantle_dispose"));
                      } else {
                        setServices(prev => [...prev, disposalMode]);
                      }
                    };
                    const switchMode = (mode: "dispose" | "dismantle_dispose") => {
                      setDisposalMode(mode);
                      setServices(prev => {
                        const without = prev.filter(s => s !== "dispose" && s !== "dismantle_dispose");
                        return [...without, mode];
                      });
                    };
                    return (
                      <div className={`border transition-all duration-150 ${disposalActive ? "border-black bg-black/[0.025]" : "border-black/10 bg-white"}`}>
                        <button
                          data-testid="service-dispose"
                          onClick={toggleDisposal}
                          className="w-full p-3 sm:p-5 text-left"
                        >
                          <div className="flex items-start gap-4">
                            <div className={`w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center flex-shrink-0 transition-colors ${disposalActive ? "bg-black text-white" : "bg-black/[0.05] text-black/50"}`}>
                              <Trash2 className="w-5 h-5 sm:w-6 sm:h-6" />
                            </div>
                            <div className="flex-1">
                              <p className="font-black text-base uppercase tracking-[0.04em]">Disposal</p>
                              <p className="text-sm text-black/45 mt-0.5">Haul away and dispose of unwanted furniture</p>
                            </div>
                            <div className={`w-5 h-5 border flex items-center justify-center shrink-0 mt-1 transition-all ${disposalActive ? "bg-black border-black" : "border-black/20"}`}>
                              {disposalActive && <Check className="w-3 h-3 text-white" />}
                            </div>
                          </div>
                        </button>
                        {disposalActive && (
                          <div className="px-5 pb-5 border-t border-black/10 pt-4 space-y-2">
                            <p className="text-[10px] font-black uppercase tracking-[0.15em] text-black/40 mb-3">Choose disposal type</p>
                            <button
                              data-testid="disposal-mode-dismantle-dispose"
                              onClick={() => switchMode("dismantle_dispose")}
                              className={`w-full flex items-start gap-3 p-3 border text-left transition-all ${disposalMode === "dismantle_dispose" ? "border-black bg-black text-white" : "border-black/10 hover:border-black/30"}`}
                            >
                              <div className={`w-4 h-4 mt-0.5 border-2 rounded-full flex-shrink-0 flex items-center justify-center ${disposalMode === "dismantle_dispose" ? "border-white" : "border-black/30"}`}>
                                {disposalMode === "dismantle_dispose" && <div className="w-2 h-2 rounded-full bg-white" />}
                              </div>
                              <div>
                                <p className="font-black text-sm uppercase tracking-[0.04em]">Dismantle + Dispose <span className={`ml-1 text-[10px] px-1.5 py-0.5 ${disposalMode === "dismantle_dispose" ? "bg-white/20" : "bg-green-100 text-green-700"}`}>SAVE MORE</span></p>
                                <p className={`text-xs mt-0.5 ${disposalMode === "dismantle_dispose" ? "text-white/60" : "text-black/45"}`}>We dismantle the furniture first, then dispose — bundle price is cheaper than disposal only</p>
                              </div>
                            </button>
                            <button
                              data-testid="disposal-mode-dispose-only"
                              onClick={() => switchMode("dispose")}
                              className={`w-full flex items-start gap-3 p-3 border text-left transition-all ${disposalMode === "dispose" ? "border-black bg-black text-white" : "border-black/10 hover:border-black/30"}`}
                            >
                              <div className={`w-4 h-4 mt-0.5 border-2 rounded-full flex-shrink-0 flex items-center justify-center ${disposalMode === "dispose" ? "border-white" : "border-black/30"}`}>
                                {disposalMode === "dispose" && <div className="w-2 h-2 rounded-full bg-white" />}
                              </div>
                              <div>
                                <p className="font-black text-sm uppercase tracking-[0.04em]">Disposal Only</p>
                                <p className={`text-xs mt-0.5 ${disposalMode === "dispose" ? "text-white/60" : "text-black/45"}`}>Haul away assembled furniture as-is — no dismantling included</p>
                              </div>
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
                {photoAlternative}
                {services.length > 0 && (
                  <div className="flex flex-wrap gap-2 pt-2">
                    {services.map(s => {
                      const labels: Record<string, string> = { install: "Installation", dismantle: "Dismantling", relocate: "Relocation", dispose: "Disposal Only", dismantle_dispose: "Dismantle + Dispose" };
                      return (
                        <span key={s} className="inline-flex items-center gap-1.5 px-3 py-1 border border-black/15 text-black bg-black/[0.03] text-xs font-black uppercase tracking-[0.08em]">
                          <Check className="w-3 h-3" /> {labels[s] ?? s}
                        </span>
                      );
                    })}
                  </div>
                )}

                {/* ── Lead intent (job type) — compact refinement of the broad
                    service selection. Optional, works together with the cards
                    above. Selecting an intent auto-picks its base service when
                    nothing is selected yet. ── */}
                <div className="border border-black/12 bg-[rgba(250,250,247,0.88)] p-5">
                  <p className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.15em] text-black/45 mb-1">
                    <EstAccentSquare /> What best describes your job?
                  </p>
                  <p className="text-[11px] text-black/40 mb-3">Optional — helps us respond faster with the right team.</p>
                  <div className="flex flex-wrap gap-2">
                    {LEAD_INTENT_OPTIONS.map(opt => {
                      const active = leadIntents.includes(opt.value);
                      return (
                        <button
                          key={opt.value}
                          type="button"
                          data-testid={`intent-${opt.value}`}
                          onClick={() => {
                            const nextIntents = active
                              ? leadIntents.filter(value => value !== opt.value)
                              : [...leadIntents, opt.value];
                            setLeadIntents(nextIntents);
                            if (!active) {
                              trackFunnelEvent("estimate_intent_selected", { lead_intent: opt.value });
                              // Auto-pick the matching base service only when the
                              // customer hasn't chosen any service yet.
                              if (services.length === 0) {
                                setServices([...opt.services] as ServiceType[]);
                              }
                            }
                          }}
                          className={`px-3 py-2 border text-xs font-black uppercase tracking-[0.06em] transition-all ${
                            active
                              ? "border-black bg-black text-white"
                              : "border-black/15 bg-white text-black/60 hover:border-black/40 hover:text-black"
                          }`}
                        >
                          {opt.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="border border-black/12 bg-white/70 px-4 py-4">
                  <p className="text-[10px] font-black uppercase tracking-[0.12em] text-black/55">
                    Where is the job? <span className="normal-case tracking-normal font-semibold">(optional)</span>
                  </p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {[{ value: "office", label: "Office / business" }, { value: "home", label: "Home" }].map(option => (
                      <button key={option.value} type="button" data-testid={`early-site-${option.value}`}
                        aria-pressed={siteType === option.value}
                        onClick={() => setSiteType(siteType === option.value ? "" : option.value)}
                        className={`px-3 py-2 text-xs font-bold border ${siteType === option.value ? "bg-black text-white border-black" : "bg-white text-black/60 border-black/15"}`}>
                        {option.label}
                      </button>
                    ))}
                  </div>
                  <p className="text-xs text-black/55 mt-2 leading-relaxed">
                    Multiple items or workstations? Add quantities to your item list. Photos, manuals or a floor plan help us check the scope.
                    Single-item and residential jobs are welcome too.
                  </p>
                </div>

                {/* Bundle upsell — show when Install selected but not Dismantle */}
                {services.includes("install") && !services.includes("dismantle") && !services.includes("relocate") && (
                  <div className="flex items-start gap-3 border border-amber-300 bg-amber-50 px-4 py-3.5">
                    <Tag className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <p className="font-black text-xs uppercase tracking-[0.08em] text-amber-900">Save 40% — Add Dismantling</p>
                      <p className="text-xs text-amber-700 mt-0.5 leading-relaxed">Replacing old furniture? When Installation + Dismantling are combined, the dismantle price drops 40%. Most popular for IKEA moves.</p>
                    </div>
                    <button
                      data-testid="button-add-dismantle-upsell"
                      onClick={() => setServices(prev => [...prev, "dismantle"])}
                      className="shrink-0 text-[10px] font-black uppercase tracking-[0.08em] bg-amber-600 text-white px-3 py-2 hover:bg-amber-700 transition-colors whitespace-nowrap"
                    >
                      Add it
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* ── STEP 2: Address ── */}
            {step === 2 && (
              <div className="space-y-6">
                <div className="relative overflow-hidden -mx-4 px-4 pb-2">

                  <EstDotGrid opacity={0.32} />

                  <div className="relative">

                    <p className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-black/45 mb-3">

                      <EstAccentSquare /> Step 2 of 5

                    </p>

                    <h2 data-estimate-step-heading tabIndex={-1} className="font-heading text-4xl font-black uppercase tracking-[-0.02em] text-black mb-1 focus-visible:outline focus-visible:outline-2">
                    {isRelocation ? "Pickup & Dropoff" : "Service Location"}
                  </h2>

                    <p className="text-sm text-black/45">
                    {isRelocation ? "Where should we pick up and deliver?" : "Where will the work take place?"}
                  </p>

                  </div>

                </div>
                <div className="bg-[rgba(250,250,247,0.88)] border border-black/12 p-6 space-y-5">
                  {isRelocation ? (
                    <>
                      {/* Same-Property toggle: when on, only one address is needed and the transport fee is skipped. */}
                      <div className="border border-black/10 bg-white p-4">
                        <p className="text-[10px] font-black uppercase tracking-[0.15em] text-black/40 mb-3">Move type</p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <button type="button" data-testid="move-type-different-address"
                            onClick={() => setSamePropertyMove(false)}
                            className={`p-3 text-left border transition-all ${!samePropertyMove ? "border-black bg-black/[0.03]" : "border-black/15 bg-white hover:border-black/30"}`}>
                            <p className="font-black text-xs uppercase tracking-[0.06em] text-black">Different Address</p>
                            <p className="text-[11px] text-black/55 mt-0.5 leading-snug">Pickup and destination details are used to itemise transport in your quote.</p>
                          </button>
                          <button type="button" data-testid="move-type-same-property"
                            onClick={() => setSamePropertyMove(true)}
                            className={`p-3 text-left border transition-all ${samePropertyMove ? "border-black bg-black/[0.03]" : "border-black/15 bg-white hover:border-black/30"}`}>
                            <p className="font-black text-xs uppercase tracking-[0.06em] text-black">Same Property <span className="ml-1 text-[10px] px-1.5 py-0.5 bg-green-100 text-green-700">NO TRANSPORT FEE</span></p>
                            <p className="text-[11px] text-black/55 mt-0.5 leading-snug">Move items between rooms or floors at the same address. Carry, access and any additional work are itemised in your quote.</p>
                          </button>
                        </div>
                      </div>

                      <AddressInput required label={samePropertyMove ? "Property Address" : "Pickup Address"} value={pickupAddress}
                        onSelect={(addr, lat, lng) => {
                          setPickupAddress(addr);
                          if (lat && lng) setPickupLatLng({ lat, lng });
                          else setPickupLatLng(null);
                        }}
                        placeholder="e.g. 100 Beach Road Singapore 189702" />
                      {!samePropertyMove && (
                        <AddressInput required label="Dropoff Address" value={dropoffAddress}
                          onSelect={(addr, lat, lng) => {
                            setDropoffAddress(addr);
                            if (lat && lng) setDropoffLatLng({ lat, lng });
                            else setDropoffLatLng(null);
                          }}
                          placeholder="e.g. 10 Bayfront Ave Singapore 018956" />
                      )}

                      {/* Same-Property explainer badge */}
                      {samePropertyMove && pickupAddress && (
                        <div className="flex items-start gap-2 px-4 py-2.5 text-sm border border-black/15 bg-black/[0.025] text-black/70" data-testid="badge-same-property-move">
                          <Check className="w-4 h-4 mt-0.5 shrink-0" />
                          <span>Same-Property Move — no transport or distance fee. Carry handling and any dismantle or reinstall work are itemised in your quote.</span>
                        </div>
                      )}

                      {/* Route distance badge — hidden for Same-Property Moves */}
                      {!samePropertyMove && pickupAddress && dropoffAddress && (
                        <div className={`flex items-center gap-2 px-4 py-2.5 text-sm border ${
                          distanceLoading ? "border-black/10 bg-black/[0.025] text-black/40" :
                          distanceKm > 0 ? "border-black/15 bg-black/[0.025] text-black/70" :
                          distanceError ? "border-black/15 bg-black/[0.025] text-black/60" : "border-black/10 bg-black/[0.025] text-black/40"
                        }`}>
                          {distanceLoading
                            ? <><Loader2 className="w-4 h-4 animate-spin" /> Calculating route distance…</>
                            : distanceKm > 0
                              ? <><Navigation className="w-4 h-4" /> Route distance: <strong>{distanceKm} km</strong> — transport fee will be calculated</>
                              : distanceError
                                ? <><AlertCircle className="w-4 h-4" /> {distanceError} — transport fee will be reviewed</>
                                : null
                          }
                        </div>
                      )}

                      {/* ── Additional stops (multi-stop relocation) ── */}
                      {!samePropertyMove && (
                        <div className="border border-black/10 bg-white p-4" data-testid="section-additional-stops">
                          <p className="text-[10px] font-black uppercase tracking-[0.15em] text-black/40 mb-1">Additional stops <span className="text-black/25 font-normal normal-case tracking-normal">(optional)</span></p>
                          <p className="text-[11px] text-black/45 mb-3 leading-snug">Picking up from more than one place, or dropping off at multiple addresses? Add the extra stops here. Each extra stop adds a ${PricingConfig.multiStop.additionalStopFee} stop fee.</p>

                          {extraStops.length > 0 && (
                            <div className="space-y-4 mb-3">
                              {extraStops.map(es => {
                                const label = stopGroups.all.find(s => s.id === es.id)?.label
                                  ?? (es.kind === "pickup" ? "Pickup" : "Drop-off");
                                return (
                                  <div key={es.id} className="border border-black/10 bg-[rgba(250,250,247,0.7)] p-3 space-y-3" data-testid={`extra-stop-${es.id}`}>
                                    <div className="flex items-center justify-between">
                                      <span className="text-[10px] font-black uppercase tracking-[0.1em] text-black/55">{label}</span>
                                      <button type="button" onClick={() => removeExtraStop(es.id)}
                                        data-testid={`button-remove-stop-${es.id}`}
                                        className="text-black/30 hover:text-black hover:bg-slate-100 p-1 transition-colors">
                                        <X className="w-4 h-4" />
                                      </button>
                                    </div>
                                    <AddressInput required label={`${label} Address`} value={es.address}
                                      onSelect={(addr, lat, lng) => updateExtraStop(es.id, { address: addr, lat: lat ?? undefined, lng: lng ?? undefined })}
                                      placeholder="Start typing an address…" />
                                    <div className="flex items-center gap-3">
                                      <span className="text-xs text-black/40 font-black uppercase">Floor</span>
                                      <input type="number" min="0" max="50" value={es.floor}
                                        onChange={e => updateExtraStop(es.id, { floor: e.target.value })}
                                        className="w-20 px-3 py-2 bg-white border border-black/10 text-center outline-none focus:border-black text-sm"
                                        data-testid={`input-stop-floor-${es.id}`} />
                                      <label className="flex items-center gap-2 text-sm cursor-pointer text-black/60">
                                        <input type="checkbox" checked={es.hasLift}
                                          onChange={e => updateExtraStop(es.id, { hasLift: e.target.checked })}
                                          className="w-4 h-4 accent-black"
                                          data-testid={`checkbox-stop-lift-${es.id}`} />
                                        Has lift
                                      </label>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}

                          <div className="flex flex-wrap gap-2">
                            <button type="button" onClick={() => addExtraStop("pickup")}
                              data-testid="button-add-pickup-stop"
                              className="text-[10px] font-black uppercase tracking-[0.1em] text-black/50 hover:text-black flex items-center gap-1 border border-black/15 px-3 py-2 hover:border-black/40 transition-colors">
                              <Plus className="w-3.5 h-3.5" /> Add pickup stop
                            </button>
                            <button type="button" onClick={() => addExtraStop("dropoff")}
                              data-testid="button-add-dropoff-stop"
                              className="text-[10px] font-black uppercase tracking-[0.1em] text-black/50 hover:text-black flex items-center gap-1 border border-black/15 px-3 py-2 hover:border-black/40 transition-colors">
                              <Plus className="w-3.5 h-3.5" /> Add drop-off stop
                            </button>
                          </div>
                        </div>
                      )}

                      <div>
                        <p className="text-[10px] font-black uppercase tracking-[0.15em] text-black/40 mb-3">Floor details <span className="text-black/25 font-normal normal-case tracking-normal">(affects pricing)</span></p>
                        {floors.map((floor, i) => (
                          <div key={i} className="flex items-center gap-3 mb-3">
                            <div className="flex items-center gap-2 flex-1">
                              <span className="text-xs text-black/40 w-12 shrink-0 font-black uppercase">Floor {i + 1}</span>
                              <input
                                type="number" min="1" max="50"
                                value={floor.level}
                                onChange={e => setFloors(prev => prev.map((f, fi) => fi === i ? { ...f, level: e.target.value } : f))}
                                className="w-20 px-3 py-2 bg-white border border-black/10 text-center outline-none focus:border-black text-sm"
                                data-testid={`input-floor-level-${i}`}
                              />
                            </div>
                            <label className="flex items-center gap-2 text-sm cursor-pointer text-black/60">
                              <input type="checkbox" checked={floor.hasLift}
                                onChange={e => setFloors(prev => prev.map((f, fi) => fi === i ? { ...f, hasLift: e.target.checked } : f))}
                                className="w-4 h-4 accent-black"
                              />
                              Has lift
                            </label>
                            {floors.length > 1 && (
                              <button onClick={() => setFloors(prev => prev.filter((_, fi) => fi !== i))} className="text-black/30 hover:text-black hover:bg-slate-100 p-1.5 transition-colors">
                                <X className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        ))}
                        <button onClick={() => setFloors(prev => [...prev, { level: "1", hasLift: true }])}
                          className="text-[10px] font-black uppercase tracking-[0.1em] text-black/40 hover:text-black flex items-center gap-1 transition-colors">
                          <Plus className="w-3.5 h-3.5" /> Add floor
                        </button>
                      </div>
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-[0.15em] text-black/40 mb-3">Access difficulty</p>
                        <div className="flex gap-2">
                          {(["easy", "medium", "hard"] as const).map(d => (
                            <button key={d} data-testid={`difficulty-${d}`}
                              onClick={() => setAccessDifficulty(d)}
                              className={`flex-1 py-2.5 text-xs font-black uppercase tracking-[0.08em] capitalize transition-all border ${
                                accessDifficulty === d ? "border-black bg-black/[0.03] text-black" : "border-black/10 bg-white text-black/40 hover:border-black/30 hover:bg-slate-50"
                              }`}
                            >{d}</button>
                          ))}
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      <AddressInput required label="Service Address" value={serviceAddress} onSelect={(addr) => setServiceAddress(addr)} placeholder="e.g. 100 Beach Road Singapore 189702" />
                      {/* Installation and other non-relocation jobs are priced flat —
                          floor level, lift and stairs do NOT affect the price, so we
                          no longer ask for them here. (They previously produced a
                          floor / access fee on the estimate that the server never
                          actually billed, which confused customers.) */}
                    </>
                  )}
                </div>
              </div>
            )}

            {/* ── STEP 3: Items ── */}
            {step === 3 && (
              <div className="space-y-5">
                <div className="relative overflow-hidden -mx-4 px-4 pb-2">

                  <EstDotGrid opacity={0.32} />

                  <div className="relative">

                    <p className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-black/45 mb-3">

                      <EstAccentSquare /> Step 3 of 5

                    </p>

                    <h2 data-estimate-step-heading tabIndex={-1} className="font-heading text-4xl font-black uppercase tracking-[-0.02em] text-black mb-1 focus-visible:outline focus-visible:outline-2">Add Your Items</h2>

                    <p className="text-sm text-black/45">Search our catalog, paste a list, or upload a photo.</p>

                  </div>

                </div>

                {/* Catalog Browse */}
                <div className="space-y-3">
                  {/* Category tabs */}
                  <div className="flex flex-wrap gap-2">
                    {CATEGORY_GROUPS.map(tab => (
                      <button
                        key={tab.label}
                        data-testid={`category-tab-${tab.label.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}
                        onClick={() => { setActiveCategory(tab.label); setCatalogSearch(""); setCatalogVisibleCount(24); }}
                        className={`shrink-0 px-3 py-1.5 text-[10px] font-black uppercase tracking-[0.1em] border transition-all ${
                          activeCategory === tab.label
                            ? "bg-black text-white border-black"
                            : "bg-white text-black/50 border-black/15 hover:border-black/40 hover:text-black"
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>
                  {additionalCategories.length > 0 && (
                    <label className="block max-w-sm text-[10px] font-black uppercase tracking-[0.12em] text-black/40">
                      More categories
                      <select
                        value={activeCategory.startsWith("exact:") ? activeCategory.slice("exact:".length) : ""}
                        onChange={e => { setActiveCategory(e.target.value ? `exact:${e.target.value}` : "All"); setCatalogSearch(""); setCatalogVisibleCount(24); }}
                        data-testid="select-more-categories"
                        className="mt-1 w-full px-3 py-2.5 bg-white border border-black/10 focus:border-black outline-none text-sm normal-case font-medium tracking-normal text-black"
                      >
                        <option value="">Choose an exact category…</option>
                        {additionalCategories.map(category => <option key={category} value={category}>{category}</option>)}
                      </select>
                    </label>
                  )}

                  {/* Search input */}
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-black/25 pointer-events-none" />
                    <input
                      value={catalogSearch}
                      onChange={e => { setCatalogSearch(e.target.value); setCatalogVisibleCount(24); if (e.target.value) setActiveCategory("All"); }}
                      onFocus={() => setCatalogFocused(true)}
                      onBlur={() => { setTimeout(() => setCatalogFocused(false), 150); }}
                      placeholder="Search items e.g. wardrobe, bed, sofa…"
                      data-testid="input-catalog-search"
                      autoComplete="off"
                      className="w-full pl-9 pr-10 py-3 bg-white border border-black/10 focus:border-black transition-all outline-none text-sm"
                    />
                    {catalogSearch && (
                      <button onClick={() => setCatalogSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-black/30 hover:text-black">
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  {/* Search results dropdown (when searching) */}
                  {showCatalogResults && catalogSearch.trim() && (
                    <div className="border border-black/10 overflow-hidden bg-white">
                      {filteredGroups.length === 0 ? (
                        <div className="px-4 py-6 text-center text-sm text-black/50">
                          <p>No catalogue match for <strong>"{catalogSearch}"</strong>.</p>
                          <p className="mt-1 text-xs">Try a common name such as bed frame, wardrobe, cubicle or flat-pack, or add it below for team review.</p>
                          <button type="button" data-testid="button-no-result-custom" onClick={() => {
                            setCustomName(catalogSearch.trim()); setCatalogSearch(""); setCatalogFocused(false);
                            requestAnimationFrame(() => {
                              const input=document.querySelector<HTMLInputElement>('[data-testid="input-custom-item-name"]');
                              input?.scrollIntoView({block:"center"}); input?.focus({preventScroll:true});
                            });
                          }} className="mt-3 px-3 py-2 border border-black/25 text-[10px] font-black uppercase tracking-[0.1em] text-black hover:bg-black hover:text-white">
                            Add as custom item for review
                          </button>
                        </div>
                      ) : (
                        filteredGroups.map(group => {
                          const isSpecial = group.entries.some(e => requiresSpecialHandling(e.sku));
                          const showLiftWarning = isSpecial && services.includes('relocate');
                          return (
                          <button
                            key={group.name}
                            onClick={() => { addCatalogGroup(group, 1); setCatalogSearch(""); setCatalogFocused(false); }}
                            data-testid={`catalog-item-${group.name.toLowerCase().replace(/\s+/g, "-")}`}
                            className="w-full text-left px-4 py-3 hover:bg-slate-50 active:bg-slate-100 border-b border-black/6 last:border-0 transition-colors flex items-center justify-between gap-3"
                          >
                            <div className="min-w-0">
                              <p className="font-semibold text-sm leading-tight break-words">{group.name}</p>
                              <p className="text-xs text-black/35">{(group.categories || [group.category]).join(" / ")}</p>
                              {showLiftWarning && (
                                <p className="text-[10px] font-bold uppercase tracking-wider text-amber-700 mt-1" data-testid={`badge-lift-warning-${group.name.toLowerCase().replace(/\s+/g, '-')}`}>
                                  ⚠ Won't fit in lift — needs survey
                                </p>
                              )}
                            </div>
                            <div className="text-right shrink-0 space-y-0.5">
                              {(() => {
                                if (furnitureNeedsSpecificationReview(group.name))
                                  return <span className="text-xs font-bold text-amber-700">Model / dimensions review</span>;
                                if (services.length === 1 && services[0] === 'relocate') {
                                  const rel = group.entries.find(e => e.serviceType === 'relocate');
                                  if (rel) {
                                    const inst = group.entries.find(e => e.serviceType === 'install');
                                    const dis = group.entries.find(e => e.serviceType === 'dismantle');
                                    const fullPrice = computeDRPrice(
                                      inst ? parseFloat(inst.basePrice) : undefined,
                                      dis ? parseFloat(dis.basePrice) : undefined,
                                      parseFloat(rel.basePrice),
                                    );
                                    return (
                                      <div className="flex items-center gap-2 justify-end">
                                        {serviceBadge('relocate')}
                                        <span className="text-xs font-bold">{fullPrice <= 0 ? 'FREE' : `$${fullPrice.toFixed(0)}`}</span>
                                      </div>
                                    );
                                  }
                                }
                                return group.entries.filter(e => services.includes(e.serviceType)).map(e => {
                                  let displayPrice = parseFloat(e.basePrice);
                                  if (e.serviceType === 'relocate') {
                                    const inst2 = group.entries.find(x => x.serviceType === 'install');
                                    const dis2  = group.entries.find(x => x.serviceType === 'dismantle');
                                    displayPrice = computeDRPrice(
                                      inst2 ? parseFloat(inst2.basePrice) : undefined,
                                      dis2 ? parseFloat(dis2.basePrice) : undefined,
                                      parseFloat(e.basePrice),
                                    );
                                  }
                                  return (
                                    <div key={e.id} className="flex items-center gap-2 justify-end">
                                      {serviceBadge(e.serviceType)}
                                      <span className="text-xs font-bold">{e.serviceType === 'relocate' && displayPrice <= 0 ? 'FREE' : `$${displayPrice.toFixed(0)}`}</span>
                                    </div>
                                  );
                                });
                              })()}
                            </div>
                          </button>
                        );})
                      )}
                    </div>
                  )}

                  {/* Browse grid (when not searching — show popular items as cards) */}
                  {!catalogSearch.trim() && (
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-[0.15em] text-black/35 mb-2">
                        {activeCategory === "All" ? "Popular items — tap to add" : `${activeCategoryLabel} — tap to add`}
                      </p>
                      {showAllCatalog && (
                        <p className="text-xs text-black/40 mb-2" data-testid="text-catalog-showing-count">
                          Showing {Math.min(catalogVisibleCount, filteredGroups.length)} of {filteredGroups.length} catalogue items
                        </p>
                      )}
                      {filteredGroups.length === 0 ? (
                        <p className="text-sm text-black/35 py-4 text-center">No items in this category</p>
                      ) : (
                        <div className="grid grid-cols-2 gap-2">
                          {visibleCatalogGroups.map(group => {
                            const alreadyAdded = items.some(i => i.name === group.name);
                            const isSpecial = group.entries.some(e => requiresSpecialHandling(e.sku));
                            const showLiftWarning = isSpecial && services.includes('relocate');
                            const priceDisplay = (() => {
                              if (services.length === 1 && services[0] === 'relocate') {
                                const rel = group.entries.find(e => e.serviceType === 'relocate');
                                if (rel) {
                                  const inst = group.entries.find(e => e.serviceType === 'install');
                                  const dis = group.entries.find(e => e.serviceType === 'dismantle');
                                  const fullPrice = computeDRPrice(
                                    inst ? parseFloat(inst.basePrice) : undefined,
                                    dis ? parseFloat(dis.basePrice) : undefined,
                                    parseFloat(rel.basePrice),
                                  );
                                  return fullPrice <= 0 ? 'FREE' : `$${fullPrice.toFixed(0)}`;
                                }
                              }
                              const relevant = group.entries.filter(e => services.includes(e.serviceType));
                              if (relevant.length === 0) return null;
                              const total = relevant.reduce((s, e) => {
                                if (e.serviceType === 'relocate') {
                                  const inst2 = group.entries.find(x => x.serviceType === 'install');
                                  const dis2  = group.entries.find(x => x.serviceType === 'dismantle');
                                  return s + computeDRPrice(
                                    inst2 ? parseFloat(inst2.basePrice) : undefined,
                                    dis2 ? parseFloat(dis2.basePrice) : undefined,
                                    parseFloat(e.basePrice),
                                  );
                                }
                                return s + parseFloat(e.basePrice);
                              }, 0);
                              return total <= 0 ? 'FREE' : `$${total.toFixed(0)}`;
                            })();
                            return (
                              <button
                                key={group.name}
                                data-testid={`catalog-item-${group.name.toLowerCase().replace(/\s+/g, "-")}`}
                                data-added={alreadyAdded ? "true" : undefined}
                                aria-pressed={alreadyAdded}
                                onClick={() => addCatalogGroup(group, 1)}
                                className={`relative text-left p-3 border transition-all active:scale-[0.98] ${
                                  alreadyAdded
                                    ? "border-black bg-black/[0.03]"
                                    : "border-black/10 bg-white hover:border-black/40 hover:bg-slate-50"
                                }`}
                              >
                                <div className="flex items-start justify-between gap-1">
                                  <p className="font-semibold text-sm leading-tight line-clamp-2 flex-1">{group.name}</p>
                                  <div className={`shrink-0 w-5 h-5 flex items-center justify-center border transition-all ${alreadyAdded ? "bg-black border-black" : "border-black/20 hover:border-black"}`}>
                                    {alreadyAdded ? <Check className="w-3 h-3 text-white" /> : <Plus className="w-3 h-3 text-black/40" />}
                                  </div>
                                </div>
                                <div className="flex items-center justify-between mt-2">
                                  <p className="text-[10px] text-black/35 truncate">{(group.categories || [group.category]).join(" / ")}</p>
                                  {priceDisplay && <p className="text-xs font-black text-black shrink-0">{priceDisplay}</p>}
                                </div>
                                {showLiftWarning && (
                                  <p className="text-[9px] font-bold uppercase tracking-wider text-amber-700 mt-1.5 leading-tight" data-testid={`badge-lift-warning-grid-${group.name.toLowerCase().replace(/\s+/g, '-')}`}>
                                    ⚠ Won't fit in lift — needs survey
                                  </p>
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}
                      {showAllCatalog && catalogVisibleCount < filteredGroups.length && (
                        <button type="button" data-testid="button-show-more-catalog-items" onClick={() => setCatalogVisibleCount(count => Math.min(count + 24, filteredGroups.length))} className="mt-3 w-full border border-black/20 px-4 py-2.5 text-[10px] font-black uppercase tracking-[0.12em] text-black/65 hover:border-black/50 hover:text-black">
                          Show more items ({filteredGroups.length - catalogVisibleCount} remaining)
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {/* Manual custom review line — separate from the verified catalogue. */}
                <div className="bg-[rgba(250,250,247,0.88)] border border-black/12 p-5 space-y-3" data-testid="custom-item-form">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.15em] text-black/45">Can't find your item?</p>
                    <p className="text-sm text-black/55 mt-1">Add it for team review. Custom work is not priced until TMG confirms the details.</p>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-3">
                    <label className="text-[10px] font-black uppercase tracking-[0.12em] text-black/45">
                      Item name
    <input value={customName} maxLength={300} onChange={e => setCustomName(e.target.value)} data-testid="input-custom-item-name" placeholder="e.g. built-in shoe cabinet" className="mt-1 w-full px-3 py-2.5 bg-white border border-black/10 focus:border-black outline-none text-sm normal-case font-medium tracking-normal" />
                    </label>
                    <label className="text-[10px] font-black uppercase tracking-[0.12em] text-black/45">
                      Service
                        <select value={customService && services.includes(customService) ? customService : services[0] || ""} onChange={e => setCustomService(e.target.value as ServiceType)} data-testid="select-custom-item-service" className="mt-1 w-full px-3 py-2.5 bg-white border border-black/10 focus:border-black outline-none text-sm normal-case font-medium tracking-normal">
                        {services.map(service => <option key={service} value={service}>{service.replaceAll("_", " ")}</option>)}
                      </select>
                    </label>
                    <label className="text-[10px] font-black uppercase tracking-[0.12em] text-black/45">
                      Quantity
                        <input type="number" min={1} max={9999} step={1} value={customQuantity} onChange={e => setCustomQuantity(e.target.value)} data-testid="input-custom-item-quantity" className="mt-1 w-full px-3 py-2.5 bg-white border border-black/10 focus:border-black outline-none text-sm normal-case font-medium tracking-normal" />
                    </label>
                    <label className="text-[10px] font-black uppercase tracking-[0.12em] text-black/45">
                      Dimensions (optional)
                      <input value={customDimensions} maxLength={300} onChange={e => setCustomDimensions(e.target.value)} data-testid="input-custom-item-dimensions" placeholder="Width × height × depth" className="mt-1 w-full px-3 py-2.5 bg-white border border-black/10 focus:border-black outline-none text-sm normal-case font-medium tracking-normal" />
                    </label>
                    <label className="text-[10px] font-black uppercase tracking-[0.12em] text-black/45 sm:col-span-2">
                      Details for the team (optional)
                      <textarea value={customDetails} maxLength={2000} onChange={e => setCustomDetails(e.target.value)} rows={2} data-testid="input-custom-item-details" placeholder="Brand, model, access or special instructions" className="mt-1 w-full px-3 py-2.5 bg-white border border-black/10 focus:border-black outline-none text-sm normal-case font-medium tracking-normal resize-y" />
                    </label>
                    <label className="text-[10px] font-black uppercase tracking-[0.12em] text-black/45 sm:col-span-2">
                      Product link (optional)
                      <input type="url" value={customLink} maxLength={2000} onChange={e => setCustomLink(e.target.value)} data-testid="input-custom-item-link" placeholder="https://" className="mt-1 w-full px-3 py-2.5 bg-white border border-black/10 focus:border-black outline-none text-sm normal-case font-medium tracking-normal" />
                    </label>
                    <label className="text-[10px] font-black uppercase tracking-[0.12em] text-black/45">
                      Photo (optional)
                      <input type="file" accept="image/jpeg,image/png" data-testid="input-custom-item-photo" disabled={photoConversionsPending > 0} onChange={e => {
                        const file = e.currentTarget.files?.[0];
                        e.currentTarget.value = "";
                        if (file) void prepareCustomPhoto(file, setCustomPhoto);
                      }} className="mt-1 block w-full text-xs normal-case font-medium tracking-normal" />
                      {customPhoto && <span className="mt-1 block text-[10px] normal-case tracking-normal text-black/50">Photo attached · compressed for review</span>}
                      {photoConversionsPending > 0 && <span role="status" className="mt-1 block text-[10px] normal-case tracking-normal text-black/50">Preparing photo…</span>}
                    </label>
                  </div>
                  {customError && <p role="alert" className="text-xs font-semibold text-red-700">{customError}</p>}
                  <button type="button" onClick={addCustomItem} disabled={photoConversionsPending > 0} data-testid="button-add-custom-item" className="inline-flex items-center gap-2 px-4 py-2.5 bg-black text-white text-[10px] font-black uppercase tracking-[0.12em] hover:bg-black/80 disabled:opacity-40">
                    <Plus className="w-3.5 h-3.5" /> {photoConversionsPending ? "Preparing photo…" : "Add for review"}
                  </button>
                </div>

                {/* Photo Upload */}
                <div className="bg-[rgba(250,250,247,0.88)] border border-black/12 p-5">
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-black/40 mb-3 flex items-center gap-2">
                    <Camera className="w-3.5 h-3.5" /> AI Photo Detection
                    <span className="text-black/25 font-normal normal-case tracking-normal">(optional · multiple photos)</span>
                  </p>
                  <input type="file" ref={fileInputRef} accept="image/jpeg,image/png" multiple className="hidden" onChange={handlePhotoUpload} />
                  <div className="grid sm:grid-cols-2 gap-3 mb-4">
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5 block">Photo shows</label>
                      <select
                        value={manualCategoryHint}
                        onChange={e => setManualCategoryHint(e.target.value as FurnitureCategory | "")}
                        data-testid="select-photo-category"
                        className="w-full px-3 py-2.5 bg-white border border-black/10 focus:border-black outline-none text-sm"
                      >
                        <option value="">Let AI identify it</option>
                        {FURNITURE_CATEGORY_OPTIONS.filter(option => option.value !== "unknown").map(option => (
                          <option key={option.value} value={option.value}>{option.label}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5 block">Room / work area</label>
                      <select
                        value={roomType}
                        onChange={e => setRoomType(e.target.value)}
                        data-testid="select-photo-room"
                        className="w-full px-3 py-2.5 bg-white border border-black/10 focus:border-black outline-none text-sm"
                      >
                        <option value="">Select if helpful</option>
                        {ROOM_TYPE_OPTIONS.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
                      </select>
                    </div>
                    <div className="sm:col-span-2">
                      <label className="text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5 block">Seller link or photo note</label>
                      <input
                        value={productLink}
                        onChange={e => setProductLink(e.target.value.slice(0, 1000))}
                        data-testid="input-photo-product-link"
                        placeholder="Paste the IKEA, Taobao or seller link, or add it later"
                        className="w-full px-3 py-2.5 bg-white border border-black/10 focus:border-black outline-none text-sm"
                      />
                    </div>
                  </div>

                  {/* While scanning */}
                  {photoDetecting && (
                    <div className="w-full border border-dashed border-black/20 py-6 flex flex-col items-center gap-2 text-black/50">
                      <Loader2 className="w-7 h-7 animate-spin" />
                      <span className="text-sm font-black">
                        {detectingProgress && detectingProgress.total > 1
                          ? `Scanning photo ${detectingProgress.current} of ${detectingProgress.total}…`
                          : "Scanning photo with AI…"}
                      </span>
                      <span className="text-xs text-black/35">Identifying furniture — this may take a few seconds</span>
                    </div>
                  )}

                  {/* Success state — photo grid + item chips + add more */}
                  {!photoDetecting && detectedPhotos.length > 0 && (
                    <div className="space-y-4">
                      {/* Thumbnail grid */}
                      <div className="flex flex-wrap gap-3">
                        {detectedPhotos.map((photo, idx) => (
                          <div key={idx} className="relative" data-testid={`detected-photo-${idx}`}>
                            <img src={photo.thumbnail} alt={`Photo ${idx + 1}`}
                              className="w-20 h-20 object-cover border border-black/15" />
                            {/* Item count badge */}
                            <div className="absolute -top-2 -right-2 w-6 h-6 bg-black text-white text-[11px] font-black flex items-center justify-center rounded-full">
                              {photo.count}
                            </div>
                            {/* Remove photo */}
                            <button
                              onClick={() => {
                                const removedPhoto = photo.thumbnail;
                                setDetectedPhotos(prev => prev.filter((_, i) => i !== idx));
                                setItems(prev => prev.map(item => item.photo === removedPhoto ? { ...item, photo: undefined } : item));
                              }}
                              className="absolute -bottom-2 -right-2 w-5 h-5 bg-white border border-black/20 rounded-full flex items-center justify-center hover:bg-slate-100 transition-colors"
                              data-testid={`button-remove-photo-${idx}`}>
                              <X className="w-3 h-3 text-black/60" />
                            </button>
                          </div>
                        ))}

                        {/* Add more photos tile */}
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          disabled={detectedPhotos.length >= 10}
                          data-testid="button-add-more-photos"
                          className="w-20 h-20 border-2 border-dashed border-black/20 flex flex-col items-center justify-center gap-1 hover:border-black/50 hover:bg-slate-50 transition-all text-black/35 hover:text-black/60 disabled:opacity-40 disabled:cursor-not-allowed">
                          <Plus className="w-5 h-5" />
                          <span className="text-[9px] font-black uppercase tracking-wide leading-tight text-center">{detectedPhotos.length >= 10 ? <>Photo<br />limit</> : <>Add<br />More</>}</span>
                        </button>
                      </div>

                      {/* Summary */}
                      <p className="text-sm font-black flex items-center gap-1.5">
                        <Check className="w-4 h-4" />
                        {detectedPhotos.reduce((t, p) => t + p.count, 0)} item{detectedPhotos.reduce((t, p) => t + p.count, 0) !== 1 ? "s" : ""} detected from {detectedPhotos.length} photo{detectedPhotos.length !== 1 ? "s" : ""}
                      </p>

                      {/* All detected names as chips */}
                      <div className="flex flex-wrap gap-1.5">
                        {detectedPhotos.flatMap(p => p.names).map((nm, i) => (
                          <span key={i} className="inline-flex items-center text-[10px] font-black uppercase tracking-[0.08em] bg-black text-white px-2 py-0.5">
                            {nm}
                          </span>
                        ))}
                      </div>

                      <p className="text-xs text-black/40">Review and adjust quantities in the item list below.</p>
                    </div>
                  )}

                  {/* Initial upload zone */}
                  {!photoDetecting && detectedPhotos.length === 0 && (
                    <button onClick={() => fileInputRef.current?.click()}
                      data-testid="button-upload-photo"
                      className="w-full border border-dashed border-black/20 py-6 flex flex-col items-center gap-2 hover:border-black/40 hover:bg-slate-50 transition-all text-black/35 hover:text-black/60">
                      <Camera className="w-7 h-7" />
                      <span className="text-sm font-black">Take or upload photos</span>
                      <span className="text-xs text-center">Select multiple photos at once — AI detects furniture from each one</span>
                    </button>
                  )}

                  {photoError && (
                    <p className="text-sm text-black/60 mt-3 flex items-center gap-1.5 border border-black/15 px-3 py-2">
                      <AlertCircle className="w-4 h-4 shrink-0" />{photoError}
                    </p>
                  )}
                  {photoRouting && (
                    <p className="text-xs text-black/45 mt-3" data-testid="text-photo-routing">
                      Detected category: <strong className="text-black/70">{photoRouting.categoryLabel}</strong>
                      {photoRouting.requiresReview ? " · Our team will confirm the exact item." : ""}
                    </p>
                  )}
                </div>

                {/* Paste List */}
                <div className="bg-[rgba(250,250,247,0.88)] border border-black/12 p-5">
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-[10px] font-black uppercase tracking-[0.15em] text-black/40 flex items-center gap-2"><ClipboardList className="w-3.5 h-3.5" /> Paste Item List <span className="text-black/25 font-normal normal-case tracking-normal">(optional)</span></p>
                    <button onClick={() => setShowPaste(s => !s)} className="text-[10px] font-black uppercase tracking-[0.1em] text-black/40 hover:text-black transition-colors">{showPaste ? "Close" : "Open"}</button>
                  </div>
                  {showPaste && (
                    <div className="space-y-3">
                      <textarea
                        value={pasteText}
                        onChange={e => setPasteText(e.target.value)}
                        rows={5}
                        placeholder={"2 queen bed\n6 office chair\n1 dining table"}
                        data-testid="input-paste-list"
                        className="w-full px-4 py-3 bg-white border border-black/10 focus:border-black outline-none resize-none text-sm font-mono"
                      />
                      <p className="text-xs text-black/35">One item per line. Format: "2 queen bed" or "dining table x4"</p>
                      <button onClick={applyPaste} disabled={!pasteText.trim()}
                        data-testid="button-apply-paste"
                        className="bg-black text-white px-5 py-2.5 text-xs font-black uppercase tracking-[0.1em] disabled:opacity-50 hover:bg-neutral-800 transition-colors">
                        Add Items
                      </button>
                    </div>
                  )}
                </div>

                {/* Items list */}
                {items.length > 0 && (
                  <div className="bg-[rgba(250,250,247,0.88)] border border-black/12 overflow-hidden">
                    <div className="px-5 py-4 border-b border-black/8 flex items-center justify-between">
                      <p className="font-black text-sm flex items-center gap-2 uppercase tracking-[0.06em]"><Package className="w-4 h-4 text-black/40" /> Items ({items.length})</p>
                      <p className="font-black text-sm">{hasUnpricedItems && !hasKnownPricedItems ? "Pending team pricing review" : hasUnpricedItems ? `Priced items $${subtotal.toFixed(2)} · pending review` : `$${subtotal.toFixed(2)}`}</p>
                    </div>
                    <div className="divide-y divide-black/6">
                      {items.map((item) => {
                        const isPendingReview = item.isCustom || item.requiresReview || item.catalogItemId == null;
                        const displayUnitPrice = isPendingReview ? 0 : item.unitPrice;
                        const isFallback = false;
                        return (
                        <div key={item.id} data-testid={`item-${item.id}`} className="px-5 py-4 flex flex-col sm:flex-row items-stretch sm:items-start gap-4">
                          <div className="flex-1 min-w-0 w-full sm:w-auto">
                            <div className="flex flex-wrap items-center gap-2 mb-1">
                              <p className="font-semibold text-sm truncate">{item.name}</p>
                              {item.sku && <span className="text-[10px] border border-black/10 px-2 py-0.5 font-mono text-black/40">{item.sku}</span>}
                              {isPendingReview && <span className="text-[10px] border border-black/15 px-2 py-0.5 font-black uppercase tracking-[0.06em] text-black/50">Custom · review</span>}
                              {isFallback && <span className="text-[10px] border border-amber-200 bg-amber-50 px-2 py-0.5 font-black uppercase tracking-[0.06em] text-amber-600">Est.</span>}
                            </div>
                            <div className="flex items-center gap-2 flex-wrap">
                              {serviceBadge(item.serviceType)}
                              {item.category && <span className="text-xs text-black/35">{item.category}</span>}
                            </div>
                            {isPendingReview && (
                              <div className="mt-3 grid sm:grid-cols-2 gap-2">
                                <label className="text-[9px] font-black uppercase tracking-[0.1em] text-black/40">
                                  Item name
                                  <input aria-label={`Item name for ${item.name}`} data-testid={`input-custom-row-name-${item.id}`} value={item.name} maxLength={300} onChange={e => setItems(prev => prev.map(row => row.id === item.id ? { ...row, name: e.target.value } : row))} className="mt-1 w-full px-2.5 py-2 border border-black/10 bg-white text-xs font-medium normal-case tracking-normal text-black" />
                                </label>
                                <label className="text-[9px] font-black uppercase tracking-[0.1em] text-black/40">
                                  Service
                                  <select aria-label={`Service for ${item.name}`} data-testid={`select-custom-row-service-${item.id}`} value={item.serviceType} onChange={e => setItems(prev => prev.map(row => row.id === item.id ? { ...row, serviceType: e.target.value as ServiceType } : row))} className="mt-1 w-full px-2.5 py-2 border border-black/10 bg-white text-xs font-medium normal-case tracking-normal text-black">
                                    {Array.from(new Set([...services, item.serviceType])).map(service => <option key={service} value={service}>{service.replaceAll("_", " ")}</option>)}
                                  </select>
                                </label>
                                <label className="text-[9px] font-black uppercase tracking-[0.1em] text-black/40">
                                  Dimensions
                                  <input aria-label={`Dimensions for ${item.name}`} data-testid={`input-custom-row-dimensions-${item.id}`} value={item.dimensions || ""} maxLength={300} onChange={e => setItems(prev => prev.map(row => row.id === item.id ? { ...row, dimensions: e.target.value } : row))} className="mt-1 w-full px-2.5 py-2 border border-black/10 bg-white text-xs font-medium normal-case tracking-normal text-black" />
                                </label>
                                <label className="text-[9px] font-black uppercase tracking-[0.1em] text-black/40 sm:col-span-2">
                                  Details
                                  <textarea aria-label={`Details for ${item.name}`} data-testid={`input-custom-row-details-${item.id}`} value={item.details || ""} maxLength={2000} rows={2} onChange={e => setItems(prev => prev.map(row => row.id === item.id ? { ...row, details: e.target.value } : row))} className="mt-1 w-full px-2.5 py-2 border border-black/10 bg-white text-xs font-medium normal-case tracking-normal text-black resize-y" />
                                </label>
                                <label className="text-[9px] font-black uppercase tracking-[0.1em] text-black/40 sm:col-span-2">
                                  Product link
                                  <input aria-label={`Product link for ${item.name}`} data-testid={`input-custom-row-link-${item.id}`} value={item.productLink || ""} maxLength={2000} onChange={e => setItems(prev => prev.map(row => row.id === item.id ? { ...row, productLink: e.target.value } : row))} className="mt-1 w-full px-2.5 py-2 border border-black/10 bg-white text-xs font-medium normal-case tracking-normal text-black" />
                                </label>
                                <div className="sm:col-span-2 flex flex-wrap items-center gap-2">
                                  {item.photo && <><img src={item.photo} alt={`Review photo for ${item.name}`} className="w-12 h-12 object-cover border border-black/15" /><span className="text-[10px] text-black/45">Photo attached to this item</span><button type="button" data-testid={`button-remove-custom-row-photo-${item.id}`} onClick={() => setItems(prev => prev.map(row => row.id === item.id ? { ...row, photo: undefined } : row))} className="text-[10px] underline text-black/50">Remove</button></>}
                                  <label className="text-[9px] font-black uppercase tracking-[0.1em] text-black/45">
                                    {item.photo ? "Replace photo" : "Add photo"}
                                    <input type="file" accept="image/jpeg,image/png" disabled={photoConversionsPending > 0} data-testid={`input-custom-row-photo-${item.id}`} onChange={e => {
                                      const file = e.currentTarget.files?.[0];
                                      e.currentTarget.value = "";
                                      if (file) void prepareCustomPhoto(file, photo => setItems(prev => prev.map(row => row.id === item.id ? { ...row, photo } : row)));
                                    }} className="mt-1 block w-full text-[10px] normal-case tracking-normal" />
                                  </label>
                                  {photoConversionsPending > 0 && <span role="status" className="text-[10px] text-black/40">Preparing photo…</span>}
                                </div>
                              </div>
                            )}
                            {/* Wrapping protection toggle — opt-in $10 per unit */}
                            {!isPendingReview && <div className="mt-2 flex flex-wrap items-center gap-2">
                              <button
                                data-testid={`button-wrap-${item.id}`}
                                onClick={() => setItems(prev => prev.map(i => i.id === item.id ? { ...i, wrap: !i.wrap } : i))}
                                className={`inline-flex items-center gap-1 px-2 py-1 text-[10px] font-black uppercase tracking-[0.06em] border transition-colors ${
                                  item.wrap
                                    ? 'bg-amber-500 text-white border-amber-500'
                                    : 'bg-white text-black/45 border-black/15 hover:text-black hover:border-black/40'
                                }`}
                                title="Add bubble-wrap protection (+$10 per unit)"
                              >
                                <Package className="w-3 h-3" />
                                {item.wrap ? `Wrapped +$${(10 * item.quantity).toFixed(0)}` : 'Wrap +$10'}
                              </button>
                            </div>}
                            {/* Relocate sub-mode toggle — shown for all relocate items */}
                            {item.serviceType === 'relocate' && !isPendingReview && (
                              <div className="mt-2 inline-flex border border-black/15 overflow-hidden text-[10px] font-black uppercase tracking-[0.06em]">
                                <button
                                  data-testid={`button-full-relocate-${item.id}`}
                                  onClick={() => setItems(prev => prev.map(i => {
                                    if (i.id !== item.id) return i;
                                    // Re-derive prices from catalog in case item was added before toggle feature
                                    const grp = catalogGroups.find(g => g.entries.some(e => e.id === i.catalogItemId));
                                    const rel = grp?.entries.find(e => e.serviceType === 'relocate');
                                    const inst = grp?.entries.find(e => e.serviceType === 'install');
                                    const dis = grp?.entries.find(e => e.serviceType === 'dismantle');
                                    const carry = rel ? parseFloat(rel.basePrice) : (i.carryPrice ?? i.unitPrice);
                                    const full = (inst && dis)
                                      ? computeDRPrice(parseFloat(inst.basePrice), parseFloat(dis.basePrice), carry)
                                      : (i.fullPrice ?? computeDRPrice(undefined, undefined, carry));
                                    return { ...i, relocateMode: 'full', carryPrice: carry, fullPrice: full, unitPrice: full };
                                  }))}
                                  className={`px-2.5 py-1.5 transition-colors ${item.relocateMode === 'full' ? 'bg-black text-white' : 'bg-white text-black/40 hover:text-black/70'}`}
                                >
                                  Dismantle &amp; Reinstall
                                </button>
                                <button
                                  data-testid={`button-carry-only-${item.id}`}
                                  onClick={() => setItems(prev => prev.map(i => {
                                    if (i.id !== item.id) return i;
                                    // Re-derive prices from catalog in case item was added before toggle feature
                                    const grp = catalogGroups.find(g => g.entries.some(e => e.id === i.catalogItemId));
                                    const rel = grp?.entries.find(e => e.serviceType === 'relocate');
                                    const inst = grp?.entries.find(e => e.serviceType === 'install');
                                    const dis = grp?.entries.find(e => e.serviceType === 'dismantle');
                                    const carry = rel ? parseFloat(rel.basePrice) : (i.carryPrice ?? i.unitPrice);
                                    const full = (inst && dis)
                                      ? computeDRPrice(parseFloat(inst.basePrice), parseFloat(dis.basePrice), carry)
                                      : (i.fullPrice ?? computeDRPrice(undefined, undefined, carry));
                                    // Fairness cap: customer should never pay more for less work.
                                    // For non-special-handling items, Carry Only is capped at the
                                    // D&R bundle price (e.g. single bed carry $80 → $63 D&R cap).
                                    const carryEffective = effectiveCarryPrice(
                                      inst ? parseFloat(inst.basePrice) : undefined,
                                      dis ? parseFloat(dis.basePrice) : undefined,
                                      carry,
                                      i.sku,
                                    );
                                    return { ...i, relocateMode: 'carry', carryPrice: carry, fullPrice: full, unitPrice: carryEffective };
                                  }))}
                                  className={`px-2.5 py-1.5 border-l border-black/15 transition-colors ${item.relocateMode === 'carry' ? 'bg-black text-white' : 'bg-white text-black/40 hover:text-black/70'}`}
                                >
                                  Carry Only
                                </button>
                                <button
                                  data-testid={`button-reinstall-only-${item.id}`}
                                  onClick={() => setItems(prev => prev.map(i => {
                                    if (i.id !== item.id) return i;
                                    // Already dismantled — charge reinstallation (assembly at
                                    // destination) only, at the full install catalog rate.
                                    // No 40% bundle discount (that's for the D&R pair).
                                    const grp = catalogGroups.find(g => g.entries.some(e => e.id === i.catalogItemId));
                                    const rel = grp?.entries.find(e => e.serviceType === 'relocate');
                                    const inst = grp?.entries.find(e => e.serviceType === 'install');
                                    const dis = grp?.entries.find(e => e.serviceType === 'dismantle');
                                    const carry = rel ? parseFloat(rel.basePrice) : (i.carryPrice ?? i.unitPrice);
                                    const full = (inst && dis)
                                      ? computeDRPrice(parseFloat(inst.basePrice), parseFloat(dis.basePrice), carry)
                                      : (i.fullPrice ?? computeDRPrice(undefined, undefined, carry));
                                    const reinstall = computeReinstallOnlyPrice(
                                      inst ? parseFloat(inst.basePrice) : undefined,
                                      carry,
                                    );
                                    return { ...i, relocateMode: 'reinstall_only', carryPrice: carry, fullPrice: full, unitPrice: reinstall };
                                  }))}
                                  className={`px-2.5 py-1.5 border-l border-black/15 transition-colors ${item.relocateMode === 'reinstall_only' ? 'bg-black text-white' : 'bg-white text-black/40 hover:text-black/70'}`}
                                >
                                  Already Dismantled
                                </button>
                              </div>
                            )}
                            {item.serviceType === 'relocate' && item.relocateMode === 'reinstall_only' && (
                              <p className="mt-1 text-[10px] text-black/40 leading-tight" data-testid={`text-reinstall-note-${item.id}`}>
                                Item is already dismantled — we carry it and reassemble at the destination. No dismantling charge.
                              </p>
                            )}
                            {/* Multi-stop: tag which pickup this item comes from
                                and which drop-off it goes to. Defaults to the
                                first pickup / drop-off. */}
                            {isMultiStop && item.serviceType === 'relocate' && (
                              <div className="mt-2 flex flex-wrap items-center gap-2 text-[10px] font-black uppercase tracking-[0.06em] text-black/40">
                                <span>From</span>
                                <select
                                  data-testid={`select-from-stop-${item.id}`}
                                  value={item.fromStopId || primaryPickupStopId}
                                  onChange={e => setItems(prev => prev.map(i => i.id === item.id ? { ...i, fromStopId: e.target.value } : i))}
                                  className="px-2 py-1 bg-white border border-black/15 outline-none focus:border-black normal-case font-semibold tracking-normal text-black/70">
                                  {stopGroups.pickups.map(s => (
                                    <option key={s.id} value={s.id}>{s.label}</option>
                                  ))}
                                </select>
                                <ArrowRight className="w-3 h-3" />
                                <span>To</span>
                                <select
                                  data-testid={`select-to-stop-${item.id}`}
                                  value={item.toStopId || primaryDropoffStopId}
                                  onChange={e => setItems(prev => prev.map(i => i.id === item.id ? { ...i, toStopId: e.target.value } : i))}
                                  className="px-2 py-1 bg-white border border-black/15 outline-none focus:border-black normal-case font-semibold tracking-normal text-black/70">
                                  {stopGroups.dropoffs.map(s => (
                                    <option key={s.id} value={s.id}>{s.label}</option>
                                  ))}
                                </select>
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-0.5">
                            {isPendingReview ? (
                              <label className="text-[9px] font-black uppercase tracking-[0.1em] text-black/40">
                                Qty
                                <input
                                  type="text"
                                  inputMode="numeric"
                                  pattern="[0-9]*"
                                  maxLength={4}
                                  value={customItemQuantityDrafts[item.id] ?? String(item.quantity)}
                                  onChange={e => {
                                    const value = e.target.value;
                                    setCustomItemQuantityDrafts(prev => ({ ...prev, [item.id]: value }));
                                    if (isValidQuantityDraft(value)) {
                                      const quantity = Number(value);
                                      if (quantity <= 9999) setItems(prev => prev.map(row => row.id === item.id ? { ...row, quantity } : row));
                                    }
                                  }}
                                  aria-label={`Quantity for ${item.name}`}
                                  data-testid={`input-custom-row-quantity-${item.id}`}
                                  className="mt-1 w-16 px-2 py-1.5 border border-black/15 bg-white text-center text-sm font-black text-black"
                                />
                                {customItemQuantityDrafts[item.id] !== undefined && !isValidQuantityDraft(customItemQuantityDrafts[item.id]) && <span className="block mt-1 text-[9px] normal-case tracking-normal text-red-700">Enter 1–9,999</span>}
                              </label>
                            ) : (
                              <>
                                <button onClick={() => setItems(prev => prev.map(i => i.id === item.id && i.quantity > 1 ? { ...i, quantity: i.quantity - 1 } : i))}
                                  data-testid={`button-decrease-${item.id}`}
                                  className="w-7 h-7 border border-black/10 flex items-center justify-center hover:bg-slate-50 transition-colors">
                                  <Minus className="w-3.5 h-3.5" />
                                </button>
                                <span className="w-6 text-center text-sm font-black">{item.quantity}</span>
                                <button onClick={() => setItems(prev => prev.map(i => i.id === item.id && i.quantity < 9999 ? { ...i, quantity: i.quantity + 1 } : i))}
                                  data-testid={`button-increase-${item.id}`}
                                  className="w-7 h-7 border border-black/10 flex items-center justify-center hover:bg-slate-50 transition-colors">
                                  <Plus className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                          </div>
                          <div className="text-right w-20">
                            <p className="font-black text-sm">{isPendingReview ? "Price to be confirmed" : `${isFallback ? "~" : ""}$${(displayUnitPrice * item.quantity).toFixed(2)}`}</p>
                            {isPendingReview ? null : item.serviceType === 'relocate' && item.relocateMode === 'carry' && displayUnitPrice === 0 ? (
                              <p className="text-[10px] text-black/35 leading-tight">Bundled in transport</p>
                            ) : (
                              <p className="text-xs text-black/35">{isFallback ? "~" : ""}${displayUnitPrice.toFixed(2)} ea</p>
                            )}
                          </div>
                          <button onClick={() => setItems(prev => prev.filter(i => i.id !== item.id))}
                            data-testid={`button-remove-${item.id}`}
                            className="text-black/25 hover:text-black p-1.5 hover:bg-slate-100 transition-colors">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        );
                      })}
                    </div>
                    <div className="px-5 py-4 bg-black/[0.025] space-y-1.5 text-sm border-t border-black/8">
                      <div className="flex justify-between text-black/45"><span>Priced catalogue items</span><span>{hasUnpricedItems && !hasKnownPricedItems ? "Pending team pricing review" : `$${subtotal.toFixed(2)}`}</span></div>
                      {items.some(i => i.serviceType === 'relocate' && i.relocateMode !== 'carry' && i.relocateMode !== 'reinstall_only') && (
                        <div className="flex items-center gap-1.5 text-green-700 text-xs font-medium">
                          <Tag className="w-3 h-3 shrink-0" />
                          <span>Relocation: D&amp;R bundle rate applied — 40% off (install + dismantle combined)</span>
                        </div>
                      )}
                      {pricingResult.discountLine && (
                        <div className="flex justify-between text-black/60 font-medium">
                          <span className="flex items-center gap-1"><Tag className="w-3.5 h-3.5" />{pricingResult.discountLine.label}</span>
                          <span>-${pricingResult.discountAmount.toFixed(2)}</span>
                        </div>
                      )}
                      {pricingResult.feeLines.map((fee, i) => (
                        <div key={i} className="flex justify-between text-black/45">
                          <span>{fee.label}</span><span>+${fee.amount.toFixed(2)}</span>
                        </div>
                      ))}
                      {isRelocation && pricingResult.hasVolumeData && (
                        <div className="flex justify-between text-black/40 text-xs pt-1">
                          <span className="flex items-center gap-1"><Truck className="w-3 h-3" /> {pricingResult.totalVolumeM3.toFixed(2)} m³</span>
                          <span>{pricingResult.numTrips} {pricingResult.numTrips === 1 ? "trip" : "trips"}</span>
                        </div>
                      )}
                      <div className="flex justify-between font-black text-base pt-1.5 border-t border-black/10 mt-2">
                        <span className="uppercase tracking-[0.06em] text-sm">{hasUnpricedItems ? "Priced portion only" : "Estimated Total"}</span>
                        <span>{hasUnpricedItems ? hasKnownPricedItems ? `$${grandTotalAfterPromo.toFixed(2)} · pending review` : "Pending team pricing review" : `$${total.toFixed(2)}`}</span>
                      </div>
                      {isRelocation && hasDRMode && (
                        <div data-testid="notice-relocation-dr" className="mt-3 flex items-start gap-2 bg-green-50 border border-green-200 rounded px-3 py-2.5">
                          <span className="text-green-600 text-base leading-none mt-0.5">✓</span>
                          <div className="text-xs text-green-800 leading-relaxed">
                            <span className="font-black">No hourly overtime.</span> Your dismantle &amp; reinstall labor is priced per item, not by the hour. Other charges in our Terms — second-day continuation, waiting time, and floor &amp; access surcharges — may still apply if site conditions differ from your booking.
                          </div>
                        </div>
                      )}
                      {isRelocation && !hasDRMode && items.some(i => i.serviceType === 'relocate') && (
                        <div data-testid="notice-relocation-cap" className="mt-3 flex items-start gap-2 bg-blue-50 border border-blue-200 rounded px-3 py-2.5">
                          <span className="text-blue-500 text-base leading-none mt-0.5">⏱</span>
                          <div className="text-xs text-blue-800 leading-relaxed">
                            <span className="font-black">Scheduled crew time (Carry Only).</span> Your price covers the scheduled crew time shown above. If the job runs longer, additional time is $50 per mover, per hour — billed in 30-min blocks, no cap.
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Timeline + manpower banner — only shown for ≥50-unit projects */}
                {timelinePlan && (
                  <div data-testid="banner-timeline-plan" className="border-l-2 border-black bg-black/[0.025] px-5 py-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Truck className="w-4 h-4 text-black" />
                      <p className="font-black text-xs uppercase tracking-[0.12em] text-black">Project Timeline &amp; Crew</p>
                      <span className="text-[10px] border border-black/15 px-2 py-0.5 font-black uppercase tracking-[0.08em] text-black/50">{timelinePlan.totalUnits} units</span>
                    </div>
                    <div className="grid grid-cols-3 gap-3 mb-3">
                      <div data-testid="stat-crew-size">
                        <p className="text-[9px] font-black uppercase tracking-[0.1em] text-black/40">Recommended crew</p>
                        <p className="font-black text-2xl text-black leading-tight">{timelinePlan.crewSize}-man</p>
                      </div>
                      <div data-testid="stat-days">
                        <p className="text-[9px] font-black uppercase tracking-[0.1em] text-black/40">Working days</p>
                        <p className="font-black text-2xl text-black leading-tight">{timelinePlan.days} {timelinePlan.days === 1 ? "day" : "days"}</p>
                      </div>
                      <div data-testid="stat-man-hours">
                        <p className="text-[9px] font-black uppercase tracking-[0.1em] text-black/40">Total man-hours</p>
                        <p className="font-black text-2xl text-black leading-tight">{timelinePlan.totalManHours}h</p>
                      </div>
                    </div>
                    <div className="text-xs text-black/55 leading-relaxed border-t border-black/8 pt-3 space-y-1">
                      <p>
                        <span className="font-black text-black/70">How we calculated this:</span>{" "}
                        {timelinePlan.totalManHours} man-hours total (item-by-item field averages + 20% overhead for setup, breaks &amp; packaging) ÷ {timelinePlan.crewSize}-man crew × 7 productive hrs/day = {timelinePlan.days} working {timelinePlan.days === 1 ? "day" : "days"}.
                      </p>
                      <p className="text-black/40">
                        Final schedule confirmed after on-site survey — access, lift size and stairs can shift the figure either way. Larger crews available on request to compress the timeline.
                      </p>
                    </div>
                  </div>
                )}

                {items.length === 0 && (
                  <div className="border border-dashed border-black/20 p-10 text-center text-black/35">
                    <Package className="w-10 h-10 mx-auto mb-3 opacity-30" />
                    <p className="font-black text-sm uppercase tracking-[0.06em]">No items yet — search above or paste a list</p>
                  </div>
                )}
              </div>
            )}

            {/* ── STEP 4: Schedule ── */}
            {step === 4 && (
              <div className="space-y-5">
                <div className="relative overflow-hidden -mx-4 px-4 pb-2">

                  <EstDotGrid opacity={0.32} />

                  <div className="relative">

                    <p className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-black/45 mb-3">

                      <EstAccentSquare /> Step 4 of 5

                    </p>

                    <h2 data-estimate-step-heading tabIndex={-1} className="font-heading text-4xl font-black uppercase tracking-[-0.02em] text-black mb-1 focus-visible:outline focus-visible:outline-2">Preferred Timing</h2>

                    <p className="text-sm text-black/45">Optional: share a date and time window that suits you. Your request does not reserve or book a slot.</p>

                  </div>

                </div>

                <SlotPicker
                  date={slotDateStr}
                  time={slotTime}
                  onDateChange={value => { setSlotDateStr(value); setScheduleError(""); }}
                  onTimeChange={value => { setSlotTime(value); setScheduleError(""); }}
                  availability={slotAvailability ?? null}
                />

                {/* Confirmation banner */}
                {slotDateStr && slotTime && !isSlotTaken(slotDateStr, slotTime) && (
                  <div className="border-l-2 border-emerald-500 bg-emerald-50/60 px-4 py-3 flex items-start gap-3">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-black text-xs uppercase tracking-[0.1em] text-emerald-700">Preference noted</p>
                      <p className="text-sm text-black/60 mt-0.5">
                        {new Date(slotDateStr + "T12:00:00").toLocaleDateString("en-SG", { weekday: "long", day: "numeric", month: "short", year: "numeric" })},{" "}
                        {TIME_SLOTS.find(t => t.value === slotTime)?.time}
                      </p>
                      <p className="text-xs text-black/45 mt-1">Our team will check availability and confirm the schedule with you. Nothing is held or booked yet.</p>
                    </div>
                  </div>
                )}

                {scheduleError && (
                  <div role="alert" className="border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-900">
                    <p>{scheduleError}</p>
                    <button type="button" data-testid="button-clear-appointment-preference" onClick={() => { setSlotDateStr(""); setSlotTime(""); setScheduleError(""); goNext(); }} className="mt-2 font-black text-[10px] uppercase tracking-[0.1em] underline underline-offset-2">
                      Clear preference and continue
                    </button>
                  </div>
                )}

                <button type="button" data-testid="button-skip-appointment-preference" onClick={() => { setSlotDateStr(""); setSlotTime(""); setScheduleError(""); goNext(); }} className="inline-flex items-center gap-2 border border-black/20 px-4 py-2.5 text-[10px] font-black uppercase tracking-[0.12em] text-black/55 hover:border-black/50 hover:text-black">
                  Skip appointment preference
                </button>

                <div className="border border-black/8 bg-black/[0.012] px-4 py-3">
                  <p className="text-xs text-black/45">
                    <strong>Scheduling is optional.</strong> TMG staff confirm an available date and time with you after reviewing this request.
                  </p>
                </div>
              </div>
            )}

            {/* ── STEP 5: Review ── */}
            {step === 5 && (
              <div className="space-y-6">
                <div className="relative overflow-hidden -mx-4 px-4 pb-2">

                  <EstDotGrid opacity={0.32} />

                  <div className="relative">

                    <p className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-black/45 mb-3">

                      <EstAccentSquare /> Step 5 of 5

                    </p>

                    <h2 data-estimate-step-heading tabIndex={-1} className="font-heading text-4xl font-black uppercase tracking-[-0.02em] text-black mb-1 focus-visible:outline focus-visible:outline-2">Your Details</h2>

                    <p className="text-sm text-black/45">Review your estimate and enter your contact info.</p>

                  </div>

                </div>

                {/* Customer details form */}
                <div className="bg-[rgba(250,250,247,0.88)] border border-black/12 p-6 space-y-4">
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-black/40">Contact Information</p>

                  {/* If name + email already captured earlier, show a compact confirmation strip with edit toggle */}
                  {email && !showContactEditor ? (
                    <div className="flex items-start justify-between gap-4 px-4 py-3 bg-black/[0.03] border border-black/10">
                      <div className="min-w-0">
                        <p className="text-[10px] font-black uppercase tracking-[0.15em] text-black/40 mb-1">Sending quote to</p>
                        <p className="text-sm font-bold text-black truncate" data-testid="text-contact-summary">
                          {name ? `${name} · ` : ""}{email}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowContactEditor(true)}
                        data-testid="button-edit-contact"
                        className="text-xs font-black uppercase tracking-[0.1em] text-black/60 hover:text-black underline shrink-0"
                      >
                        Edit
                      </button>
                    </div>
                  ) : (
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5 block">Full Name <span className="text-black">*</span></label>
                        <input required value={name} onFocus={() => setShowContactEditor(true)} onChange={e => setName(e.target.value)} data-testid="input-name"
                          placeholder="e.g. James Tan Wei Ming" className="w-full px-4 py-3 bg-white border border-black/10 focus:border-black outline-none transition-all text-sm" />
                      </div>
                      <div>
                        <label className="text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5 block">Email <span className="text-black">*</span></label>
                        <input required type="email" value={email} onFocus={() => setShowContactEditor(true)} onChange={e => setEmail(e.target.value)} data-testid="input-email"
                          placeholder="e.g. james.tan@email.com" className="w-full px-4 py-3 bg-white border border-black/10 focus:border-black outline-none transition-all text-sm" />
                      </div>
                    </div>
                  )}

                  {/* Phone is always asked here (never collected in modal) */}
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5 block">Phone <span className="text-black">*</span></label>
                    <input required value={phone} onChange={e => setPhone(e.target.value)} data-testid="input-phone"
                      placeholder="+65 9000 0000" className="w-full px-4 py-3 bg-white border border-black/10 focus:border-black outline-none transition-all text-sm" />
                    <p className="text-[11px] text-black/45 mt-1.5">We'll text you to confirm — no spam, ever.</p>
                  </div>
                </div>

                {/* Job details — optional lead-quality fields. Compact chip
                    rows; everything here is skippable so the form stays fast. */}
                <div className="bg-[rgba(250,250,247,0.88)] border border-black/12 p-6 space-y-4">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.15em] text-black/40">Job Details <span className="text-black/25 normal-case tracking-normal font-semibold">(optional — helps us respond faster)</span></p>
                    {leadIntentText && (
                      <p className="text-sm font-bold text-black mt-2" data-testid="text-review-intent">
                        Job type{leadIntents.length > 1 ? "s" : ""}: {leadIntentText}
                      </p>
                    )}
                  </div>
                  {([
                    { label: "How soon do you need this done?", options: URGENCY_OPTIONS, value: urgency, set: setUrgency, testPrefix: "urgency" },
                    { label: "Site type", options: SITE_TYPE_OPTIONS, value: siteType, set: setSiteType, testPrefix: "sitetype" },
                  ] as const).map(row => (
                    <div key={row.testPrefix}>
                      <p className="text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5">{row.label}</p>
                      <div className="flex flex-wrap gap-1.5">
                        {row.options.map(opt => {
                          const active = row.value === opt.value;
                          return (
                            <button
                              key={opt.value}
                              type="button"
                              data-testid={`${row.testPrefix}-${opt.value}`}
                              onClick={() => row.set(active ? "" : opt.value)}
                              className={`px-2.5 py-1.5 border text-[11px] font-black uppercase tracking-[0.05em] transition-all ${
                                active
                                  ? "border-black bg-black text-white"
                                  : "border-black/15 bg-white text-black/55 hover:border-black/40 hover:text-black"
                              }`}
                            >
                              {opt.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                  <div className="grid sm:grid-cols-3 gap-3">
                    <div className="sm:col-span-2">
                      <p className="text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5">Seller / product link</p>
                      <input
                        value={productLink}
                        onChange={e => setProductLink(e.target.value.slice(0, 1000))}
                        data-testid="input-product-link"
                        placeholder="IKEA, Taobao or retailer link"
                        className="w-full px-3 py-2.5 bg-white border border-black/10 focus:border-black outline-none text-sm"
                      />
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5">Cartons</p>
                      <input
                        type="number"
                        min="0"
                        max="10000"
                        value={cartonCount}
                        onChange={e => setCartonCount(e.target.value)}
                        data-testid="input-carton-count"
                        placeholder="e.g. 12"
                        className="w-full px-3 py-2.5 bg-white border border-black/10 focus:border-black outline-none text-sm"
                      />
                    </div>
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5">Assembly manuals</p>
                    <div className="flex flex-wrap gap-1.5">
                      {MANUALS_OPTIONS.map(option => (
                        <button
                          key={option.value}
                          type="button"
                          onClick={() => setManualsAvailable(manualsAvailable === option.value ? "" : option.value)}
                          data-testid={`manuals-${option.value}`}
                          className={`px-2.5 py-1.5 border text-[11px] font-black uppercase tracking-[0.05em] ${
                            manualsAvailable === option.value ? "border-black bg-black text-white" : "border-black/15 bg-white text-black/55"
                          }`}
                        >{option.label}</button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5">Work needed</p>
                    <div className="flex flex-wrap gap-1.5">
                      {([
                        ["wall_mount", "Wall mounting", wallMounting, setWallMounting],
                        ["drilling", "Drilling", drillingRequired, setDrillingRequired],
                        ["dismantle", "Dismantle", dismantleRequired, setDismantleRequired],
                        ["reinstall", "Reinstall", reinstallRequired, setReinstallRequired],
                        ["disposal", "Disposal", disposalRequired, setDisposalRequired],
                      ] as const).map(([key, label, active, setter]) => (
                        <button
                          key={key}
                          type="button"
                          onClick={() => setter(!active)}
                          data-testid={`scope-${key}`}
                          className={`px-2.5 py-1.5 border text-[11px] font-black uppercase tracking-[0.05em] ${
                            active ? "border-black bg-black text-white" : "border-black/15 bg-white text-black/55"
                          }`}
                        >{label}</button>
                      ))}
                    </div>
                  </div>
                  {(siteType === "office" || leadIntents.some(intent => intent.includes("office")) || items.some(item => /office|workstation|cubicle/i.test(item.category || item.name))) && (
                    <div className="border-l-2 border-black/15 pl-3 space-y-3" data-testid="office-project-details">
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5">Office seats / workstations</p>
                        <input
                          type="number"
                          min="0"
                          max="10000"
                          value={officeSeatCount}
                          onChange={e => setOfficeSeatCount(e.target.value)}
                          data-testid="input-office-seat-count"
                          placeholder="e.g. 24"
                          className="w-full sm:w-40 px-3 py-2.5 bg-white border border-black/10 focus:border-black outline-none text-sm"
                        />
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {([
                          ["floor_plan", "Floor plan ready", floorPlanAvailable, setFloorPlanAvailable],
                          ["after_hours", "After-hours work", afterHoursRequired, setAfterHoursRequired],
                          ["partitions", "Partitions", partitionsRequired, setPartitionsRequired],
                          ["pedestals", "Pedestals", pedestalsRequired, setPedestalsRequired],
                          ["cables", "Cable management", cableManagementRequired, setCableManagementRequired],
                        ] as const).map(([key, label, active, setter]) => (
                          <button
                            key={key}
                            type="button"
                            onClick={() => setter(!active)}
                            data-testid={`office-${key}`}
                            className={`px-2.5 py-1.5 border text-[11px] font-black uppercase tracking-[0.05em] ${
                              active ? "border-black bg-black text-white" : "border-black/15 bg-white text-black/55"
                            }`}
                          >{label}</button>
                        ))}
                      </div>
                    </div>
                  )}
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5">Anything else we should know?</p>
                    <textarea
                      value={leadNotes}
                      onChange={e => setLeadNotes(e.target.value.slice(0, 600))}
                      data-testid="input-lead-notes"
                      rows={2}
                      placeholder="e.g. brand, dimensions, lift access, dismantle & reinstall needed"
                      className="w-full px-4 py-3 bg-white border border-black/10 focus:border-black outline-none transition-all text-sm resize-none"
                    />
                  </div>
                </div>

                {/* Promo code field */}
                <div className="bg-[rgba(250,250,247,0.88)] border border-black/12 p-6">
                  <p className="text-[10px] font-black uppercase tracking-[0.15em] text-black/40 mb-4">Promo Code</p>
                  {promoBlockedByRelocation ? (
                    <div className="px-4 py-3 bg-amber-50 border border-amber-200" data-testid="promo-relocation-blocked">
                      <p className="text-xs font-semibold text-amber-800">
                        Promo codes can't be combined with relocation pricing.
                      </p>
                      <p className="text-[11px] text-amber-700 mt-1">
                        Your dismantle &amp; reinstall (D&amp;R) bundle already includes a 40% discount, so a promo code can't be added on top. Only one discount applies per job.
                      </p>
                    </div>
                  ) : (promoStatus === "valid" || promoStatus === "restored") && promoCode ? (
                    <div className="flex items-center justify-between gap-3 px-4 py-3 bg-green-50 border border-green-200">
                      <div>
                        <div className="flex items-center gap-2">
                          <Check className="w-4 h-4 text-green-600" />
                          <span className="text-sm font-black text-green-800">{promoCode}</span>
                          <span className="text-xs font-semibold text-green-700 bg-green-100 px-2 py-0.5">-${promoDiscount} OFF</span>
                        </div>
                         <p className="text-xs text-green-600 mt-1" data-testid={promoStatus === "restored" ? "promo-restored" : "promo-message"}>
                           {promoStatus === "restored" ? "Saved with this pending enquiry; final eligibility is confirmed by TMG." : promoMessage}
                         </p>
                      </div>
                      <button
                        onClick={removePromo}
                        data-testid="promo-remove"
                        className="text-xs font-semibold text-green-700 hover:text-red-600 underline transition-colors"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <input
                          value={promoInput}
                          onChange={e => setPromoInput(e.target.value.toUpperCase())}
                          onKeyDown={e => e.key === "Enter" && applyPromo(promoInput)}
                          placeholder={
                            typeof promoBarData?.code === "string" &&
                            promoBarData.code.trim() &&
                            promoBarData.remaining > 0
                              ? `Try ${promoBarData.code.trim()}`
                              : "Enter promo code"
                          }
                          data-testid="input-promo-code"
                          className="flex-1 px-4 py-3 bg-white border border-black/10 focus:border-black outline-none transition-all text-sm font-mono tracking-wider uppercase"
                          disabled={promoStatus === "validating"}
                        />
                        <button
                          onClick={() => applyPromo(promoInput)}
                          disabled={!promoInput.trim() || promoStatus === "validating"}
                          data-testid="promo-apply"
                          className="px-5 py-3 bg-black text-white text-xs font-black uppercase tracking-[0.1em] hover:bg-black/85 disabled:opacity-40 transition-all"
                        >
                          {promoStatus === "validating" ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : "Apply"}
                        </button>
                      </div>
                      {promoStatus === "invalid" && promoMessage && (
                        <p className="text-xs text-red-600 font-semibold">{promoMessage}</p>
                      )}
                      {promoBarData && promoBarData.remaining > 0 && promoStatus === "idle" && (
                        <p className="text-[11px] text-amber-600 font-semibold">
                          🎉 Launch offer: Use <strong>{promoBarData.code}</strong> for ${promoBarData.discount} off while the promotion is active
                        </p>
                      )}
                    </div>
                  )}
                </div>

                {/* Slot summary */}
                {slotDateStr && slotTime && (
                  <div className="border border-black/10 bg-black/[0.02] p-5">
                    <p className="text-[10px] font-black uppercase tracking-[0.18em] text-black/40 mb-3">Preferred Appointment Slot</p>
                    <div className="flex items-center gap-2 font-black text-sm text-black">
                      <CalendarDays className="w-4 h-4 text-black/40" />
                      {new Date(slotDateStr + "T12:00:00").toLocaleDateString("en-SG", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-black/50 mt-1.5">
                      <Clock className="w-4 h-4 text-black/30" />
                      {TIME_SLOTS.find(t => t.value === slotTime)?.label} — {TIME_SLOTS.find(t => t.value === slotTime)?.time}
                    </div>
                  </div>
                )}

                {/* Summary */}
                <div className="bg-[rgba(250,250,247,0.88)] border border-black/12 overflow-hidden">
                  <div className="px-5 py-4 border-b border-black/8 flex items-center gap-2">
                    <Star className="w-3.5 h-3.5 text-black/40" />
                    <p className="text-[10px] font-black uppercase tracking-[0.15em] text-black/50">Estimate Summary</p>
                  </div>
                  <div className="px-5 py-4 space-y-4 divide-y divide-black/6">
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-[0.12em] text-black/35 mb-2">Services</p>
                      <div className="flex flex-wrap gap-2">
                        {services.map(s => (
                          <span key={s} className="capitalize border border-black/15 px-3 py-1 text-xs font-black uppercase tracking-[0.06em] text-black">{s}</span>
                        ))}
                      </div>
                    </div>
                    <div className="pt-4">
                      <p className="text-[10px] font-black uppercase tracking-[0.12em] text-black/35 mb-2">Location</p>
                      {isRelocation ? (
                        <div className="space-y-1 text-sm text-black/70">
                          <p className="flex gap-2"><span className="font-black text-black/40 w-16 shrink-0 uppercase text-[10px] tracking-[0.08em]">Pickup</span><span>{pickupAddress}</span></p>
                          <p className="flex gap-2"><span className="font-black text-black/40 w-16 shrink-0 uppercase text-[10px] tracking-[0.08em]">Dropoff</span><span>{dropoffAddress}</span></p>
                        </div>
                      ) : (
                        <p className="text-sm text-black/70">{serviceAddress}</p>
                      )}
                    </div>
                    <div className="pt-4">
                      <p className="text-[10px] font-black uppercase tracking-[0.12em] text-black/35 mb-3">Items ({items.length})</p>
                      <div className="space-y-2">
                        {items.map(item => (
                          <div key={item.id} className="flex items-center justify-between text-sm">
                            <div className="flex items-center gap-2 flex-wrap">
                              {serviceBadge(item.serviceType)}
                              <span className="text-black/70">{item.name} ×{item.quantity}</span>
                              {(item.isCustom || item.requiresReview || item.catalogItemId == null) && <span className="text-xs text-black/30">(TBD)</span>}
                              {item.serviceType === 'relocate' && item.relocateMode === 'carry' && (
                                <span className="text-[10px] font-black uppercase tracking-[0.06em] text-black/40">Carry Only</span>
                              )}
                              {item.serviceType === 'relocate' && item.relocateMode === 'full' && (
                                <span className="text-[10px] font-black uppercase tracking-[0.06em] text-black/40">Dismantle &amp; Reinstall</span>
                              )}
                              {item.serviceType === 'relocate' && item.relocateMode === 'reinstall_only' && (
                                <span className="text-[10px] font-black uppercase tracking-[0.06em] text-black/40">Already Dismantled — Reinstall Only</span>
                              )}
                              {item.serviceType === 'relocate' && requiresSpecialHandling(item.sku) && (
                                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700" data-testid={`badge-cart-lift-warning-${item.id}`}>
                                  ⚠ Won't fit in lift — survey needed
                                </span>
                              )}
                            </div>
                            <span className="font-black text-sm">{item.isCustom || item.requiresReview || item.catalogItemId == null ? "TBD" : `$${(item.unitPrice * item.quantity).toFixed(2)}`}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    {timelinePlan && (
                      <div className="pt-4" data-testid="review-timeline-plan">
                        <p className="text-[10px] font-black uppercase tracking-[0.12em] text-black/35 mb-2">Project Timeline &amp; Crew</p>
                        <div className="border border-black/10 px-3 py-2.5 space-y-1.5">
                          <div className="flex justify-between text-sm">
                            <span className="text-black/55">Recommended crew</span>
                            <span className="font-black text-black">{timelinePlan.crewSize}-man</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-black/55">Estimated duration</span>
                            <span className="font-black text-black">{timelinePlan.days} {timelinePlan.days === 1 ? "day" : "days"} ({timelinePlan.totalManHours} man-hrs)</span>
                          </div>
                          <p className="text-[10px] text-black/40 pt-1 border-t border-black/8 leading-relaxed">
                            {timelinePlan.totalManHours} man-hrs (incl. 20% overhead) ÷ {timelinePlan.crewSize}-man × 7 productive hrs/day = {timelinePlan.days} {timelinePlan.days === 1 ? "day" : "days"}. Confirmed after on-site survey.
                          </p>
                        </div>
                      </div>
                    )}
                    <div className="pt-4 space-y-2 text-sm">
                      <div className="flex justify-between text-black/45"><span>Priced catalogue items</span><span>{hasUnpricedItems && !hasKnownPricedItems ? "Pending team pricing review" : `$${subtotal.toFixed(2)}`}</span></div>
                      {items.some(i => i.serviceType === 'relocate' && i.relocateMode !== 'carry' && i.relocateMode !== 'reinstall_only') && (
                        <div className="flex items-center gap-1.5 text-green-700 text-xs font-medium">
                          <Tag className="w-3 h-3 shrink-0" />
                          <span>Relocation: D&amp;R bundle rate applied — 40% off (install + dismantle combined)</span>
                        </div>
                      )}
                      {pricingResult.discountLine && (
                        <div className="flex justify-between text-black/60 font-medium">
                          <span className="flex items-center gap-1.5"><Tag className="w-3.5 h-3.5" />{pricingResult.discountLine.label}</span>
                          <span>−${pricingResult.discountAmount.toFixed(2)}</span>
                        </div>
                      )}
                      {pricingResult.feeLines.map((fee, i) => (
                        <div key={i} className="flex justify-between text-black/45">
                          <span>{fee.label}</span><span>+${fee.amount.toFixed(2)}</span>
                        </div>
                      ))}
                      {isRelocation && distanceKm > 0 && (
                        <div className="flex justify-between text-black/50 text-xs mt-1">
                          <span className="flex items-center gap-1"><Navigation className="w-3 h-3" /> Route distance</span>
                          <span>{distanceKm} km</span>
                        </div>
                      )}
                      {isRelocation && pricingResult.hasVolumeData && (
                        <div className="mt-2 border border-black/8 bg-black/[0.015] px-3 py-2 space-y-1">
                          <div className="flex justify-between text-xs text-black/50">
                            <span className="flex items-center gap-1"><Truck className="w-3 h-3" /> Total volume</span>
                            <span>{pricingResult.totalVolumeM3.toFixed(2)} m³</span>
                          </div>
                          <div className="flex justify-between text-xs font-black text-black/70">
                            <span>Toyota Hiace trips needed</span>
                            <span>{pricingResult.numTrips} {pricingResult.numTrips === 1 ? "trip" : "trips"}</span>
                          </div>
                          {pricingResult.numTrips > 1 && (
                            <p className="text-[10px] text-black/40 mt-1">Load exceeds one van — an additional trip is included in the transport fee.</p>
                          )}
                        </div>
                      )}
                      {promoDiscount > 0 && promoCode && (
                        <div className="flex justify-between text-green-700 font-semibold">
                          <span className="flex items-center gap-1.5">
                            <Tag className="w-3.5 h-3.5" /> Promo: {promoCode}
                          </span>
                          <span>−${promoDiscount.toFixed(2)}</span>
                        </div>
                      )}
                      <div className="flex justify-between font-black text-base pt-2 border-t border-black/10">
                        <span className="uppercase tracking-[0.06em] text-sm">{hasUnpricedItems ? "Priced portion only" : "Grand Total"}</span>
                        <span>{hasUnpricedItems ? hasKnownPricedItems ? `$${grandTotalAfterPromo.toFixed(2)} · pending review` : "Pending team pricing review" : `$${grandTotalAfterPromo.toFixed(2)}`}</span>
                      </div>
                      {hasUnpricedItems && <p className="border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900">One or more custom items need pricing review. This is a partial estimate only, not a fixed quote. TMG will confirm the complete price with you.</p>}
                      {isRelocation && hasDRMode && (
                        <div data-testid="notice-relocation-dr-review" className="flex items-start gap-2 bg-green-50 border border-green-200 rounded px-3 py-2 mt-1">
                          <span className="text-green-600 text-sm leading-none mt-0.5">✓</span>
                          <p className="text-xs text-green-800 leading-relaxed">
                            <span className="font-black">No hourly overtime.</span> This job's dismantle &amp; reinstall labor is priced per item, not by the hour. Other charges in our Terms — second-day continuation, waiting time, and floor &amp; access surcharges — may still apply if site conditions differ from your booking.
                          </p>
                        </div>
                      )}
                      {isRelocation && !hasDRMode && items.some(i => i.serviceType === 'relocate') && (
                        <div data-testid="notice-relocation-cap-review" className="flex items-start gap-2 bg-blue-50 border border-blue-200 rounded px-3 py-2 mt-1">
                          <span className="text-blue-500 text-sm leading-none mt-0.5">⏱</span>
                          <p className="text-xs text-blue-800 leading-relaxed">
                            <span className="font-black">Scheduled crew time (Carry Only).</span> Your price covers the scheduled crew time shown above. If the job runs longer, additional time is $50 per mover, per hour — billed in 30-min blocks, no cap.
                          </p>
                        </div>
                      )}
                      {!hasUnpricedItems && (fullUpfront ? (
                        <div className="flex justify-between text-black/45"><span>Full payment after scope review</span><span className="font-black">${effectiveDeposit.toFixed(2)}</span></div>
                      ) : (
                        <>
                          <div className="flex justify-between text-black/45"><span>Deposit after confirmation (50%)</span><span className="font-black">${effectiveDeposit.toFixed(2)}</span></div>
                          <div className="flex justify-between text-black/45"><span>Balance on completion (50%)</span><span>${effectiveFinal.toFixed(2)}</span></div>
                        </>
                      ))}
                      <div className="flex items-start gap-2 text-[11px] text-black/55 leading-relaxed mt-2 border-t border-black/8 pt-3">
                        <Check className="w-3.5 h-3.5 text-black/40 shrink-0 mt-0.5" />
                        <span>Submitting this request <strong>does not charge you or book a slot</strong>. TMG staff will review the request and confirm pricing and any preferred timing with you.</span>
                      </div>
                      {pricingResult.feeLines.some(f => f.label.toLowerCase().includes('stairs') || f.label.toLowerCase().includes('access')) && !accessAnswered && (
                        <div className="flex items-start gap-2 text-[11px] text-amber-700 leading-relaxed mt-1">
                          <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                          <span>Floor / access fee shown is an <strong>estimate</strong> — confirmed on-site once we see the building.</span>
                        </div>
                      )}
                      {pricingResult.requiresAdminReview && (
                        <div className="mt-2 flex items-start gap-2 border border-black/10 bg-black/[0.015] px-3 py-2">
                          <AlertCircle className="w-4 h-4 text-black/40 shrink-0 mt-0.5" />
                          <p className="text-xs text-black/55">This quote includes items requiring admin review — final pricing may be adjusted.</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* What happens next — sets clear expectations so the customer
                    knows submitting is a request, not a charge. */}
                <div className="bg-[rgba(250,250,247,0.88)] border border-black/12 p-6" data-testid="section-what-happens-next">
                  <p className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.18em] text-black/50 mb-4">
                    <EstAccentSquare /> What Happens Next
                  </p>
                  <ol className="space-y-3">
                    {[
                      { n: 1, t: "We review your request", d: "Usually within a few hours during business hours." },
                      { n: 2, t: "Staff confirm the scope, price & appointment", d: "Date and time preferences are not bookings. Pricing is confirmed after review." },
                      ...(hasUnpricedItems
                        ? [{ n: 3, t: "We send the complete quotation after review", d: "No payment is due for this partial estimate. Payment terms apply to the confirmed total; staff separately confirm any appointment." }]
                        : fullUpfront
                        ? [{ n: 3, t: "Full payment after scope confirmation", d: "PayNow or card link. Payment does not confirm an appointment; staff must confirm the date and time." }]
                        : [
                            { n: 3, t: "Deposit after scope confirmation", d: "50% deposit via PayNow or card link. Staff separately confirm the date and time." },
                            { n: 4, t: "Balance is paid after completion", d: "Once the job is done and you're happy with the work." },
                          ]),
                    ].map(s => (
                      <li key={s.n} className="flex items-start gap-3">
                        <span className="w-6 h-6 shrink-0 bg-black text-white text-[11px] font-black flex items-center justify-center mt-0.5">{s.n}</span>
                        <div className="min-w-0">
                          <p className="font-black text-sm text-black uppercase tracking-[0.04em]">{s.t}</p>
                          <p className="text-xs text-black/50 mt-0.5 leading-relaxed">{s.d}</p>
                        </div>
                      </li>
                    ))}
                  </ol>
                </div>

                {retryStorageWarning && <p role="alert" className="mb-4 border border-amber-500 p-3 text-sm">{retryStorageWarning}</p>}
                {submitError && (
                  <div className="border border-black/15 bg-black/[0.03] px-4 py-3 flex items-center gap-2 text-sm font-medium text-black">
                    <AlertCircle className="w-4 h-4 shrink-0" /> {submitError}
                  </div>
                )}

              </div>
            )}

          </motion.div>
        </AnimatePresence>

        {/* Standard terms + T&C checkbox — step 5 only */}
        {step === 5 && (
          <div className="mt-6 p-4 border border-black/10 bg-black/[0.015]">
            {isRelocation && (
              <QuoteScheduleNote
                items={items.map(i => ({ serviceType: i.serviceType, quantity: i.quantity, volumeM3: i.volumeM3, carryOnly: i.relocateMode === 'carry' }))}
                distanceKm={samePropertyMove ? 0 : distanceKm}
                isRelocation={isRelocation}
                className="mb-4"
              />
            )}
            <QuoteTermsBlock isRelocation={isRelocation} className="mb-4 pb-4 border-b border-black/10" />
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={termsAccepted}
                onChange={e => setTermsAccepted(e.target.checked)}
                data-testid="checkbox-terms"
                className="mt-0.5 w-4 h-4 accent-black shrink-0"
              />
              <span className="text-sm text-black/55 leading-relaxed">
                I have read and agree to the{" "}
                <button
                  type="button"
                  onClick={() => setShowTermsModal(true)}
                  className="text-black font-black underline underline-offset-2 hover:text-black/70 transition-colors"
                  data-testid="button-view-terms"
                >
                  Terms & Conditions
                </button>
                {" "}of The Moving Guy Pte Ltd, including the deposit, cancellation, and rescheduling policies.
              </span>
            </label>
          </div>
        )}

        {/* Live price bar — visible from step 3 onwards when items exist */}
        {items.length > 0 && step >= 3 && step < 5 && (
          <div className="mt-6 border border-black/10 bg-black/[0.02] px-4 py-3 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Package className="w-4 h-4 text-black/40 shrink-0" />
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.1em] text-black/40">{hasUnpricedItems ? "Priced portion · pending review" : "Estimated total"}</p>
                <p className="font-black text-lg leading-none tabular-nums">
                  {hasUnpricedItems ? hasKnownPricedItems ? `$${grandTotalAfterPromo.toFixed(2)}+` : "Pending review" : `$${total.toFixed(2)}`}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 text-right">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.1em] text-black/40">{items.length} item{items.length !== 1 ? "s" : ""}</p>
                <p className="text-xs text-black/40">{hasUnpricedItems ? "Custom item pricing pending" : `${fullUpfront ? "Full payment" : "50% deposit"} $${effectiveDeposit.toFixed(2)}`}</p>
              </div>
            </div>
          </div>
        )}

        {/* Navigation — pinned to the bottom of the screen so the Back / Next
            (or Submit) buttons stay visible the moment a customer picks an
            option, with no need to scroll to the end of a long step. */}
        <div id="estimate-step-actions" className="sticky bottom-0 z-30 -mx-4 mt-6 border-t border-black/15 bg-[#f1efe7]/95 px-4 py-3 backdrop-blur" style={{ paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" }}>
          <div className="flex items-center justify-between gap-4">
            {step > 1 ? (
              <button onClick={back} data-testid="button-back"
                className="flex items-center gap-2 px-5 py-3 border border-black/30 text-black font-black text-[11px] uppercase tracking-[0.22em] hover:bg-black hover:text-white hover:border-black transition-colors">
                <ChevronLeft className="w-4 h-4" /> Back
              </button>
            ) : <div />}

            {step < 5 ? (
              <button onClick={next} disabled={!canNext()} data-testid="button-next"
                className="bg-black text-white flex items-center gap-2 px-7 py-3 font-black text-[11px] uppercase tracking-[0.22em] hover:bg-neutral-800 disabled:opacity-35 disabled:cursor-not-allowed transition-colors">
                {step === 1 ? "Next" : step === 2 ? "Add Items" : step === 3 ? `Continue · ${items.length}` : "Review"}
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={isSubmitting || !name.trim() || !email.trim() || !phone.trim() || !termsAccepted || photoDetecting || distanceLoading || promoStatus === "validating" || photoConversionsPending > 0}
                data-testid="button-submit"
                className="text-black flex items-center gap-2 px-7 py-3 font-black text-[11px] uppercase tracking-[0.22em] hover:opacity-90 disabled:opacity-35 disabled:cursor-not-allowed transition-opacity"
                style={{ background: EST_ACCENT }}
              >
                {isSubmitting ? <><Loader2 className="w-4 h-4 animate-spin" /> Submitting…</> : <>Request My Quote <ArrowRight className="w-4 h-4" /></>}
              </button>
            )}
          </div>
        </div>

        {/* Save-progress secondary link — step 3 only, optional + low-emphasis */}
        {step === 3 && items.length > 0 && (
          <div className="text-center mt-3">
            <button
              type="button"
              data-testid="button-save-progress"
              onClick={() => { trackEvent("cta_click", "/estimate", "save_progress_step3"); setCaptureShown(true); setShowCaptureModal(true); }}
              className="inline-flex items-center gap-1.5 text-xs text-black/40 hover:text-black/70 transition-colors underline underline-offset-2"
            >
              Email me my progress so I can finish later (optional)
            </button>
          </div>
        )}

        {/* WhatsApp escape hatch — step 5 only · prefilled with everything we
            already know about the customer's request so they don't have to
            re-type it on WhatsApp. The same message is logged server-side via
            POST /api/whatsapp/handoff so the admin inbox shows the full quote
            context the moment the customer's first message lands. */}
        {step === 5 && (() => {
          const slotLabel = slotDateStr && slotTime
            ? `${new Date(slotDateStr + "T12:00:00").toLocaleDateString("en-SG", { weekday: "short", day: "numeric", month: "short" })} · ${TIME_SLOTS.find(t => t.value === slotTime)?.label || slotTime}`
            : "";
          const serviceLabelMap: Record<string, string> = { install: "Installation", dismantle: "Dismantling", relocate: "Relocation", dispose: "Disposal", dismantle_dispose: "Dismantle + Dispose" };
          const handoffPayload: HandoffPayload = {
            source: "estimate_step5",
            services,
            serviceLabels: services.map(s => serviceLabelMap[s] || s),
            pickupAddress: pickupAddress || "",
            dropoffAddress: dropoffAddress || "",
            serviceAddress: serviceAddress || "",
            isRelocation,
            liftAvailable: floors[0]?.hasLift === true ? "yes" : floors[0]?.hasLift === false ? "no" : "",
            floorLevel: floors[0]?.level || "",
            stairsAnswer: stairsAnswer || "",
            items: items.map(i => ({ name: i.name, quantity: i.quantity,
              requiresReview: !!i.isCustom || !!i.requiresReview,
              dimensions: i.dimensions || "", details: i.details || "", productLink: i.productLink || "" })),
            requiresReview: hasUnpricedItems,
            slotDate: slotDateStr || "",
            slotLabel,
            estimatedTotal: total > 0 ? grandTotalAfterPromo : undefined,
            customerName: name?.trim() || "",
            customerPhone: phone?.trim() || "",
            customerEmail: email?.trim() || "",
            promoCode: (promoStatus === "valid" || promoStatus === "restored") && promoCode ? promoCode : "",
            pageContext: "estimate",
            leadIntent: leadIntentLabel(leadIntent) || "",
            leadIntents: leadIntents.map(leadIntentLabel).filter(Boolean),
            urgency: urgencyLabel(urgency) || "",
            itemCountRange: itemCountLabel(itemCountRange) || "",
            siteType: siteTypeLabel(siteType) || "",
            roomType: ROOM_TYPE_OPTIONS.find(option => option.value === roomType)?.label || roomType,
            productLink: productLink.trim(),
            cartonCount: cartonCount ? Number(cartonCount) : undefined,
            manualsAvailable: manualsAvailable,
            originatingServicePage: estimateLandingContext(window.location.search).originatingServicePage || "",
            requestedScope: [
              wallMounting && "wall mounting",
              drillingRequired && "drilling",
              dismantleRequired && "dismantle",
              reinstallRequired && "reinstall",
              disposalRequired && "disposal",
            ].filter((value): value is string => Boolean(value)),
            officeDetails: [
              officeSeatCount && `${officeSeatCount} seats/workstations`,
              floorPlanAvailable && "floor plan available",
              afterHoursRequired && "after-hours work",
              partitionsRequired && "partitions",
              pedestalsRequired && "pedestals",
              cableManagementRequired && "cable management",
            ].filter((value): value is string => Boolean(value)),
            detectedCategory: leadRouting.categoryLabel,
            jobPriority: leadRouting.priority,
            recommendedSalesPath: leadRouting.recommendedSalesPath.replace(/_/g, " "),
          };
          const waHref = buildHandoffWaUrl(handoffPayload);
          const handleHandoffClick = () => {
            trackEvent("cta_click", "/estimate", "whatsapp_escape_step5");
            // Funnel-analysis event (non-conversion) — WhatsApp lead prepared.
            trackFunnelEvent("estimate_lead_prepared", {
              channel: "whatsapp",
              lead_intent: leadIntentText || undefined,
              urgency: urgency || undefined,
              item_count_range: itemCountRange || undefined,
              site_type: siteType || undefined,
              services: services.join(","),
              estimated_total: total > 0 ? Math.round(grandTotalAfterPromo * 100) / 100 : undefined,
            });
            // Fire-and-forget — don't block the wa.me open on this. The browser
            // navigates away to WhatsApp regardless of the fetch outcome.
            try {
              const body = JSON.stringify(handoffPayload);
              if (typeof navigator !== "undefined" && typeof navigator.sendBeacon === "function") {
                navigator.sendBeacon("/api/whatsapp/handoff", new Blob([body], { type: "application/json" }));
              } else {
                fetch("/api/whatsapp/handoff", { method: "POST", headers: { "Content-Type": "application/json" }, body, keepalive: true }).catch(() => {});
              }
            } catch { /* never block the WhatsApp open */ }
          };
          return (
            <div className="text-center mt-3">
              <a
                href={waHref}
                target="_blank"
                rel="noopener noreferrer"
                data-testid="link-whatsapp-escape"
                onClick={handleHandoffClick}
                className="inline-flex items-center gap-1.5 text-xs text-black/35 hover:text-black/60 transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                Send current estimate details on WhatsApp
              </a>
            </div>
          );
        })()}
      </div>
    </div>

    {/* Terms & Conditions Modal */}
    {showTermsModal && (
      <div className="fixed inset-0 z-50 tmg-scrim flex items-center justify-center p-4" onClick={() => setShowTermsModal(false)}>
        <div
          className="bg-[#fafaf7] border border-black/20 max-w-2xl w-full max-h-[85vh] flex flex-col"
          onClick={e => e.stopPropagation()}
        >
          {/* Modal header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-black/10 shrink-0">
            <div>
              <h2 className="font-black text-base uppercase tracking-[0.04em]">Terms & Conditions</h2>
              <p className="text-[10px] text-black/40 mt-0.5 font-black uppercase tracking-[0.12em]">The Moving Guy Pte Ltd · UEN 202424156H</p>
            </div>
            <button onClick={() => setShowTermsModal(false)} className="w-8 h-8 flex items-center justify-center hover:bg-slate-100 transition-colors text-black/40 hover:text-black" data-testid="button-close-terms">✕</button>
          </div>

          {/* Scrollable body */}
          <div className="overflow-y-auto px-6 py-5 space-y-5 text-sm text-black/65 leading-relaxed">

            <section>
              <h3 className="font-black text-sm uppercase tracking-[0.04em] text-black mb-1.5">1. Incomplete or Missing Parts</h3>
              <p>If our team arrives on-site and discovers that the furniture to be installed, dismantled, or relocated is incomplete, missing parts, damaged beyond assembly, or otherwise in a condition that prevents safe or proper installation, The Moving Guy Pte Ltd reserves the right to halt work without completion. In such cases:</p>
              <ul className="list-disc pl-5 mt-2 space-y-1">
                <li>The deposit paid will be <strong>non-refundable</strong>.</li>
                <li>The customer is entitled to <strong>one (1) complimentary reschedule</strong> to complete the work once the full set of parts is obtained and ready for installation.</li>
                <li>Subsequent visits after the free reschedule will be treated as a new booking and charged accordingly.</li>
              </ul>
            </section>

            <section>
              <h3 className="font-black text-sm uppercase tracking-[0.04em] text-black mb-1.5">2. Deposit & Payment Policy</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>For jobs <strong>under S$150</strong>, <strong>full payment</strong> is required up front. Staff must separately confirm the appointment date and time; payment alone does not confirm a booking.</li>
                <li>For jobs <strong>S$150 and above</strong>, a <strong>50% non-refundable deposit</strong> is required, with the remaining <strong>50% balance due upon completion</strong>. Staff must separately confirm the appointment date and time. Once our admin team has verified the completed work, a payment link will be sent to your email for the balance payment.</li>
                <li>Accepted payment methods: <strong>Stripe (credit/debit card), PayNow, bank transfer, or cash</strong>.</li>
                <li>Failure to pay the balance within the stipulated timeframe may result in legal action and recovery of costs.</li>
              </ul>
            </section>

            <section>
              <h3 className="font-black text-sm uppercase tracking-[0.04em] text-black mb-1.5">3. Cancellation Policy</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>Cancellations made <strong>more than 48 hours</strong> before the scheduled appointment: deposit refunded less a <strong>$30 administrative fee</strong>.</li>
                <li>Cancellations made <strong>within 48 hours</strong> of the scheduled appointment: <strong>deposit is forfeited</strong> in full.</li>
                <li>No-shows on the day of appointment are treated as a same-day cancellation — deposit is forfeited.</li>
              </ul>
            </section>

            <section>
              <h3 className="font-black text-sm uppercase tracking-[0.04em] text-black mb-1.5">4. Rescheduling Policy</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>Each customer is entitled to <strong>one (1) free reschedule</strong>, with a minimum of <strong>24 hours' notice</strong> before the appointment.</li>
                <li>Rescheduling requests made with less than 24 hours' notice will be treated as a cancellation.</li>
                <li>Subsequent rescheduling requests (beyond the first free one) will incur a <strong>$30 administrative fee</strong>.</li>
              </ul>
            </section>

            <section>
              <h3 className="font-black text-sm uppercase tracking-[0.04em] text-black mb-1.5">5. Scope of Work & Additional Charges</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>The estimate provided is based on the items and services described at the time of booking. Any additional items or services discovered on-site will be quoted separately and must be agreed upon before work commences.</li>
                <li>Additional charges may apply for <strong>stairs access</strong> (if no lift is available), <strong>difficult access</strong>, or <strong>disposal of old furniture</strong> (if requested).</li>
                <li><strong>Relocation jobs</strong> include the <strong>scheduled crew time shown on your quote</strong> (movers × hours on site). Time beyond the schedule is charged at $50 per mover, per hour — billed in 30-minute blocks, no cap — and our team will advise you on-site.</li>
                <li>Waiting time exceeding <strong>30 minutes</strong> beyond the scheduled window due to customer delays may incur a waiting fee of $20 per 30 minutes.</li>
              </ul>
            </section>

            <section>
              <h3 className="font-black text-sm uppercase tracking-[0.04em] text-black mb-1.5">6. Damage & Liability</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>Our team will exercise reasonable care during all work. However, The Moving Guy Pte Ltd is <strong>not liable</strong> for: pre-existing damage or wear; damage resulting from furniture with manufacturing defects or poor structural integrity; superficial marks to walls from standard drilling or fixing.</li>
                <li>Any damage claims must be reported <strong>immediately on the day of service</strong>, before our team departs.</li>
                <li>Maximum liability is capped at the total value of services paid for that job.</li>
              </ul>
            </section>

            <section>
              <h3 className="font-black text-sm uppercase tracking-[0.04em] text-black mb-1.5">7. Site Access & Customer Responsibilities</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>The customer is responsible for securing all necessary <strong>permits, lift access bookings, and HDB/condo approvals</strong> prior to the appointment.</li>
                <li>The customer must ensure the site is safe, accessible, and free of obstructions before our team arrives.</li>
                <li>If access is denied by building management, the deposit will be forfeited and a new booking will be required.</li>
              </ul>
            </section>

            <section>
              <h3 className="font-black text-sm uppercase tracking-[0.04em] text-black mb-1.5">8. Warranty</h3>
              <p>TMG Install provides a <strong>7-day workmanship warranty</strong> on all installations. This covers defects directly resulting from our installation work. It does not cover damage from misuse, unauthorised modification, or manufacturer defects.</p>
            </section>

            <section>
              <h3 className="font-black text-sm uppercase tracking-[0.04em] text-black mb-1.5">9. Privacy</h3>
              <p>Your personal information (name, phone, email, address) is collected solely for the purpose of delivering our services and communicating with you regarding your booking. We do not sell or share your data with third parties, in accordance with Singapore's <strong>Personal Data Protection Act (PDPA)</strong>.</p>
            </section>

            <section>
              <h3 className="font-black text-sm uppercase tracking-[0.04em] text-black mb-1.5">10. Governing Law</h3>
              <p>These Terms & Conditions are governed by the laws of the <strong>Republic of Singapore</strong>. Any disputes shall be subject to the exclusive jurisdiction of the Singapore courts. The Moving Guy Pte Ltd (UEN: 202424156H) reserves the right to update these terms at any time.</p>
            </section>

            <p className="text-[10px] font-black uppercase tracking-[0.1em] text-black/30 border-t border-black/8 pt-4">Last updated: March 2026 · The Moving Guy Pte Ltd · UEN 202424156H · tmginstall.com</p>
          </div>

          {/* Footer */}
          <div className="px-6 py-4 border-t border-black/10 shrink-0 flex justify-end gap-3">
            <button onClick={() => setShowTermsModal(false)} className="px-5 py-2.5 border border-black/15 font-black text-xs uppercase tracking-[0.1em] hover:bg-slate-50 transition-colors" data-testid="button-decline-terms">Close</button>
            <button onClick={() => { setTermsAccepted(true); setShowTermsModal(false); }} className="px-5 py-2.5 bg-black text-white font-black text-xs uppercase tracking-[0.1em] hover:bg-neutral-800 transition-colors" data-testid="button-accept-terms">I Agree</button>
          </div>
        </div>
      </div>
    )}

    {/* ── Partial Lead Capture Modal ── */}
    {showCaptureModal && (
      <div className="fixed inset-0 z-50 tmg-scrim flex items-end sm:items-center justify-center p-0 sm:p-4"
        onClick={() => saveCaptureAndNext(true)}>
        <motion.div
          initial={{ y: 60, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ type: "spring", damping: 26, stiffness: 300 }}
          className="bg-white w-full sm:max-w-md sm:border sm:border-black/15"
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-start justify-between px-6 pt-6 pb-0">
            <div>
              <p className="font-heading text-2xl font-black uppercase tracking-[-0.02em] leading-tight">Save your progress</p>
              <p className="text-sm text-black/50 mt-1 leading-relaxed">Enter your email and we'll keep your items saved — pick up right where you left off anytime.</p>
            </div>
            <button
              onClick={() => saveCaptureAndNext(true)}
              data-testid="button-capture-close"
              className="ml-4 p-1.5 text-black/30 hover:text-black transition-colors shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Trust strip */}
          <div className="mx-6 mt-4 px-4 py-3 bg-black/[0.03] border border-black/8 flex items-center gap-3">
            <Star className="w-4 h-4 text-amber-500 fill-amber-500 shrink-0" />
            <p className="text-[11px] text-black/55 leading-snug">
              <strong className="text-black">Itemised quote based on scope and access</strong> · Photo-based quote · Clear pricing · Island-wide
            </p>
          </div>

          {/* Form */}
          <div className="px-6 pb-6 pt-4 space-y-3">
            <div>
              <label className="block text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5">Email Address *</label>
              <input
                type="email"
                autoFocus
                value={captureEmail}
                onChange={e => setCaptureEmail(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter") saveCaptureAndNext(false); }}
                placeholder="you@email.com"
                data-testid="input-capture-email"
                className="w-full px-4 py-3 border border-black/15 text-sm outline-none focus:border-black transition-colors placeholder:text-black/25"
              />
            </div>
            <div>
              <label className="block text-[10px] font-black uppercase tracking-[0.12em] text-black/40 mb-1.5">Your Name <span className="font-normal normal-case tracking-normal text-black/30">(optional)</span></label>
              <input
                type="text"
                value={captureName}
                onChange={e => setCaptureName(e.target.value)}
                placeholder="e.g. Sarah"
                data-testid="input-capture-name"
                className="w-full px-4 py-3 border border-black/15 text-sm outline-none focus:border-black transition-colors placeholder:text-black/25"
              />
            </div>

            <button
              onClick={() => saveCaptureAndNext(false)}
              disabled={captureSaving || !captureEmail.trim()}
              data-testid="button-capture-save"
              className="w-full bg-black text-white py-3.5 font-black text-xs uppercase tracking-[0.1em] hover:bg-neutral-800 disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
            >
              {captureSaving ? <><Loader2 className="w-4 h-4 animate-spin" /> Saving…</> : <>Save & Continue <ArrowRight className="w-4 h-4" /></>}
            </button>

            <button
              onClick={() => saveCaptureAndNext(true)}
              data-testid="button-capture-skip"
              className="w-full text-center text-xs text-black/35 hover:text-black/60 transition-colors py-1"
            >
              Skip — continue without saving
            </button>

            <p className="text-[10px] text-black/30 text-center leading-relaxed">
              We'll only use your email to send you the resume link. No spam, ever.
            </p>
          </div>
        </motion.div>
      </div>
    )}
    </>
  );
}
