import {financialBasis} from "@shared/financialBasis";
const money=(n:number)=>`S$${n.toFixed(2)}`;
/** Customer-safe amounts only: never include internal payment notes or actors. */
export function FinancialBasisNotice({quote}:{quote:any}) {
  if(!Array.isArray(quote?.payments))return <p role="status">Payment data unavailable. Reload to verify funds; do not assume zero received.</p>;
  const f=financialBasis(quote);
  if(!f.reconciliationRequired&&!f.settledRefunds&&!f.noncashCredits)return null;
  return <section data-testid="financial-basis" className="rounded-lg border border-amber-300 bg-amber-50 p-4 text-sm text-zinc-900 space-y-2">
    <h3 className="font-semibold">Payment history — this job</h3>
    <p>Gross verified receipts: {money(f.grossReceived)} · Settled refunds: {money(f.settledRefunds)}</p>
    <p>Net received: <strong>{money(f.netReceived)}</strong></p>
    {f.priceReductions>0&&<p>Saved discounts/goodwill: {money(f.priceReductions)} — already included in the price, not cash received.</p>}
    {f.noncashCredits>0&&<p>Noncash credit: {money(f.noncashCredits)} — not money received; application requires its approved basis.</p>}
    {f.acceptedVersion&&<p>Accepted agreement v{f.acceptedVersion}: {money(Number(f.acceptedTotal))}.
      {f.acceptedVersion!==quote.version?" Proposed amendment: ":" Current quotation: "}{money(f.proposedTotal)}.</p>}
    {f.acceptedBalance!==null&&<p>Accepted-scope balance after its verified receipts: {money(f.acceptedBalance)}.
      This does not authorise collection of an unaccepted amendment.</p>}
    {f.reconciliationRequired&&<p role="status">Payment reconciliation required. Earlier receipts remain recorded, but are not silently allocated to this revision.
      Staff must review the original receipt and accepted agreement in payment activity. Do not pay again while this is unresolved.</p>}
  </section>;
}
