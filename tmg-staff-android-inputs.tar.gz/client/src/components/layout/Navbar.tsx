import { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { usePromoBar } from "@/hooks/use-promo-bar";
import { LogOut, MessageCircle, Menu, X, LayoutDashboard, Calendar, FileDown, Briefcase, Users, ClipboardList, ChevronDown, Settings } from "lucide-react";
import { AdminTopbarTools } from "@/components/admin/AdminTopbarTools";

const WHATSAPP = "https://wa.me/6580880757?text=hi";

const AVATAR_COLORS = ["#6366f1","#ec4899","#f59e0b","#10b981","#3b82f6","#ef4444","#8b5cf6","#14b8a6","#06b6d4","#84cc16"];
function avatarColor(id: number) { return AVATAR_COLORS[id % AVATAR_COLORS.length]; }

export function Navbar() {
  const { user, logout } = useAuth();
  const [location] = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);
  const { visible: promoVisible, promo, dismiss: dismissPromo } = usePromoBar();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    setProfileOpen(false);
  }, [location]);

  useEffect(() => {
    function handleOutside(e: MouseEvent) {
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setProfileOpen(false);
      }
    }
    if (profileOpen) document.addEventListener("mousedown", handleOutside);
    return () => document.removeEventListener("mousedown", handleOutside);
  }, [profileOpen]);

  if (location === "/admin/login" || location === "/staff/login") return null;
  if (location === "/") return null;

  const isAdminArea = location.startsWith("/admin");
  const isStaffArea = location.startsWith("/staff");
  const isCustomerArea = !isAdminArea && !isStaffArea;

  // Customer nav
  if (isCustomerArea) {
    const ACCENT = "#2af56a";
    const tickerSegments = promo && promoVisible
      ? [
          { kind: "tag" as const, text: "Launch Offer" },
          { kind: "text" as const, text: "Use code" },
          { kind: "code" as const, text: promo.code },
          { kind: "text" as const, text: `$${promo.discount} off` },
          { kind: "text" as const, text: "Limited-time promotion" },
          { kind: "text" as const, text: "Get your discount now →" },
        ]
      : [];

    const renderTicker = (keyPrefix: string) => (
      <div className="flex items-center shrink-0">
        {tickerSegments.map((seg, i) => (
          <span key={`${keyPrefix}-${i}`} className="flex items-center">
            {seg.kind === "tag" ? (
              <span
                className="inline-block text-[10px] font-black uppercase tracking-[0.22em] px-2 py-[3px] mx-3 text-black"
                style={{ background: ACCENT }}
              >
                {seg.text}
              </span>
            ) : seg.kind === "code" ? (
              <span
                className="inline-block text-[10px] font-black uppercase tracking-[0.22em] px-2 py-[3px] mx-3 border"
                style={{ borderColor: ACCENT, color: ACCENT }}
              >
                {seg.text}
              </span>
            ) : (
              <span className="text-white text-[11px] font-bold uppercase tracking-[0.18em] mx-3">{seg.text}</span>
            )}
            <span className="text-white/40 mx-1" aria-hidden="true">·</span>
          </span>
        ))}
      </div>
    );

    return (
      <div className="fixed top-0 left-0 right-0 z-50">
        {/* Promo announcement bar — INK + ACCENT (matches homepage editorial system) */}
        {promoVisible && promo && (
          <div className="relative overflow-hidden h-7 sm:h-10 flex items-center bg-black border-b border-white/10" data-testid="promo-bar">
            <style>{`
              @keyframes promo-scroll {
                0% { transform: translateX(0); }
                100% { transform: translateX(-50%); }
              }
              .promo-ticker {
                display: flex;
                white-space: nowrap;
                animation: promo-scroll 38s linear infinite;
              }
              .promo-ticker:hover {
                animation-play-state: paused;
              }
            `}</style>
            <div className="promo-ticker select-none pr-12">
              {renderTicker("a")}
              {renderTicker("b")}
            </div>
            <button
              onClick={dismissPromo}
              data-testid="promo-bar-dismiss"
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-white/70 hover:text-black transition-colors"
              style={{}}
              onMouseEnter={(e) => { e.currentTarget.style.background = ACCENT; }}
              onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; }}
              aria-label="Dismiss offer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
        {/* Main nav — matches homepage editorial / paper aesthetic */}
        <nav className={`transition-all duration-300 ${
          scrolled
            ? "bg-[#f1efe7]/95 backdrop-blur-md border-b border-black/15"
            : "bg-[#f1efe7] border-b border-black/12"
        }`}>
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
            <Link href="/">
              <span className="brand-title text-black cursor-pointer tracking-[0.04em]">TMG INSTALL</span>
            </Link>
            <div className="flex items-center gap-2">
              <a href={WHATSAPP} target="_blank" rel="noopener noreferrer" data-testid="nav-whatsapp"
                className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 text-[11px] font-black uppercase tracking-[0.15em] text-black/65 border border-black/20 hover:border-black hover:text-black transition-all">
                <MessageCircle className="w-3.5 h-3.5" />
                WhatsApp
              </a>
              <Link href="/estimate" data-testid="nav-get-estimate"
                className="px-5 py-2 bg-black text-white text-[11px] font-black uppercase tracking-[0.15em] hover:bg-neutral-800 transition-colors">
                Get Estimate
              </Link>
            </div>
          </div>
        </nav>
      </div>
    );
  }

  const adminLinks = [
    { href: "/admin",               label: "Dashboard",  icon: LayoutDashboard },
    { href: "/admin/schedule",      label: "Schedule",   icon: Calendar },
    { href: "/admin/conversations", label: "WhatsApp",   icon: MessageCircle },
    { href: "/admin/staff",         label: "Staff",      icon: Users },
    { href: "/admin/settings",      label: "Settings",   icon: Settings },
  ];

  const staffLinks = [
    { href: "/staff",    label: "My Jobs", icon: Briefcase },
    { href: "/staff/hr", label: "My HR",   icon: ClipboardList },
  ];

  const navLinks = isStaffArea ? staffLinks : adminLinks;

  const initials = user?.name
    ? user.name.split(" ").map((w: string) => w[0]).slice(0, 2).join("").toUpperCase()
    : "?";
  const bgColor = user?.id ? avatarColor(user.id) : "#6366f1";

  // Active check for admin (prefix match for nested pages)
  function isActive(href: string) {
    if (href === "/admin") return location === "/admin";
    if (href === "/admin/staff") return location.startsWith("/admin/staff");
    return location.startsWith(href);
  }

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-200 ${
      isAdminArea
        ? "bg-[#F5F4F0] border-b border-black/15"
        : "bg-white border-b border-gray-200"
    }`}>
      <div className={`${isAdminArea ? "px-4 sm:px-6" : "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"} h-14 flex items-center justify-between`}>

        {/* Brand */}
        <Link href={isStaffArea ? "/staff" : "/admin"}>
          <div className="flex items-center gap-2.5 cursor-pointer">
            <span className={`brand-title ${isAdminArea ? "text-[#0A0A0A] tracking-[0.04em]" : "text-gray-900"}`}>
              TMG INSTALL
            </span>
            {isAdminArea && (
              <span className="hidden sm:inline text-[9px] font-black tracking-[0.24em] uppercase px-1.5 h-[18px] inline-flex items-center bg-[#0A0A0A] text-white">
                OPS
              </span>
            )}
          </div>
        </Link>

        <div className="flex items-center gap-1 sm:gap-2">
          {user && (
            <>
              {/* Desktop nav links — hidden at lg for admin (sidebar takes over) */}
              <div className={`hidden items-center ${
                isAdminArea
                  ? "sm:flex lg:hidden gap-0"
                  : "sm:flex gap-4 text-sm font-medium text-muted-foreground"
              }`}>
                {navLinks.map(({ href, label, icon: Icon }) => (
                  isAdminArea ? (
                    <Link key={href} href={href} data-testid={`nav-${label.toLowerCase().replace(/\s/g, "-")}`}>
                      <div className={`flex items-center gap-1.5 h-9 px-3 text-[10px] font-black uppercase tracking-[0.16em] transition-colors cursor-pointer ${
                        isActive(href)
                          ? "bg-[#0A0A0A] text-white"
                          : "text-[#0A0A0A]/65 hover:text-[#0A0A0A] hover:bg-black/5"
                      }`}>
                        <Icon className="w-3.5 h-3.5" strokeWidth={1.75} />
                        {label}
                      </div>
                    </Link>
                  ) : (
                    <Link key={href} href={href} data-testid={`nav-${label.toLowerCase().replace(/\s/g, "-")}`}>
                      <span className={`hover:text-primary transition-colors ${location === href ? "text-primary font-semibold" : ""}`}>
                        {label}
                      </span>
                    </Link>
                  )
                ))}
              </div>

              {!isAdminArea && <div className="hidden sm:block h-7 w-px bg-border" />}

              {/* Admin: global search + notification bell */}
              {isAdminArea && (
                <div className="flex items-center gap-1.5 mr-1">
                  <AdminTopbarTools />
                </div>
              )}

              {/* User avatar + dropdown */}
              <div className="relative ml-1" ref={profileRef}>
                <button
                  onClick={() => setProfileOpen(v => !v)}
                  data-testid="button-user-avatar"
                  className={`flex items-center gap-2 px-2 h-9 transition-colors ${
                    isAdminArea ? "hover:bg-black/5" : "hover:bg-gray-100 rounded-lg"
                  }`}
                  title={user.name}
                >
                  <div
                    className={`w-7 h-7 flex items-center justify-center text-white font-black text-xs shrink-0 ${
                      isAdminArea ? "" : "rounded-full"
                    }`}
                    style={{ backgroundColor: isAdminArea ? "#0A0A0A" : bgColor }}
                  >
                    {initials}
                  </div>
                  {isAdminArea && (
                    <>
                      <span className="hidden sm:block text-[10px] font-black uppercase tracking-[0.16em] text-[#0A0A0A] max-w-[90px] truncate">
                        {user.name?.split(" ")[0]}
                      </span>
                      <ChevronDown className="w-3 h-3 hidden sm:block text-[#0A0A0A]/40" />
                    </>
                  )}
                </button>

                {/* Profile dropdown */}
                {profileOpen && (
                  isAdminArea ? (
                    <div className="absolute right-0 top-11 w-60 bg-white border border-[#0A0A0A] z-50 overflow-hidden" data-testid="profile-dropdown">
                      <div className="px-4 py-4 flex items-center gap-3 bg-[#EBE9E2] border-b border-black/15">
                        <div className="w-10 h-10 flex items-center justify-center bg-[#0A0A0A] text-white font-black text-[11px] shrink-0 tracking-wider">
                          {initials}
                        </div>
                        <div className="min-w-0">
                          <p className="font-black text-[12px] text-[#0A0A0A] leading-tight truncate uppercase tracking-[0.08em]">{user.name}</p>
                          <p className="text-[10px] font-mono text-black/55 mt-0.5">@{user.username}</p>
                          <p className="text-[9px] font-black uppercase tracking-[0.22em] text-[#0A0A0A]/65 mt-1">Online</p>
                        </div>
                      </div>
                      <div className="px-4 h-9 flex items-center justify-between border-b border-black/10 bg-white">
                        <span className="text-[10px] font-black uppercase tracking-[0.2em] text-black/55">Role</span>
                        <span className="text-[10px] font-black px-1.5 h-5 inline-flex items-center uppercase tracking-[0.16em] bg-[#0A0A0A] text-white">
                          {user.role === "admin" ? "Administrator" : "Staff"}
                        </span>
                      </div>
                      <button
                        onClick={async () => {
                          setProfileOpen(false);
                          const loginUrl = user?.role === "admin" ? "/admin/login" : "/staff/login";
                          try { await logout(); } catch {}
                          window.location.replace(loginUrl);
                        }}
                        data-testid="button-profile-signout"
                        className="w-full flex items-center justify-center gap-2 h-11 text-[11px] font-black uppercase tracking-[0.18em] text-[#0A0A0A]/70 hover:text-white hover:bg-[#0A0A0A] transition-colors"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        Sign Out
                      </button>
                    </div>
                  ) : (
                    <div className="absolute right-0 top-11 w-60 bg-white border border-gray-200 rounded-2xl shadow-2xl z-50 overflow-hidden" data-testid="profile-dropdown">
                      <div className="px-4 py-4 flex items-center gap-3 bg-slate-50 border-b">
                        <div className="w-11 h-11 rounded-full flex items-center justify-center text-white font-black text-sm shrink-0"
                          style={{ backgroundColor: bgColor }}>
                          {initials}
                        </div>
                        <div className="min-w-0">
                          <p className="font-bold text-sm text-foreground leading-tight truncate">{user.name}</p>
                          <p className="text-xs font-mono text-muted-foreground">@{user.username}</p>
                          <div className="flex items-center gap-1 mt-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
                            <span className="text-[11px] font-semibold text-emerald-600">Active</span>
                          </div>
                        </div>
                      </div>
                      <div className="px-4 py-2.5 flex items-center justify-between border-b">
                        <span className="text-xs text-muted-foreground">Role</span>
                        <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-700">
                          {user.role === "admin" ? "Administrator" : "Staff"}
                        </span>
                      </div>
                      <button
                        onClick={async () => {
                          setProfileOpen(false);
                          const loginUrl = user?.role === "admin" ? "/admin/login" : "/staff/login";
                          try { await logout(); } catch {}
                          window.location.replace(loginUrl);
                        }}
                        data-testid="button-profile-signout"
                        className="w-full flex items-center gap-2 px-4 py-3 text-sm font-semibold text-red-600 hover:bg-red-50 transition-colors"
                      >
                        <LogOut className="w-4 h-4" />
                        Sign Out
                      </button>
                    </div>
                  )
                )}
              </div>

              {/* Mobile hamburger — customer area only; admin uses bottom nav, staff uses bottom nav */}
              {isCustomerArea && (
                <button
                  onClick={() => setMenuOpen(!menuOpen)}
                  className="sm:hidden p-2.5 rounded-xl transition-colors text-muted-foreground hover:bg-gray-100"
                  aria-label={menuOpen ? "Close menu" : "Open menu"}
                  data-testid="button-mobile-menu"
                >
                  {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Mobile dropdown */}
      {user && menuOpen && (
        <div className={`sm:hidden border-t ${isAdminArea ? "bg-slate-900 border-white/10" : "bg-white border-gray-100"} shadow-lg`}>
          <div className="px-4 py-3 space-y-1">
            <div className={`flex items-center gap-3 px-3 py-2.5 mb-1 rounded-xl ${isAdminArea ? "bg-white/8" : "bg-gray-50"}`}>
              <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-black text-sm shrink-0"
                style={{ backgroundColor: bgColor }}>
                {initials}
              </div>
              <div className="min-w-0">
                <p className={`font-bold text-sm leading-tight truncate ${isAdminArea ? "text-white" : ""}`}>{user.name}</p>
                <div className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
                  <span className={`text-[11px] font-semibold ${isAdminArea ? "text-emerald-400" : "text-emerald-600"}`}>
                    Active · @{user.username}
                  </span>
                </div>
              </div>
            </div>

            {navLinks.map(({ href, label, icon: Icon }) => (
              <Link key={href} href={href}>
                <div className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
                  isActive(href)
                    ? isAdminArea ? "bg-white/12 text-white font-semibold" : "bg-primary/10 text-primary font-semibold"
                    : isAdminArea ? "text-white/60 hover:bg-white/8 hover:text-white" : "text-foreground hover:bg-gray-50"
                }`} data-testid={`mobile-nav-${label.toLowerCase().replace(/\s/g, "-")}`}>
                  <Icon className="w-4 h-4" />
                  {label}
                </div>
              </Link>
            ))}

            <div className="pt-2 mt-1 border-t border-white/10">
              <button
                onClick={async () => {
                  setMenuOpen(false);
                  const loginUrl = user?.role === "admin" ? "/admin/login" : "/staff/login";
                  try { await logout(); } catch {}
                  window.location.replace(loginUrl);
                }}
                className="w-full flex items-center gap-2 px-3 py-3 rounded-xl text-sm font-semibold text-red-500 hover:bg-red-500/10 transition-colors"
                data-testid="button-mobile-logout"
              >
                <LogOut className="w-4 h-4" /> Sign Out
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
