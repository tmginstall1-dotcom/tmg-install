import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { AlertCircle, CheckCircle2, Clock3, RefreshCw } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { termsAcceptedForCurrentVersion } from "@shared/businessRules";

type OfferValidityStatus = "draft" | "valid" | "expired" | "review" | "accepted" | "withdrawn" | "superseded";
type OfferValidity = {
  status: OfferValidityStatus;
  message: string;
  issuedAt?: string;
  expiresAt?: string;
  policyLabel?: string;
};

const statusStyles: Record<OfferValidityStatus, string> = {
  draft: "border-black/15 bg-black/[0.025] text-black/65",
  valid: "border-[#B6D6B7] bg-[#EFF7EF] text-[#28582D]",
  expired: "border-[#D7B5A7] bg-[#FBF0EC] text-[#783F31]",
  review: "border-[#D9C69D] bg-[#FBF6E9] text-[#735A27]",
  accepted: "border-[#B6D6B7] bg-[#EFF7EF] text-[#28582D]",
  withdrawn: "border-black/15 bg-black/[0.025] text-black/65",
  superseded: "border-black/15 bg-black/[0.025] text-black/65",
};

const statusLabels: Record<OfferValidityStatus, string> = {
  draft: "Draft",
  valid: "Offer valid",
  expired: "Offer expired",
  review: "Validity needs review",
  accepted: "Offer accepted",
  withdrawn: "Offer withdrawn",
  superseded: "Offer superseded",
};

function asDate(value?: string) {
  if (!value) return "";
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime())
    ? ""
    : parsed.toLocaleString("en-SG", { timeZone:"Asia/Singapore",day:"numeric",month:"short",year:"numeric",
      hour:"2-digit",minute:"2-digit",second:"2-digit",fractionalSecondDigits:3,hourCycle:"h23",timeZoneName:"short" });
}

export function OfferValidityStatusNotice({
  offerValidity,
  className = "",
}: {
  offerValidity?: OfferValidity | null;
  className?: string;
}) {
  if (!offerValidity) return null;
  const state = statusStyles[offerValidity.status] ? offerValidity.status : "review";
  const missingMessage = state === "review" && !offerValidity.message?.trim()
    ? "We do not have recorded validity evidence for this offer. Staff review is needed."
    : "";
  const Icon = state === "valid" || state === "accepted" ? CheckCircle2 : state === "review" || state === "expired" ? AlertCircle : Clock3;
  return (
    <section
      className={`flex min-w-0 items-start gap-2.5 border px-3 py-2.5 text-[12px] leading-relaxed ${statusStyles[state]} ${className}`}
      aria-label={`Quotation validity: ${statusLabels[state]}`}
      data-testid="offer-validity-status"
    >
      <Icon aria-hidden="true" className="mt-0.5 h-4 w-4 shrink-0" />
      <div className="min-w-0">
        <p className="font-bold">{statusLabels[state]}</p>
        <p className="break-words">{offerValidity.message?.trim() || missingMessage || "Validity details are not available."}</p>
        {(offerValidity.expiresAt || offerValidity.issuedAt || offerValidity.policyLabel) && (
          <p className="mt-1 text-[11px] opacity-75">
            {offerValidity.issuedAt && <>Issued {asDate(offerValidity.issuedAt)}</>}
            {offerValidity.issuedAt && offerValidity.expiresAt && " · "}
            {offerValidity.expiresAt && <>Expires {asDate(offerValidity.expiresAt)}</>}
            {(offerValidity.issuedAt || offerValidity.expiresAt) && offerValidity.policyLabel && " · "}
            {offerValidity.policyLabel}
          </p>
        )}
      </div>
    </section>
  );
}

export function AdminOfferValidityPanel({
  quote,
  dirty,
}: {
  quote: any;
  dirty: boolean;
}) {
  const { toast } = useToast();
  const [approveValidity, setApproveValidity] = useState(false);
  const [validityDays, setValidityDays] = useState("");
  const [refreshedValidity, setRefreshedValidity] = useState<OfferValidity | null>(null);
  useEffect(()=>{setRefreshedValidity(null);},[quote?.id,quote?.version,quote?.editRevision]);
  const validity = (refreshedValidity ?? quote?.offerValidity ?? {
    status: "review",
    message: "No recorded offer-validity evidence is available. Staff review is needed.",
  }) as OfferValidity;
  const status = validity?.status || "review";
  const isDraft = status === "draft";
  const acceptedScope = status === "accepted" || termsAcceptedForCurrentVersion(quote);
  const mutation = useMutation({
    mutationFn: async () => {
      const daysText = validityDays.trim();
      const days = daysText ? Number(daysText) : undefined;
      if (approveValidity && daysText && (!Number.isInteger(days) || Number(days) < 1 || Number(days) > 365)) {
        throw new Error("Enter a whole number of days from 1 to 365, or leave it blank to use configured terms.");
      }
      const body = {
        expectedVersion: Number(quote.version ?? 1),
        expectedRevision: quote.editRevision ?? quote.revision ?? null,
        requestKey: crypto.randomUUID(),
        ...(approveValidity ? { approveValidity: true as const } : {}),
        ...(approveValidity && days !== undefined ? { validityDays: days } : {}),
      };
      const response = await apiRequest("POST", `/api/admin/quotes/${quote.id}/offer/renew`, body);
      return response.json();
    },
    onSuccess: async (data) => {
      const returnedValidity = data?.quote?.offerValidity ?? data?.offerValidity;
      if (returnedValidity) setRefreshedValidity(returnedValidity);
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["/api/quotes/:id", String(quote.id)] }),
        queryClient.invalidateQueries({ queryKey: ["/api/quotes"] }),
        queryClient.invalidateQueries({ queryKey: ["/api/admin/quotes", String(quote.id), "workspace-context"] }),
      ]);
      toast({ title: "Offer validity updated", description: "No message was sent." });
      setApproveValidity(false);
      setValidityDays("");
    },
    onError: (error: any) => {
      toast({
        title: "Could not renew offer validity",
        description: error?.message || "Refresh the quotation and try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <section className="border border-black/12 bg-white px-3 py-3 sm:px-4" aria-label="Offer validity controls">
      <OfferValidityStatusNotice offerValidity={validity} />
      <details className="mt-2">
        <summary className="min-h-9 cursor-pointer py-2 text-[11px] font-bold text-black/65 underline decoration-black/20 underline-offset-4 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black">
          Offer renewal and validity
        </summary>
        <div className="mt-2 space-y-3 border-t border-black/10 pt-3">
          {isDraft ? (
            <p className="text-[11px] leading-relaxed text-black/60">
              Finalise this draft first using the workspace action below. Renewal is separate from saving or sending.
            </p>
          ) : acceptedScope ? (
            <p className="text-[11px] leading-relaxed text-black/60">
              This offer has been accepted. Its accepted scope cannot be renewed here.
            </p>
          ) : (
            <>
              <p className="text-[11px] leading-relaxed text-black/60">
                Renew or issue a new offer revision without changing your entered work. This action does not save unsaved edits or send a message.
              </p>
              <label className="flex min-h-10 cursor-pointer items-start gap-2.5 text-[11px] leading-relaxed text-black/75">
                <input
                  type="checkbox"
                  checked={approveValidity}
                  onChange={(event) => setApproveValidity(event.target.checked)}
                  disabled={dirty || mutation.isPending}
                  className="mt-0.5 h-4 w-4 shrink-0 accent-[#11110F] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
                  aria-label="I explicitly approve offer validity terms for this renewal"
                />
                <span>I explicitly approve validity terms for this offer</span>
              </label>
              {approveValidity && (
                <div className="max-w-xs">
                  <label htmlFor="offer-renewal-validity-days" className="mb-1 block text-[10px] font-bold uppercase tracking-[0.14em] text-black/55">
                    Validity days (optional)
                  </label>
                  <input
                    id="offer-renewal-validity-days"
                    type="number"
                    min={1}
                    max={365}
                    step={1}
                    inputMode="numeric"
                    value={validityDays}
                    onChange={(event) => setValidityDays(event.target.value)}
                    placeholder="Use configured terms"
                    aria-describedby="offer-renewal-validity-hint"
                    disabled={dirty || mutation.isPending}
                    className="min-h-10 w-full border border-black/15 bg-white px-3 text-[12px] outline-none focus:border-black focus:ring-2 focus:ring-black/10 disabled:bg-black/[0.03]"
                  />
                  <p id="offer-renewal-validity-hint" className="mt-1 text-[10px] leading-relaxed text-black/50">
                    Leave blank to use already-approved configured terms. Enter 1–365 only when approving a specific duration.
                  </p>
                </div>
              )}
              {dirty && <p role="status" className="text-[11px] font-medium text-[#735A27]">Save your unsaved work before renewing. Your entered edits remain untouched.</p>}
              <button
                type="button"
                onClick={() => mutation.mutate()}
                disabled={dirty || mutation.isPending}
                className="inline-flex min-h-10 items-center justify-center gap-2 border border-black bg-[#11110F] px-3 py-2 text-[10px] font-black uppercase tracking-[0.12em] text-white hover:bg-black/80 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black disabled:cursor-not-allowed disabled:opacity-45"
                data-testid="button-renew-offer-validity"
              >
                {mutation.isPending ? <span className="h-3.5 w-3.5 animate-pulse rounded-full bg-white/70" /> : <RefreshCw aria-hidden="true" className="h-3.5 w-3.5" />}
                {mutation.isPending ? "Updating validity" : "Renew / issue new revision"}
              </button>
            </>
          )}
        </div>
      </details>
    </section>
  );
}

export function WorkspaceValidityControls({
  approveValidity,
  onApproveValidityChange,
  validityDays,
  onValidityDaysChange,
}: {
  approveValidity: boolean;
  onApproveValidityChange: (value: boolean) => void;
  validityDays: string;
  onValidityDaysChange: (value: string) => void;
}) {
  return (
    <details className="border border-black/12 bg-white px-3 sm:px-4" data-testid="workspace-offer-validity-controls">
      <summary className="min-h-11 cursor-pointer py-3 text-[10px] font-black uppercase tracking-[0.14em] text-black/65 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black">
        Optional offer validity approval
      </summary>
      <div className="space-y-3 border-t border-black/10 py-3">
        <p className="text-[11px] leading-relaxed text-black/55">
          Applies only when you finalise or send. Saving a draft never requires validity approval.
        </p>
        <label className="flex min-h-10 cursor-pointer items-start gap-2.5 text-[11px] leading-relaxed text-black/75">
          <input
            type="checkbox"
            checked={approveValidity}
            onChange={(event) => onApproveValidityChange(event.target.checked)}
            className="mt-0.5 h-4 w-4 shrink-0 accent-[#11110F] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
            aria-label="I explicitly approve offer validity terms for finalisation or sending"
          />
          <span>I explicitly approve validity terms for this offer</span>
        </label>
        {approveValidity && (
          <div className="max-w-xs">
            <label htmlFor="workspace-validity-days" className="mb-1 block text-[10px] font-bold uppercase tracking-[0.14em] text-black/55">
              Validity days (optional)
            </label>
            <input
              id="workspace-validity-days"
              type="number"
              min={1}
              max={365}
              step={1}
              inputMode="numeric"
              value={validityDays}
              onChange={(event) => onValidityDaysChange(event.target.value)}
              placeholder="Use configured terms"
              aria-describedby="workspace-validity-hint"
              className="min-h-10 w-full border border-black/15 bg-white px-3 text-[12px] outline-none focus:border-black focus:ring-2 focus:ring-black/10"
            />
            <p id="workspace-validity-hint" className="mt-1 text-[10px] leading-relaxed text-black/50">
              Leave blank to use already-approved configured terms. Enter 1–365 only when approving a specific duration.
            </p>
          </div>
        )}
      </div>
    </details>
  );
}
