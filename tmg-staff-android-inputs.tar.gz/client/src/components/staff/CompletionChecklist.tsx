import type {useCompletionChecklist} from "@/hooks/use-completion-checklist";

export function CompletionChecklist({required,checklist}:{required:string[];checklist:ReturnType<typeof useCompletionChecklist>}) {
  return <section aria-labelledby="completion-checklist-heading" className="rounded-xl border p-4 space-y-3" data-testid="completion-checklist">
    <h3 id="completion-checklist-heading" className="font-bold">Confirm work before customer sign-off</h3>
    <p className="text-sm text-muted-foreground">Confirm only work actually checked. Each tick must be saved before submission. A signature does not complete this checklist.</p>
    <p role="status" aria-live="polite" className="text-sm font-semibold">
      {checklist.loading?"Loading saved confirmations…":checklist.saving?"Saving and verifying your confirmation…":
        checklist.ready?"All required confirmations saved. Ready for customer sign-off.":
        `${checklist.savedCount}/${required.length} required confirmations saved`}
    </p>
    {checklist.readError&&<div role="alert" className="text-sm text-red-700">
      Saved confirmations could not be loaded. Nothing has been assumed complete; your photos and sign-off remain here.
      <button type="button" className="block underline min-h-11" onClick={()=>void checklist.retryRead()}>Retry loading checklist</button>
    </div>}
    {checklist.saveError&&<div role="alert" className="text-sm text-red-700">
      Save not confirmed: {checklist.saveError}. Your selection is retained, but does not yet count as saved.
      <button type="button" className="block underline min-h-11" disabled={checklist.saving||checklist.loading} onClick={checklist.retrySave}>Retry saving confirmations</button>
    </div>}
    {checklist.intent!==null&&!checklist.saveError&&!checklist.saving&&<div role="status" className="text-sm">
      Retained selections need server confirmation; they are not assumed saved.
      <button type="button" className="block underline min-h-11" disabled={checklist.loading||checklist.readError}
        onClick={checklist.retrySave}>Review and save retained confirmations</button>
    </div>}
    <div className="divide-y">
      {required.map((label,index)=><label key={label} className="flex items-start gap-3 py-3 text-sm">
        <input type="checkbox" checked={checklist.selected.includes(label)}
          disabled={checklist.loading||checklist.readError||checklist.saving}
          onChange={()=>checklist.toggle(label)} className="mt-1 h-5 w-5 shrink-0"
          data-testid={`completion-check-${index}`}/>
        <span className="min-w-0 break-words">{label}
          <span className="block text-xs text-muted-foreground">
            {checklist.intent!==null&&checklist.selected.includes(label)!==checklist.saved.includes(label)
              ?checklist.saving?"Saving…":"Not saved — retry required":checklist.saved.includes(label)?"Saved":"Not confirmed"}
          </span>
        </span>
      </label>)}
    </div>
    {!checklist.ready&&<p className="text-sm">Finish and save these confirmations before asking the customer to sign. Any genuine entries already captured stay in this draft.</p>}
  </section>;
}
