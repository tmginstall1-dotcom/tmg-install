import {useState} from "react";
import {useQuery,useQueryClient} from "@tanstack/react-query";
import {useLocation} from "wouter";
import {apiRequest} from "@/lib/queryClient";

const API_BASE=(import.meta.env.VITE_API_BASE as string)||"";
type Alert={
  paymentId:number;quoteId:number;referenceNo:string;customer:string;amount:number;
  type:string;paidAt:string;remainingBalance:number|null;requiresReview:boolean;
  readAt:string|null;href:string;push:{status:string;attempts:number};
};
type Feed={items:Alert[];total:number;unreadCount:number;offset:number};
export function useAdminPaymentAlerts(offset=0, enabled=true) {
  return useQuery<Feed>({queryKey:["/api/admin/payment-alerts",offset],refetchInterval:30_000,
    enabled, staleTime:0,refetchOnMount:"always",refetchOnWindowFocus:true,
    queryFn:async()=>{const res=await fetch(`${API_BASE}/api/admin/payment-alerts?offset=${offset}`,{credentials:"include"});
      if(!res.ok)throw new Error("Payment alerts could not be refreshed");return res.json();}});
}
const money=(v:number)=>`S$${v.toFixed(2)}`;
const pushLabels:Record<string,string>={
  not_attempted:"Persistent alert saved; push not attempted.",
  sending:"Push pending or outcome unknown. Do not resend until reconciled.",
  accepted:"Push provider accepted; delivery is not confirmed.",
  partial:"Some push requests accepted; others failed. Persistent alert is saved.",
  unavailable:"No background push available. Persistent alert is saved.",
  failed:"Background push failed. Persistent alert is saved; safe retry available.",
  uncertain:"Push outcome uncertain. Persistent alert is saved; no blind resend.",
};
export function AdminPaymentAlerts({onOpenQuote}:{onOpenQuote:()=>void}) {
  const [offset,setOffset]=useState(0),[busy,setBusy]=useState<number|null>(null),[error,setError]=useState("");
  const feed=useAdminPaymentAlerts(offset),cache=useQueryClient(),[,navigate]=useLocation();
  async function action(id:number,kind:"read"|"retry-push") {
    if(busy!==null)return;
    setBusy(id);setError("");
    try {await apiRequest("POST",`/api/admin/payment-alerts/${id}/${kind}`,{});
      await cache.invalidateQueries({queryKey:["/api/admin/payment-alerts"]});}
    catch {setError(kind==="read"?"Could not mark read. Retry; the receipt is unchanged.":
      "Push status unavailable. Refresh before retrying; the receipt and bell alert remain saved.");}
    finally {setBusy(null);}
  }
  return <div className="max-h-[60vh] overflow-y-auto text-[12px]" data-testid="payment-activity">
    <p className="px-4 py-3 border-b">Verified card receipts. Reading an alert does not change the payment or book a job.</p>
    {(feed.isPending||feed.isFetching)&&<p className="p-4" role="status">Refreshing payment activity…</p>}
    {(feed.isError||error)&&<div className="p-4 text-red-700" role="alert">{error||"Latest payment alerts unavailable. Any shown entries are saved history."}
      <button className="underline ml-2 min-h-10" onClick={()=>{setError("");feed.refetch();}}>Retry refresh</button></div>}
    {!feed.isFetching&&feed.data?.items.length===0&&<p className="p-4">No new verified card payment alerts. Historical receipts remain on their quotations.</p>}
    {feed.data?.items.map(item=><article key={item.paymentId} className="p-4 border-b space-y-2 break-words" data-testid={`payment-alert-${item.paymentId}`}>
      <p className="font-bold">{item.readAt?"Read · ":"New · "}Card payment received</p>
      <p>{item.customer} · <span className="break-all">{item.referenceNo}</span></p>
      <p className="font-bold">{money(item.amount)} · {({deposit:"Deposit",full:"Full payment",balance:"Final balance",review:"Reconciliation required"} as Record<string,string>)[item.type]||"Card payment"}</p>
      <p>{item.remainingBalance===null?"Balance requires staff reconciliation":`Remaining balance ${money(item.remainingBalance)}`}</p>
      <p>{new Date(item.paidAt).toLocaleString("en-SG",{timeZone:"Asia/Singapore"})} SGT</p>
      <p className="text-black/60">{pushLabels[item.push.status]||"Push status unavailable; receipt saved."}</p>
      {item.push.attempts>0&&<p className="text-black/60">Background push attempts: {item.push.attempts}</p>}
      <div className="flex flex-wrap gap-2">
        <button className="border px-3 min-h-10 font-bold" onClick={()=>{navigate(item.href);onOpenQuote();}}>Open quote</button>
        {!item.readAt&&<button className="border px-3 min-h-10" disabled={busy!==null} onClick={()=>action(item.paymentId,"read")}>Mark read</button>}
        {["failed","unavailable","not_attempted"].includes(item.push.status)&&<button className="underline min-h-10" disabled={busy!==null}
          onClick={()=>action(item.paymentId,"retry-push")}>Retry background push</button>}
      </div>
    </article>)}
    {!!feed.data?.total&&<div className="p-4 flex justify-between items-center gap-2">
      <button className="min-h-10 underline" disabled={offset===0} onClick={()=>setOffset(Math.max(0,offset-20))}>Newer</button>
      <span>{offset+1}–{Math.min(offset+20,feed.data.total)} of {feed.data.total}</span>
      <button className="min-h-10 underline" disabled={offset+20>=feed.data.total} onClick={()=>setOffset(offset+20)}>Older</button>
    </div>}
  </div>;
}
