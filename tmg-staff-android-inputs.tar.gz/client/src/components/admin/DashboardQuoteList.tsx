import { useState, type ReactNode } from "react";
import { Button } from "@/components/admin/AdminUI";

// Keep first paint bounded on phones without truncating data used for KPIs
// or search. Every matching job remains available through Show more.
export function DashboardQuoteList({ quotes, renderRow }: {
  quotes: any[];
  renderRow: (quote: any) => ReactNode;
}) {
  const [limit, setLimit] = useState(20);
  const remaining = Math.max(0, quotes.length - limit);
  return (
    <>
      <div className="divide-y divide-black/8">
        {quotes.slice(0, limit).map(renderRow)}
      </div>
      {remaining > 0 && (
        <div className="flex items-center justify-between gap-3 border-t border-black/10 px-4 py-3">
          <p className="text-[11px] text-black/55">{Math.min(limit, quotes.length)} of {quotes.length} jobs</p>
          <Button variant="outline" onClick={() => setLimit(n => n + 20)} data-testid="button-show-more-jobs">
            Show {Math.min(remaining, 20)} more
          </Button>
        </div>
      )}
    </>
  );
}