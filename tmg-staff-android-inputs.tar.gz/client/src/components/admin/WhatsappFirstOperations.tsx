import { useEffect, useRef, useState } from "react";
import { isOutboundAttempt } from "@shared/outbound-recovery";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, CheckCircle2, ExternalLink, RefreshCw, Save, ShieldCheck, Truck } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

type ChecklistItem = { key: string; label: string; ok: boolean; reason?: string };
type SetupPolicy = {
  approved: boolean;
  publicBaseUrl: string;
  contactHours: string;
  crewHours: string;
  crewSlots: string[];
  holdMinutes: number;
  morningCapacity: number;
  afternoonCapacity: number;
  availabilityMode?: "staff_confirmation" | "workload_slots";
  workloadCapacity?: number;
};
type ReleaseManifest = { bundleSha256:string; clientSha256:string; sqlSha256:string };
type SetupResponse = { policy: SetupPolicy; quoteReady:boolean;bookingReady:boolean;checklist: ChecklistItem[]; templates: any[];
  releaseEnabled:boolean; requestedOn:boolean; blockingReasons:string[]; canActivate:boolean;quoteTemplateReady:boolean;
  controlRevision:string;
  quoteTemplateLanguages:{english:boolean;chinese:boolean};
  readiness:{ready:boolean;enabled:boolean;errors:string[];activation?:{activatedAt?:string;boundaryAt?:string;[key:string]:any};manifest?:ReleaseManifest} };
type ActivationReview = {
  enabled: boolean;
  controlRevision: string;
  manifest?: ReleaseManifest;
  releaseEnabled: boolean;
};
type ReviewLine = {
  key: string;
  savedItemId?: number;
  name: string;
  quantity: string;
  unit?: string;
  serviceType: string;
  catalogItemId?: number | null;
  unitPrice: string;
  remark: string;
  hasSavedPrice: boolean;
  priceReason: string;
};
type Resolution = { chargeKey: string; mode: "approve" | "waive"; amount: string; reason: string };
type ReviewDraft = {
  id: number;
  version: number;
  expectedRevision: string;
  referenceNo?: string;
  total?: number | string;
  transportFee?: number | string;
  pricingPending?: boolean;
  transportPending?: boolean;
  promoDiscount?: number | string;
};
type CatalogOption = { id: number; name: string; serviceType: string; basePrice: number | string };

const card = "border border-zinc-200 bg-white";
const labelClass = "block text-[11px] font-semibold text-zinc-500 mb-1";
const inputClass = "w-full h-9 px-2.5 border border-zinc-300 bg-white text-sm text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]";
const buttonClass = "inline-flex items-center justify-center gap-2 px-3 py-2 bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-black disabled:opacity-50";
const knownSlots = ["09:00-12:00", "13:00-17:00"];

function ErrorNote({ error, retry }: { error: unknown; retry: () => void }) {
  if (!error) return null;
  return <div role="alert" className="flex items-start gap-2 border border-red-200 bg-red-50 p-3 text-xs text-red-800">
    <AlertTriangle className="w-4 h-4 shrink-0" /><span className="flex-1">{error instanceof Error ? error.message : "Could not load operational data."}</span>
    <button type="button" onClick={retry} className="font-bold underline">Retry</button>
  </div>;
}

export function OperationsSetup() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const queryKey = ["/api/admin/whatsapp-first/setup"];
  const { data, isLoading, error, refetch } = useQuery<SetupResponse>({ queryKey });
  const [policy, setPolicy] = useState<SetupPolicy | null>(null);
  const [acknowledged, setAcknowledged] = useState(false);
  const [activationDialogOpen, setActivationDialogOpen] = useState(false);
  const [activationReview, setActivationReview] = useState<ActivationReview | null>(null);
  const [activationAcknowledged, setActivationAcknowledged] = useState(false);
  const [activationError, setActivationError] = useState<string | null>(null);
  const [activationSuccess, setActivationSuccess] = useState<any>(null);
  const [refreshingActivationReview, setRefreshingActivationReview] = useState(false);
  const activationInFlight = useRef(false);
  useEffect(() => {
    if (data?.policy) {
      setPolicy({
        ...data.policy,
        morningCapacity: Number(data.policy.morningCapacity || 0),
        afternoonCapacity: Number(data.policy.afternoonCapacity || 0),
        crewSlots: data.policy.crewSlots || [],
      });
      setAcknowledged(false);
    }
  }, [data]);
  const save = useMutation({
    mutationFn: async () => {
      if (!policy) throw new Error("Setup is not loaded.");
      if (policy.crewSlots.some(slot => !knownSlots.includes(slot))) throw new Error("Select only supported crew slots.");
      if (policy.morningCapacity < 0 || policy.afternoonCapacity < 0) throw new Error("Secondary monetary limits cannot be negative.");
      if (policy.holdMinutes < 0 || policy.holdMinutes > 120) throw new Error("Hold must be between 0 and 120 minutes.");
      let quoteHost = "";
      try { quoteHost = new URL(policy.publicBaseUrl).hostname; } catch { throw new Error("Enter a valid public quote URL on tmginstall.com."); }
      if (quoteHost !== "tmginstall.com" && !quoteHost.endsWith(".tmginstall.com")) throw new Error("Public quote links must use the tmginstall.com domain.");
      return apiRequest("PUT", "/api/admin/whatsapp-first/setup", { ...policy, approved: true,availabilityMode:"staff_confirmation",crewSlots:[],holdMinutes:0,morningCapacity:0,afternoonCapacity:0 });
    },
    onSuccess: async () => {
      toast({ title: "Operational policy saved" });
      setAcknowledged(false);
      await qc.invalidateQueries({ queryKey });
    },
    onError: (e: Error) => toast({ title: "Could not save setup", description: e.message, variant: "destructive" }),
  });
  const activation=useMutation({
    mutationFn:async(review:ActivationReview)=>{
      if (!review.controlRevision) throw new Error("The setup control revision is missing. Refresh and review the current setup.");
      if (review.enabled && !review.manifest) throw new Error("The reviewed release fingerprint is unavailable. Refresh and review the current setup.");
      let timer: ReturnType<typeof setTimeout> | undefined;
      try {
        return await Promise.race([
          apiRequest("POST","/api/admin/whatsapp-first/activation",{
            enabled:review.enabled,
            ...(review.enabled ? { expectedRelease:review.manifest } : {}),
            expectedControlRevision:review.controlRevision,
          }).then(response=>response.json()),
          new Promise<never>((_,reject)=>{timer=setTimeout(()=>reject(new Error("Server confirmation timed out. The change may have saved. Refresh and review the persisted state before trying again.")),20000);}),
        ]);
      } finally {if(timer)clearTimeout(timer);}
    },
    onSuccess:(result)=>{
      setActivationSuccess(result);
      setActivationError(null);
      void qc.invalidateQueries({queryKey});
      void qc.invalidateQueries({queryKey:["/api/admin/ai/whatsapp-first/status"]});
    },
  });
  const openActivationReview = (enabled:boolean) => {
    if (!data) return;
    setActivationReview({
      enabled,
      controlRevision:data.controlRevision,
      manifest:data.readiness?.manifest ? { ...data.readiness.manifest } : undefined,
      releaseEnabled:data.releaseEnabled,
    });
    setActivationAcknowledged(false);
    setActivationError(null);
    setActivationSuccess(null);
    setActivationDialogOpen(true);
  };
  const submitActivation = async () => {
    if (!activationReview || activationInFlight.current || activation.isPending) return;
    if (activationReview.enabled && !activationAcknowledged) return;
    activationInFlight.current = true;
    setActivationError(null);
    try {
      await activation.mutateAsync(activationReview);
    } catch (cause) {
      setActivationAcknowledged(false);
      setActivationError(cause instanceof Error ? cause.message : "The activation state was not changed.");
    } finally {
      activationInFlight.current = false;
    }
  };
  const refreshActivationReview = async () => {
    if (!activationReview || refreshingActivationReview || activation.isPending) return;
    const enabled = activationReview.enabled;
    setRefreshingActivationReview(true);
    setActivationAcknowledged(false);
    setActivationSuccess(null);
    try {
      const refreshed = await refetch();
      const current = refreshed.data;
      if (refreshed.isError || !current) throw new Error("Current setup could not be loaded. Try refreshing again.");
      setActivationReview({
        enabled,
        controlRevision:current.controlRevision,
        manifest:current.readiness?.manifest ? { ...current.readiness.manifest } : undefined,
        releaseEnabled:current.releaseEnabled,
      });
      setActivationError(null);
    } catch (cause) {
      setActivationError(cause instanceof Error ? cause.message : "Current setup could not be loaded.");
    } finally {
      setRefreshingActivationReview(false);
    }
  };
  const closeActivationReview = () => {
    if (activation.isPending || activationInFlight.current) return;
    setActivationDialogOpen(false);
  };
  const persistedActivation = activationSuccess?.readiness?.activation ?? activationSuccess?.activation;
  const persistedBoundary = persistedActivation?.activatedAt ?? persistedActivation?.boundaryAt ??
    (typeof activationSuccess?.requestedOn === "string" ? activationSuccess.requestedOn : null);
  const readableBoundary = persistedBoundary
    ? (Number.isNaN(Date.parse(persistedBoundary)) ? persistedBoundary : new Date(persistedBoundary).toLocaleString())
    : null;
  const persistedOperational = activationSuccess?.operational ?? activationSuccess?.releaseEnabled ??
    activationSuccess?.readiness?.enabled;
  const templates = useQuery<{ templates: any[]; inventory?: any[]; availableTemplates?: any[] }>({
    queryKey: ["/api/admin/whatsapp-first/templates"],
    queryFn: async () => (await apiRequest("GET", "/api/admin/whatsapp-first/templates")).json(),
  });
  const templateInventory = templates.data?.inventory || templates.data?.availableTemplates || templates.data?.templates || [];
  const [selectedTemplates, setSelectedTemplates] = useState<string[]>([]);
  const [templateEdits,setTemplateEdits]=useState<Record<string,{purpose?:string;bindings?:Record<string,string>}>>({});
  useEffect(() => {
    const configured = templates.data?.templates || [];
    setSelectedTemplates(configured.map((t: any) => String(t.id ?? `${t.name}:${t.language || ""}`)));
  }, [templates.data]);
  const sync = useMutation({
    mutationFn: () => apiRequest("POST", "/api/admin/whatsapp-first/templates/sync", {}),
    onSuccess: async () => {
      toast({ title: "Meta template inventory refreshed" });
      await qc.invalidateQueries({ queryKey: ["/api/admin/whatsapp-first/templates"] });
      await qc.invalidateQueries({ queryKey });
    },
    onError: (e: Error) => toast({ title: "Template inventory sync failed", description: e.message, variant: "destructive" }),
  });
  const saveTemplates = useMutation({
    mutationFn: () => {
      const selected = templateInventory.filter((template: any) => selectedTemplates.includes(String(template.id ?? `${template.name}:${template.language || ""}`)));
      return apiRequest("PUT", "/api/admin/whatsapp-first/templates", { templates: selected.map((t:any)=>({...t,...templateEdits[String(t.id)]})) });
    },
    onSuccess: async () => {
      toast({ title: "Verified template selection saved" });
      await qc.invalidateQueries({ queryKey: ["/api/admin/whatsapp-first/templates"] });
    },
    onError: (e: Error) => toast({ title: "Template selection was not saved", description: e.message, variant: "destructive" }),
  });
  const update = (patch: Partial<SetupPolicy>) => setPolicy(current => current ? { ...current, ...patch } : current);

  return <section className={`${card} overflow-hidden`} data-testid="whatsapp-first-operations-setup">
    <div className="flex items-center gap-3 border-b border-zinc-200 px-4 py-3">
      <ShieldCheck className="w-4 h-4 text-[#0A0A0A]" />
      <div><h3 className="text-sm font-bold text-zinc-900">WhatsApp-first operations</h3><p className="text-[11px] text-zinc-500">Quotation-only · staff confirms every date/time · payment never books automatically</p></div>
      <span data-testid="quotation-activation-state" className="ml-auto border border-amber-200 bg-amber-50 px-2 py-1 text-[10px] font-bold uppercase tracking-wide text-amber-800">{data?.releaseEnabled?"Operational":data?.requestedOn?"Paused · owner review":"Off · staff handling"}</span>
    </div>
    <div className="space-y-4 p-4">
      {isLoading && <div className="space-y-2 animate-pulse"><div className="h-4 w-2/3 bg-zinc-100" /><div className="h-14 bg-zinc-100" /><div className="h-14 bg-zinc-100" /></div>}
      <ErrorNote error={error} retry={() => refetch()} />
      {!isLoading && !error && !policy && <p className="text-sm text-zinc-500">Setup data is not available yet.</p>}
      {policy && <>
        {data?.requestedOn&&!data.releaseEnabled&&<div role="alert" className="border-l-4 border-amber-500 bg-amber-50 p-3 text-xs text-amber-950" data-testid="quotation-runtime-blocker">
          <strong>Automatic quoting is paused{data.blockingReasons.some(reason=>/older|fingerprint|release/i.test(reason))?" after a site update":""}.</strong>
          <p className="mt-1">Incoming enquiries are saved. The owner can review and reactivate. Earlier messages need staff attention.</p>
          <div className="mt-2 flex flex-wrap items-center gap-3">
            <button type="button" data-testid="quotation-activation-toggle" className={buttonClass} disabled={activation.isPending||!data.readiness?.ready||!data.canActivate} onClick={()=>openActivationReview(true)}>Review and reactivate</button>
            <a href="/admin/conversations" className="font-semibold underline">Conversations / handoffs</a>
          </div>
          <details className="mt-2"><summary className="cursor-pointer font-semibold">Release details</summary>
            {data.blockingReasons.map(reason=><p key={reason} className="mt-1">{reason}</p>)}
            <p className="mt-1">Confirmation checks the installed client, server and database release and starts a new-message boundary. No earlier messages replay.</p>
          </details>
        </div>}
        <div className="grid gap-2 sm:grid-cols-2 text-xs" data-testid="separate-readiness">
          <p className="border p-3">Formal quote link setup: <strong>{data?.quoteReady?"Ready (not a live-bot status)":"Secure link needs configuration"}</strong></p>
          <p className="border p-3">Scheduling: <strong>Staff confirms every date/time · payment never books automatically</strong></p>
        </div>
        <p className="text-xs">Automatic quotation only. The existing accountable owner confirms every appointment; no automatic scheduling policy is offered here.</p>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="border-l-2 border-[#0A0A0A] bg-zinc-50 p-3 text-xs">
            <p className="font-bold text-zinc-800">Verified operating hours</p>
            <p className="mt-1 text-zinc-600">Crew · {policy.crewHours}</p><p className="text-zinc-600">Customer contact · {policy.contactHours}</p>
          </div>
          <div className="border-l-2 border-[#0A0A0A] bg-zinc-50 p-3 text-xs">
            <p className="font-bold text-zinc-800">Quote domain</p>
            <p className="mt-1 text-zinc-600">Customer links must use <strong>tmginstall.com</strong>.</p>
            <label className="mt-2 block"><span className={labelClass}>Public base URL</span><input className={inputClass} value={policy.publicBaseUrl || ""} onChange={e => update({ publicBaseUrl: e.target.value })} placeholder="https://tmginstall.com" /></label>
          </div>
        </div>
        <p className="border p-3 text-xs">Saved crew slots: {policy.crewSlots.join(", ")||"none"} · hold: {policy.holdMinutes} minutes · capacity: {policy.morningCapacity}/{policy.afternoonCapacity}. Saving sets quotation-only mode with zero slots, holds and capacity.</p>
        <div className="grid gap-2 sm:grid-cols-2">
          {(data?.checklist || []).map(item => <div key={item.key} className="flex items-start gap-2 border border-zinc-100 bg-zinc-50 p-2.5 text-xs">
            {item.ok ? <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-700" /> : <AlertTriangle className="w-4 h-4 shrink-0 text-amber-700" />}
            <div><p className="font-semibold text-zinc-800">{item.label}</p>{item.reason && <p className="mt-0.5 text-zinc-500">{item.reason}</p>}</div>
          </div>)}
        </div>
        <button type="button" className={buttonClass} disabled={save.isPending} onClick={() => save.mutate()}><Save className="w-3.5 h-3.5" />{save.isPending ? "Saving…" : "Save quotation setup"}</button>
        <div className="border-t border-zinc-200 pt-3">
          <div className="flex items-center gap-2"><p className="text-xs font-bold text-zinc-800">Eligible message templates</p><button type="button" className="ml-auto inline-flex items-center gap-1 text-[11px] font-semibold text-zinc-600 hover:text-zinc-900 disabled:opacity-50" onClick={() => sync.mutate()} disabled={sync.isPending}><RefreshCw className={`h-3 w-3 ${sync.isPending ? "animate-spin" : ""}`} />Sync Meta inventory</button></div>
          <p role="status" data-testid="quotation-template-status" className={`mt-2 text-xs ${data?.quoteTemplateReady?"text-zinc-700":"text-amber-800"}`}>
            {data?.quoteTemplateReady?"A fresh Meta-approved quotation template with a secure quote-link mapping is configured. Customer request/consent still applies outside the 24-hour window.":
              "Outside the 24-hour customer window, quotation messages are blocked: no fresh Meta-approved quotation template with a secure quote-link mapping is configured. Ask the owner to obtain provider approval for a suitable English/Chinese utility template, sync the inventory and bind the actual URL; never use a sample template or assume consent."}
          </p>
          <p className="mt-1 text-xs text-zinc-700">Quote templates by language (outside the 24-hour window): English — {data?.quoteTemplateLanguages?.english?"verified":"unavailable"} · Chinese — {data?.quoteTemplateLanguages?.chinese?"verified":"unavailable"}. Each requires a fresh approved version and an actual customer request/consent.</p>
          <p className="mt-1 text-xs text-zinc-500">Configured quotation templates automatically recheck Meta approval when their 24-hour verification expires. Failed checks pause outside-window delivery, not ordinary replies. Manual sync remains available.</p>
          {templates.isLoading ? <div className="mt-2 h-8 animate-pulse bg-zinc-100" /> : templates.error ? <p className="mt-2 text-xs text-amber-800">Template configuration unavailable. Check server setup before using outside-window messaging.</p> : templateInventory.length ? <>
            <ul className="mt-2 space-y-1.5 text-xs text-zinc-600">{templateInventory.map((t: any, i: number) => {
              const key = String(t.id ?? `${t.name}:${t.language || ""}`);
              const isConfigured = (templates.data?.templates || []).some((item: any) => String(item.id ?? `${item.name}:${item.language || ""}`) === key);
              const edit=templateEdits[key]||t;
              const placeholders=(t.components||[]).flatMap((c:any)=>["BODY","HEADER"].includes(c.type)?Array.from(String(c.text||"").matchAll(/\{\{(\d+|[A-Za-z][A-Za-z0-9_]*)\}\}/g)).map((m:any)=>`${c.type}:${m[1]}`):[]);
              return <li key={key || i} className="space-y-2 border border-zinc-200 p-2">
                <div className="flex items-center gap-2"><input aria-label={`Select verified template ${t.name || t.id}`} type="checkbox" disabled={t.status!=="APPROVED"||t.category!=="UTILITY"} checked={selectedTemplates.includes(key)} onChange={e => setSelectedTemplates(current => e.target.checked ? [...current, key] : current.filter(item => item !== key))} /><span>{t.name || t.id} · {t.language} · {t.status} · {t.category}</span>{isConfigured && <span className="ml-auto text-[9px] font-bold uppercase text-emerald-700">Configured</span>}</div>
                <p className="whitespace-pre-wrap text-[11px] text-zinc-600">{(t.components||[]).map((c:any)=>c.text||"").filter(Boolean).join("\n")}</p>
                {selectedTemplates.includes(key)&&<>
                  <label><span className={labelClass}>Applicable utility purpose · review approved wording</span><select className={inputClass} value={edit.purpose||""} onChange={e=>setTemplateEdits(v=>({...v,[key]:{...edit,purpose:e.target.value}}))}><option value="">Select an applicable purpose</option><option value="quote">Requested quotation</option><option value="payment">Payment request</option><option value="booking">Confirmed booking</option><option value="reminder">Requested reminder</option></select></label>
                  {Array.from(new Set<string>(placeholders)).map(field=><label key={field}><span className={labelClass}>{field} · approved quote value</span><select className={inputClass} value={edit.bindings?.[field]||""} onChange={e=>setTemplateEdits(v=>({...v,[key]:{...edit,bindings:{...edit.bindings,[field]:e.target.value}}}))}><option value="">Select field mapping</option><option value="referenceNo">Quotation reference</option><option value="total">Approved total</option><option value="dueNow">Required payment</option><option value="url">Secure quotation URL</option></select></label>)}
                </>}
              </li>;
            })}</ul>
            <button type="button" className="mt-2 border border-zinc-300 px-2.5 py-1.5 text-[10px] font-semibold text-zinc-700 hover:bg-zinc-50 disabled:opacity-50" onClick={() => saveTemplates.mutate()} disabled={saveTemplates.isPending}>{saveTemplates.isPending ? "Saving…" : "Save verified selection"}</button>
          </> : <p className="mt-2 text-xs text-zinc-500">No eligible templates configured. Sync inventory, then configure verified approved templates; consent is recorded separately per conversation.</p>}
        </div>
        <div className="space-y-2 border-t pt-3 text-xs">
          <p>Saving setup does not activate automatic quoting.</p>
          <p>{data?.readiness?.ready?"Installed quotation release and booking safeguards verified. This alone does not mean the bot is operational.":"Installed quotation release needs attention before activation."}</p>
          {data?.releaseEnabled && <p role="status">Automatic quotation replies are operational for new messages only.</p>}
          {(data?.readiness?.errors||[]).map(e=><p key={e} role="alert" className="text-amber-800">{e}</p>)}
          {data?.readiness?.activation&&<p>Activation boundary: {data.readiness.activation.activatedAt}</p>}
          {(!data?.requestedOn||data.releaseEnabled)&&<button type="button" data-testid="quotation-activation-toggle" className={buttonClass} disabled={activation.isPending||(!data?.releaseEnabled&&(!data?.readiness?.ready||!data?.canActivate))} onClick={()=>openActivationReview(!data?.releaseEnabled)}>{data?.releaseEnabled?"Deactivate quotation automation":"Review and activate"}</button>}
          {!data?.canActivate && <p>Only the pinned accountable owner can activate; other operators can continue handling conversations manually.</p>}
          {activationError && <p role="alert" className="text-amber-900">Activation was not confirmed. Review the current state before trying again.</p>}
        </div>
      </>}
    </div>
    <Dialog open={activationDialogOpen} onOpenChange={(open) => open ? setActivationDialogOpen(true) : closeActivationReview()}>
      <DialogContent data-testid="quotation-activation-dialog" className="w-[calc(100%-2rem)] max-h-[90dvh] overflow-y-auto border-zinc-300 bg-[#fffdf8] p-5 text-zinc-900 sm:max-w-xl sm:p-6">
        <DialogHeader>
          <DialogTitle className="text-left text-lg font-bold text-zinc-950" data-testid="quotation-activation-dialog-title">
            {activationSuccess ? (persistedOperational ? "Quotation automation activated" : "Quotation automation deactivated") :
              activationReview?.enabled ? "Review activation" : "Review deactivation"}
          </DialogTitle>
          <DialogDescription className="text-left text-sm text-zinc-600">
            {activationSuccess
              ? "The server response below records the persisted operating state and message boundary."
              : activationReview?.enabled
                ? "This confirmation applies only to the exact release and control revision captured when this review opened."
                : "Review the current control revision before turning automatic quotations off."}
          </DialogDescription>
        </DialogHeader>
        {!activationSuccess && activationReview && <>
          <div className="space-y-3 border-y border-zinc-200 py-4">
            <div className="flex items-start gap-3">
              <span className={`mt-0.5 inline-flex h-6 w-6 shrink-0 items-center justify-center border text-xs font-bold ${activationReview.enabled ? "border-amber-300 bg-amber-50 text-amber-900" : "border-zinc-300 bg-zinc-100 text-zinc-700"}`}>
                {activationReview.enabled ? "01" : "OFF"}
              </span>
              <div className="min-w-0">
                <p className="text-sm font-semibold">{activationReview.enabled ? "New messages only" : "Automatic replies stop"}</p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-600">
                  {activationReview.enabled
                    ? "Only messages received after the persisted activation boundary are eligible. Earlier messages remain for staff attention; they will not replay."
                    : "Incoming enquiries remain available for staff handling. Turning automation off does not delete conversations or change appointment decisions."}
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 border-t border-zinc-100 pt-3">
              <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-zinc-700" />
              <p className="text-xs leading-relaxed text-zinc-700">
                Staff confirms every appointment. Payment never books an appointment automatically.
              </p>
            </div>
            <details className="border-l-2 border-zinc-300 bg-zinc-50 px-3 py-2">
              <summary className="cursor-pointer text-xs font-semibold text-zinc-700">Release details</summary>
              <p className="mt-1 text-xs text-zinc-700">Control revision · <code data-testid="activation-control-revision" className="break-all font-mono">{activationReview.controlRevision || "Unavailable"}</code></p>
              {activationReview.enabled && activationReview.manifest && <details className="mt-2">
                <summary className="cursor-pointer text-xs font-semibold text-zinc-700">Release fingerprint</summary>
                <dl data-testid="activation-release-fingerprint" className="mt-2 space-y-1 font-mono text-[10px] text-zinc-600">
                  {Object.entries(activationReview.manifest).map(([key, value]) => <div key={key} className="break-all"><dt className="inline font-sans font-semibold">{key}: </dt><dd className="inline">{value}</dd></div>)}
                </dl>
              </details>}
            </details>
            {activationReview.enabled && <label className="flex cursor-pointer items-start gap-2.5 border border-zinc-300 bg-white p-3 text-xs leading-relaxed">
              <input
                data-testid="activation-understanding-checkbox"
                type="checkbox"
                className="mt-0.5 h-4 w-4 shrink-0 accent-zinc-900"
                checked={activationAcknowledged}
                disabled={activation.isPending || !!activationSuccess}
                onChange={event => setActivationAcknowledged(event.target.checked)}
              />
              <span>I understand that activation applies to new messages only, earlier messages need staff attention, and staff confirms appointments—payment never books them.</span>
            </label>}
          </div>
          {activationError && <div role="alert" data-testid="activation-confirmation-error" className="border border-amber-300 bg-amber-50 p-3 text-xs text-amber-950">
            <p className="font-semibold">No activation change was confirmed. Review is still open.</p>
            <p className="mt-1 break-words">{activationError}</p>
            <button type="button" data-testid="activation-refresh-review" className="mt-2 inline-flex items-center gap-1.5 font-semibold underline disabled:opacity-50" onClick={refreshActivationReview} disabled={refreshingActivationReview || activation.isPending}>
              <RefreshCw className={`h-3 w-3 ${refreshingActivationReview ? "animate-spin" : ""}`} />
              {refreshingActivationReview ? "Refreshing setup…" : "Refresh and review again"}
            </button>
            {refreshingActivationReview && <p role="status" className="mt-1 text-zinc-600">The previous confirmation has been discarded. Confirm again after reviewing the refreshed revision.</p>}
          </div>}
        </>}
        {activationSuccess && <div role="status" data-testid="activation-confirmation-success" className="space-y-2 border border-emerald-300 bg-emerald-50 p-4 text-sm text-emerald-950">
          <p className="font-semibold">{persistedOperational ? "Automatic quotation is operational." : "Automatic quotation is off."}</p>
          <p className="text-xs leading-relaxed">Persisted server state: operational {String(persistedOperational ?? "not reported")} · requested {String(activationSuccess.requestedOn ?? "not reported")}.</p>
          <p className="text-xs leading-relaxed"><strong>New-message boundary:</strong> {readableBoundary || "The server persisted the boundary; no readable timestamp was returned."}</p>
          <p className="text-xs leading-relaxed">Earlier messages remain for staff attention. Staff confirms every appointment; payment never books.</p>
        </div>}
        <DialogFooter className="sticky bottom-0 gap-2 border-t border-zinc-100 bg-white pt-3 sm:gap-2">
          {activationSuccess ? <button type="button" data-testid="activation-confirmation-done" className={buttonClass} onClick={closeActivationReview}>Done</button> : <>
            <button type="button" data-testid="activation-confirmation-cancel" className="inline-flex items-center justify-center border border-zinc-300 bg-white px-3 py-2 text-xs font-semibold text-zinc-700 hover:bg-zinc-50 disabled:opacity-50" onClick={closeActivationReview} disabled={activation.isPending}>Cancel</button>
            <button
              type="button"
              data-testid="activation-confirmation-submit"
              className={buttonClass}
              disabled={!activationReview || !!activationError || activation.isPending || refreshingActivationReview || (activationReview.enabled && !activationAcknowledged)}
              onClick={submitActivation}
            >{activation.isPending ? "Saving activation…" : activationReview?.enabled ? "Confirm activation" : "Confirm deactivation"}</button>
          </>}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  </section>;
}

export function ReviewDraftPanel({ quoteId }: { quoteId: number }) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const queryKey = ["/api/admin/whatsapp-first/reviews", quoteId];
  const { data, isLoading, error, refetch } = useQuery<{
    draft: ReviewDraft;
    facts?: Record<string, unknown>;
    lines: Array<{
      key: string;
      savedItemId?: number;
      name: string;
      quantity?: number | string;
      unit?: string;
      serviceType: string;
      catalogItemId?: number | null;
      unitPrice?: number | string | null;
      remark?: string;
      hasSavedPrice?: boolean;
      priceReason?: string;
    }>;
    questions?: string[];
    questionLabels?:Record<string,string>;
    charges?: string[];
    catalogOptions?: CatalogOption[];
    approvedQuote?: any;
  }>({
    queryKey,
    queryFn: async () => (await apiRequest("GET", `/api/admin/whatsapp-first/reviews/${quoteId}`)).json(),
  });
  const [lines, setLines] = useState<ReviewLine[]>([]);
  const [facts, setFacts] = useState<Record<string, string>>({});
  const factTypes = useRef<Record<string, "number" | "boolean" | "string">>({});
  const [answers, setAnswers] = useState<string[]>([]);
  const [resolutions, setResolutions] = useState<Resolution[]>([]);
  const [approved, setApproved] = useState<any>(null);
  const [approvalError, setApprovalError] = useState<string | null>(null);
  const [reviewSummary,setReviewSummary]=useState("");
  const initializedFor = useRef<number | null>(null);
  const loadedRevision=useRef<{version:number;revision:string}|null>(null);
  const approvalLock = useRef(false);
  const requestKey = useRef("");
  const [selectedCatalog, setSelectedCatalog] = useState<Record<string, string>>({});
  const safeFactLabels: Record<string, string> = {
    customerName: "Customer name", customer_name: "Customer name",
    customer: "Customer name",
    customerPhone: "Customer phone", customer_phone: "Customer phone",
    phone: "Customer phone",
    address: "Installation address", installationAddress: "Installation address",
    installation_address: "Installation address", location: "Location",
    jobAddress: "Job address", toAddress: "Delivery address",
    floorLevel: "Floor level", hasLift: "Lift available",
    destinationFloor: "Destination floor", destinationLift: "Destination lift",
    itemLocation: "Item location",
    postalCode: "Postal code", postal_code: "Postal code", unitNumber: "Unit number",
    unit_number: "Unit number", sourceAddress: "Collection address", source_address: "Collection address",
    destinationAddress: "Delivery address", destination_address: "Delivery address",
    pickupLocation: "Collection location", pickup_location: "Collection location",
    deliveryLocation: "Delivery location", delivery_location: "Delivery location",
  };
  useEffect(() => {
    if (!data?.draft || initializedFor.current === data.draft.id) return;
    initializedFor.current = data.draft.id;
    loadedRevision.current={version:data.draft.version,revision:data.draft.expectedRevision};
    setLines((data.lines || []).map(line => ({
      ...line,
      quantity: line.quantity == null ? "" : String(line.quantity),
      unitPrice: line.unitPrice == null ? "" : String(line.unitPrice),
      remark: line.remark || "",
      priceReason: line.priceReason || "",
      hasSavedPrice: Boolean(line.hasSavedPrice),
    })));
    const safeFacts = Object.entries(data.facts || {})
      .filter(([key, value]) => safeFactLabels[key] && (typeof value === "string" || typeof value === "number" || typeof value === "boolean"));
    factTypes.current = Object.fromEntries(safeFacts.map(([key, value]) => [key, typeof value==="number"?"number":typeof value==="boolean"?"boolean":"string"]));
    setFacts(Object.fromEntries(safeFacts.map(([key, value]) => [key, String(value)])));
    setAnswers((data.questions || []).map(() => ""));
    setResolutions((data.charges || []).map(chargeKey => ({ chargeKey, mode: "approve", amount: "", reason: "" })));
    setSelectedCatalog(Object.fromEntries((data.lines || []).map(line => [line.key, line.catalogItemId == null ? "" : String(line.catalogItemId)])));
    setApproved(null);
    setApprovalError(null);
    requestKey.current = `review-${data.draft.id}-${data.draft.version}-${Date.now()}`;
  }, [data?.draft?.id]);
  const postFacts = () => Object.fromEntries(Object.entries(facts).flatMap<[string,string|number|boolean]>(([key, value]) => {
    const type = factTypes.current[key];
    if (type === "boolean") return [[key, value === "true"]];
    if (type === "number") return value.trim() === "" ? [] : [[key, Number(value)]];
    return [[key, value]];
  }));
  const approve = useMutation({
    mutationFn: async () => {
      if (!data?.draft) throw new Error("Review draft is unavailable.");
      if(loadedRevision.current?.revision!==data.draft.expectedRevision)throw new Error("The saved quotation changed while you were reviewing it. Your entries are retained; open the current quotation before approving.");
      if (lines.some(line => !line.name.trim() || !line.unit?.trim() || !line.quantity.trim() || !Number.isFinite(Number(line.quantity)) || Number(line.quantity) <= 0)) throw new Error("Every saved item needs a work description, unit and positive quantity.");
      if (lines.some(line => line.unitPrice.trim() !== "" && !/^\d+(?:\.\d{1,2})?$/.test(line.unitPrice.trim()))) throw new Error("Finish each unit price using no more than two decimal places, for example 60.25. Your entries are retained.");
      const unanswered=answers.findIndex((answer,index)=>(data.questions||[])[index]?.trim()&&!answer.trim());
      if(unanswered>=0)throw new Error(`Record a staff answer for: ${data.questionLabels?.[data.questions![unanswered]]||data.questions![unanswered]}`);
      if (resolutions.some(row => !row.reason.trim() || (row.mode === "approve" && (!row.amount.trim() || !Number.isFinite(Number(row.amount)) || Number(row.amount) <= 0)))) throw new Error("Resolve each existing charge with an amount and reason, or waive it with a reason.");
      if (!requestKey.current) requestKey.current = `review-${data.draft.id}-${data.draft.version}-${Date.now()}`;
      const response = await apiRequest("POST", `/api/admin/whatsapp-first/reviews/${quoteId}/approve`, {
        expectedVersion: loadedRevision.current!.version,
        expectedRevision: loadedRevision.current!.revision,
        requestKey: requestKey.current,
        lines: lines.map(line => ({
          key: line.key,
          savedItemId: line.savedItemId,
          name: line.name.trim(),
          quantity: Number(line.quantity),
          unit: line.unit,
          serviceType: line.serviceType,
          catalogItemId: selectedCatalog[line.key] ? Number(selectedCatalog[line.key]) : (line.catalogItemId ?? undefined),
          unitPrice: line.unitPrice.trim() === "" ? undefined : Number(line.unitPrice),
          remark: line.remark.trim(),
          reason: line.priceReason.trim() || undefined,
        })),
        resolutions: resolutions.map(row => ({ ...row, amount: row.mode === "approve" ? Number(row.amount) : 0 })),
        facts: postFacts(),
        answers: (data.questions || []).map((question, index) => ({ question, answer: answers[index]?.trim() || "" })),
        preserveSavedCharges: true,
        share: false,
        scopeConfirmed: true,
        scopeReason:reviewSummary.trim(),
      });
      return response.json();
    },
    onSuccess: result => {
      setApproved(result);
      setApprovalError(null);
      toast({ title: "Quotation approved", description: "Review the approved quotation before sharing it with the customer." });
      qc.invalidateQueries({ queryKey: ["/api/quotes"] });
      qc.invalidateQueries({ queryKey: ["/api/quotes/:id", quoteId] });
      qc.invalidateQueries({ queryKey: ["/api/admin/whatsapp-first/conversations"] });
    },
    onError: (e: Error) => {
      setApprovalError(e.message || "Approval was not confirmed. Your review remains available.");
      toast({ title: "Approval not saved", description: e.message, variant: "destructive" });
    },
  });
  const editLine = (index: number, patch: Partial<ReviewLine>) => setLines(current => current.map((line, i) => i === index ? { ...line, ...patch } : line));
  const editFact = (key: string, value: string) => setFacts(current => ({ ...current, [key]: value }));
  const issued = approved || data?.approvedQuote;
  const money = (value: unknown) => value == null || value === "" ? "—" : `S$${Number(value).toFixed(2)}`;
  const reviewedTotal=data&&lines.every(l=>/^\d+(?:\.\d{1,2})?$/.test(l.unitPrice.trim())&&Number(l.quantity)>0)
    ? Number(data.draft.total)+lines.reduce((n,l)=>n+Number(l.quantity)*Number(l.unitPrice),0)
      -(data.lines||[]).reduce((n,l)=>n+Number(l.quantity)*Number(l.unitPrice||0),0)
      +resolutions.filter(r=>r.mode==="approve").reduce((n,r)=>n+(Number(r.amount)||0),0):undefined;
  const beginApproval = () => {
    if (approvalLock.current || approve.isPending || issued) return;
    approvalLock.current = true;
    setApprovalError(null);
    approve.mutate();
  };
  useEffect(() => {
    if (!approve.isPending) approvalLock.current = false;
  }, [approve.isPending]);
  return <section className={`${card} overflow-hidden`} data-testid={`review-draft-${quoteId}`}>
    <div className="flex items-center gap-3 border-b border-zinc-200 px-4 py-3"><ShieldCheck className="h-4 w-4 text-amber-700" /><div><h3 className="text-sm font-bold text-zinc-900">Quotation review</h3><p className="text-[11px] text-zinc-500">Check saved work, prices and customer clarifications before approval</p></div></div>
    <div className="space-y-4 p-4">
      {isLoading && <div className="space-y-2 animate-pulse"><div className="h-5 w-1/2 bg-zinc-100" /><div className="h-20 bg-zinc-100" /></div>}
      <ErrorNote error={error} retry={() => refetch()} />
      {!isLoading && !error && !data && <p className="text-sm text-zinc-500">No review draft is available.</p>}
      {data?.draft && <>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 bg-zinc-50 p-3 text-xs">
          <strong className="text-zinc-900">{data.draft.referenceNo || `Draft ${data.draft.id}`}</strong>
          <span className="text-zinc-500">Version {data.draft.version}</span>
          <span className="ml-auto font-semibold text-zinc-700">{data.draft.pricingPending?"Proposed components":"Draft total"} {money(data.draft.total)}{data.draft.pricingPending?" · final pricing pending":""}</span>
        </div>
        {Object.keys(facts).length > 0 && <section><h4 className="mb-2 text-xs font-bold uppercase tracking-wide text-zinc-600">Customer & location</h4><div className="grid gap-2 sm:grid-cols-2">{Object.entries(facts).map(([key, value]) => <label key={key}><span className={labelClass}>{safeFactLabels[key]}</span>{factTypes.current[key] === "boolean" ? <span className="flex h-9 items-center gap-2 text-sm text-zinc-800"><input type="checkbox" checked={value === "true"} onChange={e => editFact(key, String(e.target.checked))} />Yes</span> : <input className={inputClass} type={factTypes.current[key] === "number" ? "number" : "text"} value={value} onChange={e => editFact(key, e.target.value)} />}</label>)}</div><p className="mt-1 text-[10px] text-zinc-500">Dates and appointment times remain staff-confirmed.</p></section>}
        <section>
          <div className="mb-2 flex flex-wrap items-baseline justify-between gap-2"><h4 className="text-xs font-bold uppercase tracking-wide text-zinc-600">Saved items · {lines.length}</h4><p className="text-[11px] text-zinc-500">Transport {data.draft.transportPending?"pending":money(data.draft.transportFee)} · Discount −{money(data.draft.promoDiscount)}</p></div>
          {!lines.length ? <p className="border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">No saved items are available. Add and save the work items before approving a quotation.</p> : <div className="space-y-3">{lines.map((line, index) => <article key={`${line.key}-${index}`} className="border border-zinc-200 p-3">
            <div className="mb-3 flex flex-wrap items-start justify-between gap-2"><div><p className="text-sm font-bold text-zinc-900">Saved item {index + 1}</p><p className="text-[11px] text-zinc-500">{({install:"Assembly / installation",dismantle:"Dismantling",relocate:"Relocation work — see scope",dismantle_install:"Dismantle and reassemble",dispose:"Disposal",dismantle_dispose:"Dismantle and dispose",manual:"Work as described"} as Record<string,string>)[line.serviceType]||"Work as described"}{line.hasSavedPrice ? " · saved price" : " · price needed"}</p></div><span className="text-xs font-semibold text-zinc-700">{line.quantity || "—"} {line.unit || ""} × {line.unitPrice.trim() ? money(line.unitPrice) : "price needed"}</span></div>
            <div className="grid gap-2 sm:grid-cols-2">
              <label className="sm:col-span-2"><span className={labelClass}>Work description</span><input className={inputClass} value={line.name} onChange={e => editLine(index, { name: e.target.value })} /></label>
              <label><span className={labelClass}>Quantity</span><input className={inputClass} inputMode="decimal" value={line.quantity} onChange={e => editLine(index, { quantity: e.target.value })} placeholder="e.g. 2" /></label>
              <label><span className={labelClass}>Unit</span><input className={inputClass} value={line.unit || ""} onChange={e => editLine(index, { unit: e.target.value })} placeholder="items / sets / visits" /></label>
              <label><span className={labelClass}>Unit price (S$)</span><input className={inputClass} inputMode="decimal" value={line.unitPrice} onChange={e => editLine(index, { unitPrice: e.target.value })} placeholder="Saved amount" /></label>
              <label><span className={labelClass}>Work type</span><select className={inputClass} value={line.serviceType} onChange={e=>editLine(index,{serviceType:e.target.value})}>{!["install","dismantle","relocate","dismantle_install","manual"].includes(line.serviceType)&&<option value={line.serviceType}>Saved scope — as described</option>}<option value="install">Assembly / installation</option><option value="dismantle">Dismantling</option><option value="relocate">Relocation work — see scope</option><option value="dismantle_install">Dismantle and reassemble</option><option value="manual">Work as described (manual price)</option></select></label>
              <label><span className={labelClass}>Approved catalogue item · optional</span><select className={inputClass} value={selectedCatalog[line.key] || ""} onChange={e => setSelectedCatalog(current => ({ ...current, [line.key]: e.target.value }))}><option value="">Keep existing selection</option>{(data.catalogOptions || []).map(option => <option key={option.id} value={String(option.id)}>{option.name} · {option.serviceType} · list {money(option.basePrice)}</option>)}</select></label>
              <label className="sm:col-span-2"><span className={labelClass}>Work details / remark</span><textarea className="w-full border border-zinc-300 bg-white p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]" rows={2} value={line.remark} onChange={e => editLine(index, { remark: e.target.value })} placeholder="Specific scope, access, assembly or installation notes" /></label>
              <label className="sm:col-span-2"><span className={labelClass}>Internal price note · optional</span><input className={inputClass} value={line.priceReason} onChange={e => editLine(index, { priceReason: e.target.value })} placeholder="Optional context; your changes are recorded automatically" /></label>
            </div>
          </article>)}</div>}
        </section>
        {!!data.questions?.length && <section className="border-l-2 border-amber-500 bg-amber-50/60 p-3">
          <h4 className="text-xs font-bold uppercase tracking-wide text-amber-900">Outstanding scope questions · text answers only</h4>
          <div className="mt-2 space-y-3">{data.questions.map((question, index) => <div key={`${question}-${index}`} className="border-t border-amber-200 pt-2"><p className="text-xs font-semibold text-zinc-800">{data.questionLabels?.[question]||question}</p><label className="mt-2 block"><span className={labelClass}>Staff answer / review decision</span><textarea className="w-full border border-zinc-300 bg-white p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]" rows={2} value={answers[index] || ""} onChange={e => setAnswers(current => current.map((value, i) => i === index ? e.target.value : value))} placeholder="Record what was confirmed; no monetary charge." /></label></div>)}</div>
        </section>}
        {!!data.charges?.length && <section><h4 className="mb-2 text-xs font-bold uppercase tracking-wide text-amber-800">Additional requested charges</h4><p className="mb-2 text-[11px] text-zinc-500">Price only the additional requested work below. Existing saved charges are preserved; scope questions are not monetary charges.</p><div className="space-y-2">{resolutions.map((row, index) => <div key={row.chargeKey} className="grid gap-2 border border-amber-200 bg-amber-50/50 p-3 sm:grid-cols-[1fr_130px_130px]">
          <div><p className="text-xs font-bold text-zinc-900">{row.chargeKey}</p><label className="mt-2 block"><span className={labelClass}>Reason</span><input className={inputClass} value={row.reason} onChange={e => setResolutions(current => current.map((value, i) => i === index ? { ...value, reason: e.target.value } : value))} placeholder="Why approve or waive this charge?" /></label></div>
          <label><span className={labelClass}>Resolution</span><select className={inputClass} value={row.mode} onChange={e => setResolutions(current => current.map((value, i) => i === index ? { ...value, mode: e.target.value as Resolution["mode"] } : value))}><option value="approve">Approve charge</option><option value="waive">Waive charge</option></select></label>
          <label><span className={labelClass}>Amount (S$)</span><input className={inputClass} inputMode="decimal" disabled={row.mode === "waive"} value={row.amount} onChange={e => setResolutions(current => current.map((value, i) => i === index ? { ...value, amount: e.target.value } : value))} placeholder={row.mode === "waive" ? "Waived" : "Required"} /></label>
        </div>)}</div></section>}
        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-zinc-200 pt-3">
          <label className="w-full"><span className={labelClass}>Internal review note · optional</span><textarea className={inputClass} rows={2} value={reviewSummary} onChange={e=>setReviewSummary(e.target.value)} placeholder="Optional context; approval and price changes are recorded automatically. Appointment remains staff-confirmed." /></label>
          <p className="text-xs text-zinc-600">Approve creates a quotation only. It does not send a message or book a date.</p>
          <div className="text-right"><p className="mb-2 text-sm font-bold">{data.draft.pricingPending?"Proposed components:":"Reviewed total:"} {reviewedTotal===undefined?"complete item prices":money(reviewedTotal)} <span className="text-xs font-normal">{data.draft.pricingPending?"(not yet saved; final pricing pending)":"(not yet saved)"}</span></p><button type="button" className={buttonClass} disabled={!!issued || approve.isPending || !lines.length} onClick={beginApproval}>{approve.isPending ? "Approving quotation…" : "Approve quotation for sharing"}</button></div>
        </div>
        {approve.isPending && <p role="status" className="border border-zinc-200 bg-zinc-50 p-2.5 text-xs text-zinc-700">Approval is being saved. Keep this panel open; your reviewed values are retained.</p>}
        {approvalError && <div role="alert" className="border border-red-200 bg-red-50 p-3 text-xs text-red-800"><p className="font-semibold">Approval was not confirmed. Your edits are still here.</p><p className="mt-1">{approvalError}</p><button type="button" className="mt-2 font-semibold underline disabled:opacity-50" disabled={approve.isPending} onClick={beginApproval}>Retry approval</button></div>}
        {issued && <div className="border border-emerald-200 bg-emerald-50 p-3 text-xs text-emerald-950">
          <p className="flex items-center gap-2 font-bold"><CheckCircle2 className="h-4 w-4" />Quotation approved</p>
          <p className="mt-1">Reference {issued.referenceNo || data.draft.referenceNo || "—"} · Version {issued.version ?? data.draft.version} · Total {money(issued.total ?? data.draft.total)}</p>
          <p className="mt-1">No message was sent and no date was booked. Open the approved quotation to review it, then share it explicitly if appropriate.</p>
          {issued.secureUrl && <a className="mt-2 inline-flex items-center gap-1 font-semibold underline" href={issued.secureUrl} target="_blank" rel="noreferrer">Open secure customer quote <ExternalLink className="h-3 w-3" /></a>}
          {(issued.id || issued.quoteId || issued.quote?.id) && <a className="ml-4 inline-flex items-center gap-1 font-semibold underline" href={`/admin/quotes/${issued.id || issued.quoteId || issued.quote.id}`}>Review approved quotation <ExternalLink className="h-3 w-3" /></a>}
        </div>}
      </>}
    </div>
  </section>;
}

export function DeliveryRecovery({ phone }: { phone: string }) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const queryKey = ["/api/admin/whatsapp-first/conversations", phone];
  const { data, isLoading, error, refetch } = useQuery<any>({
    queryKey,
    queryFn: async () => (await apiRequest("GET", `/api/admin/whatsapp-first/conversations/${encodeURIComponent(phone)}`)).json(),
    enabled: !!phone,
    refetchInterval: 30_000,
  });
  const [reasonById, setReasonById] = useState<Record<number, string>>({});
  const [providerIdById, setProviderIdById] = useState<Record<number, string>>({});
  const [notSubmittedById, setNotSubmittedById] = useState<Record<number, boolean>>({});
  const [consentReason, setConsentReason] = useState("");
  const [purpose, setPurpose] = useState<"quote" | "payment" | "booking" | "reminder">("quote");
  const deliveryUpdate = async () => { await qc.invalidateQueries({ queryKey }); };
  const retry = useMutation({
    mutationFn: ({ id, reason }: { id: number; reason: string }) => apiRequest("POST", `/api/admin/whatsapp-first/messages/${id}/retry`, { reason }),
    onSuccess: async () => { toast({ title: "Retry requested" }); await deliveryUpdate(); },
    onError: (e: Error) => toast({ title: "Retry was not accepted", description: e.message, variant: "destructive" }),
  });
  const reconcile = useMutation({
    mutationFn: ({ id, reason, providerMessageId, notSubmitted }: { id: number; reason: string; providerMessageId?: string; notSubmitted?: boolean }) =>
      apiRequest("POST", `/api/admin/whatsapp-first/messages/${id}/reconcile`, { reason, providerMessageId: providerMessageId || undefined, notSubmitted: notSubmitted || undefined }),
    onSuccess: async () => { toast({ title: "Delivery evidence recorded" }); await deliveryUpdate(); },
    onError: (e: Error) => toast({ title: "Could not reconcile delivery", description: e.message, variant: "destructive" }),
  });
  const recordConsent = useMutation({
    mutationFn: () => apiRequest("POST", `/api/admin/whatsapp-first/conversations/${encodeURIComponent(phone)}/consent`, { reason: consentReason.trim(),customerEvidence:consentReason.trim(), purpose }),
    onSuccess: async () => { toast({ title: "Conversation consent recorded" }); setConsentReason(""); await deliveryUpdate(); },
    onError: (e: Error) => toast({ title: "Consent was not recorded", description: e.message, variant: "destructive" }),
  });
  const messages = (data?.outboundAttempts ?? data?.messages ?? []).filter(isOutboundAttempt);
  const recoveryFacts = data?.facts && typeof data.facts === "object" ? data.facts as Record<string, any> : {};
  const statusText = (msg: any) => String(msg.deliveryStatus || "unknown").toLowerCase();
  return <section className={`${card} overflow-hidden`} data-testid={`delivery-recovery-${phone}`}>
    <div className="flex items-center gap-2 border-b border-zinc-200 px-3 py-2.5"><Truck className="h-4 w-4 text-zinc-700" /><div><h3 className="text-xs font-bold text-zinc-900">Delivery recovery</h3><p className="text-[10px] text-zinc-500">Evidence first · no blind duplicate sends</p></div><button type="button" onClick={() => refetch()} className="ml-auto p-1.5 text-zinc-500 hover:bg-zinc-100" aria-label="Refresh delivery evidence"><RefreshCw className="h-3.5 w-3.5" /></button></div>
    <div className="space-y-3 p-3">
      {isLoading && <div className="space-y-2 animate-pulse"><div className="h-8 bg-zinc-100" /><div className="h-12 bg-zinc-100" /></div>}
      <ErrorNote error={error} retry={() => refetch()} />
      {!isLoading && !error && data && <>
        <div className="flex flex-wrap gap-x-3 gap-y-1 bg-zinc-50 p-2 text-[10px] text-zinc-600">
          <span>Owner: <b>{data.ownership || "unknown"}</b></span><span>Window: <b>{data.window?.open ? "open" : "closed"}</b>{!data.window?.open && data.window?.reason ? ` · ${data.window.reason}` : ""}</span>
          {data.currentQuote?.referenceNo && <span>Quote: <b>{data.currentQuote.referenceNo}</b></span>}
          {data.counters && <span className="ml-auto">Attempts {data.counters.attempts ?? "—"} · failed {data.counters.failed ?? "—"}</span>}
        </div>
        {Array.isArray(data.reviewReasons) && data.reviewReasons.length > 0 && <div className="border border-amber-200 bg-amber-50 p-2 text-[10px] text-amber-900"><b>Review reasons</b><ul className="mt-1 list-disc pl-4">{data.reviewReasons.map((reason: string, i: number) => <li key={`${reason}-${i}`}>{reason}</li>)}</ul></div>}
        {Object.keys(recoveryFacts).length > 0 && <details className="border border-zinc-200 bg-white p-2">
          <summary className="cursor-pointer text-[10px] font-bold text-zinc-700">Conversation facts · {Object.keys(recoveryFacts).length}</summary>
          <dl className="mt-2 grid gap-2 sm:grid-cols-2">{Object.entries(recoveryFacts).map(([key, value]) => <div key={key} className="border-t border-zinc-100 pt-1"><dt className="text-[9px] font-semibold uppercase tracking-wide text-zinc-500">{key.replace(/_/g, " ")}</dt><dd className="whitespace-pre-wrap break-words text-[10px] text-zinc-800">{Array.isArray(value) ? value.map(v => typeof v === "object" ? JSON.stringify(v) : String(v)).join(", ") : value && typeof value === "object" ? JSON.stringify(value) : String(value ?? "Not recorded")}</dd></div>)}</dl>
        </details>}
        {messages.length ? <div className="max-h-72 space-y-2 overflow-y-auto">{messages.map((msg: any) => {
          const status = statusText(msg);
          const safelyRetryable = ["failed", "blocked", "delivery_failed", "blocked_outside_window"].includes(status);
          const ambiguous = ["unknown", "sending", "pending", "processing"].includes(status);
          return <article key={msg.id} className="border border-zinc-200 p-2.5">
            <div className="flex items-center gap-2"><span className={`text-[9px] font-bold uppercase ${safelyRetryable ? "text-red-700" : ambiguous ? "text-amber-800" : "text-zinc-600"}`}>{status}</span><span className="text-[10px] text-zinc-500">#{msg.id} · attempts {msg.attempts ?? 0}</span></div>
            <p className="mt-1 line-clamp-3 whitespace-pre-wrap text-[11px] text-zinc-700">{msg.body || "Message body unavailable"}</p>
            {msg.deliveryError && <p className="mt-1 text-[10px] text-red-700">Delivery error: {msg.deliveryError}</p>}
            {safelyRetryable && <div className="mt-2 space-y-1.5"><input className={inputClass} value={reasonById[msg.id] || ""} onChange={e => setReasonById(v => ({ ...v, [msg.id]: e.target.value }))} placeholder="Why is a retry safe? Required" /><button type="button" className="border border-red-300 px-2.5 py-1.5 text-[10px] font-bold text-red-800 hover:bg-red-50 disabled:opacity-40" disabled={!reasonById[msg.id]?.trim() || retry.isPending} onClick={() => retry.mutate({ id: msg.id, reason: reasonById[msg.id].trim() })}>Retry definite failure</button></div>}
            {ambiguous && <div className="mt-2 space-y-1.5 border-l-2 border-amber-500 bg-amber-50/70 p-2">
              <p className="text-[10px] font-bold text-amber-950">Reconcile first — sending may already have reached WhatsApp. Never retry an unknown or sending message.</p>
              <input className={inputClass} value={reasonById[msg.id] || ""} onChange={e => setReasonById(v => ({ ...v, [msg.id]: e.target.value }))} placeholder="Evidence / reconciliation reason (required)" />
              <input className={inputClass} value={providerIdById[msg.id] || ""} onChange={e => setProviderIdById(v => ({ ...v, [msg.id]: e.target.value }))} placeholder="Provider message ID, if verified" />
              <label className="flex items-center gap-2 text-[10px] text-amber-950"><input type="checkbox" checked={!!notSubmittedById[msg.id]} onChange={e => setNotSubmittedById(v => ({ ...v, [msg.id]: e.target.checked }))} />Verified evidence says it was not submitted</label>
              <button type="button" className="border border-amber-400 px-2.5 py-1.5 text-[10px] font-bold text-amber-950 hover:bg-amber-100 disabled:opacity-40" disabled={!reasonById[msg.id]?.trim() || (!providerIdById[msg.id]?.trim() && !notSubmittedById[msg.id]) || reconcile.isPending} onClick={() => reconcile.mutate({ id: msg.id, reason: reasonById[msg.id].trim(), providerMessageId: providerIdById[msg.id], notSubmitted: notSubmittedById[msg.id] })}>Record delivery evidence</button>
            </div>}
          </article>;
        })}</div> : <p className="border border-dashed border-zinc-300 p-3 text-center text-[11px] text-zinc-500">No outgoing delivery attempts in this snapshot.</p>}
        <div className="border-t border-zinc-200 pt-3">
          <p className="text-[11px] font-bold text-zinc-800">Outside-window consent</p><p className="mt-0.5 text-[10px] text-zinc-500">Record explicit conversation consent separately. This does not create template approval or send a message.</p>
          <div className="mt-2 grid gap-2 sm:grid-cols-[130px_1fr]"><select className={inputClass} value={purpose} onChange={e => setPurpose(e.target.value as typeof purpose)}><option value="quote">Quote</option><option value="payment">Payment</option><option value="booking">Booking</option><option value="reminder">Reminder</option></select><input className={inputClass} value={consentReason} onChange={e => setConsentReason(e.target.value)} placeholder="Consent evidence / reason" /></div>
          <button type="button" className="mt-2 border border-zinc-300 px-2.5 py-1.5 text-[10px] font-semibold text-zinc-700 hover:bg-zinc-50 disabled:opacity-40" disabled={!consentReason.trim() || recordConsent.isPending} onClick={() => recordConsent.mutate()}>{recordConsent.isPending ? "Recording…" : "Record consent for this conversation"}</button>
        </div>
      </>}
    </div>
  </section>;
}
