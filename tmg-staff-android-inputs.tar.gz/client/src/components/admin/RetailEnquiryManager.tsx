import { useMemo, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import {
  AlertCircle, Archive, ArrowUpRight, Check, ChevronRight, ClipboardCheck,
  FolderOpen, RotateCcw, Search, ShieldCheck, Trash2, X,
} from "lucide-react";
import { DASHBOARD_QUOTES_KEY } from "@shared/dashboard";
import { api } from "@shared/routes";
import { queryClient } from "@/lib/queryClient";

const API_BASE = (import.meta.env.VITE_API_BASE as string) || "";
const LIST_KEY = ["/api/admin/retail-enquiries"];

const VIEWS = [
  { key: "active", label: "Active", icon: FolderOpen },
  { key: "archive", label: "Archived", icon: Archive },
  { key: "backlog", label: "Needs Review", icon: ClipboardCheck },
  { key: "project", label: "Project Invoices", icon: ArrowUpRight },
] as const;

type ViewKey = typeof VIEWS[number]["key"];
type Outcome = "declined" | "duplicate" | "dormant" | "review_backlog" | "restore";
type Enquiry = {
  id: number;
  referenceNo: string;
  customerName: string;
  status: string;
  total: number;
  jobSummary: string;
  nextAction: string;
  priceReady: boolean;
  view: ViewKey;
  outcome?: string;
  reason?: string;
  canonicalQuoteId?: number;
  lastCustomerAt?: string;
  lastMeaningfulAt?: string;
  protectedReasons: string[];
  fingerprint: string;
  candidate?: { outcome: string; reason: string; canonicalQuoteId?: number };
};
type EnquiryResponse = {
  rows: Enquiry[];
  counts: Record<ViewKey | "operations", number>;
  productionMutated: false;
};
type Decision = { id: number; outcome: Outcome; reason: string; canonicalQuoteId?: number };
type PreviewRow = { id: number; fingerprint: string; allowed: boolean; reasons: string[]; decision: Decision };
type PreviewResponse = { rows: PreviewRow[]; before: Record<string, number>; after: Record<string, number> };
type Draft = { outcome: Outcome; reason: string; canonicalQuoteId: string };
type DeletePreviewRow = {
  id: number;
  referenceNo: string;
  fingerprint: string;
  allowed: boolean;
  reasons: string[];
};
type DeletePreviewResponse = { rows: DeletePreviewRow[] };
type DeleteResult = {
  id: number;
  referenceNo: string;
  outcome: "deleted" | "already_deleted" | "blocked" | "failed";
  reasons: string[];
};
type DeleteResponse = { results: DeleteResult[] };

const OUTCOMES: { value: Outcome; label: string }[] = [
  { value: "review_backlog", label: "Needs review (default)" },
  { value: "declined", label: "Declined" },
  { value: "duplicate", label: "Duplicate" },
  { value: "dormant", label: "Dormant" },
  { value: "restore", label: "Restore to Active" },
];

function money(value: number) {
  return `$${Number(value || 0).toLocaleString("en-SG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function activityLabel(value?: string) {
  if (!value) return "No activity recorded";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "No activity recorded";
  return date.toLocaleString("en-SG", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

function outcomeLabel(value?: string) {
  if (!value) return "";
  const labels: Record<string, string> = {
    declined: "Declined",
    duplicate: "Duplicate",
    dormant: "Dormant",
    review_backlog: "Needs review",
    restore: "Restored",
  };
  return labels[value] || "Recorded outcome";
}

async function responseJson<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, { credentials: "include", ...init });
  if (!response.ok) {
    const payload = await response.json().catch(() => null);
    const error = new Error(payload?.message || payload?.error || `Request failed (${response.status})`);
    (error as Error & { status?: number }).status = response.status;
    throw error;
  }
  return response.json() as Promise<T>;
}

const buttonBase = "inline-flex min-h-9 items-center justify-center gap-1.5 border px-2.5 text-[9px] font-black uppercase tracking-[0.09em] transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black disabled:cursor-not-allowed disabled:opacity-40";

export function RetailEnquiryManager() {
  const [limit, setLimit] = useState(20);
  const [view, setView] = useState<ViewKey>("active");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Set<number>>(() => new Set());
  const [drafts, setDrafts] = useState<Record<number, Draft>>({});
  const [preview, setPreview] = useState<PreviewResponse | null>(null);
  const [notice, setNotice] = useState("");
  const [deletePreview, setDeletePreview] = useState<DeletePreviewResponse | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [typedReferences, setTypedReferences] = useState<Record<number, string>>({});
  const [deleteIssue, setDeleteIssue] = useState("");
  const [deleteResults, setDeleteResults] = useState<DeleteResult[] | null>(null);
  const { data, isLoading, isError, error, refetch, isFetching } = useQuery<EnquiryResponse>({
    queryKey: LIST_KEY,
    queryFn: () => responseJson<EnquiryResponse>("/api/admin/retail-enquiries"),
  });

  const previewMutation = useMutation({
    mutationFn: (decisions: Decision[]) => responseJson<PreviewResponse>("/api/admin/retail-enquiries/preview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ decisions }),
    }),
    onSuccess: result => {
      setPreview(result);
      setNotice("");
    },
    onError: err => setNotice(`Preview failed: ${(err as Error).message}`),
  });
  const applyMutation = useMutation({
    mutationFn: (rows: PreviewRow[]) => responseJson<{ applied?: number }>("/api/admin/retail-enquiries/apply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rows }),
    }),
    onSuccess: async result => {
      setNotice(`Changes applied: ${result?.applied ?? preview?.rows.filter(row => row.allowed).length ?? 0}.`);
      setSelected(new Set());
      setPreview(null);
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: LIST_KEY }),
        queryClient.invalidateQueries({ queryKey: DASHBOARD_QUOTES_KEY }),
        queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] }),
      ]);
    },
    onError: err => setNotice(`Changes could not be confirmed. Your selection and preview are retained. ${(err as Error).message}`),
  });
  const deletePreviewMutation = useMutation({
    mutationFn: (ids: number[]) => responseJson<DeletePreviewResponse>("/api/admin/retail-enquiries/delete-preview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids }),
    }),
  });
  const deleteMutation = useMutation({
    mutationFn: (rows: { id: number; referenceNo: string; fingerprint: string }[]) => responseJson<DeleteResponse>("/api/admin/retail-enquiries/delete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rows }),
    }),
  });

  const visibleRows = useMemo(() => {
    const rows = (data?.rows || []).filter(row => row.view === view);
    const query = search.trim().toLowerCase();
    if (!query) return rows;
    return rows.filter(row => [
      row.customerName, row.referenceNo, row.jobSummary, row.nextAction, row.outcome, row.reason,
      ...row.protectedReasons,
    ].filter(Boolean).join(" ").toLowerCase().includes(query));
  }, [data?.rows, search, view]);

  const selectedRows = (data?.rows || []).filter(row => selected.has(row.id));
  const validDecisions = selectedRows.flatMap(row => {
    const draft = drafts[row.id];
    if (!draft || !draft.reason.trim()) return [];
    if (draft.outcome === "duplicate" && (!draft.canonicalQuoteId.trim() || !Number.isInteger(Number(draft.canonicalQuoteId)) || Number(draft.canonicalQuoteId) < 1)) return [];
    const decision: Decision = { id: row.id, outcome: draft.outcome, reason: draft.reason.trim() };
    if (draft.outcome === "duplicate" && draft.canonicalQuoteId.trim()) {
      decision.canonicalQuoteId = Number(draft.canonicalQuoteId);
    }
    return [decision];
  });
  const incompleteCount = selectedRows.length - validDecisions.length;
  const allowedCount = preview?.rows.filter(row => row.allowed).length || 0;
  const excludedCount = preview ? preview.rows.length - allowedCount : 0;

  const toggleSelected = (id: number) => {
    setSelected(previous => {
      const next = new Set(previous);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
    setPreview(null);
    setDeleteResults(null);
  };
  const updateDraft = (id: number, current: Enquiry, patch: Partial<Draft>) => {
    setDrafts(previous => ({
      ...previous,
      [id]: {
        outcome: (previous[id]?.outcome || current.candidate?.outcome || "review_backlog") as Outcome,
        reason: previous[id]?.reason ?? current.candidate?.reason ?? "",
        canonicalQuoteId: previous[id]?.canonicalQuoteId ?? String(current.candidate?.canonicalQuoteId ?? ""),
        ...patch,
      },
    }));
    setPreview(null);
  };
  const prepareAction = (ids: number[], outcome: Outcome) => {
    const rows = (data?.rows || []).filter(row => ids.includes(row.id));
    setSelected(new Set(ids));
    setDrafts(previous => {
      const next = { ...previous };
      rows.forEach(row => {
        next[row.id] = {
          outcome,
          reason: previous[row.id]?.reason || "",
          canonicalQuoteId: previous[row.id]?.canonicalQuoteId || "",
        };
      });
      return next;
    });
    setPreview(null);
    setDeleteResults(null);
    setNotice("");
  };
  const locallyProtected = (row: Enquiry) => (row.protectedReasons || []).length > 0;
  const previewDelete = async (ids: number[]) => {
    setDeleteIssue("");
    setDeleteResults(null);
    setTypedReferences({});
    try {
      const result = await deletePreviewMutation.mutateAsync(ids);
      setDeletePreview(result);
      setDeleteDialogOpen(true);
    } catch (err) {
      setDeleteIssue(`Could not check permanent deletion. Selection is unchanged. ${(err as Error).message}`);
    }
  };
  const allowedDeleteRows = (deletePreview?.rows || []).filter(row => {
    const source = data?.rows.find(item => item.id === row.id);
    return row.allowed && !(source && locallyProtected(source));
  });
  const canConfirmDelete = allowedDeleteRows.length > 0
    && allowedDeleteRows.every(row => typedReferences[row.id] === row.referenceNo)
    && !deletePreviewMutation.isPending
    && !deleteMutation.isPending;

  const confirmDelete = async () => {
    if (!deletePreview || !canConfirmDelete) return;
    setDeleteIssue("");
    try {
      const ids = deletePreview.rows.map(row => row.id);
      const fresh = await deletePreviewMutation.mutateAsync(ids);
      const currentRows = new Map(fresh.rows.map(row => [row.id, row]));
      const expected = new Map(deletePreview.rows.map(row => [row.id, row]));
      const changed = deletePreview.rows.length !== fresh.rows.length || deletePreview.rows.some(old => {
        const current = currentRows.get(old.id);
        return !current || current.referenceNo !== old.referenceNo || current.fingerprint !== old.fingerprint || current.allowed !== old.allowed;
      });
      setDeletePreview(fresh);
      if (changed) {
        setTypedReferences({});
        setDeleteIssue("The records changed since the preview. Review the updated references and type them again before continuing.");
        return;
      }
      const safeRows = fresh.rows.filter(row => {
        const source = data?.rows.find(item => item.id === row.id);
        return row.allowed && !(source && locallyProtected(source));
      });
      if (safeRows.some(row => !expected.has(row.id)) || !safeRows.length) {
        setTypedReferences({});
        setDeleteIssue("No records are currently approved for permanent deletion. Review the reasons below.");
        return;
      }
      const result = await deleteMutation.mutateAsync(safeRows.map(({ id, referenceNo, fingerprint }) => ({ id, referenceNo, fingerprint })));
      if (!Array.isArray(result?.results)) throw new Error("The server returned an unrecognized result.");
      const knownOutcomes = new Set(["deleted", "already_deleted", "blocked", "failed"]);
      const expectedRows = new Map(safeRows.map(row => [row.id, row]));
      const validResults = result.results.filter(row => expectedRows.has(row.id)
        && knownOutcomes.has(row.outcome)
        && expectedRows.get(row.id)?.referenceNo === row.referenceNo
        && typeof row.referenceNo === "string"
        && Array.isArray(row.reasons));
      const completeResponse = validResults.length === safeRows.length
        && new Set(validResults.map(row => row.id)).size === safeRows.length;
      setDeleteResults(validResults);
      if (!completeResponse) {
        setDeleteIssue("The server response did not account for every selected record. Your selection is retained; refresh or retry after checking the records.");
      } else {
        const unresolvedIds = validResults.filter(row => row.outcome === "blocked" || row.outcome === "failed").map(row => row.id);
        setSelected(previous => {
          const next = new Set(previous);
          validResults.filter(row => row.outcome === "deleted" || row.outcome === "already_deleted").forEach(row => next.delete(row.id));
          unresolvedIds.forEach(id => next.add(id));
          return next;
        });
        setDeleteDialogOpen(false);
        setDeleteIssue(unresolvedIds.length ? "Some records could not be deleted. Their selection is retained." : "");
      }
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: LIST_KEY }),
        queryClient.invalidateQueries({ queryKey: DASHBOARD_QUOTES_KEY }),
        queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] }),
      ]);
    } catch (err) {
      setDeleteIssue(`Deletion could not be confirmed. Your selection is retained. ${(err as Error).message}`);
    }
  };

  return (
    <section className="border border-black/15 bg-[#F7F6F1] shadow-[0_2px_8px_rgba(10,10,10,0.04)]" aria-labelledby="retail-enquiries-title" data-testid="retail-enquiry-manager">
      <div className="flex flex-col gap-4 border-b border-black/10 bg-white px-4 py-4 sm:flex-row sm:items-end sm:justify-between sm:px-5">
        <div>
          <p className="mb-1 text-[10px] font-black uppercase tracking-[0.22em] text-black/50">TMG Install · customer service</p>
          <h2 id="retail-enquiries-title" className="text-[18px] font-black uppercase tracking-[0.04em] text-[#0A0A0A]">Customer Quotations</h2>
          <p className="mt-1 text-[11px] font-medium text-black/55">Review quotation details and take the next appropriate action.</p>
          <p className="mt-1 text-[11px] text-black/55">Paid, accepted, booked and historical work stays in existing job and history views ({data?.counts?.operations || 0}).</p>
        </div>
        <label className="relative block w-full sm:max-w-[300px]">
          <span className="sr-only">Search customer quotations</span>
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-black/40" aria-hidden="true" />
          <input
            value={search}
            onChange={event => setSearch(event.target.value)}
            placeholder="Search name, reference, job…"
            className="h-10 w-full border border-black/15 bg-[#F7F6F1] pl-9 pr-3 text-[12px] font-medium outline-none placeholder:text-black/35 focus:border-black"
          />
        </label>
      </div>

      <div className="flex gap-1 overflow-x-auto border-b border-black/10 bg-[#EBE9E2] px-3 pt-2 sm:px-4" role="tablist" aria-label="Quotation views">
        {VIEWS.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            type="button"
            role="tab"
            aria-selected={view === key}
            onClick={() => setView(key)}
            className={`flex shrink-0 items-center gap-2 border-b-2 px-3 py-2.5 text-[10px] font-black uppercase tracking-[0.12em] transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-black ${view === key ? "border-[#0A0A0A] bg-white text-[#0A0A0A]" : "border-transparent text-black/50 hover:text-black"}`}
          >
            <Icon className="h-3.5 w-3.5" aria-hidden="true" />
            {label}
            <span className={`min-w-5 px-1 text-center font-mono text-[10px] tabular-nums ${view === key ? "bg-[#0A0A0A] text-white" : "bg-black/10 text-black/60"}`}>{data?.counts?.[key] ?? "—"}</span>
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-3 p-4" aria-label="Loading customer quotations" aria-busy="true">
          {[0, 1, 2].map(item => <div key={item} className="h-[96px] animate-pulse bg-black/[0.06]" />)}
        </div>
      ) : isError ? (
        <div className="flex flex-col items-center gap-2 px-5 py-9 text-center" role="alert">
          <AlertCircle className="h-5 w-5 text-[#A32E27]" aria-hidden="true" />
          <p className="text-[11px] font-black uppercase tracking-[0.12em]">Couldn't load customer quotations</p>
          <p className="max-w-sm text-[11px] text-black/55">{(error as Error)?.message || "Check your connection and retry. Existing dashboard data is unchanged."}</p>
          <button type="button" onClick={() => void refetch()} disabled={isFetching} className="mt-2 border border-black/20 bg-white px-3 py-2 text-[10px] font-black uppercase tracking-[0.12em] hover:bg-[#EBE9E2] disabled:opacity-50">
            {isFetching ? "Retrying…" : "Retry"}
          </button>
        </div>
      ) : (
        <>
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-black/10 px-4 py-2.5 sm:px-5">
            <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-black/50">{Math.min(limit, visibleRows.length)} of {visibleRows.length} shown <span className="mx-1.5">·</span> {selected.size} selected</p>
            <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.08em] text-black/45"><ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" /> Protected records stay visible</p>
          </div>
          {visibleRows.length === 0 ? (
            <div className="px-5 py-10 text-center">
              <FolderOpen className="mx-auto h-5 w-5 text-black/25" aria-hidden="true" />
              <p className="mt-2 text-[11px] font-black uppercase tracking-[0.12em]">{search ? "No matching quotations" : "Nothing in this view"}</p>
              <p className="mt-1 text-[11px] text-black/45">{search ? "Try another name, reference or job." : "Records will appear here when they meet this view."}</p>
            </div>
          ) : (
            <div className="divide-y divide-black/10">
              {visibleRows.slice(0, limit).map(row => {
                const draft = drafts[row.id] || {
                  outcome: (row.candidate?.outcome || "review_backlog") as Outcome,
                  reason: row.candidate?.reason || "",
                  canonicalQuoteId: String(row.candidate?.canonicalQuoteId || ""),
                };
                const isSelected = selected.has(row.id);
                const activity = row.lastMeaningfulAt || row.lastCustomerAt;
                return (
                  <article key={row.id} className={`px-4 py-4 transition-colors sm:px-5 ${isSelected ? "bg-[#EDEBE4]" : "bg-[#F7F6F1]"}`}>
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelected(row.id)}
                        aria-label={`Select ${row.customerName || "customer"} quotation ${row.referenceNo}`}
                        className="mt-1 h-4 w-4 shrink-0 accent-[#0A0A0A]"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                          <Link href={`/admin/quotes/${row.id}`} aria-label={`Open quote ${row.referenceNo} for ${row.customerName || "customer"}`}
                            data-testid={`retail-open-quote-${row.id}`}
                            className="block min-w-0 rounded-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-black">
                            <h3 className="text-[12px] font-black uppercase tracking-[0.06em] text-[#0A0A0A] underline decoration-black/25 underline-offset-2">{row.customerName || "Unknown customer"}</h3>
                            <span className="block min-w-0 break-all font-mono text-[10px] font-bold tracking-tight text-black/55">{row.referenceNo}</span>
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold underline underline-offset-2">Open quote<ChevronRight className="h-3 w-3" aria-hidden="true" /></span>
                          </Link>
                        </div>
                        <p className="mt-2 text-[11px] font-semibold leading-relaxed text-[#25251F]">{row.jobSummary || "Job summary not provided."}</p>
                        <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-[10px] font-medium text-black/55">
                          <span className={`font-mono tabular-nums ${row.priceReady ? "" : "font-black text-[#8C2924]"}`}>{row.priceReady ? money(row.total) : "Price not ready"}</span>
                          {row.nextAction && <span><span className="font-bold text-black/70">Next:</span> {row.nextAction}</span>}
                          <span>Last activity: {activityLabel(activity)}</span>
                          {row.outcome && <span>Recorded: {outcomeLabel(row.outcome)}</span>}
                          {row.canonicalQuoteId && (
                            <Link href={`/admin/quotes/${row.canonicalQuoteId}`} className="inline-flex items-center gap-1 font-black text-[#0A0A0A] underline underline-offset-2">
                              Related quote #{row.canonicalQuoteId}<ChevronRight className="h-3 w-3" aria-hidden="true" />
                            </Link>
                          )}
                        </div>
                        {row.reason && <p className="mt-1 text-[10px] text-black/55">Reason on record: {row.reason}</p>}
                        {row.protectedReasons?.length > 0 && (
                          <div id={`protected-${row.id}`} className="mt-2 border-l-2 border-[#A32E27]/50 bg-[#F8ECE9] px-2.5 py-2" aria-label="Record protections">
                            <p className="flex items-center gap-1 text-[9px] font-black uppercase tracking-[0.1em] text-[#8C2924]"><ShieldCheck className="h-3 w-3" aria-hidden="true" /> Actions restricted</p>
                            <ul className="mt-1 space-y-0.5 text-[10px] text-[#8C2924]">
                              {row.protectedReasons.map((reason, index) => <li key={`${reason}-${index}`}>{reason}</li>)}
                            </ul>
                          </div>
                        )}
                      </div>
                      <span className="hidden shrink-0 text-[10px] font-black tabular-nums text-black/40 sm:block">#{row.id}</span>
                    </div>
                    <div className="ml-7 mt-3 flex flex-wrap gap-2" aria-label={`Actions for ${row.referenceNo}`}>
                      <button type="button" onClick={() => prepareAction([row.id], "review_backlog")} className={`${buttonBase} border-black/20 bg-white text-black hover:bg-[#EBE9E2]`}>
                        <Archive className="h-3 w-3" aria-hidden="true" /> Archive
                      </button>
                      <button type="button" onClick={() => prepareAction([row.id], "restore")} className={`${buttonBase} border-[#286345]/35 bg-[#E9F1EB] text-[#24573D] hover:bg-[#DDEADF]`}>
                        <RotateCcw className="h-3 w-3" aria-hidden="true" /> Restore
                      </button>
                      <button type="button" onClick={() => void previewDelete([row.id])} disabled={locallyProtected(row) || deletePreviewMutation.isPending || deleteMutation.isPending} aria-describedby={locallyProtected(row) ? `protected-${row.id}` : undefined} className={`${buttonBase} border-[#A32E27]/25 bg-[#F8ECE9] text-[#8C2924] hover:bg-[#F4DFDB]`}>
                        <Trash2 className="h-3 w-3" aria-hidden="true" /> Permanent Delete
                      </button>
                    </div>
                    {isSelected && (
                      <div className="ml-7 mt-3 grid gap-2 sm:grid-cols-[190px_minmax(180px,1fr)_160px]">
                        <label className="block">
                          <span className="mb-1 block text-[9px] font-black uppercase tracking-[0.12em] text-black/50">Outcome</span>
                          <select value={draft.outcome} onChange={event => updateDraft(row.id, row, { outcome: event.target.value as Outcome })} className="h-9 w-full border border-black/15 bg-white px-2 text-[11px] font-bold outline-none focus:border-black">
                            {OUTCOMES.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
                          </select>
                        </label>
                        <label className="block">
                          <span className="mb-1 block text-[9px] font-black uppercase tracking-[0.12em] text-black/50">Reason <span className="text-[#A32E27]">required</span></span>
                          <input value={draft.reason} onChange={event => updateDraft(row.id, row, { reason: event.target.value })} placeholder="Explain why this action is appropriate" className="h-9 w-full border border-black/15 bg-white px-2 text-[11px] outline-none placeholder:text-black/30 focus:border-black" />
                        </label>
                        {draft.outcome === "duplicate" && (
                          <label className="block">
                            <span className="mb-1 block text-[9px] font-black uppercase tracking-[0.12em] text-black/50">Related quote ID</span>
                            <input type="number" min="1" value={draft.canonicalQuoteId} onChange={event => updateDraft(row.id, row, { canonicalQuoteId: event.target.value })} placeholder="Required for duplicate" className="h-9 w-full border border-black/15 bg-white px-2 text-[11px] outline-none placeholder:text-black/30 focus:border-black" />
                          </label>
                        )}
                        <p className="text-[10px] leading-relaxed text-black/50 sm:col-span-3">Archive starts in Needs Review. Choose Declined, Duplicate or Dormant only when the record supports that decision. A reason is required.</p>
                      </div>
                    )}
                  </article>
                );
              })}
            </div>
          )}

          <div className="border-t border-black/15 bg-white px-4 py-4 sm:px-5">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div className="text-[10px] font-medium text-black/55">
                {preview ? (
                  <span className="flex flex-wrap items-center gap-x-2 gap-y-1">
                    <span className="font-black uppercase tracking-[0.1em] text-black">Review changes</span>
                    <span>{preview.rows.length} submitted</span><span>·</span>
                    <span className="font-bold text-[#286345]">{allowedCount} allowed</span><span>·</span>
                    <span className="font-bold text-[#A32E27]">{excludedCount} held</span>
                  </span>
                ) : (
                  <span>{selected.size ? `${incompleteCount ? `${incompleteCount} selected need a reason` : `${validDecisions.length} change${validDecisions.length === 1 ? "" : "s"} ready to preview`}` : "Select quotations to archive, restore or delete."}</span>
                )}
              </div>
              <div className="flex flex-wrap gap-2">
                {visibleRows.length > limit && <button type="button" onClick={() => setLimit(n => n + 20)} className={`${buttonBase} m-0 border-black/20 bg-white px-3 hover:bg-[#EBE9E2]`}>Show 20 more</button>}
                {selected.size > 0 && (
                  <>
                    <button type="button" onClick={() => prepareAction(Array.from(selected), "review_backlog")} className={`${buttonBase} border-black/20 bg-white hover:bg-[#EBE9E2]`}><Archive className="h-3 w-3" aria-hidden="true" /> Archive selected</button>
                    <button type="button" onClick={() => prepareAction(Array.from(selected), "restore")} className={`${buttonBase} border-[#286345]/35 bg-[#E9F1EB] text-[#24573D] hover:bg-[#DDEADF]`}><RotateCcw className="h-3 w-3" aria-hidden="true" /> Restore selected</button>
                    <button
                      type="button"
                      onClick={() => void previewDelete(Array.from(selected))}
                      disabled={selectedRows.some(locallyProtected) || deletePreviewMutation.isPending || deleteMutation.isPending}
                      className={`${buttonBase} border-[#A32E27]/25 bg-[#F8ECE9] text-[#8C2924] hover:bg-[#F4DFDB]`}
                    >
                      <Trash2 className="h-3 w-3" aria-hidden="true" /> Permanent Delete selected
                    </button>
                    <button type="button" onClick={() => { setSelected(new Set()); setPreview(null); setDeleteResults(null); }} className={`${buttonBase} border-black/15 hover:bg-[#EBE9E2]`}>
                      <X className="h-3 w-3" aria-hidden="true" /> Clear
                    </button>
                  </>
                )}
                <button
                  type="button"
                  onClick={() => { setPreview(null); previewMutation.mutate(validDecisions); }}
                  disabled={!validDecisions.length || incompleteCount > 0 || previewMutation.isPending}
                  className="inline-flex min-h-9 items-center gap-2 bg-[#0A0A0A] px-3 text-[10px] font-black uppercase tracking-[0.1em] text-white hover:bg-black/80 disabled:cursor-not-allowed disabled:opacity-35"
                >
                  <ClipboardCheck className="h-3.5 w-3.5" aria-hidden="true" /> {previewMutation.isPending ? "Checking…" : "Preview changes"}
                </button>
                {preview && (
                  <button
                    type="button"
                    onClick={() => applyMutation.mutate(preview.rows.filter(row => row.allowed))}
                    disabled={!allowedCount || applyMutation.isPending}
                    className="inline-flex min-h-9 items-center gap-2 border border-[#286345] bg-[#E9F1EB] px-3 text-[10px] font-black uppercase tracking-[0.1em] text-[#24573D] hover:bg-[#DDEADF] disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    {applyMutation.isPending ? "Applying…" : <><Check className="h-3.5 w-3.5" aria-hidden="true" /> Apply {allowedCount} allowed</>}
                  </button>
                )}
              </div>
            </div>
            {selectedRows.some(locallyProtected) && selected.size > 0 && <p className="mt-2 text-[10px] font-semibold text-[#8C2924]">Permanent deletion is unavailable while a selected record has a protection in place. Deselect protected records to continue.</p>}
            {preview && (
              <div className="mt-3 grid gap-3 border-t border-black/10 pt-3 md:grid-cols-2">
                <div className="flex items-start gap-2">
                  <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#286345]" aria-hidden="true" />
                  <div>
                    <p className="text-[9px] font-black uppercase tracking-[0.12em]">Before / after counts</p>
                    <p className="mt-1 text-[10px] leading-relaxed text-black/55">
                      {Object.keys(preview.before || {}).map(key => `${key.replaceAll("_", " ")} ${preview.before[key] ?? 0} → ${preview.after?.[key] ?? 0}`).join(" · ") || "The server returned no count changes."}
                    </p>
                  </div>
                </div>
                <div>
                  <p className="text-[9px] font-black uppercase tracking-[0.12em]">Records held back</p>
                  {preview.rows.filter(row => !row.allowed).length === 0 ? (
                    <p className="mt-1 text-[10px] text-black/50">None. Every submitted change is allowed.</p>
                  ) : (
                    <ul className="mt-1 space-y-1">
                      {preview.rows.filter(row => !row.allowed).map(row => (
                        <li key={`${row.id}-${row.fingerprint}`} className="text-[10px] text-[#8C2924]">
                          <span className="font-mono font-bold">#{row.id}</span> — {row.reasons?.join("; ") || "This change is not available"}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            )}
            {deleteIssue && <p role="alert" className="mt-3 border-t border-[#A32E27]/20 pt-3 text-[10px] font-bold text-[#8C2924]">{deleteIssue}</p>}
            {deleteResults && (
              <div className="mt-3 border-t border-black/10 pt-3" aria-live="polite">
                <p className="text-[9px] font-black uppercase tracking-[0.12em]">Permanent deletion results</p>
                <ul className="mt-1 space-y-1">
                  {deleteResults.map(result => (
                    <li key={`${result.id}-${result.referenceNo}`} className={`text-[10px] ${result.outcome === "deleted" || result.outcome === "already_deleted" ? "text-[#24573D]" : "text-[#8C2924]"}`}>
                      <span className="font-mono font-bold">{result.referenceNo}</span> — {result.outcome === "already_deleted" ? "Already deleted" : result.outcome === "deleted" ? "Deleted" : result.outcome === "blocked" ? "Blocked" : "Failed"}
                      {result.reasons?.length > 0 && `: ${result.reasons.join("; ")}`}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {notice && <p role="status" className={`mt-3 border-t border-black/10 pt-3 text-[10px] font-bold ${notice.startsWith("Changes could not") || notice.startsWith("Preview failed") ? "text-[#8C2924]" : "text-[#286345]"}`}>{notice}</p>}
            {previewMutation.isError && <p className="sr-only" role="alert">Change preview could not be completed.</p>}
          </div>
        </>
      )}

      {deleteDialogOpen && deletePreview && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#161613]/55 p-0 sm:items-center sm:p-5" onMouseDown={event => { if (event.target === event.currentTarget && !deleteMutation.isPending) setDeleteDialogOpen(false); }}>
          <section role="alertdialog" aria-modal="true" aria-labelledby="delete-dialog-title" aria-describedby="delete-dialog-description" className="max-h-[92dvh] w-full max-w-xl overflow-y-auto border border-black/20 bg-[#F7F6F1] p-4 shadow-[0_12px_40px_rgba(10,10,10,0.25)] sm:p-6">
            <div className="flex items-start justify-between gap-4 border-b border-black/10 pb-4">
              <div>
                <p className="text-[9px] font-black uppercase tracking-[0.18em] text-[#8C2924]">Permanent action</p>
                <h2 id="delete-dialog-title" className="mt-1 text-[16px] font-black uppercase tracking-[0.04em]">Permanently delete quotations?</h2>
                <p id="delete-dialog-description" className="mt-1 max-w-lg text-[11px] leading-relaxed text-black/60">This cannot be undone. Check each exact reference below and type it exactly to enable deletion. The server will check the records again before applying.</p>
              </div>
              <button type="button" onClick={() => setDeleteDialogOpen(false)} disabled={deleteMutation.isPending} aria-label="Close permanent deletion confirmation" className="inline-flex h-9 w-9 shrink-0 items-center justify-center border border-black/15 bg-white hover:bg-[#EBE9E2] disabled:opacity-50"><X className="h-4 w-4" aria-hidden="true" /></button>
            </div>
            <ul className="mt-4 space-y-3">
              {deletePreview.rows.map(row => {
                const source = data?.rows.find(item => item.id === row.id);
                const allowed = row.allowed && !(source && locallyProtected(source));
                const reasons = [
                  ...(row.reasons || []),
                  ...(source && locallyProtected(source) ? source.protectedReasons : []),
                ];
                return (
                  <li key={`${row.id}-${row.fingerprint}`} className="border border-black/10 bg-white p-3">
                    <p className="font-mono text-[12px] font-black break-all">{row.referenceNo}</p>
                    {allowed ? (
                      <label className="mt-2 block">
                        <span className="mb-1 block text-[9px] font-black uppercase tracking-[0.1em] text-black/55">Type the exact reference to confirm</span>
                        <input
                          value={typedReferences[row.id] || ""}
                          onChange={event => setTypedReferences(previous => ({ ...previous, [row.id]: event.target.value }))}
                          autoComplete="off"
                          spellCheck={false}
                          aria-label={`Type exact reference ${row.referenceNo} to confirm deletion`}
                          placeholder={row.referenceNo}
                          className="h-10 w-full border border-black/20 bg-[#F7F6F1] px-3 font-mono text-[12px] outline-none focus:border-black focus:ring-1 focus:ring-black"
                        />
                      </label>
                    ) : (
                      <div className="mt-2 border-l-2 border-[#A32E27]/50 bg-[#F8ECE9] px-2 py-1.5 text-[10px] text-[#8C2924]">
                        <p className="font-black uppercase tracking-[0.08em]">Protected — cannot delete</p>
                        <p className="mt-0.5">{reasons.join("; ") || "The server did not approve deletion."}</p>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
            {deleteIssue && <p role="alert" className="mt-3 border-l-2 border-[#A32E27] bg-[#F8ECE9] px-3 py-2 text-[10px] font-bold text-[#8C2924]">{deleteIssue}</p>}
            {deleteResults && (
              <div className="mt-3 border-t border-black/10 pt-3" aria-live="polite">
                <p className="text-[9px] font-black uppercase tracking-[0.12em]">Results received</p>
                <ul className="mt-1 space-y-1">
                  {deleteResults.map(result => (
                    <li key={`dialog-${result.id}-${result.referenceNo}`} className={`text-[10px] ${result.outcome === "deleted" || result.outcome === "already_deleted" ? "text-[#24573D]" : "text-[#8C2924]"}`}>
                      <span className="font-mono font-bold">{result.referenceNo}</span> — {result.outcome === "already_deleted" ? "Already deleted" : result.outcome === "deleted" ? "Deleted" : result.outcome === "blocked" ? "Blocked" : "Failed"}
                      {result.reasons?.length > 0 && `: ${result.reasons.join("; ")}`}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            <div className="mt-4 flex flex-col-reverse gap-2 border-t border-black/10 pt-4 sm:flex-row sm:justify-end">
              <button type="button" onClick={() => setDeleteDialogOpen(false)} disabled={deleteMutation.isPending} className={`${buttonBase} border-black/20 bg-white hover:bg-[#EBE9E2]`}>Cancel</button>
              <button type="button" onClick={() => void confirmDelete()} disabled={!canConfirmDelete} className="inline-flex min-h-10 items-center justify-center gap-2 border border-[#8C2924] bg-[#8C2924] px-4 text-[10px] font-black uppercase tracking-[0.1em] text-white hover:bg-[#71211D] disabled:cursor-not-allowed disabled:opacity-35">
                <Trash2 className="h-3.5 w-3.5" aria-hidden="true" /> {deletePreviewMutation.isPending || deleteMutation.isPending ? "Checking…" : `Delete ${allowedDeleteRows.length} allowed`}
              </button>
            </div>
          </section>
        </div>
      )}
    </section>
  );
}

export default RetailEnquiryManager;
