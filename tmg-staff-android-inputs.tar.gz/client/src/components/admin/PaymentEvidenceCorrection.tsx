import {useState,useRef} from "react";
import {useMutation,useQueryClient} from "@tanstack/react-query";
import {apiRequest} from "@/lib/queryClient";
import {refreshQuoteViews} from "@/lib/quote-edit-cache";

export function PaymentEvidenceCorrection({quote}:{quote:any}) {
  const [open,setOpen]=useState(false),[reason,setReason]=useState(""),[checked,setChecked]=useState(false);
  const key=useRef(crypto.randomUUID()),qc=useQueryClient();
  const save=useMutation({mutationFn:async()=> (await apiRequest("POST",
    `/api/admin/quotes/${quote.id}/payment/correct-status`,{expectedVersion:quote.version,
      expectedRevision:quote.editRevision,reason,confirmedNoFunds:checked,requestKey:key.current})).json(),
    onSuccess:()=>{refreshQuoteViews(qc);setOpen(false);}});
  if(quote.paymentEvidence?.status!=="missing")return null;
  return <div className="mt-3 border border-amber-200 bg-amber-50 p-3 text-sm" data-testid="payment-correction-panel">
    <p className="font-semibold">Paid status needs bank evidence review</p>
    <p className="mt-1">An app audit or cancelled message is not bank receipt evidence. Do not collect again to repair history.</p>
    {!open?<button className="mt-2 underline font-semibold" onClick={()=>setOpen(true)}>
      Correct a mistaken paid status</button>:<div className="mt-3 space-y-3">
      <label className="block">Bank check and correction reason
        <textarea className="mt-1 w-full border bg-white p-2" value={reason}
          onChange={e=>setReason(e.target.value)} data-testid="payment-correction-reason"/></label>
      <label className="flex gap-2"><input type="checkbox" checked={checked}
        onChange={e=>setChecked(e.target.checked)} data-testid="payment-correction-confirm"/>
        I checked the bank/provider evidence: no funds were received for this paid status.</label>
      <p className="text-xs">This records the correction and keeps collection on hold. It sends nothing, creates no payment link and preserves acceptance and quote prices.</p>
      {save.error&&<p role="alert" className="text-red-700">{(save.error as Error).message}</p>}
      <div className="flex gap-3"><button onClick={()=>setOpen(false)} disabled={save.isPending}>Cancel</button>
        <button className="bg-black text-white p-2 disabled:opacity-50" disabled={!checked||reason.trim().length<10||save.isPending}
          onClick={()=>save.mutate()} data-testid="payment-correction-save">{save.isPending?"Saving…":"Save correction — no message"}</button></div>
    </div>}
  </div>;
}
