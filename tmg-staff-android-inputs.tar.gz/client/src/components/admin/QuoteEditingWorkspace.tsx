import {detectAdminCatalogRate} from "@shared/adminCatalogRate";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import type { CatalogItem } from "@shared/schema";
import {isWrappingRollupLine} from "@shared/pricing";
import {formatItemServiceLabel} from "@/lib/itemLabel";
import type { QuoteWorkspaceRequirement } from "@/components/admin/QuoteWorkspaceReview";
import {
  AlertCircle,
  ArrowUpRight,
  Check,
  ChevronDown,
  CircleDollarSign,
  FileText,
  Plus,
  Save,
  Trash2,
  UserRound,
} from "lucide-react";

export interface QuoteEditingWorkspaceProps {
  reference: string;
  customer: any;
  onCustomerChange: (value: any) => void;
  quoteData: any;
  onQuoteDataChange: (value: any) => void;
  items: any[];
  onItemChange: (index: number, field: string, value: any) => void;
  rateReasonItems: number[];
  rateReasons: Record<string, string>;
  onRateReasonChange: (key: string, value: string) => void;
  onAddItem: () => void;
  onRemoveItem: (index: number) => void;
  catalog: CatalogItem[];
   onCatalogSelect: (index: number, item: CatalogItem, applyRate?:boolean) => void;
  totals: {
    subtotal: number;
    discount: number;
    promoDiscount: number;
    goodwill: number;
    transport: number;
    secondDay: number;
    additionalTrip: number;
    afterOffice: number;
    total: number;
    paid: number;
  };
  pending: boolean;
  sending?: boolean;
  calculating?: boolean;
  transportIsPending?: boolean;
  dirty: boolean;
  totalIsPending?: boolean;
  error: string;
  sendError?: string;
  sendStatusMessage?: string;
  deliveryOutcome?: any;
  sendLocked?: boolean;
  sendRetryAllowed?: boolean;
  deliveryContext?: any;
  deliveryContextLoading?: boolean;
  deliveryContextError?: boolean;
  fieldErrors: Record<string, string>;
  requirements: QuoteWorkspaceRequirement[];
  onSave: () => void;
  onSaveAndSend: () => void;
  surchargeAck: boolean;
  onSurchargeAckChange: (value: boolean) => void;
  surchargeChanged: boolean;
  logistics?: ReactNode;
  reviewPanel?: ReactNode;
  historicalNotes?: string;
  currentQuoteUrl: string;
  pdfPreviewUrl: string;
}

const SERVICES = [
  ["install", "Install"],
  ["align", "Alignment / adjustment"],
  ["fit_castors", "Fit castor wheels"],
  ["uncarton", "Uncartoning only"],
  ["place", "Placement only"],
  ["dismantle", "Dismantle"],
  ["relocate", "Relocate"],
  ["dispose", "Dispose"],
  ["dismantle_install", "Dismantle + install"],
  ["dismantle_dispose", "Dismantle + dispose"],
  ["fee", "Fee / charge"],
];

const inputClass =
  "w-full min-w-0 border border-black/15 bg-white px-3 py-2.5 text-[13px] font-medium text-[#171713] outline-none transition-colors placeholder:text-black/35 focus:border-[#0A0A0A] focus:ring-2 focus:ring-black/10";
const selectClass = `${inputClass} pr-8`;
const labelClass = "mb-1.5 block text-[10px] font-black uppercase tracking-[0.17em] text-black/55";
const money = (value: number) =>
  `$${(Number.isFinite(Number(value)) ? Number(value) : 0).toLocaleString("en-SG", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
const stringValue = (value: unknown) => (value == null ? "" : String(value));

function FieldError({ id, errors }: { id: string; errors: Record<string, string> }) {
  const message = errors[id] || (["name","email","phone"].includes(id) ? errors[`customer.${id}`] : undefined);
  return message ? (
    <p id={`${id}-error`} className="mt-1.5 flex items-start gap-1.5 text-[11px] font-medium leading-snug text-[#B4232D]" role="alert">
      <AlertCircle aria-hidden="true" className="mt-px h-3.5 w-3.5 shrink-0" />
      {message}
    </p>
  ) : null;
}

function SectionTitle({
  number,
  title,
  detail,
  trailing,
}: {
  number: string;
  title: string;
  detail: string;
  trailing?: ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-black/10 px-4 py-4 sm:px-6">
      <div className="flex min-w-0 items-start gap-3">
        <span className="pt-0.5 font-mono text-[10px] font-bold tracking-[0.14em] text-black/35">{number}</span>
        <div className="min-w-0">
          <h2 className="text-[12px] font-black uppercase tracking-[0.17em] text-[#11110F]">{title}</h2>
          <p className="mt-1 text-[12px] text-black/50">{detail}</p>
        </div>
      </div>
      {trailing}
    </div>
  );
}

export default function QuoteEditingWorkspace({
  reference,
  customer,
  onCustomerChange,
  quoteData,
  onQuoteDataChange,
  items,
  onItemChange,
  rateReasonItems,
  rateReasons,
  onRateReasonChange,
  onAddItem,
  onRemoveItem,
  catalog,
  onCatalogSelect,
  totals,
  pending,
  sending = false,
  calculating=false,
  dirty,
  totalIsPending = false,
  transportIsPending = false,
  error,
  sendError = "",
  sendStatusMessage = "",
  deliveryOutcome,
  sendLocked = false,
  sendRetryAllowed = false,
  deliveryContext,
  deliveryContextLoading = false,
  deliveryContextError = false,
  fieldErrors,
  requirements,
  onSave,
  onSaveAndSend,
  surchargeAck,
  onSurchargeAckChange,
  surchargeChanged,
  logistics,
  reviewPanel,
  historicalNotes = "",
  currentQuoteUrl,
  pdfPreviewUrl,
}: QuoteEditingWorkspaceProps) {
  const [catalogFor, setCatalogFor] = useState<number | null>(null);
  const [catalogQuery, setCatalogQuery] = useState("");
  const [customerDetailsOpen, setCustomerDetailsOpen] = useState(false);
  const [businessDetailsOpen, setBusinessDetailsOpen] = useState(false);
  const [itemWorkDetailsOpen, setItemWorkDetailsOpen] = useState<Record<string, boolean>>({});

  const quote = quoteData || {};
  const person = customer || {};
  const normalizeRequirementField = (value: string) => value.replace(/[^a-z0-9]/gi, "").toLowerCase();
  const customerFieldError = (field: string) =>
    /^(customer\.)?(name|email|phone)$/i.test(field) ||
    /^customerName$/i.test(field) ||
    /^(service[._-]?address|job[._-]?address)$/i.test(field);
  useEffect(() => {
    if (
      Object.keys(fieldErrors).some(customerFieldError) ||
      requirements.some((requirement) => customerFieldError(requirement.field))
    ) {
      setCustomerDetailsOpen(true);
    }
  }, [fieldErrors, requirements]);

  const fieldTarget = (field: string) => {
    const itemMatch = field.match(/items\.(\d+)\.(originalDescription|description|detectedName|serviceType|quantity|unitPrice|rateReason|remark|itemRemark)/i);
    if (itemMatch) {
      const [, index, key] = itemMatch;
      const ids: Record<string, string> = {
        description: `edit-item-desc-${index}`,
        originaldescription: `edit-item-desc-${index}`,
        detectedname: `edit-item-desc-${index}`,
        servicetype: `edit-item-service-${index}`,
        quantity: `edit-item-qty-${index}`,
        unitprice: `edit-item-price-${index}`,
        ratereason: `edit-item-rate-reason-${index}`,
        remark: `edit-item-remark-${index}`,
        itemremark: `edit-item-remark-${index}`,
      };
      return ids[key.toLowerCase()];
    }
    if(field.startsWith("facts."))return `workspace-fact-${field.slice(6)}`;
    const rateMatch=field.match(/^rateReasons\.(\d+)$/);
    if(rateMatch)return `edit-item-rate-reason-${rateMatch[1]}`;
    const normalized = field.replace(/^(customer|quote|quoteData)[._]/i, "").replace(/[^a-z0-9]/gi, "").toLowerCase();
    const targets: Record<string, string> = {
      name: "name",
      customername: "name",
      email: "email",
      phone: "phone",
      serviceaddress: "quote-service-address",
      jobaddress: "quote-service-address",
      dropoffaddress: "workspace-fact-toAddress",
      transportfee: "transportFee",
      goodwilldiscount: "goodwillDiscount",
      goodwillreason: "goodwillReason",
      invoicetype: "invoice-type",
      billingcompanyname: "billing-company-name",
      billingcompanyuen: "billing-company-uen",
      ponumber: "po-number",
      billingaddress: "billing-address",
      seconddayhours: "secondDayHours",
      seconddaycrewsize: "secondDayCrewSize",
      afterofficesurchargeamount: "afterOfficeSurchargeAmount",
      afterofficewaiverreason: "afterOfficeWaiverReason",
      additionaltripcharge: "additionalTripCharge",
      specialremarks: "special-remarks",
      cancellationnoticehours: "cancellationNoticeHours",
      stafftransportallowance: "staffTransportAllowance",
      seconddaycontinuation: "secondDayContinuation",
      afterofficeinvolved: "afterOfficeInvolved",
      afterofficewaived: "afterOfficeWaived",
      ownmoverinvolved: "ownMoverInvolved",
      depositrefundable: "depositRefundable",
    };
    return targets[normalized] || field;
  };
  const fieldLabel = (field: string) => {
    const rateMatch=field.match(/^rateReasons\.(\d+)$/);
    if(rateMatch)return `Item ${Number(rateMatch[1])+1} · price approval`;
    const itemMatch = field.match(/items\.(\d+)\.(originalDescription|description|detectedName|serviceType|quantity|unitPrice|rateReason|remark|itemRemark)/i);
    if (itemMatch) {
      const names: Record<string, string> = {
        description: "description",
        originaldescription: "description",
        detectedname: "description",
        servicetype: "service",
        quantity: "quantity",
        unitprice: "unit price",
        ratereason: "price override reason",
        remark: "customer item remark",
        itemremark: "customer item remark",
      };
      return `Item ${Number(itemMatch[1]) + 1} · ${names[itemMatch[2].toLowerCase()]}`;
    }
    const name = field.replace(/^customer\./i, "").split(".").pop() || field;
    return name
      .replace(/([a-z])([A-Z])/g, "$1 $2")
      .replace(/[-_]/g, " ")
      .replace(/\b\w/g, (letter) => letter.toUpperCase());
  };
  const currentRequirement = (requirement: {field:string;message:string}) => {
    const authority=requirement.field.match(/^rateReasons\.(\d+)$/);
    if(authority) {
      const index=Number(authority[1]),key=String(items[index]?.id??index);
      if(String(rateReasons[key]||"").trim().length>=5)
        return {...requirement,message:"Price approval entered. Save to validate it; nothing has been sent."};
    }
    const match=requirement.field.match(/^items\.(\d+)\.unitPrice$/);
    if(match && /^\d+(\.\d{1,2})?$/.test(String(items[Number(match[1])]?.unitPrice??"").trim()) &&
      /approved unit price is still needed/.test(requirement.message)) {
      return {...requirement,message:"Rate entered. Save to check its pricing approval; nothing has been sent."};
    }
    return requirement;
  };
  const actionableIssues = [
    ...Object.entries(fieldErrors)
      .filter(([, message]) => Boolean(message))
      .map(([field, message]) => ({ field, message })),
    ...requirements.map(currentRequirement),
  ].filter((issue, index, all) =>
    all.findIndex((candidate) =>
      fieldTarget(candidate.field) === fieldTarget(issue.field)
    ) === index
  );
  const knownFieldIds = new Set([
    "name", "email", "phone", "quote-service-address", "transportFee", "goodwillDiscount", "goodwillReason",
    "invoice-type", "billing-company-name", "billing-company-uen", "po-number", "billing-address",
    "secondDayHours", "secondDayCrewSize", "afterOfficeSurchargeAmount", "afterOfficeWaiverReason",
    "additionalTripCharge", "special-remarks", "cancellationNoticeHours", "staffTransportAllowance",
    "secondDayContinuation", "afterOfficeInvolved", "afterOfficeWaived", "ownMoverInvolved", "depositRefundable",
  ]);
  const isFocusableIssue = (field: string) =>
    /items\.\d+\.(originalDescription|description|detectedName|serviceType|quantity|unitPrice|rateReason|remark|itemRemark)/i.test(field) ||
    /^rateReasons\.\d+$/.test(field) || /^facts\./.test(field) || field==="dropoffAddress" ||
    knownFieldIds.has(fieldTarget(field));
  const linkedIssues = actionableIssues.filter((issue) => isFocusableIssue(issue.field));
  const unmatchedIssues = actionableIssues.filter((issue) => !isFocusableIssue(issue.field));
  const focusIssueField = (field: string) => {
    const targetId = fieldTarget(field);
    const target = document.getElementById(targetId) as HTMLElement | null;
    for(let node=target?.parentElement;node;node=node.parentElement){
      if(node instanceof HTMLDetailsElement)node.open=true;
    }
    if (customerFieldError(field)) setCustomerDetailsOpen(true);
    if (target?.closest("#quote-business-details")) setBusinessDetailsOpen(true);
    window.setTimeout(() => {
      const fieldElement = document.getElementById(targetId) as HTMLElement | null;
      fieldElement?.focus();
      fieldElement?.scrollIntoView({ block: "center", behavior: "smooth" });
    }, customerFieldError(field) ? 40 : 0);
    target?.scrollIntoView({ block: "center", behavior: "smooth" });
  };
  const inlineRequirements = (...fields: string[]) => {
    const wanted = new Set(fields.map(normalizeRequirementField));
    return requirements.filter((requirement) => wanted.has(normalizeRequirementField(requirement.field))).map(currentRequirement).map((requirement, index) => (
      <p key={`${requirement.field}-${index}`} className="mt-1 flex items-start gap-1.5 text-[11px] font-medium leading-snug text-[#8A5A21]" role="status">
        {requirement.message}
      </p>
    ));
  };
  const contextRecipient = typeof deliveryContext?.recipient === "string"
    ? deliveryContext.recipient
    : deliveryContext?.recipient?.phone || deliveryContext?.recipient?.label || "";
  const consentContext = deliveryContext?.consentStatus ?? deliveryContext?.consent?.status ??
    deliveryContext?.recipient?.consentStatus ?? deliveryContext?.recipient?.consent ?? null;
  const consentLabel = consentContext == null
    ? deliveryContext ? "Not returned by context; server checks before send" : "Checking"
    : typeof consentContext === "boolean" ? consentContext ? "Confirmed" : "Not confirmed"
      : String(consentContext);
  const rawRoute = String(deliveryContext?.route || "");
  const routeLabel = deliveryContext && !deliveryContext.windowOpen
    ? deliveryContext.templateAvailable
      ? "Approved quotation link only (not a PDF attachment)"
      : "No eligible route; the window is closed and no approved link template is available"
    : /link|template/i.test(rawRoute)
      ? "Approved quotation link only (not a PDF attachment)"
      : /pdf|attachment|document/i.test(rawRoute)
        ? "PDF attachment"
        : deliveryContext?.windowOpen
          ? "PDF attachment"
          : rawRoute || "Delivery route not available";
  const eligibilityReason = deliveryContext?.eligibilityReason || deliveryContext?.blockReason || (!deliveryContext
    ? deliveryContextError ? "Delivery context could not be loaded. Retry before sending." : "Checking recipient and delivery eligibility."
    : !contextRecipient
      ? "No WhatsApp recipient is recorded."
      : deliveryContext?.requirements?.length
        ? `${deliveryContext.requirements.length} review requirement${deliveryContext.requirements.length === 1 ? "" : "s"} are recorded; your structured edits are rechecked on save.`
        : deliveryContext.windowOpen
          ? "The 24-hour window is open; attachment delivery is subject to the send-time provider check."
          : deliveryContext.templateAvailable
            ? "The window is closed. Only the approved quotation-link template is available; no PDF attachment will be sent."
            : "The window is closed and no approved quotation-link template is currently available.");
  const deliveryRouteUnavailable = Boolean(deliveryContext) &&
    (!contextRecipient || (!deliveryContext.windowOpen && !deliveryContext.templateAvailable));
  const totalsReady=items.every(item=>/^\d+$/.test(String(item.quantity))&&Number(item.quantity)>=1&&/^\d+(\.\d{1,2})?$/.test(String(item.unitPrice)));
  const activeCatalogService = catalogFor == null ? "" : stringValue(items[catalogFor]?.serviceType);
  const catalogMatches = useMemo(() => {
    const query = catalogQuery.trim().toLowerCase();
    const matches = catalog
      .filter((entry) => `${entry.name} ${entry.serviceType}`.toLowerCase().includes(query))
      .sort((a, b) => {
        const aMatchesService = String(a.serviceType) === activeCatalogService;
        const bMatchesService = String(b.serviceType) === activeCatalogService;
        return Number(bMatchesService) - Number(aMatchesService);
      });
    return matches.slice(0, query ? 7 : 6);
  }, [catalog, catalogQuery, activeCatalogService]);

  const changeQuote = (field: string, value: unknown) =>
    onQuoteDataChange({ ...quote, [field]: value });
  const changeCustomer = (field: string, value: unknown) =>
    onCustomerChange({ ...person, [field]: value });
  const numericInput = (
    id: string,
    label: string,
    value: unknown,
    onChange: (value: string) => void,
    hint?: string,
  ) => (
    <div>
      <label className={labelClass} htmlFor={id}>{label}</label>
      <input
        id={id}
        type="text"
        inputMode="decimal"
        value={stringValue(value)}
        onChange={(event) => onChange(event.target.value)}
        className={inputClass}
        aria-invalid={Boolean(fieldErrors[id])}
        aria-describedby={fieldErrors[id] ? `${id}-error` : hint ? `${id}-hint` : undefined}
      />
      <FieldError id={id} errors={fieldErrors} />
      {hint && !fieldErrors[id] && <p id={`${id}-hint`} className="mt-1 text-[11px] text-black/45">{hint}</p>}
    </div>
  );
  const textInput = (
    id: string,
    label: string,
    value: unknown,
    onChange: (value: string) => void,
    options?: { type?: string; placeholder?: string },
  ) => (
    <div>
      <label className={labelClass} htmlFor={id}>{label}</label>
      <input
        id={id}
        type={options?.type || "text"}
        data-testid={id==="name"?"input-edit-name":id==="email"?"input-edit-email":id==="phone"?"input-edit-phone":undefined}
        value={stringValue(value)}
        placeholder={options?.placeholder}
        onChange={(event) => onChange(event.target.value)}
        className={inputClass}
        aria-invalid={Boolean(fieldErrors[id])}
        aria-describedby={fieldErrors[id] ? `${id}-error` : undefined}
      />
      <FieldError id={id} errors={fieldErrors} />
    </div>
  );
  const toggle = (id: string, label: string, checked: unknown, onChange: (value: boolean) => void) => (
    <label htmlFor={id} className="flex min-h-11 cursor-pointer items-center gap-3 border border-black/10 bg-[#F8F7F3] px-3 py-2.5 text-[12px] font-semibold text-black/75">
      <input
        id={id}
        type="checkbox"
        checked={Boolean(checked)}
        onChange={(event) => onChange(event.target.checked)}
        className="h-4 w-4 shrink-0 accent-[#11110F]"
      />
      {label}
    </label>
  );

  return (
    <div className="overflow-hidden border border-black/15 bg-[#F5F4F0] text-[#11110F]"
      onFocusCapture={(event)=>{
        const target=event.target as HTMLElement;
        if(!target.matches("input,textarea,select"))return;
        const reveal=()=>{
          if(!target.isConnected||document.activeElement!==target)return;
          const rect=target.getBoundingClientRect();
          const height=window.visualViewport?.height??window.innerHeight;
          if(rect.top<80||rect.bottom>height-190)target.scrollIntoView({block:"center",inline:"nearest",behavior:"instant"});
        };
        requestAnimationFrame(reveal);window.setTimeout(reveal,250);
      }}>
      <header className="flex flex-col gap-3 border-b border-black/12 bg-white px-4 py-3 sm:flex-row sm:items-end sm:justify-between sm:px-6">
        <div>
          
          <div className="mt-1.5 flex flex-wrap items-baseline gap-x-3 gap-y-1">
            <h1 className="text-[23px] font-black leading-none tracking-[-0.04em] sm:text-[28px]">Edit quote</h1>
            <span className="font-mono text-[12px] font-bold tracking-wide text-black/50">{reference}</span>
          </div>
          <p className="mt-2 text-[12px] text-black/55">Edit items, save a draft or send explicitly.</p>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 sm:justify-end">
          <div className="min-w-0 text-[11px] leading-relaxed text-black/55">
            <p className="truncate"><span className="font-semibold text-black/75">WhatsApp recipient</span> · {contextRecipient || person.phone || "No recipient on file"}</p>
            <p className="truncate"><span className="font-semibold text-black/75">Route</span> · {routeLabel}</p>
            <details>
              <summary className="cursor-pointer underline underline-offset-2">Delivery details</summary>
              <p><span className="font-semibold text-black/75">24-hour window</span> · {deliveryContext?.windowOpen ? "Open" : deliveryContext ? "Closed" : "Checking"}</p>
              <p><span className="font-semibold text-black/75">Approved link template</span> · {deliveryContext?.templateAvailable ? "Available" : deliveryContext ? "Unavailable" : "Checking"}</p>
              <p><span className="font-semibold text-black/75">Consent</span> · {consentLabel}</p>
            </details>
            <p className="max-w-[34rem] text-[#8A5A21]">{eligibilityReason}</p>
          </div>
          {pdfPreviewUrl && (
            <a
              href={pdfPreviewUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex min-h-10 items-center gap-1.5 px-2 text-[10px] font-black uppercase tracking-[0.13em] text-black/60 underline decoration-black/25 underline-offset-4 hover:text-black"
              data-testid="link-quote-pdf-preview"
            >
              Saved PDF preview <ArrowUpRight aria-hidden="true" className="h-3.5 w-3.5" />
            </a>
          )}
          {currentQuoteUrl && (
            <a
              href={currentQuoteUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex min-h-10 items-center gap-1.5 px-2 text-[10px] font-black uppercase tracking-[0.13em] text-black/60 underline decoration-black/25 underline-offset-4 hover:text-black"
            >
              Saved page <ArrowUpRight aria-hidden="true" className="h-3.5 w-3.5" />
            </a>
          )}
          <span className={`hidden sm:inline-flex h-7 items-center gap-1.5 border px-2.5 text-[9px] font-black uppercase tracking-[0.15em] ${dirty ? "border-[#C89A39]/40 bg-[#FBF4E3] text-[#76550F]" : "border-black/10 bg-[#F5F4F0] text-black/45"}`}>
            {dirty ? <><span className="h-1.5 w-1.5 rounded-full bg-[#C28B1B]" /> Unsaved changes</> : <><Check aria-hidden="true" className="h-3 w-3" /> Up to date</>}
          </span>
        </div>
      </header>

      <fieldset disabled={pending} className="min-w-0 space-y-4 p-3 sm:space-y-5 sm:p-5">
        <section className="border border-black/12 bg-white">
          <SectionTitle
            number="01"
            title="Quote items"
            detail="Set the description, service, quantity and unit price for each line."
            trailing={<span className="hidden shrink-0 font-mono text-[10px] font-bold text-black/40 sm:inline">{items.length} {items.length === 1 ? "LINE" : "LINES"}</span>}
          />
          <div className="divide-y divide-black/10">
            {items.length === 0 && (
              <div className="px-5 py-10 text-center">
                <p className="text-[12px] font-bold">No quote items yet</p>
                <p className="mt-1 text-[11px] text-black/50">Add a line to start building the itemised quote.</p>
              </div>
            )}
            {items.map((item, index) => {
              if(isWrappingRollupLine(item.detectedName)||isWrappingRollupLine(item.originalDescription))return <article key={item._draftKey??item.id??index} className="px-4 py-4 sm:px-6 bg-zinc-50">
                <p className="text-sm font-semibold">{item.detectedName||item.originalDescription}</p>
                <p className="text-xs text-zinc-500 mt-1">Display-only wrapping summary. Its charge is already included in transport/logistics; it is not an additional priced item. Adjust wrapped stops and recalculate logistics, or adjust the logistics charge directly.</p>
              </article>;
              const description = stringValue(item.detectedName ?? item.originalDescription ?? item.description);
              const quantityText = stringValue(item.quantity);
              const priceText = stringValue(item.unitPrice);
              const pendingQuantity = quantityText.trim() === "";
              const unresolvedUnitPrice = requirements.some((requirement) =>
                normalizeRequirementField(requirement.field) === normalizeRequirementField(`items.${index}.unitPrice`)
              );
              const numericPrice = Number(priceText);
              const pendingRate = priceText.trim() === "" ||
                (unresolvedUnitPrice && Number.isFinite(numericPrice) && numericPrice <= 0);
              const rateReasonKey = String(item.id ?? index);
              const qty = Number(quantityText);
              const price = Number(priceText);
              const lineTotal = Number.isFinite(qty * price) ? qty * price : 0;
              const fieldKey = (field: string) => `items.${index}.${field}`;
              const workDetailsKey = String(item._draftKey ?? item.id ?? index);
              const remarkIssue = Object.entries(fieldErrors).some(([field, message]) =>
                Boolean(message) && new RegExp(`^items\\.${index}\\.(remark|itemRemark)$`, "i").test(field)
              ) || requirements.some((requirement) =>
                new RegExp(`^items\\.${index}\\.(remark|itemRemark)$`, "i").test(requirement.field)
              );
              const workDetailsAutoOpen = Boolean(stringValue(item.remark).trim() || remarkIssue);
              const workDetailsOpen = itemWorkDetailsOpen[workDetailsKey] ?? workDetailsAutoOpen;
              return (
                <article key={item._draftKey ?? item.id ?? index} className="relative px-4 py-3 sm:px-6 sm:py-4">
                  <div className="mb-2 flex items-center justify-between gap-3">
                    <p className="font-mono text-[10px] font-bold tracking-[0.14em] text-black/40">LINE {String(index + 1).padStart(2, "0")}</p>
                    <button
                      type="button"
                      onClick={() => {setCatalogFor(null);onRemoveItem(index);}}
                      aria-label={`Remove item ${index + 1}`}
                      data-testid={`button-remove-edit-item-${index}`}
                      className="inline-flex min-h-8 items-center gap-1.5 px-2 text-[10px] font-black uppercase tracking-[0.12em] text-[#9E3032] hover:bg-[#FBEEEE] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#9E3032]"
                    >
                      <Trash2 aria-hidden="true" className="h-3.5 w-3.5" /> Remove
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-x-3 gap-y-2.5 sm:grid-cols-12 sm:gap-x-4">
                    <div className="relative col-span-2 sm:col-span-7">
                      <label className={labelClass} htmlFor={`edit-item-desc-${index}`}>Description</label>
                      <textarea
                        id={`edit-item-desc-${index}`}
                        rows={1}
                        value={description}
                        onFocus={() => { setCatalogFor(index); setCatalogQuery(description); }}
                        onBlur={(event) => {
                          const wrapper = event.currentTarget.parentElement;
                          if (event.relatedTarget instanceof Node && wrapper?.contains(event.relatedTarget)) return;
                          window.setTimeout(() => setCatalogFor((active) => active === index ? null : active), 150);
                        }}
                        onChange={(event) => {
                          onItemChange(index, "detectedName", event.target.value);
                          setCatalogFor(index);
                          setCatalogQuery(event.target.value);
                        }}
                        className={inputClass}
                        placeholder="Describe the item or work"
                        data-testid={`input-edit-item-desc-${index}`}
                        aria-label={`Description ${index + 1}`}
                        aria-invalid={Boolean(fieldErrors[fieldKey("description")] || fieldErrors[fieldKey("detectedName")])}
                        autoComplete="off"
                      />
                      <FieldError id={fieldKey("description")} errors={fieldErrors} />
                      <FieldError id={fieldKey("detectedName")} errors={fieldErrors} />
                      <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1">
                        <button
                          type="button"
                          onClick={() => { setCatalogQuery(""); setCatalogFor(index); }}
                          aria-expanded={catalogFor === index}
                          aria-controls={`edit-item-catalog-${index}`}
                          className="inline-flex min-h-9 items-center gap-1.5 border border-[#B78535]/45 bg-[#FBF6EA] px-2.5 text-[10px] font-black uppercase tracking-[0.1em] text-[#624716] hover:border-[#B78535] hover:bg-[#F6EFD9] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B78535]"
                        >
                          Choose catalogue item <ChevronDown aria-hidden="true" className={`h-3.5 w-3.5 transition-transform ${catalogFor === index ? "rotate-180" : ""}`} />
                        </button>
                        <p className="max-w-[34rem] text-[10px] leading-snug text-black/50">
                          Catalogue selection applies its approved service and rate. For custom inspection or status wording, enter the actual work scope—do not guess a price.
                        </p>
                      </div>
                      {catalogFor === index && (
                        <div id={`edit-item-catalog-${index}`} className="absolute inset-x-0 top-full z-20 mt-1 max-h-72 overflow-auto border border-black/15 bg-white shadow-lg" aria-label={`Catalogue picker for item ${index + 1}`}>
                          <div className="sticky top-0 z-10 border-b border-black/10 bg-white p-2">
                            <label className="sr-only" htmlFor={`edit-item-catalog-search-${index}`}>Search catalogue</label>
                            <input
                              id={`edit-item-catalog-search-${index}`}
                              type="search"
                              value={catalogQuery}
                              onChange={(event) => setCatalogQuery(event.target.value)}
                              placeholder="Search catalogue items"
                              className={`${inputClass} py-2`}
                              autoComplete="off"
                            />
                            <p className="mt-1.5 px-1 text-[9px] font-black uppercase tracking-[0.15em] text-black/40">Choose an approved service and rate</p>
                          </div>
                          {catalogMatches.map((entry) => (
                            <div key={entry.id}>
                            <button
                              type="button"
                              role="option"
                              onMouseDown={(event) => event.preventDefault()}
                              onClick={() => {
                                onCatalogSelect(index, entry);
                                setCatalogFor(null);
                                setCatalogQuery("");
                              }}
                              className="flex w-full items-center justify-between gap-3 border-b border-black/5 px-3 py-2.5 text-left last:border-0 hover:bg-[#F5F4F0] focus-visible:bg-[#F5F4F0] focus-visible:outline-none"
                            >
                              <span className="min-w-0">
                                <span className="block truncate text-[12px] font-semibold">{entry.name}</span>
                                <span className="mt-0.5 block text-[9px] uppercase tracking-[0.12em] text-black/45">{String(entry.serviceType).replaceAll("_", " + ")}</span>
                              </span>
                              <span className="shrink-0 font-mono text-[11px] font-bold">{money(Number(entry.basePrice))}</span>
                            </button>
                            <button type="button" data-testid={`link-catalog-${entry.id}`} className="w-full text-left px-3 py-2 text-xs underline text-zinc-600"
                              onClick={()=>{onCatalogSelect(index,entry,false);setCatalogFor(null);setCatalogQuery("");}}>Link this catalogue item; keep my rate</button>
                            </div>
                          ))}
                          {catalogMatches.length === 0 && <p className="px-3 py-4 text-[11px] text-black/55">No catalogue items match this search. Keep the description specific to the actual work.</p>}
                        </div>
                      )}
                    </div>
                    <div className="col-span-2 sm:col-span-5">
                      <label className={labelClass} htmlFor={`edit-item-service-${index}`}>Service</label>
                      <select
                        id={`edit-item-service-${index}`}
                        value={stringValue(item.serviceType)}
                        onChange={(event) => onItemChange(index, "serviceType", event.target.value)}
                        className={selectClass}
                        aria-label={`Service ${index + 1}`}
                        aria-invalid={Boolean(fieldErrors[fieldKey("serviceType")])}
                      >
                        {!SERVICES.some(([value])=>value===item.serviceType)&&<option value={item.serviceType}>{item.serviceType==="manual"?`${formatItemServiceLabel(item,items)} (saved manual; choose to change scope)`:`${item.serviceType} (saved service)`}</option>}
                        {SERVICES.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
                      </select>
                      <FieldError id={fieldKey("serviceType")} errors={fieldErrors} />
                      {item.serviceType==="relocate"&&<div className="mt-2">
                        <label className={labelClass} htmlFor={`relocation-mode-${index}`}>Relocation mode</label>
                        <select id={`relocation-mode-${index}`} aria-label={`Relocation mode ${index+1}`} className={selectClass}
                          value={item.relocateMode||(item.carryOnly?"carry_only":"standard")}
                          onChange={event=>onItemChange(index,"relocateMode",event.target.value)}>
                          <option value="carry_only">Carry only</option><option value="standard">Dismantle and reinstall</option><option value="reinstall_only">Already dismantled — reinstall only</option>
                        </select>
                        <p className="text-xs text-black/50 mt-1">Your entered rate is kept. Apply a catalogue rate explicitly if needed.</p>
                      </div>}
                    </div>
                    <div className="col-span-1 sm:col-span-3">
                      <label className={labelClass} htmlFor={`edit-item-qty-${index}`}>Quantity</label>
                      <input
                        id={`edit-item-qty-${index}`}
                        type="text"
                        inputMode="decimal"
                        value={quantityText}
                        onChange={(event) => onItemChange(index, "quantity", event.target.value)}
                        className={`${inputClass} font-mono tabular-nums`}
                        aria-label={`Quantity ${index + 1}`}
                        data-testid={`input-edit-item-qty-${index}`}
                        aria-invalid={Boolean(fieldErrors[fieldKey("quantity")])}
                      />
                      {pendingQuantity && <p className="mt-1 text-[10px] font-semibold text-[#8A5A21]">Pending confirmation</p>}
                      <FieldError id={fieldKey("quantity")} errors={fieldErrors} />
                      {inlineRequirements(fieldKey("quantity"))}
                    </div>
                    <div className="col-span-1 sm:col-span-4">
                      <label className={labelClass} htmlFor={`edit-item-price-${index}`}>Unit price</label>
                      <div className="relative">
                        <span aria-hidden="true" className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 font-mono text-[12px] text-black/45">$</span>
                        <input
                          id={`edit-item-price-${index}`}
                          type="text"
                          inputMode="decimal"
                          value={priceText}
                          onChange={(event) => onItemChange(index, "unitPrice", event.target.value)}
                          className={`${inputClass} pl-7 font-mono tabular-nums`}
                          aria-label={`Unit price ${index + 1}`}
                          data-testid={`input-edit-item-price-${index}`}
                          aria-invalid={Boolean(fieldErrors[fieldKey("unitPrice")])}
                        />
                      </div>
                      {pendingRate && <p className="mt-1 text-[10px] font-semibold text-[#8A5A21]">Pending price</p>}
                      <FieldError id={fieldKey("unitPrice")} errors={fieldErrors} />
                      {priceText.trim()==="" && (() => {
                        const detected=detectAdminCatalogRate(item,catalog);
                        return detected.entry ? <button type="button"
                          data-testid={`apply-detected-rate-${index}`}
                          onClick={()=>onCatalogSelect(index,detected.entry!)}
                          className="mt-1 text-xs font-semibold underline">
                          Use detected catalogue rate {money(Number(detected.entry.basePrice))}
                        </button> : <p className="mt-1 text-xs text-amber-800">{detected.reason}</p>;
                      })()}
                      {inlineRequirements(fieldKey("unitPrice"))}
                    </div>
                    <div className="col-span-2 flex items-end justify-between border-t border-dashed border-black/10 pt-2 sm:col-span-5 sm:justify-end sm:gap-4 sm:border-0 sm:pt-0">
                      <span className="text-[9px] font-black uppercase tracking-[0.15em] text-black/40 sm:hidden">Line total</span>
                      <div className="text-right">
                        <span className="hidden text-[9px] font-black uppercase tracking-[0.15em] text-black/40 sm:block">Line total</span>
                         <span className="mt-0.5 block font-mono text-[15px] font-bold tabular-nums">{pendingQuantity || pendingRate ? "Pending" : money(lineTotal)}</span>
                      </div>
                    </div>
                  </div>
                  {rateReasonItems.includes(index) && (
                    <div className="mt-3 border-l-2 border-[#B78535] pl-3">
                      <label className={labelClass} htmlFor={`edit-item-rate-reason-${index}`}>Price override reason · needed before sending</label>
                      <textarea
                        id={`edit-item-rate-reason-${index}`}
                        rows={2}
                        value={rateReasons[rateReasonKey] || ""}
                        onChange={(event) => onRateReasonChange(rateReasonKey, event.target.value)}
                        className={`${inputClass} resize-y`}
                        placeholder="For example: Owner-approved installation rate"
                        data-testid={`input-edit-item-rate-reason-${index}`}
                      />
                      <p className="mt-1 text-[11px] text-black/60">For a new custom price, record who approved it and why (at least 5 characters). “NA” is not a price approval. Saved approved rates do not need another explanation.</p>
                      <FieldError id={fieldKey("rateReason")} errors={fieldErrors} />
                    </div>
                  )}
                  <details
                    className="group mt-2 border-t border-black/10 pt-1"
                    open={workDetailsOpen}
                    onToggle={(event) => {
                      // React clears currentTarget after dispatch; retain only
                      // the primitive value in the deferred state updater.
                      const open = event.currentTarget.open;
                      setItemWorkDetailsOpen((current) => current[workDetailsKey] === open
                        ? current : { ...current, [workDetailsKey]: open });
                    }}
                  >
                    <summary
                      onClick={(event) => {
                        event.preventDefault();
                        setItemWorkDetailsOpen((current) => ({
                          ...current, [workDetailsKey]: !(current[workDetailsKey] ?? workDetailsAutoOpen),
                        }));
                      }}
                      className="flex min-h-9 cursor-pointer list-none items-center justify-between gap-3 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-black/60 hover:text-black [&::-webkit-details-marker]:hidden">
                      <span>Work details <span className="font-medium normal-case tracking-normal text-black/40">· customer item remark</span></span>
                      <ChevronDown aria-hidden="true" className="h-3.5 w-3.5 shrink-0 transition-transform group-open:rotate-180" />
                    </summary>
                    <div className="pb-1">
                      <label className={labelClass} htmlFor={`edit-item-remark-${index}`}>Customer item remark</label>
                      <textarea id={`edit-item-remark-${index}`} rows={2} value={item.remark||""}
                        onChange={event=>onItemChange(index,"remark",event.target.value)} className={`${inputClass} resize-y`}
                        data-testid={`input-edit-item-remark-${index}`}
                        aria-invalid={Boolean(fieldErrors[fieldKey("remark")])}
                      />
                      <FieldError id={fieldKey("remark")} errors={fieldErrors} />
                    </div>
                  </details>
                </article>
              );
            })}
          </div>
          <div className="flex flex-col gap-4 border-t border-black/10 bg-[#FAF9F6] px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
            <button
              type="button"
              onClick={onAddItem}
              id="button-add-edit-item"
              data-testid="button-add-edit-item"
              className="inline-flex min-h-10 items-center justify-center gap-2 border border-black/20 bg-white px-3 text-[10px] font-black uppercase tracking-[0.14em] transition-colors hover:border-black hover:bg-[#F5F4F0] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
            >
              <Plus aria-hidden="true" className="h-3.5 w-3.5" /> Add item
            </button>
            <div className="flex items-center justify-between gap-6 border-t border-black/10 pt-3 sm:min-w-64 sm:justify-end sm:border-0 sm:pt-0">
              <span className="text-[10px] font-black uppercase tracking-[0.16em] text-black/50">Itemised subtotal</span>
              <span className="font-mono text-[17px] font-black tabular-nums">{totalsReady ? money(totals.subtotal) : "Pending lines"}</span>
            </div>
          </div>
        </section>

        <section id="quote-job-details" className="border border-black/12 bg-white">
          <details
            className="group"
            open={customerDetailsOpen}
            onToggle={(event) => setCustomerDetailsOpen(event.currentTarget.open)}
          >
            <summary
              onClick={(event) => { event.preventDefault(); setCustomerDetailsOpen((open) => !open); }}
              className="flex min-h-[58px] cursor-pointer list-none items-center justify-between gap-4 px-4 py-3 hover:bg-[#FAF9F6] sm:px-6 [&::-webkit-details-marker]:hidden">
              <span className="flex min-w-0 items-center gap-3">
                <span className="font-mono text-[10px] font-bold tracking-[0.14em] text-black/35">02</span>
                <span className="min-w-0">
                  <span className="block text-[12px] font-black uppercase tracking-[0.17em] text-[#11110F]">Customer & job details</span>
                  <span className="mt-1 block truncate text-[11px] text-black/50">
                    {[person.name, person.phone, quote.serviceAddress].filter(Boolean).join(" · ") || "Details not entered"}
                  </span>
                </span>
              </span>
              <ChevronDown aria-hidden="true" className="h-4 w-4 shrink-0 text-black/50 transition-transform group-open:rotate-180" />
            </summary>
            <div className="grid grid-cols-1 gap-x-5 gap-y-4 border-t border-black/10 px-4 py-4 sm:grid-cols-2 sm:px-6">
              <div>{textInput("name", "Customer name", person.name, (value) => changeCustomer("name", value))}{inlineRequirements("customer.name","customerName")}</div>
              {textInput("phone", "Phone", person.phone, (value) => changeCustomer("phone", value), { type: "tel" })}
              <div>
                {textInput("email", "Email (optional)", person.email, (value) => changeCustomer("email", value), { type: "email" })}
                <p className="mt-1 text-[11px] text-black/45">Only needed when emailing the quotation.</p>
              </div>
              <div className="sm:col-span-2">
                <label className={labelClass} htmlFor="quote-service-address">Service address</label>
                <textarea
                  id="quote-service-address"
                  value={stringValue(quote.serviceAddress)}
                  onChange={(event) => changeQuote("serviceAddress", event.target.value)}
                  className={`${inputClass} min-h-[76px] resize-y`}
                  rows={2}
                  aria-label="Service address"
                  aria-invalid={Boolean(fieldErrors.serviceAddress)}
                />
                <FieldError id="serviceAddress" errors={fieldErrors} />
                {inlineRequirements("serviceAddress","jobAddress")}
              </div>
            </div>
          </details>
          <details className="border-t border-black/10">
            <summary className="flex min-h-11 cursor-pointer items-center justify-between px-4 py-3 text-[11px] font-bold text-black/65 hover:bg-[#FAF9F6] sm:px-6">
              Notes <ChevronDown aria-hidden="true" className="h-3.5 w-3.5 text-black/45" />
            </summary>
            <div className="border-t border-black/10 px-4 py-4 sm:px-6">
              <label className={labelClass} htmlFor="quote-notes">Notes</label>
              <textarea
                id="quote-notes"
                value={stringValue(quote.notes)}
                onChange={(event) => changeQuote("notes", event.target.value)}
                className={`${inputClass} min-h-[88px] resize-y`}
                rows={3}
                aria-label="Notes"
              />
            </div>
          </details>
          {logistics && <div className="border-t border-black/10 px-4 py-4 sm:px-6">{logistics}</div>}
          {historicalNotes && (
            <details className="border-t border-black/10 bg-[#FBF8F0]">
              <summary className="cursor-pointer px-4 py-3 text-[11px] font-bold text-[#76633B] sm:px-6">Historical intake notes · retained as saved</summary>
              <p className="whitespace-pre-wrap px-4 pb-4 text-xs leading-relaxed text-[#66583A] sm:px-6">{historicalNotes}</p>
            </details>
          )}
        </section>

        {reviewPanel}

        <section id="quote-total-section" className="border border-black/12 bg-white">
          <SectionTitle
            number="03"
            title={totalIsPending ? "Known priced components" : "Quote total"}
            detail={totalIsPending ? "Proposed amounts only. Final pricing remains pending review." : "Itemised charges and adjustments supplied by the quote."}
            trailing={<CircleDollarSign aria-hidden="true" className="h-4 w-4 text-black/45" />}
          />
          <div className="grid grid-cols-1 gap-0 sm:grid-cols-2">
            <div className="space-y-2.5 px-4 py-4 sm:border-r sm:border-black/10 sm:px-6">
              {[
                ["Items", totals.subtotal],
                ["Discount", -Math.abs(totals.discount)],
                ["Promo discount", -Math.abs(totals.promoDiscount)],
                ["Goodwill", -Math.abs(totals.goodwill)],
                ["Transport", totals.transport],
                ["Second day", totals.secondDay],
                ["Additional trip", totals.additionalTrip],
                ["After-office charge", totals.afterOffice],
              ].filter(([, amount]) => Number(amount) !== 0 || amount === totals.subtotal).map(([label, amount]) => (
                <div key={String(label)} className="flex items-center justify-between gap-4 text-[12px]">
                  <span className="text-black/55">{label}</span>
                  <span className="font-mono font-semibold tabular-nums">{Number(amount) < 0 ? `−${money(Math.abs(Number(amount)))}` : money(Number(amount))}</span>
                </div>
              ))}
              {transportIsPending && <div className="flex items-center justify-between gap-4 text-[12px]" data-testid="edit-transport-pending">
                <span className="text-black/55">Transport / access</span>
                <span className="font-semibold text-amber-800">Pricing pending</span>
              </div>}
            </div>
            <div className="flex items-center justify-between gap-4 border-t border-black/10 bg-[#FAF9F6] px-4 py-4 sm:border-0 sm:px-6">
              <span className="text-[10px] font-black uppercase tracking-[0.17em] text-black/50">Paid to date</span>
              <span className="font-mono text-[14px] font-bold tabular-nums">{money(totals.paid)}</span>
            </div>
          </div>
          <div className="border-t px-4 py-4 sm:px-6 grid gap-3 sm:grid-cols-2">
            {numericInput("transportFee", "Transport / logistics charge", quote.transportFee, value=>changeQuote("transportFee",value))}
            {inlineRequirements("transportFee")}
            {numericInput("goodwillDiscount", "Goodwill discount", quote.goodwillDiscount, value=>changeQuote("goodwillDiscount",value))}
            {textInput("goodwillReason", "Goodwill reason", quote.goodwillReason,value=>changeQuote("goodwillReason",value))}
          </div>
        </section>

        <details
          id="quote-business-details"
          className="group border border-black/12 bg-white"
          open={businessDetailsOpen}
          onToggle={(event) => setBusinessDetailsOpen(event.currentTarget.open)}
        >
          <summary className="flex min-h-[58px] cursor-pointer list-none items-center justify-between gap-4 px-4 py-3 hover:bg-[#FAF9F6] sm:px-6 [&::-webkit-details-marker]:hidden">
            <span className="flex items-center gap-3">
              <span className="flex h-8 w-8 items-center justify-center bg-[#F0EFEA]"><FileText aria-hidden="true" className="h-4 w-4" /></span>
              <span>
                <span className="block text-[11px] font-black uppercase tracking-[0.16em]">Business, billing & adjustments</span>
                <span className="mt-1 block text-[11px] text-black/50">Invoice details, allowances, surcharges and job terms</span>
              </span>
            </span>
            <ChevronDown aria-hidden="true" className="h-4 w-4 shrink-0 text-black/50 transition-transform group-open:rotate-180" />
          </summary>
          <div className="space-y-5 border-t border-black/10 p-4 sm:p-6">
            <div>
              <h3 className="mb-3 text-[9px] font-black uppercase tracking-[0.18em] text-black/45">Billing details</h3>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className={labelClass} htmlFor="invoice-type">Invoice type</label>
                  <select id="invoice-type" value={stringValue(quote.invoiceType || "residential")} onChange={(event) => changeQuote("invoiceType", event.target.value)} className={selectClass}>
                    <option value="residential">Residential</option><option value="commercial">Commercial</option>
                  </select>
                  <FieldError id="invoiceType" errors={fieldErrors} />
                </div>
                {textInput("billing-company-name", "Billing company name", quote.billingCompanyName, (value) => changeQuote("billingCompanyName", value))}
                {textInput("billing-company-uen", "Billing company UEN", quote.billingCompanyUen, (value) => changeQuote("billingCompanyUen", value))}
                {textInput("po-number", "PO number", quote.poNumber, (value) => changeQuote("poNumber", value))}
                <div className="sm:col-span-2">
                  <label className={labelClass} htmlFor="billing-address">Billing address</label>
                  <textarea id="billing-address" rows={2} value={stringValue(quote.billingAddress)} onChange={(event) => changeQuote("billingAddress", event.target.value)} className={`${inputClass} min-h-[68px] resize-y`} />
                  <FieldError id="billingAddress" errors={fieldErrors} />
                </div>
              </div>
            </div>
            <div className="border-t border-black/10 pt-4">
              <h3 className="mb-3 text-[9px] font-black uppercase tracking-[0.18em] text-black/45">Discounts & crew charges</h3>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {toggle("staffTransportAllowance", "Staff transport allowance", quote.staffTransportAllowance, (value) => changeQuote("staffTransportAllowance", value))}
                {toggle("secondDayContinuation", "Second-day continuation", quote.secondDayContinuation, (value) => changeQuote("secondDayContinuation", value))}
                {numericInput("secondDayHours", "Second-day hours", quote.secondDayHours, (value) => changeQuote("secondDayHours", value))}
                {numericInput("secondDayCrewSize", "Second-day crew size", quote.secondDayCrewSize, (value) => changeQuote("secondDayCrewSize", value))}
                {toggle("afterOfficeInvolved", "After-office work involved", quote.afterOfficeInvolved, (value) => changeQuote("afterOfficeInvolved", value))}
                {numericInput("afterOfficeSurchargeAmount", "After-office amount", quote.afterOfficeSurchargeAmount, (value) => changeQuote("afterOfficeSurchargeAmount", value))}
                {toggle("afterOfficeWaived", "After-office charge waived", quote.afterOfficeWaived, (value) => changeQuote("afterOfficeWaived", value))}
                {textInput("afterOfficeWaiverReason", "Waiver reason", quote.afterOfficeWaiverReason, (value) => changeQuote("afterOfficeWaiverReason", value))}
                {numericInput("additionalTripCharge", "Additional trip charge", quote.additionalTripCharge, (value) => changeQuote("additionalTripCharge", value))}
              </div>
            </div>
            <div className="border-t border-black/10 pt-4">
              <h3 className="mb-3 text-[9px] font-black uppercase tracking-[0.18em] text-black/45">Job terms</h3>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label className={labelClass} htmlFor="special-remarks">Special remarks</label>
                  <textarea id="special-remarks" rows={3} value={stringValue(quote.specialRemarks)} onChange={(event) => changeQuote("specialRemarks", event.target.value)} className={`${inputClass} min-h-[76px] resize-y`} />
                  <FieldError id="specialRemarks" errors={fieldErrors} />
                </div>
                {toggle("ownMoverInvolved", "Customer's own mover involved", quote.ownMoverInvolved, (value) => changeQuote("ownMoverInvolved", value))}
                {toggle("depositRefundable", "Deposit refundable", quote.depositRefundable, (value) => changeQuote("depositRefundable", value))}
                {numericInput("cancellationNoticeHours", "Cancellation notice (hours)", quote.cancellationNoticeHours, (value) => changeQuote("cancellationNoticeHours", value))}
              </div>
            </div>
          </div>
        </details>

        {surchargeChanged && (
          <section className="border border-[#C89A39]/50 bg-[#FBF5E7] px-4 py-4 sm:px-6" aria-labelledby="surcharge-ack-heading">
            <h2 id="surcharge-ack-heading" className="text-[10px] font-black uppercase tracking-[0.17em] text-[#684C13]">Confirm surcharge change</h2>
            <p className="mt-1.5 max-w-2xl text-[12px] leading-relaxed text-[#765D29]">Confirm the changed surcharge is reflected in this quote, or waived in writing. This acknowledgement is only required because surcharge details changed.</p>
            <label className="mt-3 flex cursor-pointer items-start gap-2.5 text-[12px] font-medium leading-relaxed text-[#4F3B14]">
              <input
                type="checkbox"
                checked={surchargeAck}
                onChange={(event) => onSurchargeAckChange(event.target.checked)}
                className="mt-0.5 h-4 w-4 shrink-0 accent-[#7E5C17]"
                data-testid="toggle-surcharge-ack"
              />
              I confirm the updated surcharge is on the quote or has been waived in writing.
            </label>
          </section>
        )}

        <div className="flex items-center gap-2 px-1 text-[11px] text-black/45">
          <UserRound aria-hidden="true" className="h-3.5 w-3.5 shrink-0" />
          Changes remain in this editor until you save.
        </div>
      </fieldset>

      <footer className="fixed left-0 right-0 lg:left-56 bottom-[calc(64px+env(safe-area-inset-bottom))] lg:bottom-0 z-40 shadow-[0_-4px_16px_rgba(0,0,0,0.08)] flex flex-col gap-1.5 border border-black/15 bg-white px-3 py-2 sm:flex-row sm:items-center sm:justify-between sm:px-5">
        <div className="min-w-0 sm:max-w-[58%]">
          <div>
            <p className="flex items-baseline gap-2 text-[10px] font-black uppercase tracking-[0.15em] text-black/50">
              {totalIsPending ? "Known components" : "Draft total"} <span data-testid="edit-quote-total" className="font-mono text-[17px] font-black tracking-normal text-[#171713]">{totalsReady ? money(totals.total) : "Incomplete"}</span>
            </p>
            {totalIsPending && <p className="mt-0.5 text-[10px] font-semibold text-[#8A5A21]">Final price pending review</p>}
          </div>
          {linkedIssues.length > 0 && (
            <ul
              className="mt-1 flex max-h-10 flex-wrap gap-x-3 gap-y-0.5 overflow-y-auto text-[10px] leading-tight"
              aria-label="Quote fields to review"
            >
              {linkedIssues.map((issue, index) => (
                <li key={`${issue.field}-${issue.message}-${index}`} className="min-w-0 max-w-full">
                  <a
                    href={`#${fieldTarget(issue.field)}`}
                    onClick={(event) => {
                      event.preventDefault();
                      focusIssueField(issue.field);
                    }}
                    className="inline-flex max-w-full items-start gap-1 text-[#9E3032] underline decoration-[#9E3032]/40 underline-offset-2 hover:decoration-[#9E3032]"
                  >
                    <AlertCircle aria-hidden="true" className="mt-px h-3 w-3 shrink-0" />
                    <span className="truncate"><span className="font-bold">{fieldLabel(issue.field)}:</span> {issue.message}</span>
                  </a>
                </li>
              ))}
            </ul>
          )}
          {unmatchedIssues.length > 0 && (
            reviewPanel ? <button type="button" className="mt-1 text-[10px] font-semibold text-[#8A5A21] underline"
              onClick={()=>{
                const panel=document.getElementById("quote-review-details") as HTMLDetailsElement|null;
                if(panel){panel.open=true;panel.scrollIntoView({block:"center",behavior:"smooth"});}
              }}>Review remaining details · {unmatchedIssues.length}</button> : <details className="mt-1 text-[10px] text-[#8A5A21]">
              <summary className="w-fit cursor-pointer font-bold underline underline-offset-2">
                Specialist review · {unmatchedIssues.length}
              </summary>
              <ul className="mt-1 max-h-20 space-y-1 overflow-y-auto">
                {unmatchedIssues.map((issue, index) => (
                  <li key={`${issue.field}-${issue.message}-${index}`}>
                    <span className="font-bold">{fieldLabel(issue.field)}:</span> {issue.message}
                  </li>
                ))}
              </ul>
            </details>
          )}
          {sendError ? (
            <p role="alert" data-testid="edit-send-error" className="mt-1 truncate border-l-2 border-[#B4232D] pl-2 text-[10px] font-semibold text-[#9E252D]">
              {sendError}{sendRetryAllowed ? " · Retry is available." : deliveryOutcome?.status === "not_sent" || deliveryOutcome?.status === "suppressed" ? " · No message was sent." : " · Provider outcome may be uncertain."}
            </p>
          ) : error ? (
            <p role="alert" data-testid="edit-save-error" className="mt-1 truncate border-l-2 border-[#B4232D] pl-2 text-[10px] font-semibold text-[#9E252D]">
              {(linkedIssues.length || unmatchedIssues.length) && /Complete the highlighted fields/i.test(error)
                ? "Review the listed details. Nothing sent; your changes are retained." : error}
            </p>
          ) : dirty ? (
            <p className="text-[11px] font-semibold text-[#76550F]">Unsaved changes — save when this quote is ready.</p>
          ) : (
            <p className="text-[11px] text-black/45">No unsaved changes.</p>
          )}
        </div>
        <div className="grid grid-cols-2 gap-2 sm:flex sm:shrink-0">
          <button
            type="button"
            onClick={onSave}
            disabled={pending || sending || calculating || (surchargeChanged && !surchargeAck)}
            data-testid="button-save-edit"
            className="inline-flex min-h-11 items-center justify-center gap-2 border border-black/20 bg-white px-3 text-[10px] font-black uppercase tracking-[0.12em] text-[#171713] transition-colors hover:bg-[#F5F4F0] disabled:cursor-not-allowed disabled:opacity-45 sm:px-4"
          >
            <Save aria-hidden="true" className="h-3.5 w-3.5" />
            {pending ? "Saving draft…" : calculating ? "Calculating…" : "Save draft"}
          </button>
          <button
            type="button"
            onClick={onSaveAndSend}
            disabled={pending || sending || calculating || sendLocked || deliveryRouteUnavailable || deliveryContextLoading || deliveryContextError || (surchargeChanged && !surchargeAck)}
            data-testid="button-save-send-quote"
            className="inline-flex min-h-11 items-center justify-center gap-2 bg-[#171713] px-3 text-[10px] font-black uppercase tracking-[0.11em] text-white transition-colors hover:bg-[#39372F] disabled:cursor-not-allowed disabled:opacity-45 sm:px-4"
          >
            {sending ? "Preparing…" : deliveryOutcome?.status === "sent" && !dirty ? "Provider accepted" : deliveryOutcome?.status === "delivered" && !dirty ? "Delivered" : deliveryOutcome?.status === "read" && !dirty ? "Read" : sendRetryAllowed && sendError ? "Retry sending" : dirty ? "Save & send quote" : "Send quote"}
          </button>
        </div>
        {(sendStatusMessage || deliveryOutcome?.status) && <p role="status" data-testid="quote-delivery-status" className="text-[11px] leading-relaxed text-[#6C5934] sm:ml-auto sm:max-w-[24rem]">
          {sendStatusMessage}
          {deliveryOutcome?.attachment === "link_only" ? " This was a quotation link only, not a PDF attachment." : ""}
        </p>}
      </footer>
    </div>
  );
}
