import { useState } from "react";
import { ChevronDown, ClipboardCheck } from "lucide-react";

export type QuoteWorkspaceRequirement = { field: string; message: string };
export type QuoteWorkspaceFacts = Record<string, string | number | boolean | null | undefined>;

const fields: { key: string; label: string; kind: "text" | "boolean" | "difficulty" }[] = [
  { key: "customerName", label: "Customer name", kind: "text" },
  { key: "jobAddress", label: "Job address", kind: "text" },
  { key: "toAddress", label: "Destination address", kind: "text" },
  { key: "floorLevel", label: "Pickup floor", kind: "text" },
  { key: "hasLift", label: "Lift at pickup", kind: "boolean" },
  { key: "destinationFloor", label: "Destination floor", kind: "text" },
  { key: "destinationLift", label: "Lift at destination", kind: "boolean" },
  { key: "itemLocation", label: "Where the items are", kind: "text" },
  { key: "carryingRequired", label: "Carrying assistance required", kind: "boolean" },
  { key: "samePropertyMove", label: "Within the same property", kind: "boolean" },
  { key: "accessDifficulty", label: "Access difficulty", kind: "difficulty" },
];

const normalizeField = (value: string) => value.replace(/[^a-z0-9]/gi, "").toLowerCase();
const factAlias: Record<string, string> = {
  customername: "customername", customer: "customername",
  jobaddress: "jobaddress", serviceaddress: "jobaddress", pickupaddress: "jobaddress", fromaddress: "jobaddress",
  toaddress: "toaddress", destinationaddress: "toaddress", dropoffaddress: "toaddress",
  floorlevel: "floorlevel", pickupfloor: "floorlevel", floorfrom: "floorlevel",
  haslift: "haslift", liftfrom: "haslift", pickuphaslift: "haslift",
  destinationfloor: "destinationfloor", floorto: "destinationfloor", destinationlift: "destinationlift", liftto: "destinationlift",
  itemlocation: "itemlocation", carryingrequired: "carryingrequired",
  samepropertymove: "samepropertymove", accessdifficulty: "accessdifficulty",
};
const factKeyFor = (value: string) => {
  const normalized = normalizeField(value);
  const withoutFactsPrefix = normalized.startsWith("facts") ? normalized.slice(5) : normalized;
  return factAlias[normalized] || factAlias[withoutFactsPrefix] || normalized;
};
const isTransportRequirement = (value: string) => /transport|logistic/.test(normalizeField(value));
const isItemRequirement = (value: string) => /^items\d+/.test(normalizeField(value)) || /quantity|unitprice|itemprice|priceperunit/.test(normalizeField(value));
const inputClass =
  "min-h-10 w-full border border-[#D8D3C9] bg-[#FFFEFA] px-3 py-2 text-sm text-[#25231F] outline-none focus:border-[#544932] focus:ring-2 focus:ring-[#544932]/15";

const isKnown = (value: unknown) =>
  value !== null && value !== undefined && !(typeof value === "string" && value.trim() === "");

export function QuoteWorkspaceReview({
  requirements,
  existingFacts = [],
  facts,
  onFactsChange,
  decisions,
  onDecisionChange,
  transportConfirmed,
  onTransportConfirmedChange,
  transportFee,
}: {
  requirements: QuoteWorkspaceRequirement[];
  existingFacts?: string[];
  facts: QuoteWorkspaceFacts;
  onFactsChange: (field: string, value: string | boolean | null) => void;
  decisions: Record<string, string>;
  onDecisionChange: (field: string, value: string) => void;
  transportConfirmed: boolean;
  onTransportConfirmedChange: (value: boolean) => void;
  transportFee: number | string;
}) {
  const [editingField, setEditingField] = useState<string | null>(null);
  const [activeMissingFields, setActiveMissingFields] = useState<Set<string>>(() => new Set());
  const existingFactKeys = new Set(existingFacts.map(factKeyFor));
  const booleanValue = (value: unknown) => {
    const normalized=String(value??"").trim().toLowerCase();
    return ["true","yes","1"].includes(normalized) ? "true" :
      ["false","no","0"].includes(normalized) ? "false" : "";
  };
  const fieldKnown = (field: typeof fields[number]) => field.kind==="boolean"
    ? booleanValue(facts[field.key])!=="" : isKnown(facts[field.key]);
  const uniqueRequirements = requirements.filter((item, index, all) =>
    all.findIndex((candidate) =>
      factKeyFor(candidate.field) === factKeyFor(item.field) && candidate.message === item.message
    ) === index
  );
  const requiredFields = new Set(uniqueRequirements
    .filter((item) => !isTransportRequirement(item.field) && !isItemRequirement(item.field))
    .map((item) => factKeyFor(item.field)));
  const missingFields = fields.filter((field) =>
    requiredFields.has(factKeyFor(field.key)) &&
    !existingFactKeys.has(factKeyFor(field.key)) &&
    (!fieldKnown(field) || activeMissingFields.has(field.key))
  );
  const confirmedFields = fields.filter((field) =>
    !existingFactKeys.has(factKeyFor(field.key)) &&
    fieldKnown(field) && !missingFields.some(missing => missing.key === field.key)
  );
  const fieldRequirements = (key: string) => uniqueRequirements.filter((item) => factKeyFor(item.field) === factKeyFor(key));
  const specialistRequirements = uniqueRequirements.filter((item) =>
    !fields.some((field) => factKeyFor(field.key) === factKeyFor(item.field)) &&
    !existingFactKeys.has(factKeyFor(item.field)) &&
    !isTransportRequirement(item.field) &&
    !isItemRequirement(item.field) &&
    !/raterason/.test(normalizeField(item.field)) &&
    factKeyFor(item.field) !== "items" &&
    factKeyFor(item.field) !== "total"
  );
  const transportRequirements = uniqueRequirements.filter((item) =>
    isTransportRequirement(item.field) && !existingFactKeys.has(factKeyFor(item.field))
  );
  const actionableCount = missingFields.length + specialistRequirements.length + (transportRequirements.length ? 1 : 0);
  const feeIsKnown = transportFee !== null && transportFee !== undefined &&
    !(typeof transportFee === "string" && transportFee.trim() === "") &&
    Number.isFinite(Number(transportFee));
  const displayFact = (field: typeof fields[number]) => {
    const value = facts[field.key];
    if (field.kind === "boolean") return booleanValue(value) === "true" ? "Yes" : "No";
    if (field.kind === "difficulty") return String(value).charAt(0).toUpperCase() + String(value).slice(1);
    return String(value);
  };

  const renderFieldInput = (field: typeof fields[number]) => (
    field.kind === "boolean" ? (
      <select
        id={`workspace-fact-${field.key}`}
        onFocus={() => setActiveMissingFields(current => new Set(current).add(field.key))}
        className={inputClass}
        value={booleanValue(facts[field.key])}
        onChange={(event) => onFactsChange(field.key, event.target.value === "" ? null : event.target.value === "true")}
      >
        <option value="">Not confirmed</option>
        <option value="true">Yes</option>
        <option value="false">No</option>
      </select>
    ) : field.kind === "difficulty" ? (
      <select
        id={`workspace-fact-${field.key}`}
        onFocus={() => setActiveMissingFields(current => new Set(current).add(field.key))}
        className={inputClass}
        value={String(facts[field.key] ?? "")}
        onChange={(event) => onFactsChange(field.key, event.target.value || null)}
      >
        <option value="">Not assessed</option>
        <option value="easy">Easy</option>
        <option value="moderate">Moderate</option>
        <option value="hard">Hard</option>
      </select>
    ) : (
      <input
        id={`workspace-fact-${field.key}`}
        onFocus={() => setActiveMissingFields(current => new Set(current).add(field.key))}
        className={inputClass}
        value={String(facts[field.key] ?? "")}
        onChange={(event) => onFactsChange(field.key, event.target.value)}
        placeholder="Add confirmed detail"
      />
    )
  );

  return (
    <details id="quote-review-details" open={actionableCount > 0} className="group border border-[#D9D3C8] bg-[#FFFEFA]" data-testid="quote-workspace-review">
      <summary className="flex min-h-14 cursor-pointer list-none items-center justify-between gap-3 px-4 py-3 hover:bg-[#F7F4ED] [&::-webkit-details-marker]:hidden">
        <span className="flex min-w-0 items-center gap-3">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center bg-[#F1EDE3] text-[#62543A]"><ClipboardCheck className="h-4 w-4" /></span>
          <span className="min-w-0">
            <span className="block text-[11px] font-black uppercase tracking-[0.15em] text-[#26241F]">Review details</span>
            <span className="mt-1 block text-[11px] text-[#716B5E]">
              {actionableCount ? `${actionableCount} item${actionableCount === 1 ? "" : "s"} need attention` : `${confirmedFields.length} confirmed detail${confirmedFields.length === 1 ? "" : "s"}`}
            </span>
          </span>
        </span>
        <ChevronDown className="h-4 w-4 shrink-0 text-[#756D5E] transition-transform group-open:rotate-180" />
      </summary>

      <div className="space-y-4 border-t border-[#E8E2D7] p-4 sm:p-5">
        {missingFields.length > 0 && (
          <div className="grid gap-3 sm:grid-cols-2">
            {missingFields.map((field) => {
              const messages = fieldRequirements(field.key);
              return (
                <div key={field.key} className={field.key === "jobAddress" || field.key === "toAddress" ? "sm:col-span-2" : ""}>
                  <label className="mb-1 block text-[10px] font-black uppercase tracking-[0.14em] text-[#746D60]" htmlFor={`workspace-fact-${field.key}`}>
                    {field.label}<span className="ml-1 text-[#9B6321]">Required</span>
                  </label>
                  {renderFieldInput(field)}
                  {messages.map((message) => <p key={`${message.field}-${message.message}`} className="mt-1 text-[11px] font-medium text-[#8A5A21]">{message.message}</p>)}
                </div>
              );
            })}
          </div>
        )}

        {specialistRequirements.map((requirement, index) => (
          <div key={`${requirement.field}-decision-${index}`} className="grid gap-2 sm:grid-cols-[1fr_13rem] sm:items-center">
            <p className="text-xs leading-relaxed text-[#504A3E]">{requirement.message}</p>
            {(() => {
              const decisionKey = requirement.field.startsWith("decisions.") ? requirement.field.slice("decisions.".length) : requirement.field;
              return <>
            <label className="sr-only" htmlFor={`workspace-decision-${index}`}>Resolution for review item</label>
            <select
              id={`workspace-decision-${index}`}
              className={inputClass}
              value={decisions[decisionKey] || ""}
              onChange={(event) => onDecisionChange(decisionKey, event.target.value)}
            >
              <option value="">Choose a resolution</option>
              <option value="confirmed">Confirmed after review</option>
              <option value="not_applicable">Not applicable</option>
              <option value="follow_up_required">Follow up with customer</option>
            </select>
              </>;
            })()}
          </div>
        ))}

        {transportRequirements.length > 0 && (
          <div className="border-t border-[#E8E2D7] pt-3">
            {transportRequirements.map((requirement) => (
              <p key={`${requirement.field}-${requirement.message}`} className="mb-2 text-xs leading-relaxed text-[#504A3E]">{requirement.message}</p>
            ))}
            <label className="flex cursor-pointer items-start gap-2.5 text-xs leading-relaxed text-[#4F4A3F]">
              <input
                type="checkbox"
                className="mt-0.5 h-4 w-4 shrink-0 accent-[#51452D]"
                checked={transportConfirmed}
                onChange={(event) => onTransportConfirmedChange(event.target.checked)}
              />
              <span>
                I reviewed the transport / logistics charge:{" "}
                <strong className="font-mono">{feeIsKnown ? `$${Number(transportFee).toFixed(2)}` : "amount pending"}</strong>.
              </span>
            </label>
          </div>
        )}

        {confirmedFields.length > 0 && (
          <details className="border-t border-[#E8E2D7] pt-3">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-3 py-1 text-xs font-bold text-[#514B40] [&::-webkit-details-marker]:hidden">
              <span>Confirmed details <span className="font-normal text-[#81796B]">({confirmedFields.length})</span></span>
              <ChevronDown className="h-3.5 w-3.5 shrink-0 text-[#756D5E] transition-transform group-open:rotate-180" />
            </summary>
            <div className="mt-3 divide-y divide-[#E8E2D7]">
              {confirmedFields.map((field) => (
                <div key={field.key} className="flex flex-col gap-2 py-2.5 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <p className="text-[10px] font-black uppercase tracking-[0.12em] text-[#746D60]">{field.label}</p>
                    {editingField === field.key ? renderFieldInput(field) : (
                      <p className="mt-0.5 break-words text-xs text-[#37342D]">{displayFact(field)}</p>
                    )}
                  </div>
                  {editingField === field.key ? (
                    <button type="button" className="self-start text-xs font-semibold text-[#62543A] underline underline-offset-2 sm:shrink-0" onClick={() => setEditingField(null)}>Done</button>
                  ) : (
                    <button type="button" className="self-start text-xs font-semibold text-[#62543A] underline underline-offset-2 sm:shrink-0" onClick={() => setEditingField(field.key)}>Edit</button>
                  )}
                </div>
              ))}
            </div>
          </details>
        )}
      </div>
    </details>
  );
}
