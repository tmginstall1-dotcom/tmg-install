import React from "react";

export function ActiveGpsStatusNotice({ unavailable, pending, retrying, onRetry }: {
  unavailable: boolean;
  pending: boolean;
  retrying: boolean;
  onRetry: () => void;
}) {
  if (unavailable) return (
    <div role="alert" className="border border-amber-200 p-3 text-sm text-amber-900" data-testid="active-gps-unavailable">
      Active GPS status unavailable. Saved locations are not live tracking.
      <button type="button" disabled={retrying} onClick={onRetry}
        className="ml-3 underline font-semibold disabled:opacity-50"
        data-testid="button-retry-active-gps">
        {retrying ? "Retrying…" : "Retry live status"}
      </button>
    </div>
  );
  if (pending) return <p role="status" className="text-sm text-zinc-500">Checking active GPS status…</p>;
  return null;
}
