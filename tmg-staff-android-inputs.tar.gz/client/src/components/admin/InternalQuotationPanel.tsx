import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, ArrowUpRight, CheckCircle2, FileText, LockKeyhole, RefreshCw, ShieldCheck } from "lucide-react";

type InternalQuoteItem = {
  id?: number;
  description: string;
  quantity: number | null;
  serviceType: string;
  unitPrice: number | null;
  lineTotal: number | null;
  scope?: string;
  priceState: "priced" | "partial" | "pending";
};

type InternalQuotation = {
  revision: string;
  quote: null | {
    id: number;
    referenceNo: string;
    version: number;
    total: number;
    status: string;
    requiresManualReview: boolean;
  };
  items: InternalQuoteItem[];
  pricedSubtotal: number;
  knownCharges: number;
  unpricedCount: number;
  componentNotice?:string;
  missing: string[];
  protectedReason: string | null;
  assessment: null | { at: string; outcome: string };
  canAssess: boolean;
  generatedAssessment?: {quoteId:number;version:number;assessedAt:string}|null;
  staffDocument?:{messageId:number;filename:string;status:string;mediaUrl:string;associationVerified:boolean;createdAt:string;associationReason?:string;shareBlockedReason?:string};
  relatedQuotes?:Array<{id:number;referenceNo:string;version:number;total:string;status:string}>;
  olderDraft?:{id:number;referenceNo:string}|null;
  reviewBrief?:{statements:string[];staffSources?:Array<{id:number;at:string}>};
};

const API_BASE = (import.meta.env.VITE_API_BASE as string) || "";
const quotationKey = (phone: string) => ["/api/admin/whatsapp-first/conversations", phone, "internal-quotation"];

function money(value: number) {
  return new Intl.NumberFormat("en-SG", { style: "currency", currency: "SGD", minimumFractionDigits: 2 }).format(value);
}

async function responseError(response: Response) {
  const text = await response.text();
  if (!text) return new Error(`Request failed (${response.status}).`);
  try {
    const parsed = JSON.parse(text);
    return new Error(parsed.message || parsed.error || parsed.reason || text);
  } catch {
    return new Error(text);
  }
}

export function InternalQuotationPanel({
  phone,
  isActiveRecipient,
}: {
  phone: string;
  isActiveRecipient: () => boolean;
}) {
  const queryClient = useQueryClient();
  const actionLock = useRef(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const endpoint = `${API_BASE}/api/admin/whatsapp-first/conversations/${encodeURIComponent(phone)}/internal-quotation`;
  const key = quotationKey(phone);
  const { data, isLoading, error, refetch, isFetching } = useQuery<InternalQuotation>({
    queryKey: key,
    queryFn: async ({ signal }) => {
      const response = await fetch(endpoint, { credentials: "include", signal });
      if (!response.ok) throw await responseError(response);
      return response.json();
    },
  });

  const assess = useMutation({
    mutationFn: async (expectedRevision: string) => {
      if (!isActiveRecipient()) throw new Error("This conversation is no longer selected. Select it again before assessing.");
      const response = await fetch(`${endpoint}/assess`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ expectedRevision,expectedGenerated:data?.protectedReason?undefined:data?.generatedAssessment||undefined }),
      });
      if (!response.ok) throw await responseError(response);
      return response.json() as Promise<InternalQuotation>;
    },
    onSuccess: result => {
      if (!isActiveRecipient()) return;
      setActionError(null);
      queryClient.setQueryData(key, result);
    },
    onError: cause => {
      if (isActiveRecipient()) setActionError(cause instanceof Error ? cause.message : "Assessment could not be confirmed.");
    },
  });

  const runAssessment = async () => {
    if (!data || actionLock.current || assess.isPending || !data.canAssess || actionError) return;
    actionLock.current = true;
    setActionError(null);
    try {
      await assess.mutateAsync(data.revision);
    } catch {
      // The visible error is retained below; retry is safe and uses a fresh revision.
    } finally {
      actionLock.current = false;
    }
  };
  const refreshForRetry = async () => {
    const result = await refetch();
    if (!result.isError && result.data) setActionError(null);
  };

  return (
    <section aria-label="Internal quotation" data-testid="internal-quotation-panel" className="mb-5 overflow-hidden rounded-lg border border-[#d9d5cc] bg-[#fffdf8] shadow-sm">
      <div className="flex flex-wrap items-center gap-2 border-b border-[#e6e1d7] bg-[#f8f5ed] px-3.5 py-3 sm:px-4">
        <span className="flex h-8 w-8 items-center justify-center rounded-md bg-[#ebe7dc] text-[#3f4b44]">
          <FileText className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <h2 className="text-sm font-bold text-[#26332d]">Internal quotation</h2>
          <p className="text-[11px] text-[#6d746d]">Staff review only · no customer message is sent</p>
        </div>
        {data?.quote && <span className="border border-[#d9d5cc] bg-white px-2 py-1 text-[10px] font-semibold text-[#59615b]">{data.quote.referenceNo} · v{data.quote.version}</span>}
      </div>

      <div className="space-y-3.5 p-3.5 sm:p-4">
        {isLoading && <div role="status" aria-label="Loading internal quotation" className="space-y-2 animate-pulse">
          <div className="h-3 w-1/3 rounded bg-[#e9e5dc]" />
          <div className="h-12 rounded bg-[#f0ede6]" />
          <div className="h-3 w-2/3 rounded bg-[#e9e5dc]" />
        </div>}
        {error && <div role="alert" className="flex items-start gap-2 border border-red-200 bg-red-50 p-3 text-xs text-red-800">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          <div className="min-w-0 flex-1">
            <p className="font-semibold">Internal quotation could not be loaded.</p>
            <p className="mt-1 break-words">{error instanceof Error ? error.message : "The server did not return quotation details."}</p>
          </div>
          <button type="button" onClick={() => refetch()} disabled={isFetching} className="inline-flex shrink-0 items-center gap-1 font-semibold underline disabled:opacity-50">
            <RefreshCw className={`h-3 w-3 ${isFetching ? "animate-spin" : ""}`} />Retry
          </button>
        </div>}

        {data && <>
          {data.staffDocument && <div className="border border-[#d9d5cc] bg-white p-3 text-xs">
            <p className="font-bold">Latest staff quotation/document · {data.staffDocument.status}</p>
            <p className="mt-1 break-words">{data.staffDocument.filename}</p>
            <p className="mt-1 text-[#59615b]">{new Date(data.staffDocument.createdAt).toLocaleString()}</p>
            <p className="mt-1 text-[#59615b]">{data.staffDocument.associationVerified?"Saved quotation association verified. Staff-issued prices are protected.":data.staffDocument.associationReason||"Original staff document available; review its saved quotation association separately."}</p>
            {data.staffDocument.shareBlockedReason&&<p className="mt-1 text-[#59615b]">{data.staffDocument.shareBlockedReason}</p>}
            <a href={data.staffDocument.mediaUrl} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block font-semibold underline">Open original document</a>
          </div>}
          {data.olderDraft && <p className="text-xs text-[#77776e]">Earlier assistant draft (history, not the current staff quotation): <a className="underline" href={`/admin/quotes/${data.olderDraft.id}`}>{data.olderDraft.referenceNo}</a></p>}
          {!!data.relatedQuotes?.length&&<div className="text-xs text-[#59615b]"><p>Other verified saved records for this contact — check job identity; not linked by the document filename:</p>
            {data.relatedQuotes.map(q=><a key={q.id} href={`/admin/quotes/${q.id}`} className="mt-1 block underline">{q.referenceNo} · v{q.version} · ${Number(q.total).toFixed(2)} · {q.status}</a>)}
          </div>}
          {data.reviewBrief?.statements?.length ? <div className="border-l-2 border-[#7d6a42] bg-[#f4f0e6] p-3 text-xs">
            <p className="font-bold">Retained scope / staff terms — not a final payable total</p>
            {data.reviewBrief.statements.map((statement,index)=><p key={index} className="mt-1 whitespace-pre-wrap">{statement}</p>)}
            {data.reviewBrief.staffSources?.map(source=><p key={source.id} className="mt-1 text-[10px]">Staff message #{source.id} · {new Date(source.at).toLocaleString()}</p>)}
          </div>:null}
          {data.protectedReason && <div className="flex items-start gap-2 border-l-2 border-[#7d6a42] bg-[#f4f0e6] px-3 py-2.5 text-xs text-[#544b38]">
            <LockKeyhole className="mt-0.5 h-4 w-4 shrink-0" />
            <div><p className="font-bold">Protected saved work · read only</p><p className="mt-0.5 leading-relaxed">{data.protectedReason} This panel will not reprice or replace it.</p></div>
          </div>}

          <div className="flex flex-wrap items-end justify-between gap-x-4 gap-y-2">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.13em] text-[#77776e]">Saved quotation</p>
              {data.quote
                ? <p className="mt-0.5 text-sm font-semibold text-[#26332d]">{data.quote.referenceNo} <span className="font-normal text-[#70746e]">· {data.quote.status}</span></p>
                : <p className="mt-0.5 text-sm font-semibold text-[#26332d]">{data.staffDocument?"Original staff document — saved quotation unverified":"Not assessed"}</p>}
            </div>
            {data.quote
              ? <p className="text-right"><span className="block text-[10px] uppercase tracking-wide text-[#77776e]">{data.quote.requiresManualReview && (data.unpricedCount > 0 || data.quote.total <= 0) ? "Known items subtotal" : data.quote.requiresManualReview ? "Internal priced amount" : "Saved total"}</span><strong className="text-lg tabular-nums text-[#26332d]">{data.quote.requiresManualReview && (data.unpricedCount > 0 || data.quote.total <= 0) ? data.pricedSubtotal > 0 ? money(data.pricedSubtotal) : "Pricing pending" : money(data.quote.total)}</strong></p>
              : <button type="button" onClick={runAssessment} disabled={!data.canAssess || assess.isPending || !!actionError || !isActiveRecipient()} className="inline-flex min-h-9 items-center justify-center gap-2 bg-[#25332c] px-3 py-2 text-xs font-semibold text-white hover:bg-[#35463d] disabled:cursor-not-allowed disabled:opacity-50">
                  <ShieldCheck className="h-3.5 w-3.5" />{assess.isPending ? "Assessing retained enquiry…" : "Assess retained enquiry"}
                </button>}
          </div>

          {data.quote && <a href={`/admin/quotes/${data.quote.id}`} className="inline-flex items-center gap-1 text-xs font-semibold text-[#41574b] underline underline-offset-2 hover:text-[#26332d]">
            Review or edit quotation <ArrowUpRight className="h-3 w-3" />
          </a>}
          {data.quote && <button type="button" onClick={runAssessment} disabled={!data.canAssess || assess.isPending || !!actionError || !isActiveRecipient()} className="inline-flex min-h-9 items-center justify-center gap-2 self-start bg-[#25332c] px-3 py-2 text-xs font-semibold text-white hover:bg-[#35463d] disabled:cursor-not-allowed disabled:opacity-50">
            <ShieldCheck className="h-3.5 w-3.5" />{assess.isPending ? "Assessing retained enquiry…" : data.protectedReason ? "Review retained scope — keep saved prices" : "Assess retained enquiry"}
          </button>}

          {data.componentNotice&&<p className="text-xs text-amber-900">{data.componentNotice}</p>}
          {data.assessment && <div role="status" className="flex items-start gap-2 border border-[#d8e4d8] bg-[#f2f7f1] p-2.5 text-xs text-[#425849]">
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
            <p><strong>Assessment recorded:</strong> {data.assessment.outcome} · {new Date(data.assessment.at).toLocaleString("en-SG")}. This is an internal review, not a customer contact.</p>
          </div>}

          {data.quote?.requiresManualReview && <p className="border-l-2 border-amber-500 bg-amber-50 px-3 py-2 text-xs leading-relaxed text-amber-950">
            Staff review is required before this quotation is used. Confirm scope and pricing with the customer only through the separate approved sharing workflow.
          </p>}

          {data.items.length > 0 && <div className="overflow-hidden border border-[#e4e0d7] bg-white">
            <div className="border-b border-[#e4e0d7] px-3 py-2">
              <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-[#77776e]">Scope retained from conversation</p>
            </div>
            <ul className="divide-y divide-[#efede7]">
              {data.items.map((item, index) => <li key={item.id ?? `${item.description}-${index}`} className="flex flex-wrap items-start gap-x-3 gap-y-1 px-3 py-2.5 text-xs">
                <div className="min-w-0 flex-1">
                  <p className="font-semibold leading-snug text-[#303a34]">{item.description || "Unspecified item"}</p>
                  <p className="mt-0.5 text-[11px] text-[#77776e]">{item.quantity == null ? "Quantity not confirmed" : `Qty ${item.quantity}`} · {item.serviceType || "Service type not confirmed"}</p>
                  {item.scope && <p className="mt-1 leading-relaxed text-[#59615b]">{item.scope}</p>}
                </div>
                <div className="text-right">
                  {item.priceState !== "pending" && item.lineTotal != null
                    ? <p className="font-semibold tabular-nums text-[#303a34]">{money(item.lineTotal)}</p>
                    : <p className="font-semibold text-amber-800">Pending staff review</p>}
                  {item.priceState === "priced" && item.unitPrice != null && <p className="text-[10px] text-[#77776e]">{money(item.unitPrice)} / unit</p>}
                  {item.priceState === "partial" && <p className="text-[10px] text-amber-800">Dismantling component only<br />Moving costs pending</p>}
                </div>
              </li>)}
            </ul>
          </div>}

          <div className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-3">
            {data.quote && (!data.quote.requiresManualReview || (data.quote.total > 0 && data.unpricedCount === 0)) && <div className="border border-[#e4e0d7] bg-white p-2.5"><p className="text-[10px] text-[#77776e]">{data.quote.requiresManualReview ? "Internal priced amount" : "Saved total"}</p><p className="mt-0.5 font-bold tabular-nums text-[#303a34]">{money(data.quote.total)}</p></div>}
            {(data.quote || data.items.length > 0 || data.knownCharges !== 0) && <div className="border border-[#e4e0d7] bg-white p-2.5"><p className="text-[10px] text-[#77776e]">Known charges</p><p className="mt-0.5 font-bold tabular-nums text-[#303a34]">{money(data.knownCharges)}</p></div>}
            {(!data.quote || data.unpricedCount > 0 || data.quote.total <= 0) && (data.items.length > 0 || data.pricedSubtotal !== 0) && <div className="border border-[#e4e0d7] bg-white p-2.5"><p className="text-[10px] text-[#77776e]">Priced items subtotal</p><p className="mt-0.5 font-bold tabular-nums text-[#303a34]">{data.pricedSubtotal > 0 ? money(data.pricedSubtotal) : "Not priced yet"}</p></div>}
            {data.unpricedCount > 0 && <div className="border border-amber-200 bg-amber-50 p-2.5"><p className="text-[10px] text-amber-800">Pending staff review</p><p className="mt-0.5 font-bold text-amber-950">{data.unpricedCount} {data.unpricedCount === 1 ? "item" : "items"}</p></div>}
          </div>

          {data.missing.length > 0 && <div className="border border-amber-200 bg-[#fff9ec] p-3">
            <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-amber-900">Missing details / scope to confirm</p>
            <ul className="mt-1.5 list-disc space-y-1 pl-4 text-xs leading-relaxed text-[#5e5136]">{data.missing.map((reason, index) => <li key={`${reason}-${index}`}>{reason}</li>)}</ul>
          </div>}

          {!data.quote && (data.items.length > 0 || data.unpricedCount > 0 || data.pricedSubtotal !== 0) && <p className="text-[11px] leading-relaxed text-[#716b5d]">A priced subtotal is not a final or payable quotation. Confirm outstanding scope, then obtain explicit staff scope approval. Sharing remains a separate staff action.</p>}
          {!data.quote && data.items.length === 0 && <p className="text-xs leading-relaxed text-[#686f69]">No internal quotation has been created yet. Assessing reads this retained enquiry and creates or updates internal staff work only; it does not send a WhatsApp message or change conversation ownership. Any known amounts shown are not a final or payable quotation.</p>}
          {data.quote && <p className="text-[11px] leading-relaxed text-[#686f69]">{data.unpricedCount > 0 ? "Pending items still need pricing; the known subtotal is not a final or payable quotation. " : "Saved amounts remain internal until the scope is approved. "}Staff scope approval and sharing are separate; assessment never contacts the customer.</p>}

          {!data.canAssess && !data.protectedReason && <p className="text-[11px] leading-relaxed text-[#686f69]">Assessment is unavailable for this conversation at present. The conversation remains staff-owned; no customer contact will be made here.</p>}
          {actionError && <div role="alert" className="flex items-start justify-between gap-3 border border-red-200 bg-red-50 p-3 text-xs text-red-800">
            <div><p className="font-semibold">Assessment was not confirmed.</p><p className="mt-1 break-words">{actionError}</p><p className="mt-1">No customer message is sent by this action. Refresh the retained enquiry before retrying.</p></div>
            <button type="button" onClick={refreshForRetry} disabled={isFetching || assess.isPending} className="shrink-0 font-semibold underline disabled:opacity-50">Refresh</button>
          </div>}
          {data.assessment && !actionError && <p className="text-[11px] text-[#56665b]">Assessment saved successfully. Customer messaging, approval, and sharing are separate steps.</p>}
        </>}
      </div>
    </section>
  );
}
