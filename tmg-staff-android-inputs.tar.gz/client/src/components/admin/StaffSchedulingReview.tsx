import {useEffect,useRef,useState} from "react";
import {useQuery,useMutation,useQueryClient} from "@tanstack/react-query";
import {apiRequest} from "@/lib/queryClient";
import {refreshQuoteViews} from "@/lib/quote-edit-cache";
import {singaporeDate,validAppointment} from "@shared/appointment";

export function StaffSchedulingReview({quoteId,version,quote,onDirtyChange}:{quoteId:number;version:number;quote?:any;onDirtyChange?:(dirty:boolean)=>void}) {
  const qc=useQueryClient();
  const [date,setDate]=useState(""),[timeWindow,setTime]=useState("");
  const [reason,setReason]=useState(""),[billingMode,setMode]=useState("retail"),[billingReason,setBillingReason]=useState("");
  const [units,setUnits]=useState(""),[ack,setAck]=useState(false),[notify,setNotify]=useState(false);
  useEffect(()=>{onDirtyChange?.(dirty.current);},[date,timeWindow,reason,billingMode,billingReason,units,ack,notify,onDirtyChange]);
  const baseline=useRef<{version:number;revision?:string}>({version,revision:quote?.editRevision});
  const initialized=useRef(false),dirty=useRef(false),submitting=useRef(false);
  const retrying=useRef(false);
  const confirmationRequest=useRef<{signature:string;key:string}|null>(null);
  const [retryReason,setRetryReason]=useState("");
  const review=useQuery<any>({queryKey:["scheduling-review",quoteId,date,timeWindow],
    queryFn:async()=> (await apiRequest("GET",`/api/admin/quotes/${quoteId}/scheduling-review?date=${date}&timeWindow=${encodeURIComponent(timeWindow)}`)).json()});
  useEffect(()=>{
    if(initialized.current||!review.data)return;
    initialized.current=true;
    const q=review.data.quote||quote,decision=review.data.decision;
    baseline.current={version:q?.version||version,revision:q?.editRevision};
    if(!dirty.current) {
      setDate(q?.scheduledAt?singaporeDate(q.scheduledAt):q?.preferredDate&&/^\d{4}-\d{2}-\d{2}$/.test(q.preferredDate)?q.preferredDate:"");
      setTime(q?.timeWindow||q?.preferredTimeWindow||"09:00-12:00");
      if(decision){setMode(decision.billingMode);setBillingReason(decision.billingReason);setUnits(decision.workloadUnits?String(decision.workloadUnits):"");}
    }
    if(window.location.hash==="#staff-scheduling-review")requestAnimationFrame(()=>{
      const panel=document.getElementById("staff-scheduling-review");
      panel?.scrollIntoView({block:"center"});
      (panel?.querySelector('[data-testid="schedule-date"]') as HTMLInputElement)?.focus({preventScroll:true});
    });
  },[review.data,quote,version]);
  const change=()=>{dirty.current=true;save.reset();retryNotification.reset();setRetryReason("");};
  const save=useMutation({mutationFn:async(schedule:boolean)=>{
    if(submitting.current)throw new Error("A confirmation is already being saved.");
    submitting.current=true;
    try {
      if(schedule&&!validAppointment(date,timeWindow))throw new Error("Enter a real Singapore date and a valid HH:MM-HH:MM window whose end is after its start.");
      const payload={
        expectedVersion:baseline.current.version,expectedRevision:baseline.current.revision,
         billingMode,billingReason:billingReason.trim()||(billingMode==="retail"?"Admin confirmed the existing retail billing terms.":""),workloadUnits:units?Number(units):null,schedule,notify:schedule&&notify,
         ...(schedule?{date,timeWindow,capacityReason:reason.trim()||"Admin explicitly confirmed crew availability for this appointment after reviewing recorded commitments.",conflictAcknowledged:ack,
          ...(review.data?.reviewedDate===date&&review.data?.reviewedTimeWindow===timeWindow?{expectedCommitments:review.data.commitments.map((c:any)=>c.id)}:{})}:{})};
      const signature=JSON.stringify({...payload,expectedCommitments:undefined});
      if(confirmationRequest.current?.signature!==signature)confirmationRequest.current={signature,key:crypto.randomUUID()};
      return (await apiRequest("POST",`/api/admin/quotes/${quoteId}/operations-confirmation`,{
        ...payload,requestKey:confirmationRequest.current.key})).json();
    }finally{submitting.current=false;}
  },
  onSuccess:async(data)=>{
    retryNotification.reset();setRetryReason("");
    if(data.quote)baseline.current={version:data.quote.version,revision:data.quote.editRevision};
    dirty.current=false;onDirtyChange?.(false);setAck(false);
    await refreshQuoteViews(qc);
  }});
  const retryNotification=useMutation({mutationFn:async()=>{
    try {
    const delivery=save.data?.delivery||review.data?.delivery;
    if(!delivery?.messageId||!["failed","blocked"].includes(delivery.status))throw new Error("Only a recorded definite failure or block may be retried. Review uncertain outcomes first.");
    if(retryReason.trim().length<5)throw new Error("Record why this notification can safely be retried.");
    return await(await apiRequest("POST",`/api/admin/whatsapp-first/messages/${delivery.messageId}/retry`,{reason:retryReason.trim()})).json();
    }finally{retrying.current=false;}
  },onSuccess:async()=>{await refreshQuoteViews(qc);}});
  const baseDelivery=save.data?.delivery||review.data?.delivery;
  const delivery=retryNotification.data?{...baseDelivery,...retryNotification.data}:baseDelivery;
  const deliveryLabel=delivery?.status==="sent"?"Accepted by WhatsApp; delivery is not yet confirmed":
    delivery?.status==="delivered"?"Delivered":delivery?.status==="read"?"Read by customer":
    delivery?.status==="failed"?"Not sent — definite failure":delivery?.status==="blocked"?"Not sent — blocked":
    delivery?.status==="unknown"?"Outcome unknown — reconcile delivery evidence; do not blindly retry":delivery?.status;
  const input="w-full border rounded px-2 py-2 text-sm";
   const billingValid=(billingMode==="retail"||billingReason.trim().length>=10)&&(!units||Number.isInteger(Number(units))&&Number(units)>0);
   const hasConflicts=!!review.data?.commitments?.length;
   const appointmentValid=!review.isFetching&&!!review.data&&!review.isError&&validAppointment(date,timeWindow)&&(!hasConflicts||ack);
  if(!initialized.current)return <section id="staff-scheduling-review" data-testid="staff-scheduling-review" className="border rounded p-4">
     <h3 className="font-semibold">Confirm booking</h3>
    {review.error?<><p role="alert">Cannot load the saved billing and appointment decision: {review.error instanceof Error?review.error.message:"Request failed"}.</p><button onClick={()=>void review.refetch()}>Retry loading the current decision</button></>:<p>Loading the current quote, billing arrangement and appointment before editing…</p>}
  </section>;
  return <section id="staff-scheduling-review" className="border rounded p-4 space-y-3" data-testid="staff-scheduling-review"><fieldset disabled={save.isPending} className="min-w-0 space-y-3">
     <h3 className="font-semibold">Confirm booking</h3>
    {review.data?.pendingRequest && <p className="rounded bg-amber-50 p-2 text-sm">Scheduling request: {review.data.pendingRequest.status} · {review.data.pendingRequest.date || "Date not supplied"} · {review.data.pendingRequest.timeWindow || "Time not supplied"}</p>}
     <p className="text-sm text-muted-foreground">Check the date and time, then confirm. Your confirmation records that the crew can attend. Payment alone does not book the job.</p>
    {review.data?.decision?.capacityConfirmed&&<p data-testid="saved-scheduling-decision" className="rounded bg-slate-50 p-2 text-sm">Saved confirmation: {review.data.decision.date} · {review.data.decision.timeWindow}. Availability: {review.data.decision.capacityReason}</p>}
    {review.data?.quote&&<p className="text-xs">Current saved quotation: {review.data.quote.referenceNo} · version {review.data.quote.version} · S${Number(review.data.quote.total).toFixed(2)}.</p>}
     <details className="border rounded p-2"><summary className="cursor-pointer text-sm">Billing and workload options · {billingMode==="retail"?"existing retail terms":"special arrangement"}</summary><div className="grid sm:grid-cols-2 gap-2 mt-2">
      <label>Billing arrangement<select data-testid="schedule-billing-mode" className={input} value={billingMode} onChange={e=>{change();setMode(e.target.value);}}><option value="retail">Retail terms</option><option value="account_credit">Approved account credit</option><option value="partner">Approved partner arrangement</option><option value="manual">Approved manual billing</option></select></label>
       {billingMode!=="retail"&&<label>Authority for special billing<input data-testid="schedule-billing-reason" className={input} value={billingReason} onChange={e=>{change();setBillingReason(e.target.value);}} /></label>}
      <label>Confirmed workload units · leave unknown blank<input className={input} type="number" min={1} value={units} onChange={e=>{change();setUnits(e.target.value);}} /></label>
    </div>
    {billingMode==="retail"&&<p className="text-xs">Retail confirmation requires acceptance of the current quote and its required cleared payment. Screenshots are not cleared payments.</p>}
    <button className="border rounded p-2 text-sm" disabled={save.isPending||!billingValid||!initialized.current} onClick={()=>save.mutate(false)}>Save billing/workload decision only</button>
     <label className="block text-sm">Staff note · optional<textarea data-testid="schedule-capacity-reason" className={input} value={reason} onChange={e=>{change();setReason(e.target.value);}} /></label>
     </details>
    <div className="grid sm:grid-cols-2 gap-2">
      <label>Actual Singapore date<input data-testid="schedule-date" className={input} type="date" value={date} onChange={e=>{change();setDate(e.target.value);setAck(false);}} /></label>
      <label>Actual appointment window<input data-testid="schedule-window" className={input} placeholder="HH:MM-HH:MM" value={timeWindow} onChange={e=>{change();setTime(e.target.value);setAck(false);}} /></label>
    </div>
    {review.isFetching&&<p role="status" aria-live="polite">Checking commitments for this date/window…</p>}
     {review.error?<p role="alert">{String(review.error)}</p>:hasConflicts&&<div className="text-sm rounded bg-amber-50 p-2"><strong>Other jobs in this time window</strong><ul>{review.data.commitments.map((c:any)=><li key={c.id}>{c.reference_no} · {c.source_channel} · {c.trusted_workload&&c.workload_units?`${c.workload_units} workload units`:"workload unknown"}</li>)}</ul></div>}
     {hasConflicts&&<label className="flex gap-2 text-sm"><input data-testid="schedule-ack" type="checkbox" disabled={review.isFetching||!review.data||review.isError||save.isPending} checked={ack} onChange={e=>{change();setAck(e.target.checked);}} />I reviewed these jobs and confirmed the crew can handle this appointment.</label>}
    <label className="flex gap-2 text-sm"><input type="checkbox" checked={notify} onChange={e=>setNotify(e.target.checked)} />Also notify the customer after saving (subject to delivery rules)</label>
     {!billingValid&&<p className="text-xs text-amber-800">Special billing needs its authority recorded; any workload units must be a positive whole number.</p>}
     {!appointmentValid&&!review.isFetching&&<p className="text-xs text-amber-800">{!validAppointment(date,timeWindow)?"Choose a valid date and time window.":hasConflicts&&!ack?"Review the overlapping jobs above before confirming.":"Load the current appointment before confirming."}</p>}
     <button data-testid="button-confirm-staff-schedule" className="bg-black text-white rounded p-3 text-sm w-full" disabled={save.isPending||!initialized.current||!billingValid||!appointmentValid} onClick={()=>save.mutate(true)}>{save.isPending?"Confirming…":"Confirm booking"}</button>
    {save.error&&<p role="alert" className="text-red-700">{save.error instanceof Error?save.error.message:"Confirmation failed"} Your entered work is preserved.</p>}
    {save.error&&<button className="border rounded p-2 text-sm" onClick={async()=>{
      const current=await review.refetch();
      if(current.data?.quote){baseline.current={version:current.data.quote.version,revision:current.data.quote.editRevision};setAck(false);save.reset();}
    }}>Review current quote, keep entered fields</button>}
    {save.isSuccess&&<p role="status">{save.data.scheduled?"Staff schedule confirmed and recorded.":"Billing/workload decision saved; no booking made."}</p>}
    {delivery&&<div className="border rounded p-3 space-y-2" data-testid="appointment-notification-status">
      <p className="text-sm"><strong>The appointment remains saved.</strong> {delivery.date?`Notification for saved ${delivery.date}, ${delivery.timeWindow}: `:""}WhatsApp notification: {deliveryLabel}{delivery.reason?` — ${delivery.reason}`:""}.</p>
      {["failed","blocked"].includes(delivery.status)&&delivery.messageId&&<>
        <label className="block text-sm">Notification-only retry reason<input data-testid="notification-retry-reason" className={input} value={retryReason} onChange={e=>setRetryReason(e.target.value)} /></label>
        <button data-testid="button-retry-appointment-notification" disabled={retryNotification.isPending||retryReason.trim().length<5}
          className="border rounded p-2 text-sm" onClick={()=>{if(retrying.current)return;retrying.current=true;retryNotification.mutate();}}>Retry WhatsApp notification only — do not save the appointment again</button>
        <p className="text-xs">Retries recheck the current quote, window and approved-template rules. Wait five seconds after an attempt; at most three attempts are allowed. A closed window is not bypassed.</p>
      </>}
      {retryNotification.error&&<p role="alert" data-testid="notification-retry-error" className="text-sm text-red-700">Appointment still saved. Notification retry: {retryNotification.error instanceof Error?retryNotification.error.message:"Failed"}</p>}
    </div>}
  </fieldset></section>;
}
