import { useCallback, useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { refreshQuoteViews } from "@/lib/quote-edit-cache";
import { useAuth } from "@/hooks/use-auth";
import { singaporeDate, validAppointment } from "@shared/appointment";
import {bookingCapacityReason,schedulingDraftStorageKey,safeBookingError as safeError,schedulingRequestMatches} from "@/lib/booking-readiness";
export {schedulingDraftStorageKey} from "@/lib/booking-readiness";

type ReviewTarget = "scope" | "acceptance" | "payment";
type Draft = {
  date: string; timeWindow: string; reason: string; billingMode: string;
  billingReason: string; units: string; notify: boolean;
  baseline: { version: number; revision?: string };
  request?: { signature: string; key: string } | null;
};

export function clearSchedulingDraft(storageKey: string | null) {
  if (!storageKey) return;
  try { sessionStorage.removeItem(storageKey); } catch { /* Session storage may be unavailable. */ }
}

function statusLine(ready: boolean | undefined, reason: string | undefined, readyText: string) {
  return ready ? readyText : reason || "Needs review before booking can be confirmed.";
}

export function StaffSchedulingReview({
  quoteId, version, quote, onDirtyChange, onReviewNavigate,
}: {
  quoteId: number; version: number; quote?: any;
  onDirtyChange?: (dirty: boolean) => void;
  onReviewNavigate?: (target: ReviewTarget) => void;
}) {
  const qc = useQueryClient();
  const { user } = useAuth();
  const identity = user?.id ?? user?.email ?? user?.username;
  const storageKey = schedulingDraftStorageKey(quoteId, identity);
  const [draftLoaded, setDraftLoaded] = useState(false);
  const [date, setDate] = useState("");
  const [timeWindow, setTime] = useState("");
  const [reason, setReason] = useState("");
  const [billingMode, setMode] = useState("retail");
  const [billingReason, setBillingReason] = useState("");
  const [units, setUnits] = useState("");
  const [ack, setAck] = useState(false);
  const [notify, setNotify] = useState(false);
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [retryReason, setRetryReason] = useState("");
  const [outcomeChecked, setOutcomeChecked] = useState(false);
  const [localError, setLocalError] = useState("");
  const [discarded, setDiscarded] = useState(false);
  const [, setBaselineRevision] = useState(0);
  const dirty = useRef(false);
  const initializedForIdentity = useRef<string | null>(null);
  const initializedDecision = useRef(false);
  const restoredDraft = useRef(false);
  const ackSignature = useRef("");
  const submitting = useRef(false);
  const retrying = useRef(false);
  const requestRef = useRef<Draft["request"] | null>(null);
  const baseline = useRef<{ version: number; revision?: string }>({ version, revision: quote?.editRevision });

  useEffect(() => {
    if (!storageKey || initializedForIdentity.current === storageKey) return;
    initializedForIdentity.current = storageKey;
    try {
      const saved = sessionStorage.getItem(storageKey);
      const parsed = saved ? JSON.parse(saved) as Draft : null;
      if (parsed && parsed.baseline && typeof parsed.date === "string") {
        restoredDraft.current = true;
        setDate(parsed.date); setTime(parsed.timeWindow || "09:00-12:00");
        setReason(parsed.reason || ""); setMode(parsed.billingMode || "retail");
        setBillingReason(parsed.billingReason || ""); setUnits(parsed.units || "");
        setNotify(!!parsed.notify); baseline.current = parsed.baseline;
        requestRef.current = parsed.request;
        setAdvancedOpen(parsed.billingMode !== "retail");
        dirty.current = true;
      } else {
        const q = quote;
        setDate(q?.scheduledAt ? singaporeDate(q.scheduledAt) :
          q?.preferredDate && /^\d{4}-\d{2}-\d{2}$/.test(q.preferredDate) ? q.preferredDate : "");
        setTime(q?.timeWindow || q?.preferredTimeWindow || "09:00-12:00");
      }
    } catch {
      setLocalError("Saved booking draft could not be read. Your current entries are still available.");
    }
    setDraftLoaded(true);
  }, [storageKey, quote]);

  const review = useQuery<any>({
    queryKey: ["scheduling-review", quoteId, date, timeWindow],
    enabled: draftLoaded,
    retry: false,
    queryFn: async () => (await apiRequest("GET",
      `/api/admin/quotes/${quoteId}/scheduling-review?date=${encodeURIComponent(date)}&timeWindow=${encodeURIComponent(timeWindow)}`)).json(),
  });
  useEffect(() => {
    if (initializedDecision.current || restoredDraft.current || !review.data || review.isFetching) return;
    initializedDecision.current = true;
    const decision = review.data.decision;
    const current = Number(review.data.quote?.version ?? version);
    const approvedForCurrentVersion = !!review.data.readiness?.specialBillingApproved &&
      Number(decision?.quoteVersion ?? decision?.version ?? current) === current;
    if (approvedForCurrentVersion && decision?.billingMode && decision.billingMode !== "retail") {
      setMode(decision.billingMode);
      setBillingReason(decision.billingReason || "");
      setAdvancedOpen(true);
    }
    if (decision?.workloadUnits) setUnits(String(decision.workloadUnits));
    if (decision?.capacityReason) setReason(decision.capacityReason);
  }, [review.data, review.isFetching, version]);

  const saveDraft = useCallback(() => {
    if (!storageKey || !draftLoaded || discarded || (!dirty.current && !requestRef.current)) return;
    const draft: Draft = { date, timeWindow, reason, billingMode, billingReason, units, notify, baseline: baseline.current, request: requestRef.current };
    try { sessionStorage.setItem(storageKey, JSON.stringify(draft)); } catch { /* Session storage may be unavailable. */ }
  }, [storageKey, draftLoaded, discarded, date, timeWindow, reason, billingMode, billingReason, units, notify]);
  useEffect(saveDraft, [saveDraft]);
  useEffect(() => { onDirtyChange?.(dirty.current); }, [date, timeWindow, reason, billingMode, billingReason, units, ack, notify, onDirtyChange]);
  useEffect(() => {
    if (window.location.hash === "#staff-scheduling-review") requestAnimationFrame(() => {
      const panel = document.getElementById("staff-scheduling-review");
      panel?.scrollIntoView({ block: "center" });
      (panel?.querySelector('[data-testid="schedule-date"]') as HTMLInputElement | null)?.focus({ preventScroll: true });
    });
  }, []);

  const change = () => { dirty.current = true; setDiscarded(false); setLocalError(""); save.reset(); retryNotification.reset(); setRetryReason(""); setOutcomeChecked(false); };
  const currentQuote = review.data?.quote || quote;
  const currentVersion = Number(currentQuote?.version ?? version);
  const currentRevision = currentQuote?.editRevision;
  const staleSnapshot = currentVersion !== baseline.current.version || currentRevision !== baseline.current.revision;
  const readiness = review.data?.readiness;
  const availability = review.data?.availability;
  const commitments = review.data?.commitments || [];
  const reviewedCurrentSlot = review.data?.reviewedDate === date && review.data?.reviewedTimeWindow === timeWindow;
  const dataVerified = !!draftLoaded && !!review.data && !review.isFetching && !review.isError && reviewedCurrentSlot;
  const hasConflicts = commitments.length > 0;
  const currentAckSignature = `${date}|${timeWindow}|${commitments.map((c: any) => c.id).join(",")}`;
  const conflictAcked = !hasConflicts || (ack && ackSignature.current === currentAckSignature);
  const acceptedException = !!readiness?.specialBillingApproved &&
    Number(review.data?.decision?.quoteVersion ?? review.data?.decision?.version ?? currentVersion) === currentVersion;
  const usingApprovedException = acceptedException && review.data?.decision?.billingMode === billingMode;
  const billingValid = billingMode === "retail" ||
    (usingApprovedException || (readiness?.authorized === true && billingReason.trim().length >= 10));
  const unitsValid = !units || (Number.isInteger(Number(units)) && Number(units) > 0);
  const bookingReady = readiness?.authorized === true && readiness?.scope?.ready === true &&
    (billingMode === "retail" ? readiness?.retailReady === true : billingValid);
  const availabilityReady = availability?.ready === true;
  const appointmentValid = dataVerified && validAppointment(date, timeWindow) && conflictAcked;
  const save = useMutation<any, Error, void>({
    mutationFn: async () => {
      if (submitting.current) throw new Error("A confirmation is already being saved.");
      submitting.current = true;
      try {
        if (!validAppointment(date, timeWindow)) throw new Error("Choose a valid Singapore date and appointment window.");
        if (!dataVerified) throw new Error("Refresh the appointment review before confirming.");
        if (staleSnapshot) throw new Error("The quote changed. Review and explicitly use the current snapshot first.");
        const payload: Record<string, any> = {
          expectedVersion: baseline.current.version, expectedRevision: baseline.current.revision,
          billingMode, workloadUnits: units ? Number(units) : null, schedule: true, notify,
          date, timeWindow,
          capacityReason: bookingCapacityReason(reason),
          conflictAcknowledged: ack,
          ...(billingMode !== "retail" ? { billingReason: billingReason.trim() } : {}),
          ...(reviewedCurrentSlot ? { expectedCommitments: commitments.map((c: any) => c.id) } : {}),
        };
        const signature = JSON.stringify({ ...payload, expectedCommitments: undefined });
        if (requestRef.current?.signature !== signature) requestRef.current = { signature, key: crypto.randomUUID() };
        saveDraft();
        const requestKey = requestRef.current?.key;
        if (!requestKey) throw new Error("Could not prepare a confirmation request. Please retry.");
        return (await apiRequest("POST", `/api/admin/quotes/${quoteId}/operations-confirmation`,
          { ...payload, requestKey })).json();
      } finally { submitting.current = false; }
    },
    onSuccess: async (data) => {
      retryNotification.reset(); setRetryReason(""); setAck(false); dirty.current = false; onDirtyChange?.(false);
      if (data.quote) baseline.current = { version: data.quote.version, revision: data.quote.editRevision };
      clearSchedulingDraft(storageKey);
      setDiscarded(true);
      requestRef.current = null;
      await refreshQuoteViews(qc);
    },
  });

  const retryNotification = useMutation<any, Error, void>({
    mutationFn: async () => {
      try {
        const delivery = save.data?.delivery || review.data?.delivery;
        if (!delivery?.messageId || !["failed", "blocked"].includes(delivery.status)) throw new Error("Only a recorded definite failure or block may be retried.");
        if (retryReason.trim().length < 5) throw new Error("Record why this notification can safely be retried.");
        return (await apiRequest("POST", `/api/admin/whatsapp-first/messages/${delivery.messageId}/retry`, { reason: retryReason.trim() })).json();
      } finally { retrying.current = false; }
    },
    onSuccess: async () => { await refreshQuoteViews(qc); },
  });
  useEffect(() => {
    const pending = requestRef.current;
    if (!review.data || review.isFetching || review.isError ||
      !schedulingRequestMatches(review.data.quote, pending, user?.id, currentVersion)) return;
    setOutcomeChecked(true);
    dirty.current = false; onDirtyChange?.(false); clearSchedulingDraft(storageKey);
    setDiscarded(true); requestRef.current = null;
    void refreshQuoteViews(qc);
  }, [review.data, review.isFetching, review.isError, user?.id, currentVersion, qc, onDirtyChange, storageKey]);
  const confirmDisabled = !dataVerified || review.isError || save.isPending || save.isSuccess || !bookingReady ||
    !availabilityReady || !appointmentValid || !billingValid || !unitsValid || staleSnapshot || outcomeChecked;
  const deliveryBase = save.data?.delivery || review.data?.delivery;
  const delivery = retryNotification.data ? { ...deliveryBase, ...retryNotification.data } : deliveryBase;
  const deliveryLabel = delivery?.status === "sent" ? "Accepted by WhatsApp; delivery is not yet confirmed" :
    delivery?.status === "delivered" ? "Delivered" : delivery?.status === "read" ? "Read by customer" :
      delivery?.status === "failed" ? "Not sent — definite failure" : delivery?.status === "blocked" ? "Not sent — blocked" :
        delivery?.status === "unknown" ? "Outcome unknown — reconcile delivery evidence; do not blindly retry" : delivery?.status;
  const input = "w-full border border-zinc-300 bg-white px-3 py-2 text-sm text-zinc-900 focus:outline-none focus:ring-2 focus:ring-zinc-800";

  const useCurrentSnapshot = async () => {
    const refreshed = await review.refetch();
    if (!refreshed.data || refreshed.isError) return;
    const q = refreshed.data.quote;
    if (q) {
      baseline.current = { version: Number(q.version), revision: q.editRevision };
      setBaselineRevision(revision => revision + 1);
    }
    dirty.current = true; setDiscarded(false); onDirtyChange?.(true);
    ackSignature.current = "";
    setAck(false); save.reset(); setLocalError("");
    if (storageKey) {
      const draft: Draft = { date, timeWindow, reason, billingMode, billingReason, units, notify, baseline: baseline.current, request: requestRef.current };
      try { sessionStorage.setItem(storageKey, JSON.stringify(draft)); } catch { /* Session storage may be unavailable. */ }
    }
  };
  const checkSavedOutcome = async () => {
    const pending = requestRef.current;
    const refreshed = await review.refetch();
    const matches = !refreshed.isError && schedulingRequestMatches(refreshed.data?.quote, pending, user?.id, currentVersion);
    setOutcomeChecked(matches);
    if (matches) {
      dirty.current = false; onDirtyChange?.(false); clearSchedulingDraft(storageKey);
      setDiscarded(true); requestRef.current = null;
      await refreshQuoteViews(qc);
    }
  };
  const navigateToReview = (target: ReviewTarget) => onReviewNavigate?.(target);

  if (!draftLoaded || (!review.data && review.isFetching)) return <section id="staff-scheduling-review" data-testid="staff-scheduling-review" className="space-y-3 border border-zinc-300 bg-white p-4" aria-busy="true">
    <h3 className="font-semibold text-zinc-900">Confirm booking</h3>
    <div className="h-3 w-2/3 animate-pulse bg-zinc-100" />
    <div className="h-10 animate-pulse bg-zinc-100" />
    <p role="status" className="text-sm text-zinc-500">Loading the current quote and booking readiness…</p>
  </section>;

  return <section id="staff-scheduling-review" className="space-y-4 border border-zinc-300 bg-white p-4 text-zinc-900 sm:p-5" data-testid="staff-scheduling-review">
    <header className="space-y-1">
      <h3 className="text-lg font-semibold">Confirm booking</h3>
      <p className="text-sm text-zinc-600">Review the saved quote and payment evidence, then confirm the crew slot. This does not request or collect payment.</p>
    </header>
    {localError && <p role="alert" className="border border-amber-300 bg-amber-50 p-3 text-sm">{localError}</p>}
    {review.isError && <div className="border border-red-300 bg-red-50 p-3 text-sm" role="alert" data-testid="schedule-review-error">
      <p>{safeError(review.error, "Could not verify the current booking data.")} Confirming is disabled until a fresh review succeeds.</p>
      <button data-testid="schedule-refresh-review" className="mt-2 border border-zinc-500 px-3 py-2" onClick={() => void review.refetch()}>Retry current review</button>
    </div>}
    {review.data?.pendingRequest && <p className="border border-amber-300 bg-amber-50 p-3 text-sm">Scheduling request: {review.data.pendingRequest.status} · {review.data.pendingRequest.date || "Date not supplied"} · {review.data.pendingRequest.timeWindow || "Time not supplied"}</p>}
    {review.data?.decision?.capacityConfirmed && <p data-testid="saved-scheduling-decision" className="border border-zinc-200 bg-zinc-50 p-3 text-sm">Saved confirmation: {review.data.decision.date} · {review.data.decision.timeWindow}. Availability: {review.data.decision.capacityReason}</p>}
    {review.data?.quote && (readiness?.scope?.ready
      ? <p className="text-xs text-zinc-600">Current saved quotation: {review.data.quote.referenceNo} · version {review.data.quote.version} · S${Number(review.data.quote.total).toFixed(2)}.</p>
      : <p className="border-l-4 border-amber-500 bg-amber-50 px-3 py-2 text-sm text-amber-950" data-testid="scope-known-priced-components">
          Known priced components · Incomplete · S${Number(review.data.quote.total).toFixed(2)}. This is not a current final quotation.
        </p>)}
    {!review.isError && review.data && <section className="space-y-2 border border-zinc-200 p-3" aria-label="Booking readiness" data-testid="booking-readiness">
      <h4 className="text-sm font-semibold">Before you book</h4>
      {!readiness?.scope?.ready ? <div className="space-y-2 border border-amber-300 bg-amber-50 p-3" data-testid="booking-blocker-scope">
        <h5 className="font-semibold text-amber-950">Finish quote</h5>
        <p className="text-sm text-amber-950">{readiness?.scope?.reason || "Complete and save the service scope, dimensions and labour before reviewing customer acceptance or payment."}</p>
        <p className="text-xs text-amber-900">Acceptance and payment review become available after the saved scope is finalized.</p>
        <button className="border border-black bg-black px-3 py-2 text-sm font-semibold text-white" data-testid="review-scope" onClick={() => navigateToReview("scope")}>Finish quote — Edit quote</button>
      </div> : <ul className="space-y-2 text-sm">
        <li data-testid="booking-blocker-scope" className="text-zinc-700">
          <span className="font-medium">Scope ready.</span> {statusLine(readiness?.scope?.ready, readiness?.scope?.reason, "Saved quote scope is resolved.")}
        </li>
        {billingMode==="retail"?<><li data-testid="booking-blocker-acceptance" className={readiness?.acceptance?.ready ? "text-zinc-700" : "text-amber-900"}>
          <span className="font-medium">{readiness?.acceptance?.ready ? "Acceptance ready" : "Acceptance needed"}.</span> {statusLine(readiness?.acceptance?.ready, readiness?.acceptance?.reason, "Current quote version and terms are accepted.")}
          {!readiness?.acceptance?.ready && <button className="ml-2 underline" data-testid="review-acceptance" onClick={() => navigateToReview("acceptance")}>Review acceptance record</button>}
        </li>
        <li data-testid="booking-blocker-payment" className={readiness?.payment?.ready ? "text-zinc-700" : "text-amber-900"}>
          <span className="font-medium">{readiness?.payment?.ready ? "Payment ready" : "Payment needs review"}.</span> {statusLine(readiness?.payment?.ready, readiness?.payment?.reason, "Required payment is verified in the canonical record.")}
          {readiness?.payment && <span className="block text-xs text-zinc-600">Status: {readiness.payment.status || "not verified"} · Required S${Number(readiness.payment.requiredAmount || 0).toFixed(2)} · verified S${Number(readiness.payment.verifiedAmount || 0).toFixed(2)}</span>}
          {!readiness?.payment?.ready && <button className="mt-1 underline" data-testid="review-payment" onClick={() => navigateToReview("payment")}>Review Payment Status and history</button>}
        </li></>:<li data-testid="booking-special-billing-readiness" className="text-zinc-700">
          <strong>{usingApprovedException?"Existing special billing approved.":"Special billing authority required."}</strong>{" "}
          {usingApprovedException?"This saved current-version arrangement replaces ordinary retail acceptance and deposit prerequisites; finalized scope and availability are still required.":
            "Record the genuine billing authority in Advanced options. This does not record customer acceptance or received funds."}
        </li>}
      </ul>}
      {readiness?.scope?.ready && !bookingReady && <p className="text-xs text-zinc-600">Resolve these records in their existing review sections. This screen cannot accept the quote or mark a payment as cleared.</p>}
      {readiness?.authorized === false && <p className="text-xs text-amber-900" data-testid="booking-blocker-authorization">This admin role is not authorized to confirm this booking.</p>}
    </section>}

    {staleSnapshot && <div className="border border-amber-400 bg-amber-50 p-3 text-sm" data-testid="booking-stale-snapshot" role="alert">
      <p>Quote changed since this booking draft began (draft v{baseline.current.version}, current v{currentVersion}). Your entered choices are preserved; this draft has not been silently rebased.</p>
      <button data-testid="schedule-use-current-snapshot" className="mt-2 border border-zinc-700 px-3 py-2 disabled:opacity-50" disabled={review.isFetching || review.isError} onClick={() => void useCurrentSnapshot()}>Refresh and use current quote snapshot</button>
    </div>}

    <fieldset disabled={save.isPending} className="min-w-0 space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block text-sm font-medium">Actual Singapore date
        <input data-testid="schedule-date" className={`${input} mt-1`} type="date" value={date} onChange={e => { change(); setDate(e.target.value); setAck(false); ackSignature.current = ""; }} />
        </label>
        <label className="block text-sm font-medium">Actual appointment window
          <input data-testid="schedule-window" className={`${input} mt-1`} placeholder="HH:MM-HH:MM" value={timeWindow} onChange={e => { change(); setTime(e.target.value); setAck(false); ackSignature.current = ""; }} />
        </label>
      </div>
      {review.isFetching && <p role="status" aria-live="polite" className="text-sm text-zinc-600">Checking current commitments for this date and window…</p>}
      {availabilityReady && dataVerified ? <div className="border border-zinc-300 bg-zinc-50 p-3 text-sm" data-testid="booking-blocker-availability">
        <strong>Date and window available.</strong> {availability?.reason || "This Singapore date and appointment window are allowed."}
      </div> : date && timeWindow && <div className="border border-amber-300 bg-amber-50 p-3 text-sm" data-testid="booking-blocker-availability" role="status">
        <strong>Date and window need review.</strong> {review.isFetching ? "Checking Singapore date and operating-window rules…" : availability?.reason || "Availability has not been verified for this date and window."}
      </div>}
      {review.data && !review.isError && hasConflicts && <div className="border border-amber-300 bg-amber-50 p-3 text-sm" data-testid="schedule-workload">
        <strong>Recorded jobs in this time window</strong>
        <ul className="mt-1 list-disc pl-5">{commitments.map((c: any) => <li key={c.id}>{c.reference_no} · {c.source_channel} · {c.trusted_workload && c.workload_units ? `${c.workload_units} workload units` : "workload unknown"}</li>)}</ul>
      </div>}
      {hasConflicts && <label className="flex items-start gap-2 text-sm"><input data-testid="schedule-ack" type="checkbox" className="mt-1" disabled={!dataVerified || save.isPending} checked={ack && ackSignature.current === currentAckSignature} onChange={e => { change(); ackSignature.current = e.target.checked ? currentAckSignature : ""; setAck(e.target.checked); }} />
        <span>I reviewed these commitments and confirmed the crew can handle this appointment.</span>
      </label>}
      <label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={notify} onChange={e => { change(); setNotify(e.target.checked); }} /><span>Also notify the customer after saving (subject to delivery rules)</span></label>

      <details className="border border-zinc-200 p-3" open={advancedOpen} onToggle={event => {
        const details = event.currentTarget;
        const isOpen = details.open;
        setAdvancedOpen(isOpen);
      }}>
        <summary className="cursor-pointer text-sm font-semibold">Advanced billing and workload options</summary>
        <div className="mt-3 space-y-3">
          <label className="block text-sm">Billing arrangement
            <select data-testid="schedule-billing-mode" className={`${input} mt-1`} value={billingMode} onChange={e => { change(); setMode(e.target.value); setAdvancedOpen(true); }}>
              <option value="retail">Existing retail terms</option>
              {readiness?.authorized && <><option value="account_credit">Approved account credit</option><option value="partner">Approved partner arrangement</option><option value="manual">Approved manual billing</option></>}
              {acceptedException && !readiness?.authorized && review.data?.decision?.billingMode === billingMode && <option value={billingMode}>{billingMode.replace("_", " ")} · approved for this quote version</option>}
            </select>
          </label>
          {billingMode !== "retail" && <div className="space-y-1">
            {acceptedException && <p className="text-xs text-zinc-700">A special billing exception is already approved for this quote version.</p>}
            {!usingApprovedException && <p className="text-xs text-amber-900">Use a special arrangement only when this role is authorized and you can record its authority. It is not a workaround for missing retail readiness.</p>}
            <label className="block text-sm">Authority reason (at least 10 characters)
              <input data-testid="schedule-billing-reason" className={`${input} mt-1`} value={billingReason} onChange={e => { change(); setBillingReason(e.target.value); }} />
            </label>
          </div>}
          {billingMode === "retail" && acceptedException && <p className="text-xs text-zinc-600">Approved exception on file; retail terms remain selected unless you deliberately choose the approved arrangement.</p>}
          <label className="block text-sm">Confirmed workload units · leave unknown blank
            <input data-testid="schedule-workload-units" className={`${input} mt-1`} type="number" min={1} step={1} value={units} onChange={e => { change(); setUnits(e.target.value); }} />
          </label>
          <label className="block text-sm">Staff note · optional
            <textarea data-testid="schedule-capacity-reason" className={`${input} mt-1`} rows={2} value={reason} onChange={e => { change(); setReason(e.target.value); }} />
          </label>
        </div>
      </details>
      {billingMode !== "retail" && !billingValid && <p className="text-sm text-amber-900" data-testid="booking-blocker-billing">Special billing requires an authorized role and an authority reason of at least 10 characters.</p>}
      {!unitsValid && <p className="text-sm text-amber-900" data-testid="booking-blocker-workload">Workload units must be a positive whole number.</p>}
      {!validAppointment(date, timeWindow) && <p className="text-sm text-amber-900">Choose a valid date and time window.</p>}
      {hasConflicts && !conflictAcked && <p className="text-sm text-amber-900">Review the listed jobs and acknowledge crew capacity before confirming.</p>}
      <button data-testid="button-confirm-staff-schedule" className="w-full bg-black px-4 py-3 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-40" disabled={confirmDisabled} onClick={() => { setLocalError(""); save.mutate(); }}>
        {save.isPending ? "Saving confirmation…" : "Confirm booking"}
      </button>
      {save.error && <div className="space-y-2 border border-red-300 bg-red-50 p-3 text-sm" role="alert" data-testid="booking-confirm-error">
        <p>{safeError(save.error, "Confirmation could not be verified.")} Your entries and request key are preserved.</p>
        <button data-testid="booking-check-outcome" className="border border-zinc-500 px-3 py-2" onClick={() => void checkSavedOutcome()}>Check saved outcome</button>
        <button data-testid="booking-refresh-after-error" className="ml-2 underline" onClick={() => void review.refetch()}>Refresh review, keep entries</button>
        {!outcomeChecked && <button className="ml-2 underline" onClick={() => { save.reset(); setLocalError(""); }}>Retry original confirmation request</button>}
      </div>}
      {outcomeChecked && <p role="status" data-testid="booking-recovered-request" className="border border-zinc-300 bg-zinc-50 p-3 text-sm">
        This request key is already recorded for its original date, window and quote version. The booking draft is not being resubmitted; review the saved appointment on the quote.
      </p>}
      {save.isSuccess && <p role="status" className="border border-zinc-300 bg-zinc-50 p-3 text-sm">Booking confirmation saved. {save.data?.scheduled ? "The appointment is recorded." : "No appointment was made."}</p>}
      {delivery && <div className="space-y-2 border border-zinc-300 p-3" data-testid="appointment-notification-status">
        <p className="text-sm"><strong>The appointment remains saved.</strong> {delivery.date ? `Notification for saved ${delivery.date}, ${delivery.timeWindow}: ` : ""}WhatsApp notification: {deliveryLabel}{delivery.reason ? ` — ${delivery.reason}` : ""}.</p>
        {["failed", "blocked"].includes(delivery.status) && delivery.messageId && <>
          <label className="block text-sm">Notification-only retry reason<input data-testid="notification-retry-reason" className={`${input} mt-1`} value={retryReason} onChange={e => setRetryReason(e.target.value)} /></label>
          <button data-testid="button-retry-appointment-notification" disabled={retryNotification.isPending || retryReason.trim().length < 5}
            className="border border-zinc-500 px-3 py-2 text-sm disabled:opacity-50" onClick={() => { if (!retrying.current) { retrying.current = true; retryNotification.mutate(); } }}>
            Retry notification only — appointment remains saved
          </button>
          <p className="text-xs text-zinc-600">Retries recheck the current quote, window and approved-template rules. Wait five seconds after an attempt; at most three attempts are allowed. A closed window is not bypassed.</p>
        </>}
        {retryNotification.error && <p role="alert" data-testid="notification-retry-error" className="text-sm text-red-800">Appointment still saved. {safeError(retryNotification.error, "Notification retry failed.")}</p>}
      </div>}
    </fieldset>
    <button data-testid="schedule-discard-draft" className="text-xs text-zinc-600 underline" onClick={() => {
      clearSchedulingDraft(storageKey);
      setDiscarded(true);
      dirty.current = false; onDirtyChange?.(false); setDate(""); setTime(""); setReason(""); setMode("retail");
      setBillingReason(""); setUnits(""); setNotify(false); setAck(false); requestRef.current = null;
    }}>Discard booking draft</button>
  </section>;
}
