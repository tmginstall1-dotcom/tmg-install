import { useEffect, useRef, useState } from "react";
import { AlertCircle, Download, FileText, LoaderCircle, Music, Video } from "lucide-react";

const API_BASE = (import.meta.env.VITE_API_BASE as string) || "";

type MediaProps = { messageId: number; mediaType: string | null; filename?: string };

export function WhatsappMessageMedia({ messageId, mediaType, filename }: MediaProps) {
  const [previewUrl, setPreviewUrl] = useState("");
  const [previewSafe,setPreviewSafe]=useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const active=useRef(true);
  const controllers=useRef(new Set<AbortController>());
  const urls=useRef(new Set<string>());
  const type = (mediaType || "").toLowerCase();
  const kind = type.startsWith("image/") ? "image" : type.startsWith("video/") ? "video" : type.startsWith("audio/") ? "audio" : "document";
  const supportedDocument = [
    "application/pdf", "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "text/plain",
  ].includes(type);
  const route = `${API_BASE}/api/admin/whatsapp/messages/${messageId}/media`;
  const describeError = (status: number, data: any) => data.message ||
    (status === 410 ? "This original file is no longer available. Ask the customer to resend it." :
      status === 502 ? "Temporary error retrieving this file. Try again in a moment." :
        "Could not load this attachment.");

  useEffect(()=>{
    active.current=true;
    return()=>{active.current=false;controllers.current.forEach(c=>c.abort());controllers.current.clear();
      urls.current.forEach(u=>URL.revokeObjectURL(u));urls.current.clear();};
  },[route]);
  async function loadPreview() {
    const controller=new AbortController();controllers.current.add(controller);
    setBusy(true);setError("");
    try{
      const response=await fetch(route,{credentials:"include",signal:controller.signal});
      if(!response.ok)throw new Error(describeError(response.status,await response.json().catch(()=>({}))));
      const blob=await response.blob();
      if(!active.current||controller.signal.aborted)return;
      const safe=/^(application\/pdf|text\/plain|image\/(jpeg|png|gif|webp))$/.test(blob.type);
      setPreviewSafe(safe);
      if(!safe){setError("This format cannot preview here. Download the original to open in the appropriate app.");return;}
      const url=URL.createObjectURL(blob);urls.current.add(url);setPreviewUrl(url);
    }catch(err){if(active.current&&!controller.signal.aborted)setError(err instanceof Error?err.message:"Could not load this attachment.");}
    finally{controllers.current.delete(controller);if(active.current&&!controller.signal.aborted)setBusy(false);}
  }
  // Images may show a thumbnail immediately. Document bytes are NEVER fetched
  // until the operator chooses Preview or Download.
  useEffect(()=>{if(kind==="image")void loadPreview();},[route,kind,attempt]);

  async function download() {
    const controller=new AbortController();controllers.current.add(controller);
    setBusy(true);
    setError("");
    try {
      const response = await fetch(`${route}?download=1`, { credentials: "include",signal:controller.signal });
      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(describeError(response.status, data));
      }
      const blob = await response.blob();
      if(!active.current||controller.signal.aborted)return;
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = filename || `whatsapp-${messageId}`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (err) {
      if(active.current&&!controller.signal.aborted)setError(err instanceof Error ? err.message : "Download failed. Try again.");
    } finally {
      controllers.current.delete(controller);
      if(active.current&&!controller.signal.aborted)setBusy(false);
    }
  }

  const streamSrc = route;
  return <div className="min-w-[190px] max-w-full">
    {kind === "image" && previewUrl && <a href={previewUrl} target="_blank" rel="noreferrer" aria-label={`Open ${filename || "image"} in a new tab`}>
      <img src={previewUrl} alt={filename || "WhatsApp attachment"} className="block max-h-64 max-w-full rounded object-contain" />
    </a>}
    {kind === "video" && <video src={streamSrc} controls playsInline preload="metadata" className="block max-h-64 max-w-full" onError={() => setError("Video preview is unavailable. Try downloading the file or ask for a resend.")} />}
    {kind === "audio" && <div className="flex items-center gap-2"><Music className="h-4 w-4 shrink-0" /><audio src={streamSrc} controls preload="metadata" className="h-9 max-w-full" onError={() => setError("Audio preview is unavailable. Try downloading the file or ask for a resend.")} /></div>}
    {kind === "document" && <div className="flex items-center gap-2 py-1"><FileText className="h-5 w-5 shrink-0" /><span className="min-w-0 break-all text-xs font-medium">{filename || `Attachment · ${type || "unknown type"}`}</span></div>}
    {kind === "document" && !supportedDocument && <p className="text-[11px] text-amber-800">This file type may not preview here. Download to open it, or ask for a supported resend.</p>}
    {kind === "image" && !previewUrl && !error && <div className="flex items-center gap-2 py-3 text-xs text-gray-500"><LoaderCircle className="h-4 w-4 animate-spin" />Loading attachment…</div>}
    {error && <div role="alert" className="mt-1 flex items-start gap-1.5 text-xs text-red-700"><AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" /><span>{error}</span></div>}
    {error && <button type="button" disabled={busy} onClick={() => kind==="image"?setAttempt(v => v + 1):void loadPreview()} className="mt-1 text-xs font-semibold underline">Try loading again</button>}
    {kind==="document"&&!previewUrl&&<button type="button" disabled={busy} onClick={()=>void loadPreview()} className="mr-3 mt-1 text-xs font-semibold underline">{busy?"Loading…":"Preview"}</button>}
    {kind === "document" && previewSafe && previewUrl && <a href={previewUrl} target="_blank" rel="noreferrer" className="mr-3 mt-1 inline-flex items-center gap-1 text-xs font-semibold underline">Open attachment</a>}
    <button type="button" onClick={download} disabled={busy} className="mt-1 flex items-center gap-1 text-xs font-semibold opacity-80 hover:opacity-100 disabled:opacity-50">
      {busy ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" /> : kind === "video" ? <Video className="h-3.5 w-3.5" /> : <Download className="h-3.5 w-3.5" />}
      {busy ? "Preparing…" : "Download"}
    </button>
  </div>;
}
