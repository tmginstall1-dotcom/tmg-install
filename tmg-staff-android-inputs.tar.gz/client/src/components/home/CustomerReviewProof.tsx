type CustomerReview = {
  id: number;
  author: string;
  text: string;
};

type CustomerReviewProofProps = {
  reviews: CustomerReview[];
  ratingSummary?: { value: string; count: number };
  googleReviewUrl?: string;
};

export default function CustomerReviewProof({
  reviews,
  ratingSummary,
  googleReviewUrl,
}: CustomerReviewProofProps) {
  if (reviews.length === 0) return null;

  return (
    <section
      aria-label="Customer reviews"
      className="relative border-y py-14 md:py-20 px-6 md:px-10 lg:px-14"
      style={{
        background: "rgba(250,250,247,0.88)",
        color: "#0a0a0a",
        borderColor: "rgba(10,10,10,0.10)",
      }}
      data-testid="homepage-review-proof"
    >
      <div className="mx-auto max-w-[1600px]">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-10">
          <header className="md:col-span-4 md:pr-6">
            <div className="mb-5 flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center bg-[#0a0a0a] px-2 py-[4px] text-[10px] font-bold uppercase leading-none tracking-[0.2em] text-[#fafaf7]">
                Customer voices
              </span>
              <span className="inline-flex items-center bg-[#2af56a] px-2 py-[4px] text-[10px] font-bold uppercase leading-none tracking-[0.2em] text-[#0a0a0a]">
                Google reviews
              </span>
            </div>
            <h2 className="font-serif text-[clamp(32px,5vw,64px)] font-black italic leading-[0.92] tracking-[-0.04em]">
              Words from
              <br />
              customers.
            </h2>
            {ratingSummary && (
              <p className="mt-6 text-sm leading-relaxed text-black/65">
                <span className="font-serif text-2xl font-black italic tracking-[-0.03em] text-black">
                  {ratingSummary.value} / 5
                </span>
                <span className="ml-2">
                  from {ratingSummary.count} Google{" "}
                  {ratingSummary.count === 1 ? "review" : "reviews"}
                </span>
              </p>
            )}
            {googleReviewUrl && (
              <a
                href={googleReviewUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-6 inline-flex min-h-11 items-center border border-black/35 px-3 py-2 text-[11px] font-bold uppercase tracking-[0.16em] transition-colors hover:bg-[#2af56a] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#0a0a0a]"
              >
                Read reviews on Google
              </a>
            )}
          </header>

          <div className="md:col-span-8 border-t border-black/10">
            {reviews.map((review) => (
              <article
                key={review.id}
                className="grid grid-cols-1 gap-4 border-b border-black/10 py-6 md:grid-cols-[minmax(0,1fr)_minmax(120px,0.28fr)] md:gap-8 md:py-8"
                data-testid={`homepage-review-${review.id}`}
              >
                <div>
                  <p className="text-base leading-[1.65] text-black/80 md:text-lg">
                    {review.text}
                  </p>
                  <p className="mt-4 text-[11px] font-bold uppercase tracking-[0.16em]">
                    {review.author}
                  </p>
                </div>
                <p className="text-[10px] font-bold uppercase leading-relaxed tracking-[0.18em] text-black/45 md:text-right">
                  Google review
                </p>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
