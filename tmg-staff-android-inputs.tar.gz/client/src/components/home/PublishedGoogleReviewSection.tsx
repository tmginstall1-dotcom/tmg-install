import { useQuery } from "@tanstack/react-query";
import { publicGoogleReviewProof, type PublicReviewData } from "@shared/public-review-proof";
import CustomerReviewProof from "./CustomerReviewProof";

export default function PublishedGoogleReviewSection() {
  const { data } = useQuery<PublicReviewData>({
    queryKey: ["/api/public/reviews"], staleTime: 300_000,
  });
  const { data: destination } = useQuery<{ viewUrl: string }>({
    queryKey: ["/api/public/google-review"], staleTime: 300_000,
  });
  return <CustomerReviewProof {...publicGoogleReviewProof(data, destination?.viewUrl)} />;
}
