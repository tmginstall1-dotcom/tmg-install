import React from "react";
import { ArrowRight, ArrowUpRight, MessageCircle } from "lucide-react";
import { trackEvent } from "@/hooks/use-tracker";

const WHATSAPP =
  "https://wa.me/6580880757?text=" +
  encodeURIComponent(
    "Hi TMG Install, I'd like a quote for furniture installation or dismantling. I can send photos, the item count and my address with lift or stairs access details.",
  );

type HomeHeroProps = {
  onSectionNavigate: (id: string) => void;
};

const sectionLinks = [
  { id: "services", label: "Services" },
  { id: "assembly-scroll", label: "How it works" },
  { id: "business", label: "About TMG" },
];

const serviceLinks = [
  { label: "Home furniture assembly", href: "/services/furniture-installation-singapore" },
  { label: "Office furniture & workstations", href: "/services/office-workstation-installation-singapore" },
  { label: "Furniture dismantling", href: "/services/furniture-dismantling-singapore" },
  { label: "Taobao & flat-pack furniture", href: "/services/taobao-furniture-installation-singapore" },
];

export default function HomeHero({ onSectionNavigate }: HomeHeroProps) {
  const handleQuote = () => {
    trackEvent("cta_estimate_hero", "/");
    window.location.assign("/estimate");
  };

  return (
    <section className="home-hero" aria-labelledby="home-hero-title" data-testid="section-hero">
      <a className="home-hero__skip" href="#main-content">Skip to content</a>
      <div className="home-hero__topline">
        <a className="home-hero__brand" href="/" aria-label="TMG Install home">
          <img src="/apple-touch-icon-v2.png" alt="" width="38" height="38" />
          <span>
            <strong>TMG Install</strong>
            <small>The Moving Guy Pte Ltd</small>
          </span>
        </a>
        <div className="home-hero__business">
          <span>Singapore</span>
          <span aria-hidden="true">/</span>
          <span>UEN 202424156H</span>
        </div>
        <nav className="home-hero__nav" aria-label="Main navigation">
          {sectionLinks.map((link) => (
            <a
              key={link.id}
              href={`#${link.id}`}
              onClick={(event) => {
                event.preventDefault();
                onSectionNavigate(link.id);
              }}
            >
              {link.label}
            </a>
          ))}
          <a
            className="home-hero__nav-quote"
            href="/estimate"
            onClick={(event) => {
              event.preventDefault();
              handleQuote();
            }}
          >
            Get a quote <ArrowUpRight aria-hidden="true" size={15} />
          </a>
        </nav>
      </div>

      <div className="home-hero__main">
        <div className="home-hero__copy">
          <p className="home-hero__eyebrow">
            <span aria-hidden="true" />
            Furniture installation in Singapore
          </p>
          <h1 id="home-hero-title" data-testid="hero-headline">
            Furniture installation,
            <br />
            assembly &amp; dismantling
            <br />
            <span>in Singapore.</span>
          </h1>
          <p className="home-hero__intro">
            Assembly and dismantling for homes and offices, from a single wardrobe to a
            multi-seat workstation. Share the details for a clear, itemised quote.
          </p>

          <div className="home-hero__actions">
            <a
              className="home-hero__primary"
              href="/estimate"
              onClick={(event) => {
                event.preventDefault();
                handleQuote();
              }}
              data-testid="hero-cta-quote"
            >
              Get a free quote <ArrowRight aria-hidden="true" size={18} />
            </a>
            <a
              className="home-hero__whatsapp"
              href={WHATSAPP}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackEvent("cta_whatsapp_hero", "/")}
              data-testid="hero-cta-whatsapp"
            >
              <MessageCircle aria-hidden="true" size={18} />
              Send photos on WhatsApp
            </a>
          </div>
          <p className="home-hero__hint">
            Photos, item count and access details help us scope the work.
          </p>

          <div className="home-hero__services" aria-label="Furniture services">
            {serviceLinks.map((service) => (
              <a
                key={service.label}
                href={service.href}
              >
                {service.label}
                <ArrowUpRight aria-hidden="true" size={13} />
              </a>
            ))}
          </div>
          <a className="home-hero__pricing-guide" href="/guides/furniture-installation-cost-singapore">
            What affects the quote? Read our pricing guide <ArrowUpRight aria-hidden="true" size={14} />
          </a>
        </div>

        <div className="home-hero__visual">
          <img
            src="/work/office-fitout-800.webp"
            srcSet="/work/office-fitout-800.webp 800w, /work/office-fitout-1600.webp 1600w"
            sizes="(max-width: 700px) 100vw, 44vw"
            width="800"
            height="600"
            alt="Office workstations installed by TMG Install in Singapore"
            {...{fetchpriority:"high"}}
            decoding="async"
          />
          <div className="home-hero__photo-label">
            <span className="home-hero__photo-dot" aria-hidden="true" />
            Office workstation installation · Singapore
          </div>
          <a
            href="#services"
            className="home-hero__photo-link"
            onClick={(event) => {
              event.preventDefault();
              onSectionNavigate("services");
            }}
            aria-label="Explore furniture installation services"
          >
            Explore our services <ArrowUpRight aria-hidden="true" size={16} />
          </a>
          <div className="home-hero__visual-index" aria-hidden="true">01 / TMG PROJECT</div>
        </div>
      </div>

      <div className="home-hero__bottom">
        <p>Home furniture <span>·</span> Office fit-outs <span>·</span> Dismantling</p>
        <a
          href="tel:+6580880757"
          onClick={() => trackEvent("cta_call_hero", "/")}
          data-testid="hero-cta-call"
        >
          +65 8088 0757 <ArrowUpRight aria-hidden="true" size={14} />
        </a>
      </div>
    </section>
  );
}
