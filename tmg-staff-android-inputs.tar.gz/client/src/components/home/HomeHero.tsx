import React, { useEffect, useState } from "react";
import type { ReactNode } from "react";
import { trackEvent } from "@/hooks/use-tracker";

const WHATSAPP =
  "https://wa.me/6580880757?text=" +
  encodeURIComponent(
    "Hi TMG Install, I'd like a quote for furniture installation or dismantling. I'll send photos, the item count, and my address with lift or stairs access details. Relocation support may also be needed.",
  );

type HomeHeroProps = {
  onSectionNavigate: (id: string) => void;
};

const INK = "#0a0a0a";
const PAPER = "#fafaf7";
const ACCENT = "#2af56a";

const PROJECT_PHOTOS = [
  { src: "/images/work/wardrobe-install-team-800.webp", width: 750, height: 1000, label: "Wardrobe installation · Singapore" },
  { src: "/images/work/office-fitout-800.webp", width: 800, height: 600, label: "Office furniture setup · Singapore" },
  { src: "/images/work/bed-completed-800.webp", width: 800, height: 450, label: "Bed frame assembly · Singapore home" },
];

function AccentSquare() {
  return <span aria-hidden="true" className="inline-block h-[10px] w-[10px]" style={{ background: ACCENT }} />;
}

function SectionTag({ children, accent = false }: { children: ReactNode; accent?: boolean }) {
  return (
    <span
      className="inline-flex items-center px-2 py-[4px] text-[10px] md:text-[11px] tracking-[0.2em] uppercase font-bold leading-none"
      style={accent ? { background: ACCENT, color: INK } : { background: INK, color: PAPER }}
    >
      {children}
    </span>
  );
}

function ProjectPhotoTile() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => setIndex((current) => (current + 1) % PROJECT_PHOTOS.length), 4000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <div className="relative aspect-[4/3] w-full overflow-hidden border" style={{ borderColor: "rgba(10,10,10,0.2)", background: "#111" }}>
      {PROJECT_PHOTOS.map((photo, photoIndex) => (
        <img
          key={photo.src}
          src={photo.src}
          width={photo.width}
          height={photo.height}
          alt={photoIndex === index ? `TMG furniture installation work: ${photo.label}` : ""}
          aria-hidden={photoIndex !== index}
          loading={photoIndex === 0 ? "eager" : "lazy"}
          decoding="async"
          data-testid={photoIndex === 0 ? "hero-project-image" : undefined}
          className="absolute inset-0 h-full w-full object-cover transition-opacity duration-700 motion-reduce:transition-none"
          style={{ opacity: photoIndex === index ? 1 : 0 }}
        />
      ))}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 bottom-0 h-[55%]"
        style={{ background: "linear-gradient(to top, rgba(0,0,0,0.75), transparent)" }}
      />
      <div aria-hidden="true" className="pointer-events-none absolute left-2 right-2 top-2 flex items-center justify-between text-[10px] tracking-[0.18em] uppercase font-bold">
        <span className="inline-flex items-center gap-1.5 px-1.5 py-0.5" style={{ background: ACCENT, color: INK }}>
          <span className="inline-block h-[6px] w-[6px] rounded-full bg-black animate-pulse motion-reduce:animate-none" /> TMG project
        </span>
        <span className="bg-black/65 px-1.5 py-0.5 text-white backdrop-blur-sm">
          {String(index + 1).padStart(2, "0")} / 0{PROJECT_PHOTOS.length}
        </span>
      </div>
      <div aria-live="polite" className="pointer-events-none absolute bottom-2 left-2 right-2 text-[10px] tracking-[0.18em] uppercase font-bold text-white">
        {PROJECT_PHOTOS[index].label}
      </div>
    </div>
  );
}

export default function HomeHero({ onSectionNavigate }: HomeHeroProps) {
  const goToQuote = () => {
    trackEvent("cta_estimate_hero", "/");
    window.location.assign("/estimate");
  };

  const sectionLinks: Array<{ id: string; label: string; href?: string }> = [
    { id: "package", label: "PACKAGE" },
    { id: "services", label: "SERVICES" },
    { id: "assembly-scroll", label: "PROCESS" },
    { id: "business", label: "BUSINESS" },
    { id: "guides", label: "GUIDES", href: "/guides" },
  ];

  return (
    <section
      className="wordmark-home-hero relative min-h-[100svh] w-full overflow-hidden"
      style={{ background: "rgba(250,250,247,0.88)", color: INK }}
      data-testid="section-hero"
    >
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:left-2 focus:top-2 focus:z-[200] focus:bg-[#2af56a] focus:px-4 focus:py-3 focus:text-black focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
      >
        Skip to content
      </a>

      <div aria-hidden="true" className="pointer-events-none absolute inset-0" style={{
        opacity: 0.55,
        backgroundImage: "radial-gradient(circle, rgba(10,10,10,0.22) 1px, transparent 1px)",
        backgroundSize: "32px 32px",
      }} />

      <div data-testid="hero-company-badge" className="absolute left-3 top-3 z-30 max-w-[210px] md:left-6 md:top-5 md:max-w-[340px]">
        <div className="bg-black px-2.5 py-1.5 text-[9px] leading-snug tracking-[0.16em] text-white md:text-[10px]">
          <span className="font-bold">The Moving Guy Pte Ltd.</span><br />
          UEN 202424156H <span style={{ color: ACCENT }}>·</span> Singapore
        </div>
      </div>

      <div data-testid="hero-top-indicators" className="absolute right-3 top-[58px] z-30 flex gap-5 text-[10px] leading-tight tracking-[0.18em] uppercase font-bold md:right-6 md:top-5 md:gap-6 md:text-[11px]">
        <div className="flex items-center gap-1.5"><AccentSquare /><span>Photos<br />first</span></div>
        <div className="flex items-center gap-1.5"><AccentSquare /><span>Scope<br />before booking</span></div>
      </div>

      <div className="absolute left-4 top-[12%] z-20 md:left-[10%] md:top-[18%]">
        <SectionTag accent>FURNITURE INSTALLATION · SINGAPORE</SectionTag>
      </div>

      <div className="absolute inset-x-0 top-[22%] z-10 px-4 md:inset-0 md:flex md:items-center md:justify-center">
        <div className="hero-wordmark-lockup mx-auto w-full max-w-[640px] text-center md:-translate-y-6">
          <h1 className="sr-only" data-testid="hero-headline">
            Furniture installation, assembly and dismantling in Singapore for homes and offices.
          </h1>
          <div aria-hidden="true" className="hero-h1-responsive italic leading-[0.82] tracking-[-0.04em] text-black" data-testid="hero-wordmark">
            TMG
          </div>
          <div className="mt-2 md:mt-5">
            <div className="text-[11px] font-bold tracking-[0.42em] uppercase md:text-[18px] md:tracking-[0.55em]">
              Furniture install <span style={{ color: ACCENT }}>·</span> Dismantle <span style={{ color: ACCENT }}>·</span> Office
            </div>
            <div className="mt-1 text-[10px] font-bold tracking-[0.3em] uppercase opacity-60 md:text-[12px]">
              Singapore — island-wide
            </div>
          </div>

          <div className="pointer-events-auto mt-5 flex flex-col items-center gap-2 md:hidden">
            <a
              href="/estimate"
              onClick={(event) => { event.preventDefault(); goToQuote(); }}
              data-testid="hero-cta-quote-inline"
              aria-label="Get a free furniture installation quote"
              className="group inline-flex min-h-[52px] w-full max-w-[320px] items-center justify-center gap-2 border-2 border-black px-6 py-4 text-[14px] font-bold tracking-[0.18em] uppercase shadow-[0_6px_0_rgba(0,0,0,0.92)] transition-transform active:scale-[0.98] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-black motion-reduce:transition-none"
              style={{ background: ACCENT, color: INK }}
            >
              Get my free quote <span aria-hidden="true" className="text-[18px] font-black">→</span>
            </a>
            <div className="flex items-center justify-center gap-3 text-[10px] font-bold tracking-[0.12em] uppercase opacity-75">
              <span>Free, scoped quote</span><span aria-hidden="true">·</span><span>Staff-confirmed appointment</span>
            </div>
            <div className="max-w-[300px] text-center text-[9px] font-bold tracking-[0.12em] uppercase opacity-60">
              Photos, item count and access details help us scope the work.
            </div>
            <div className="max-w-[320px] text-center text-[9px] font-bold tracking-[0.12em] uppercase opacity-60" data-testid="hero-lead-quality-mobile">
              Office and multi-seat jobs welcome · Home and single-item work welcome · Relocation support when needed
            </div>
          </div>
        </div>
      </div>

      <div className="pointer-events-none absolute inset-x-0 bottom-[28%] z-[5] hidden justify-center px-2 md:flex">
        <div aria-hidden="true" className="whitespace-nowrap font-serif text-[clamp(54px,14vw,220px)] font-black italic leading-[0.85] tracking-[-0.04em]" style={{ color: "transparent", WebkitTextStroke: "1px rgba(10,10,10,0.22)" }}>
          built properly.
        </div>
      </div>

      <nav aria-label="Homepage sections" className="absolute left-[8%] top-[55%] z-20 hidden flex-col items-start gap-1.5 md:flex">
        {sectionLinks.map((link, index) => (
          <a
            key={link.id}
            href={link.href ?? `#${link.id}`}
            onClick={link.href ? undefined : (event) => { event.preventDefault(); onSectionNavigate(link.id); }}
            className="inline-flex items-center gap-2 px-2.5 py-[5px] text-[10px] font-bold tracking-[0.2em] uppercase transition-transform hover:-translate-y-[1px] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black md:text-[11px]"
            style={index === 0 ? { background: ACCENT, color: INK } : { background: INK, color: PAPER }}
          >
            {link.label} →
          </a>
        ))}
      </nav>

      <div className="absolute bottom-8 left-6 z-20 hidden w-[280px] md:block">
        <ProjectPhotoTile />
        <div className="mt-2 flex items-center justify-between text-[10px] font-bold tracking-[0.18em] uppercase">
          <span className="flex items-center gap-1.5"><AccentSquare /> Real TMG jobs · Singapore</span>
          <span className="opacity-60">Project photos</span>
        </div>
      </div>

      <div data-testid="hero-bottom-actions" className="absolute bottom-3 left-3 right-3 z-20 min-w-0 md:bottom-8 md:left-auto md:right-6 md:w-[340px]">
        <div className="mb-2 hidden items-center justify-between text-[10px] font-bold tracking-[0.2em] uppercase md:flex">
          <span className="flex items-center gap-1.5"><AccentSquare /> Free quote · Scope reviewed before booking</span>
          <span className="opacity-60">Staff-confirmed dates</span>
        </div>
        <a
          href="/estimate"
          onClick={(event) => { event.preventDefault(); goToQuote(); }}
          data-testid="hero-cta-quote"
          aria-label="Get a free furniture installation quote"
          className="group relative hidden w-full text-left transition-transform hover:-translate-y-[2px] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-black active:translate-y-0 md:block motion-reduce:transition-none"
          style={{ background: ACCENT, color: INK }}
        >
          <div className="flex items-stretch">
            <div className="flex-1 px-4 py-4 md:py-5">
              <div className="text-[10px] font-bold tracking-[0.22em] uppercase opacity-70">Step 1 · Tell us what you need</div>
              <div className="mt-1 font-serif text-[26px] font-black italic leading-none tracking-[-0.02em] md:text-[32px]">Get my free quote</div>
            </div>
            <div aria-hidden="true" className="flex items-center justify-center border-l-2 border-black/15 px-4 text-[22px] font-black md:px-5 md:text-[26px]">→</div>
          </div>
        </a>
        <div className="mt-1.5 grid grid-cols-2 gap-1.5">
          <a
            href={WHATSAPP}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => trackEvent("cta_whatsapp_hero", "/")}
            data-testid="hero-cta-whatsapp"
            className="flex min-h-[44px] items-center justify-center gap-2 bg-black px-3 py-3 text-[11px] font-bold tracking-[0.2em] uppercase text-white transition-transform hover:-translate-y-[1px] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black motion-reduce:transition-none"
          >
            <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true">
              <path d="M20.52 3.48A11.86 11.86 0 0012.05 0C5.5 0 .15 5.34.13 11.9c0 2.1.55 4.16 1.6 5.97L0 24l6.3-1.65a11.9 11.9 0 005.74 1.46h.01c6.55 0 11.9-5.34 11.92-11.9a11.84 11.84 0 00-3.46-8.43zM12.05 21.8h-.01a9.9 9.9 0 01-5.04-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.86 9.86 0 01-1.52-5.27c0-5.45 4.45-9.88 9.92-9.88a9.86 9.86 0 017.02 2.9 9.82 9.82 0 012.9 7 9.9 9.9 0 01-9.93 9.88zm5.44-7.4c-.3-.15-1.76-.87-2.04-.97-.27-.1-.47-.15-.67.15s-.77.97-.94 1.17c-.17.2-.34.22-.64.07a8.18 8.18 0 01-2.4-1.48 9.04 9.04 0 01-1.66-2.07c-.17-.3-.02-.46.13-.61.13-.17.3-.34.45-.51.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51l-.57-.01a1.1 1.1 0 00-.8.37c-.27.3-1.04 1.02-1.04 2.49s1.07 2.88 1.22 3.08c.17.2 2.1 3.21 5.09 4.5.71.31 1.27.5 1.7.64.71.23 1.36.2 1.87.12.57-.08 1.76-.72 2.01-1.41.25-.7.18-1.29.18-1.41-.07-.13-.27-.2-.57-.35z"/>
            </svg>
            WhatsApp
          </a>
          <a
            href="tel:+6580880757"
            onClick={() => trackEvent("cta_call_hero", "/")}
            data-testid="hero-cta-call"
            className="flex min-h-[44px] items-center justify-center gap-2 border-2 border-black px-3 py-3 text-[11px] font-bold tracking-[0.2em] uppercase transition-transform hover:-translate-y-[1px] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black motion-reduce:transition-none"
            style={{ background: "rgba(250,250,247,0.88)", color: INK }}
          >
            Call now
          </a>
        </div>
        <div data-testid="hero-footer-row" className="mt-2 grid min-w-0 grid-cols-2 gap-x-2 text-[8px] font-bold leading-tight tracking-[0.12em] uppercase opacity-80 md:flex md:items-center md:justify-between md:text-[10px] md:tracking-[0.18em]">
          <span className="min-w-0 break-words">Furniture work for homes &amp; offices</span><span className="min-w-0 break-words text-right">Dates and times confirmed by staff</span>
        </div>
        <div className="mt-1.5 hidden items-center justify-between text-[9px] font-bold tracking-[0.18em] uppercase opacity-70 md:flex">
          <span>Photo-based quotes · Island-wide</span><span>WhatsApp support</span>
        </div>
        <div className="mt-1.5 hidden text-[9px] font-bold tracking-[0.14em] uppercase opacity-65 md:block" data-testid="hero-lead-quality-desktop">
          Office and multi-seat jobs welcome · Home and single-item work welcome · Relocation support when needed
        </div>
      </div>

      <div className="absolute inset-x-0 bottom-0 z-10 hidden items-center justify-between border-t px-4 py-2 text-[10px] font-bold tracking-[0.18em] uppercase md:flex md:px-6 md:py-3" style={{ borderColor: "rgba(10,10,10,0.1)", background: PAPER }}>
        <span className="flex items-center gap-1.5"><AccentSquare /> Furniture services · Singapore</span>
        <span>Scroll for the process</span><span>+65 8088 0757</span>
      </div>
    </section>
  );
}
