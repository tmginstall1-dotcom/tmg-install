import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";

type OutcomeRow = {
  id: number;
  reference: string;
  stage: string;
  occurredAt: string;
  identifierType: string | null;
  eligible: boolean;
  reasons: string[];
  status: string;
  duplicateReference: string;
};

type OutcomeConfig = {
  customerId: string;
  issues: string[];
  uploadIssues: string[];
  uploadEnabled: boolean;
};

type HandoffInventoryRow = {
  claimKey: string;
  messageId: string;
  receivedAt: string;
  quotes: Array<{ id: number; reference: string; version: number }>;
};

type Preview = {
  reviewId: string;
  digest: string;
  expiresAt: string;
  fields: string[];
  rows: Array<{
    stage: string;
    conversionAction: string;
    conversionTime: string;
    identifierType: string;
    duplicateReference: string;
  }>;
  customerId: string;
};

type UploadResult = { id: number; status: string; reason?: string };

export function GoogleOutcomeReview() {
  const outcomes = useQuery<{ config: OutcomeConfig; rows: OutcomeRow[] }>({
    queryKey: ["/api/ai/attribution/google-outcomes"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/ai/attribution/google-outcomes");
      return response.json();
    },
  });
  const handoffs = useQuery<HandoffInventoryRow[]>({
    queryKey: ["/api/ai/attribution/handoffs"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/ai/attribution/handoffs");
      return response.json();
    },
  });
  const [selected, setSelected] = useState<number[]>([]);
  const [customerId, setCustomerId] = useState<string | null>(null);
  const [approved, setApproved] = useState(false);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [results, setResults] = useState<UploadResult[] | null>(null);
  const [pending, setPending] = useState<"preview" | "export" | "upload" | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [handoffNotice, setHandoffNotice] = useState("");

  const config = outcomes.data?.config;
  const configIssues = config?.issues ?? [];
  const uploadIssues = config?.uploadIssues ?? [];
  const destination = customerId ?? config?.customerId ?? "";
  const configurationReady = !!config && configIssues.length === 0 && !!destination;
  const selectionReady = selected.length > 0;
  const reviewCurrent = !!preview && preview.customerId === destination;
  const actionReady = configurationReady && selectionReady && reviewCurrent && approved && !pending;

  function toggleRow(id: number, checked: boolean) {
    setSelected(current => checked
      ? current.includes(id) ? current : [...current, id]
      : current.filter(value => value !== id));
    setApproved(false);
    setPreview(null);
    setResults(null);
  }

  async function createPreview() {
    if (!configurationReady || !selected.length || pending) return;
    setPending("preview");
    setError("");
    setNotice("");
    try {
      const response = await apiRequest("POST", "/api/ai/attribution/google-outcomes/preview", {
        ids: selected,
        customerId: destination,
      });
      const next = await response.json() as Preview;
      setPreview(next);
      setApproved(false);
      setResults(null);
      setNotice("Review prepared. This is not a Google upload or acceptance.");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Review could not be prepared. Your selected records are retained.");
    } finally {
      setPending(null);
    }
  }

  async function exportReview() {
    if (!actionReady || !preview) return;
    setPending("export");
    setError("");
    setNotice("");
    try {
      const response = await fetch("/api/ai/attribution/google-outcomes/export", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reviewId: preview.reviewId, digest: preview.digest, ownerApproved: true }),
      });
      if (!response.ok) {
        const body = await response.text();
        throw new Error(body || `Export failed (${response.status}).`);
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "google-outcomes-review.csv";
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      setNotice("CSV exported. Export does not mean Google accepted these conversions.");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Export failed. Your review is retained.");
    } finally {
      setPending(null);
    }
  }

  async function uploadReview() {
    if (!actionReady || !preview) return;
    setPending("upload");
    setError("");
    setNotice("");
    try {
      const response = await apiRequest("POST", "/api/ai/attribution/google-outcomes/upload", {
        reviewId: preview.reviewId,
        digest: preview.digest,
        ownerApproved: true,
      });
      const body = await response.json() as { results: UploadResult[] };
      setResults(body.results);
      setNotice("Upload request completed. Check per-record results; this does not confirm Google acceptance.");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Upload request failed. The selected records and review are retained.");
    } finally {
      setPending(null);
    }
  }

  return (
    <section className="space-y-4" aria-label="Google Ads outcome review">
      <div className="border border-zinc-200 bg-white p-5">
        <h2 className="font-semibold">Google Ads outcomes · owner review</h2>
        <p className="mt-2 text-sm text-zinc-600">
          Select eligible staff-reviewed outcomes, inspect the minimal-field preview, then explicitly approve an export or upload.
          No prices, personal information, or full click IDs are shown here.
        </p>
      </div>

      {outcomes.isPending && (
        <div className="space-y-2 border border-zinc-200 bg-white p-4" role="status" aria-label="Loading outcomes">
          <div className="h-4 w-48 animate-pulse bg-zinc-100" />
          <div className="h-12 animate-pulse bg-zinc-100" />
          <div className="h-12 animate-pulse bg-zinc-100" />
        </div>
      )}
      {(outcomes.isError || (!outcomes.isPending && !outcomes.data)) && (
        <div className="border border-zinc-200 bg-white p-4 text-sm" role="alert">
          Outcomes are unavailable. <button className="underline" onClick={() => outcomes.refetch()}>Retry</button>
        </div>
      )}
      {config && (
        <>
          <div className="space-y-2 border border-zinc-200 bg-white p-4">
            <h3 className="text-sm font-semibold">Destination and configuration</h3>
            <label className="block text-sm">
              Google Ads customer ID
              <input
                className="mt-1 block w-full border border-zinc-300 p-2"
                value={destination}
                onChange={event => {
                  setCustomerId(event.target.value);
                  setPreview(null);
                  setApproved(false);
                  setResults(null);
                }}
                aria-describedby="google-outcome-config-note"
                disabled={pending !== null}
              />
            </label>
            <p id="google-outcome-config-note" className="text-xs text-zinc-500">
              Destination changes invalidate the current review. Only the owner can approve delivery.
            </p>
            {configIssues.length > 0 && (
              <ul className="list-disc space-y-1 pl-5 text-sm text-zinc-700" aria-label="General configuration issues">
                {configIssues.map((issue, index) => <li key={`${issue}-${index}`}>{issue}</li>)}
              </ul>
            )}
            {uploadIssues.length > 0 && (
              <div className="border-t border-zinc-200 pt-2">
                <p className="text-sm font-medium">Google upload configuration</p>
                <ul className="mt-1 list-disc space-y-1 pl-5 text-sm text-zinc-700" aria-label="Google upload configuration issues">
                  {uploadIssues.map((issue, index) => <li key={`${issue}-${index}`}>{issue}</li>)}
                </ul>
              </div>
            )}
            {!configIssues.length && !config.customerId && (
              <p className="text-sm text-zinc-700">Google Ads customer ID is missing.</p>
            )}
            {!config.uploadEnabled && (
              <p className="text-sm text-zinc-700">Google upload is disabled by configuration.</p>
            )}
          </div>

          <div className="overflow-hidden border border-zinc-200 bg-white">
            <div className="border-b border-zinc-200 p-4">
              <h3 className="font-semibold">Outcome records</h3>
              <p className="mt-1 text-xs text-zinc-500">Only eligible records can be selected. References are internal enquiry references.</p>
            </div>
            <ul className="divide-y divide-zinc-200">
              {(outcomes.data?.rows ?? []).map(row => (
                <li key={row.id} className="flex flex-wrap items-start gap-3 p-4">
                  <input
                    type="checkbox"
                    className="mt-1"
                    aria-label={`Select ${row.reference}`}
                    checked={selected.includes(row.id)}
                    disabled={!row.eligible || pending !== null}
                    onChange={event => toggleRow(row.id, event.target.checked)}
                  />
                  <div className="min-w-0 flex-1 text-sm">
                    <div className="flex flex-wrap justify-between gap-x-4 gap-y-1">
                      <strong>{row.reference} · {row.stage}</strong>
                      <span className="text-zinc-500">{row.status}</span>
                    </div>
                    <p className="mt-1 break-words text-xs text-zinc-600 [overflow-wrap:anywhere]">
                      {row.occurredAt ? new Date(row.occurredAt).toLocaleString("en-SG", { timeZone: "Asia/Singapore" }) : "Time unavailable"}
                      {" · "}{row.identifierType || "No supported identifier"}
                      {row.duplicateReference ? ` · Import reference: ${row.duplicateReference}` : ""}
                    </p>
                    {!row.eligible && row.reasons.length > 0 && (
                      <ul className="mt-1 list-disc pl-4 text-xs text-zinc-600">
                        {row.reasons.map((reason, index) => <li key={`${row.id}-${index}`}>{reason}</li>)}
                      </ul>
                    )}
                  </div>
                </li>
              ))}
            </ul>
            {!outcomes.data?.rows.length && (
              <p className="p-4 text-sm text-zinc-500">No outcome records are available for review.</p>
            )}
            <div className="border-t border-zinc-200 p-4">
              <button
                className="border border-zinc-300 px-4 py-2 text-sm disabled:opacity-50"
                disabled={!configurationReady || !selectionReady || pending !== null}
                onClick={createPreview}
              >
                {pending === "preview" ? "Preparing review…" : "Prepare minimal-field review"}
              </button>
              {!configurationReady && configIssues.length > 0 && (
                <p className="mt-2 text-xs text-zinc-600">Review preparation is disabled: {configIssues.join(" · ")}</p>
              )}
              {!configurationReady && !configIssues.length && !destination && (
                <p className="mt-2 text-xs text-zinc-600">Review preparation is disabled: Google Ads customer ID is missing.</p>
              )}
            </div>
          </div>
        </>
      )}

      {preview && (
        <div className="space-y-3 border border-zinc-300 bg-white p-5">
          <div>
            <h3 className="font-semibold">Review prepared fields and records</h3>
            <p className="mt-1 text-xs text-zinc-600">
              Destination {preview.customerId} · expires {new Date(preview.expiresAt).toLocaleString("en-SG", { timeZone: "Asia/Singapore" })}
            </p>
          </div>
          <p className="text-sm"><strong>Fields:</strong> {preview.fields.join(", ") || "None returned"}</p>
          <ul className="divide-y divide-zinc-200 border-y border-zinc-200">
            {preview.rows.map((row, index) => (
              <li key={`${row.conversionAction}-${row.conversionTime}-${index}`} className="min-w-0 break-words py-2 text-sm [overflow-wrap:anywhere]">
                <strong>{row.stage}</strong> · {row.conversionAction} · {new Date(row.conversionTime).toLocaleString("en-SG", { timeZone: "Asia/Singapore" })}
                <p className="break-words text-xs text-zinc-600 [overflow-wrap:anywhere]">
                  {row.identifierType || "No supported identifier"}
                  {row.duplicateReference ? ` · Import reference: ${row.duplicateReference}` : ""}
                </p>
              </li>
            ))}
          </ul>
          <label className="flex items-start gap-2 text-sm">
            <input type="checkbox" className="mt-1" checked={approved} onChange={event => setApproved(event.target.checked)} disabled={pending !== null} />
            <span>I am the owner and approve these reviewed records, this destination, and the listed minimal fields for the selected action.</span>
          </label>
          <div className="flex flex-wrap gap-2">
            <button className="border border-zinc-300 px-4 py-2 text-sm disabled:opacity-50" onClick={exportReview} disabled={!actionReady}>
              {pending === "export" ? "Exporting…" : "Export CSV"}
            </button>
            <button className="bg-black px-4 py-2 text-sm text-white disabled:opacity-50" onClick={uploadReview} disabled={!actionReady || !config?.uploadEnabled || uploadIssues.length > 0}>
              {pending === "upload" ? "Submitting upload…" : "Upload to Google Ads"}
            </button>
          </div>
          {!approved && <p className="text-xs text-zinc-600">Export and upload stay disabled until owner approval is checked.</p>}
          {config && !config.uploadEnabled && <p className="text-xs text-zinc-600">Upload is disabled by configuration; CSV export remains separately owner-controlled.</p>}
          {uploadIssues.length > 0 && <p className="text-xs text-zinc-600">Google upload is disabled: {uploadIssues.join(" · ")}</p>}
        </div>
      )}

      {results && (
        <div className="border border-zinc-200 bg-white p-4">
          <h3 className="font-semibold">Upload request results</h3>
          <ul className="mt-2 divide-y divide-zinc-200">
            {results.map(result => (
              <li key={result.id} className="py-2 text-sm">
                Record {result.id}: {result.status}{result.reason ? ` · ${result.reason}` : ""}
              </li>
            ))}
          </ul>
          <p className="mt-2 text-xs text-zinc-600">These are request results only; they do not establish Google Ads acceptance.</p>
        </div>
      )}
      <section className="space-y-3 border border-zinc-200 bg-white p-4" aria-label="Staff source attachment">
        <div>
          <h3 className="font-semibold">Staff source attachment</h3>
          <p className="mt-1 text-sm text-zinc-600">
            These are verified inbound references, not phone- or time-based guesses. For staff-owned chats, review the actual incoming source message, then explicitly match it to the current job once a quote exists. Human ownership is preserved; this does not send a message or qualify a job.
          </p>
          <p className="mt-1 text-xs text-zinc-500">Open the message ID in the staff inbox to review its actual contents before matching. Automatic bot-owned attribution uses the exact signed inbound message proof. No click IDs or recipient personal data are shown.</p>
        </div>
        {handoffs.isPending && (
          <div role="status" className="space-y-2" aria-label="Loading verified inbound references">
            <div className="h-4 w-40 animate-pulse bg-zinc-100" />
            <div className="h-12 animate-pulse bg-zinc-100" />
          </div>
        )}
        {(handoffs.isError || (!handoffs.isPending && !handoffs.data)) && (
          <p role="alert" className="text-sm">
            Verified inbound references are unavailable. <button className="underline" onClick={() => handoffs.refetch()}>Retry</button>
          </p>
        )}
        {handoffs.data?.map(handoff => (
          <HandoffAttachment
            key={handoff.claimKey}
            handoff={handoff}
            onAttached={reference => {
              setHandoffNotice(`Source attached to ${reference}. No message was sent and no qualification was changed.`);
              void handoffs.refetch();
            }}
          />
        ))}
        {handoffs.data && handoffs.data.length === 0 && (
          <p className="text-sm text-zinc-500">No verified inbound references are waiting for an explicit staff match.</p>
        )}
        {handoffNotice && <p role="status" className="text-sm">{handoffNotice}</p>}
      </section>
      {error && <p role="alert" className="border border-zinc-300 bg-white p-3 text-sm">{error}</p>}
      {notice && <p role="status" className="border border-zinc-200 bg-white p-3 text-sm">{notice}</p>}
    </section>
  );
}

function HandoffAttachment({ handoff, onAttached }: {
  handoff: HandoffInventoryRow;
  onAttached: (reference: string) => void;
}) {
  const [quoteId, setQuoteId] = useState("");
  const [reviewed, setReviewed] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const selectedQuote = handoff.quotes.find(quote => String(quote.id) === quoteId);

  async function attachSource() {
    if (!selectedQuote || !reviewed || pending) return;
    setPending(true);
    setError("");
    try {
      await apiRequest("POST", "/api/ai/attribution/handoffs/attach", {
        claimKey: handoff.claimKey,
        quoteId: selectedQuote.id,
        expectedVersion: selectedQuote.version,
      });
      setQuoteId("");
      setReviewed(false);
      onAttached(selectedQuote.reference);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Source was not attached. Your selected job and confirmation are retained.");
    } finally {
      setPending(false);
    }
  }

  return (
    <article className="space-y-3 border border-zinc-200 p-4">
      <div className="flex flex-wrap justify-between gap-2 text-sm">
        <strong>Verified inbound message {handoff.messageId}</strong>
        <span className="text-zinc-500">
          {handoff.receivedAt ? new Date(handoff.receivedAt).toLocaleString("en-SG", { timeZone: "Asia/Singapore" }) : "Received time unavailable"}
        </span>
      </div>
      <label className="block text-sm">
        Matching current job
        <select
          className="mt-1 block w-full border border-zinc-300 p-2"
          value={quoteId}
          onChange={event => {
            setQuoteId(event.target.value);
            setReviewed(false);
            setError("");
          }}
          disabled={pending}
        >
          <option value="">Choose a current job explicitly</option>
          {handoff.quotes.map(quote => (
            <option key={quote.id} value={quote.id}>{quote.reference} · version {quote.version}</option>
          ))}
        </select>
      </label>
      {handoff.quotes.length === 0 && <p className="text-xs text-zinc-600">No current jobs are available for this source yet. Create a quote before attaching.</p>}
      <label className="flex items-start gap-2 text-sm">
        <input
          type="checkbox"
          className="mt-1"
          checked={reviewed}
          onChange={event => setReviewed(event.target.checked)}
          disabled={pending || !selectedQuote}
        />
        <span>I reviewed this actual incoming source message and confirmed it matches the selected current job.</span>
      </label>
      <button
        className="border border-zinc-300 px-4 py-2 text-sm disabled:opacity-50"
        disabled={!selectedQuote || !reviewed || pending}
        onClick={attachSource}
      >
        {pending ? "Attaching source…" : "Attach source to current job"}
      </button>
      {error && <p className="text-sm" role="alert">{error}</p>}
    </article>
  );
}
