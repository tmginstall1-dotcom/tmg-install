import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {refreshQuoteViews} from "@/lib/quote-edit-cache";
import {readQuoteEditResponse} from "@/lib/quote-edit-response";
import { api, buildUrl } from "@shared/routes";
import type { QuoteRequest } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { fetchJsonWithTimeout } from "@/lib/fetchJsonWithTimeout";

const API_BASE = (import.meta.env.VITE_API_BASE as string) || "";
const TERMINAL_STATUSES = ['closed', 'cancelled'];
const PAYMENT_PENDING_STATUSES = ['deposit_requested', 'final_payment_requested'];

export function useQuotes(statusFilter?: string) {
  return useQuery({
    queryKey: [api.quotes.list.path, statusFilter],
    queryFn: async ({ signal }) => {
      const base = `${API_BASE}${api.quotes.list.path}`;
      const url = new URL(base.startsWith("http") ? base : `${window.location.origin}${base}`);
      if (statusFilter && statusFilter !== 'all') {
        url.searchParams.append('status', statusFilter);
      }
      return fetchJsonWithTimeout<any[]>(url.toString(), { credentials: "include", signal });
    },
    // Recover automatically from a stalled / dropped mobile request instead of
    // spinning forever: retry network / server failures once. Don't retry
    // auth / client errors (401/403/400) — an
    // expired session won't fix itself by retrying, so fail fast in that case.
    retry: (count, err: any) => {
      if (err?.status && err.status >= 400 && err.status < 500) return false;
      return count < 1;
    },
    retryDelay: (attempt) => Math.min(1000 * 2 ** attempt, 8000),
    refetchInterval: (query) => {
      const data: any[] = query.state.data ?? [];
      const hasPaymentPending = Array.isArray(data) && data.some((q: any) => PAYMENT_PENDING_STATUSES.includes(q.status));
      if (hasPaymentPending) return 5_000;
      return 30_000;
    },
  });
}

export function useSchedule() {
  return useQuery({
    queryKey: ['/api/quotes/schedule'],
    queryFn: async () => {
      const res = await fetch('/api/quotes/schedule', { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch schedule");
      return res.json() as Promise<{ pending: any[]; confirmed: any[] }>;
    },
    refetchInterval: 30_000,
  });
}

export function useQuote(id: string | number, refNo?: string) {
  return useQuery({
    queryKey: [api.quotes.get.path, id, refNo],
    queryFn: async () => {
      if (!id) return null;
      const base = `${API_BASE}${buildUrl(api.quotes.get.path, { id })}`;
      const url = refNo ? `${base}?ref=${encodeURIComponent(refNo)}` : base;
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch quote");
      return res.json();
    },
    enabled: !!id,
    refetchInterval: (query) => {
      const data = query.state.data;
      // Only stop polling when data is confirmed terminal — keep retrying if null/loading
      if (data && TERMINAL_STATUSES.includes(data.status)) return false;
      if (data && PAYMENT_PENDING_STATUSES.includes(data.status)) return 5_000;
      return 15_000;
    },
  });
}

export function useCreateQuoteRequest() {
  return useMutation({
    mutationFn: async (data: QuoteRequest) => {
      const res = await fetch(api.quotes.createFromCustomer.path, {
        method: api.quotes.createFromCustomer.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Failed to submit request");
      }
      return res.json();
    },
  });
}

export function useUpdateQuoteStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...data }: { id: number | string; status: string; note?: string; photoUrl?: string; assignedStaffId?: number | null; assignedTeamId?: number | null }) => {
      const url = buildUrl(api.quotes.updateStatus.path, { id });
      const res = await fetch(url, {
        method: api.quotes.updateStatus.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        const error = await res.json().catch(() => null);
        throw new Error(error?.message || "Could not save the assignment or status. Please try again.");
      }
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.quotes.get.path] });
      queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] });
      queryClient.invalidateQueries({ queryKey: ['/api/quotes/schedule'] });
      queryClient.invalidateQueries({ queryKey: ['scheduling-review', Number(variables.id)] });
    },
  });
}

export function useUpdateQuotePayment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, paymentType, amount }: { id: number | string; paymentType: 'deposit' | 'final'; amount: string }) => {
      const url = buildUrl(api.quotes.updatePayment.path, { id });
      const res = await fetch(url, {
        method: api.quotes.updatePayment.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ paymentType, amount }),
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Payment failed");
      }
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.quotes.get.path] });
      queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] });
    },
  });
}

export function useRequestBooking() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, scheduledAt, timeWindow }: { id: number | string; scheduledAt: string; timeWindow: string }) => {
      const res = await fetch(`${API_BASE}/api/quotes/${id}/booking-request`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scheduledAt, timeWindow }),
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Booking request failed");
      }
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.quotes.get.path] });
      queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] });
      queryClient.invalidateQueries({ queryKey: ['/api/quotes/schedule'] });
    },
  });
}

export function useConfirmBooking() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number | string) => {
      const res = await fetch(`${API_BASE}/api/quotes/${id}/booking-confirm`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Failed to confirm booking");
      }
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.quotes.get.path, data.id] });
      queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] });
      queryClient.invalidateQueries({ queryKey: ['/api/quotes/schedule'] });
    },
  });
}

export function useRescheduleBooking() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, scheduledAt, timeWindow, referenceNo }: { id: number | string; scheduledAt: string; timeWindow: string; referenceNo?: string }) => {
      const res = await fetch(`${API_BASE}/api/quotes/${id}/booking-reschedule`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scheduledAt, timeWindow, referenceNo }),
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Reschedule failed");
      }
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.quotes.get.path] });
      queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] });
    },
  });
}

export function useStaffArrived() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...data }: { id: number | string; gpsLat: number; gpsLng: number; photoUrls: string[]; note?: string; requestKey?:string }) => {
      const res = await fetch(`${API_BASE}/api/quotes/${id}/arrived`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Check-in failed");
      }
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.quotes.get.path, variables.id] });
      queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] });
      queryClient.invalidateQueries({ queryKey: ['/api/staff/quotes'] });
    },
  });
}

export function useStaffSiteClock() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...data }: { id: number | string; action: 'arrive' | 'leave'; requestKey?:string }) => {
      const res = await fetch(`${API_BASE}/api/quotes/${id}/site-clock`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Could not update on-site time");
      }
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.quotes.get.path, variables.id] });
      queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] });
      queryClient.invalidateQueries({ queryKey: ['/api/staff/quotes'] });
    },
  });
}

export function useStaffStage() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...data }: { id: number | string; stage: 'at_pickup' | 'in_transit' | 'at_dropoff' | 'completed'; gpsLat: number; gpsLng: number; photoUrls: string[]; note?: string; signatureDataUrl?: string; customerName?: string; requestKey?:string }) => {
      const res = await fetch(`${API_BASE}/api/quotes/${id}/stage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Stage update failed");
      }
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.quotes.get.path, variables.id] });
      queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] });
      queryClient.invalidateQueries({ queryKey: ['/api/staff/quotes'] });
    },
  });
}

export function useStaffCompleted() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...data }: { id: number | string; gpsLat: number; gpsLng: number; photoUrls: string[]; note?: string; signatureDataUrl?: string; customerName?: string; requestKey?:string }) => {
      const res = await fetch(`${API_BASE}/api/quotes/${id}/completed-checkout`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Check-out failed");
      }
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.quotes.get.path, variables.id] });
      queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] });
      queryClient.invalidateQueries({ queryKey: ['/api/staff/quotes'] });
    },
  });
}

export function useEditQuote() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...data }: { id: number | string; customerUpdates?: any; quoteUpdates?: any; items?: any[]; expectedRevision?:string; expectedVersion?:number;workspace?:any }) => {
      const res = await fetch(`${API_BASE}/api/quotes/${id}/edit`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      return readQuoteEditResponse(res);
    },
    onSuccess: async (saved) => {
      queryClient.setQueryData(["/api/quotes/:id",saved.id],saved);
      await refreshQuoteViews(queryClient);
    },
  });
}

export function useRequestFinalPayment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number | string) => {
      const res = await fetch(`${API_BASE}/api/quotes/${id}/request-final-payment`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.message || "Failed to request final payment");
      return data; // includes { channel, channelTarget, message }
    },
    onSuccess: (_, id) => {
      queryClient.invalidateQueries({ queryKey: [api.quotes.get.path, id] });
      queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] });
    },
  });
}

export function useCloseQuote() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...data }: {
      id: number | string;
      reason?: string;
      cancelled?: boolean;
      outcome?: "admin_completed";
      confirmed?: true;
      requestKey?: string;
      correctCancelled?: boolean;
    }) => {
      const res = await fetch(`${API_BASE}/api/quotes/${id}/close`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {const error=await res.json().catch(()=>({}));throw new Error(error.message||"Could not close this record; check completion evidence.");}
      return res.json();
    },
    onSuccess: async (data) => {
      if (data?.id != null) queryClient.setQueryData([api.quotes.get.path, data.id], data);
      await refreshQuoteViews(queryClient);
      await queryClient.invalidateQueries({ queryKey: ["/api/staff/quotes"] });
    },
  });
}

// Blocked Slots
export function useBlockedSlots() {
  return useQuery<{ id: number; date: string; timeSlot: string | null; reason: string | null }[]>({
    queryKey: ["/api/blocked-slots"],
    staleTime: 30_000,
  });
}

export function useCreateBlockedSlot() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: { date: string; timeSlot?: string | null; reason?: string }) => {
      const res = await apiRequest("POST", "/api/admin/blocked-slots", data);
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/blocked-slots"] }),
  });
}

export function useDeleteBlockedSlot() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/admin/blocked-slots/${id}`);
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/blocked-slots"] }),
  });
}

// Keep for backward compatibility
export function useUpdateQuoteBooking() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, scheduledAt, timeWindow }: { id: number | string; scheduledAt: string; timeWindow: string }) => {
      const res = await fetch(`${API_BASE}/api/quotes/${id}/booking-request`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scheduledAt, timeWindow }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Booking failed");
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.quotes.get.path, variables.id] });
      queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] });
    },
  });
}
