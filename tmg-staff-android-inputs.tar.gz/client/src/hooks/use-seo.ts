import { useEffect, useState } from "react";
import { HOME_SEO, publicPageSeo, shouldNoIndex, SITE_ORIGIN } from "@shared/site-seo";

const DEFAULT_TITLE = HOME_SEO.title;
const DEFAULT_DESCRIPTION = HOME_SEO.description;
const DEFAULT_CANONICAL = "https://tmginstall.com/";
const DEFAULT_OG_IMAGE = "https://tmginstall.com/icon-512.png";

interface SEOOptions {
  title: string;
  description?: string;
  canonical?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  noIndex?: boolean;
  jsonLd?: object | object[];
  page?: string; // path key — defaults to window.location.pathname
}

function setMeta(selector: string, attr: string, value: string) {
  let el = document.querySelector(selector);
  if (!el) {
    const match = selector.match(/^(meta|link)\[(name|property|rel)="([^"]+)"\]$/);
    if (match) {
      el = document.createElement(match[1]);
      el.setAttribute(match[2], match[3]);
      document.head.appendChild(el);
    }
  }
  if (el) el.setAttribute(attr, value);
}

/** Covers SPA navigation to screens without their own useSEO hook. */
export function useRouteSEO(path: string) {
  useEffect(() => {
    const meta = publicPageSeo(path);
    const privatePage = shouldNoIndex(path);
    // The router's rendered fallback owns this title. Missing catalogue metadata
    // alone cannot distinguish a 404 from a legitimate private/dynamic screen.
    const missingPage = document.querySelector("[data-page-not-found]")?.getAttribute("data-page-not-found") === path;
    document.title = meta?.title || (missingPage ? "Page Not Found | TMG Install" : "Customer & Staff Access | TMG Install");
    setMeta('meta[name="description"]', "content", meta?.description || (missingPage
      ? "This page could not be found. Explore TMG Install furniture services in Singapore."
      : "Private customer, staff and account access for TMG Install."));
    for (const bot of ["robots", "googlebot", "bingbot"]) {
      setMeta(`meta[name="${bot}"]`, "content", privatePage ? "noindex, nofollow, noarchive" : "index, follow, max-image-preview:large");
    }
    if (meta) {
      setMeta('link[rel="canonical"]', "href", `${SITE_ORIGIN}${path}`);
      for (const locale of ["en-sg", "x-default"]) {
        let link = document.querySelector<HTMLLinkElement>(`link[rel="alternate"][hreflang="${locale}"]`);
        if (!link) { link = document.createElement("link"); link.rel = "alternate"; link.hreflang = locale; document.head.appendChild(link); }
        link.href = `${SITE_ORIGIN}${path}`;
      }
      for (const prefix of ["og", "twitter"]) {
        const key = prefix === "og" ? "property" : "name";
        setMeta(`meta[${key}="${prefix}:title"]`, "content", meta.title);
        setMeta(`meta[${key}="${prefix}:description"]`, "content", meta.description);
        setMeta(`meta[${key}="${prefix}:url"]`, "content", `${SITE_ORIGIN}${path}`);
      }
    } else if (privatePage) {
      document.querySelector('link[rel="canonical"]')?.remove();
      document.querySelectorAll('link[rel="alternate"][hreflang]').forEach(link => link.remove());
      document.querySelector('script[data-seo-page]')?.remove();
    }
  }, [path]);
}

// Cache the live override map across hook usages so we only fetch once per session
let liveOverrideCache: Record<string, Record<string, string>> | null = null;
let liveOverridePromise: Promise<Record<string, Record<string, string>>> | null = null;

async function loadLiveOverrides(): Promise<Record<string, Record<string, string>>> {
  if (liveOverrideCache) return liveOverrideCache;
  if (liveOverridePromise) return liveOverridePromise;
  liveOverridePromise = fetch("/api/public/site-settings")
    .then(r => r.ok ? r.json() : {})
    .then(data => { liveOverrideCache = data || {}; return liveOverrideCache!; })
    .catch(() => ({}));
  return liveOverridePromise;
}

export function overridesForPage(
  map: Record<string, Record<string, string>>,
  pageKey: string,
): Record<string, string> {
  return map[pageKey] || {};
}

export function useSEO({
  title,
  description,
  canonical,
  ogTitle,
  ogDescription,
  ogImage,
  noIndex = false,
  jsonLd,
  page,
}: SEOOptions) {
  const [overrides, setOverrides] = useState<Record<string, string>>({});

  useEffect(() => {
    const pageKey = page || (typeof window !== "undefined" ? window.location.pathname : "/");
    loadLiveOverrides().then(map => {
      const o = overridesForPage(map, pageKey);
      if (Object.keys(o).length) setOverrides(o);
    });
  }, [page]);

  useEffect(() => {
    // AI-applied overrides take precedence over the page's defaults
    const pathname = page || window.location.pathname;
    const routeSeo = publicPageSeo(pathname);
    const privatePage = noIndex || shouldNoIndex(pathname);
    const finalTitle = overrides.meta_title || routeSeo?.title || title;
    const desc = overrides.meta_description || routeSeo?.description || description || DEFAULT_DESCRIPTION;
    const canon = canonical || `${SITE_ORIGIN}${routeSeo ? pathname : "/"}`;
    const ogT = ogTitle || finalTitle;
    const ogD = ogDescription || desc;
    const ogImg = ogImage || DEFAULT_OG_IMAGE;

    document.title = finalTitle;
    setMeta('meta[name="description"]', "content", desc);
    setMeta(
      'meta[name="robots"]',
      "content",
      privatePage
        ? "noindex, nofollow, noarchive"
        : "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1",
    );
    if (privatePage) document.querySelector('link[rel="canonical"]')?.remove();
    else setMeta('link[rel="canonical"]', "href", canon);
    for (const bot of ["googlebot", "bingbot"]) {
      setMeta(`meta[name="${bot}"]`, "content", privatePage ? "noindex, nofollow, noarchive" : "index, follow, max-image-preview:large");
    }

    setMeta('meta[property="og:title"]', "content", ogT);
    setMeta('meta[property="og:description"]', "content", ogD);
    setMeta('meta[property="og:url"]', "content", canon);
    setMeta('meta[property="og:image"]', "content", ogImg);

    setMeta('meta[name="twitter:title"]', "content", ogT);
    setMeta('meta[name="twitter:description"]', "content", ogD);
    setMeta('meta[name="twitter:url"]', "content", canon);
    setMeta('meta[name="twitter:image"]', "content", ogImg);

    let ldEl: HTMLScriptElement | null = document.querySelector('script[data-seo-page]');
    if (jsonLd && !privatePage) {
      if (!ldEl) {
        ldEl = document.createElement("script");
        ldEl.type = "application/ld+json";
        ldEl.setAttribute("data-seo-page", "true");
        document.head.appendChild(ldEl);
      }
      ldEl.textContent = JSON.stringify(Array.isArray(jsonLd) ? jsonLd : [jsonLd]);
    } else if (ldEl) {
      ldEl.remove();
    }

    return () => {
      document.title = DEFAULT_TITLE;
      setMeta('meta[name="description"]', "content", DEFAULT_DESCRIPTION);
      setMeta(
        'meta[name="robots"]',
        "content",
        shouldNoIndex(window.location.pathname) ? "noindex, nofollow, noarchive" : "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1",
      );
      if (shouldNoIndex(window.location.pathname)) document.querySelector('link[rel="canonical"]')?.remove();
      else setMeta('link[rel="canonical"]', "href", DEFAULT_CANONICAL);
      setMeta('meta[property="og:title"]', "content", DEFAULT_TITLE);
      setMeta('meta[property="og:description"]', "content", DEFAULT_DESCRIPTION);
      setMeta('meta[property="og:url"]', "content", DEFAULT_CANONICAL);
      setMeta('meta[property="og:image"]', "content", DEFAULT_OG_IMAGE);
      const cleanup = document.querySelector('script[data-seo-page]');
      if (cleanup) cleanup.remove();
    };
  }, [title, description, canonical, ogTitle, ogDescription, ogImage, noIndex, overrides]);

  // Return live overrides so consumer pages can also apply h1/cta_text dynamically
  return { liveOverrides: overrides };
}
