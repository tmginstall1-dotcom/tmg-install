import {useEffect,useRef,useState} from "react";
import {useMutation,useQuery} from "@tanstack/react-query";
import {apiRequest,queryClient} from "@/lib/queryClient";
import {checklistLabels,checklistReadiness,persistChecklist} from "@/lib/completion-checklist";

export function useCompletionChecklist(id:string|undefined,owner:number|undefined,required:string[]) {
  const identity=`${owner}:${id}`;
  const current=useRef(identity);current.current=identity;
  const path=`/api/staff/jobs/${id}/checklist`,key=[path];
  const [intent,setIntent]=useState<string[]|null>(null);
  const [saveError,setSaveError]=useState("");
  const read=async()=>checklistLabels(await (await apiRequest("GET",path)).json());
  const query=useQuery({
    queryKey:key,enabled:!!id&&!!owner,retry:false,staleTime:0,
    queryFn:async()=>({checkItems:await read()}),
  });
  const mutation=useMutation({
    mutationFn:async(input:{labels:string[];identity:string})=>{
      const saved=await persistChecklist(input.labels,
        labels=>apiRequest("PATCH",path,{checkItems:labels}),
        async()=>({checkItems:await read()}));
      return saved;
    },
    onSuccess:(saved,input)=>{
      if(current.current!==input.identity)return;
      queryClient.setQueryData(key,{checkItems:saved});
      setIntent(null);setSaveError("");
    },
    onError:(error:any,input)=>{
      if(current.current===input.identity)setSaveError(error.message||"Checklist save was not confirmed. Retry saving.");
    },
  });
  useEffect(()=>{
    setIntent(null);setSaveError("");mutation.reset();
  },[identity]);
  const saved=query.data?.checkItems;
  const state=checklistReadiness(required,saved,{
    loading:query.isFetching||query.isPending,error:query.isError,
    saving:mutation.isPending,unconfirmed:intent!==null,
  });
  const save=(labels:string[])=>{
    if(mutation.isPending)return;
    setIntent(labels);setSaveError("");
    mutation.mutate({labels,identity});
  };
  const verify=async()=>{
    if(mutation.isPending||intent!==null)throw new Error("Wait for every checklist confirmation to be saved, or retry saving it.");
    const result=await query.refetch();
    if(result.isError||!result.data)throw new Error("The saved checklist could not be verified. Retry loading; your photos and sign-off remain here.");
    const missing=required.filter(label=>!result.data.checkItems.includes(label));
    if(missing.length)throw new Error(`Finish and save the work checklist first: ${missing.join("; ")}`);
  };
  return {
    ...state,saved:saved||[],selected:intent??saved??[],intent,saveError,
    loading:query.isFetching||query.isPending,readError:query.isError,saving:mutation.isPending,
    toggle:(label:string)=>save((intent??saved??[]).includes(label)
      ?(intent??saved??[]).filter(v=>v!==label):[...(intent??saved??[]),label]),
    retrySave:()=>{if(intent)save(intent);},
    retryRead:()=>query.refetch(),restoreIntent:setIntent,verify,
  };
}
