import { useState,useEffect } from "react";
import {startNativeTracker} from "@/lib/native-tracker-start";
import { Capacitor, registerPlugin } from "@capacitor/core";
import type { PluginListenerHandle } from "@capacitor/core";

// ─── Custom native plugin interface ─────────────────────────────────────────────
interface TMGLocationPlugin {
  startWatching(options?: { staffId?: number;apiBase?:string }): Promise<void>;
  stopWatching(): Promise<void>;
  addListener(
    event: "location",
    handler: (data: {
      lat: number;
      lng: number;
      accuracy: number;
      speed: number;
      time: number;
      error?:string;
    }) => void,
  ): Promise<PluginListenerHandle>;
  removeAllListeners(): Promise<void>;
}

const TMGLocation = registerPlugin<TMGLocationPlugin>("TMGLocation");

// ─── LocalStorage key for tracking persistence across app restarts/updates ────
const TRACKING_STORAGE_KEY = "tmg_gps_active_staff_id";
const LAST_GPS_STORAGE_KEY = "tmg_last_gps_fix";

export type PersistedGpsFix = {
  lat: number;
  lng: number;
  accuracy: number | null;
  speed: number | null;
  recordedAt: number;
};

function persistTrackingState(staffId: number | null) {
  try {
    if (staffId !== null && staffId >= 0) {
      localStorage.setItem(TRACKING_STORAGE_KEY, String(staffId));
    } else {
      localStorage.removeItem(TRACKING_STORAGE_KEY);
      localStorage.removeItem(LAST_GPS_STORAGE_KEY);
    }
  } catch {}
}

export function getPersistedTrackingStaffId(): number | null {
  try {
    const val = localStorage.getItem(TRACKING_STORAGE_KEY);
    if (!val) return null;
    const id = parseInt(val, 10);
    return isNaN(id) || id < 0 ? null : id;
  } catch {
    return null;
  }
}

function isValidGpsCoordinate(lat: number, lng: number) {
  return (
    Number.isFinite(lat) &&
    Number.isFinite(lng) &&
    lat >= -90 &&
    lat <= 90 &&
    lng >= -180 &&
    lng <= 180
  );
}

function persistLastGpsFix(fix: PersistedGpsFix) {
  try {
    localStorage.setItem(LAST_GPS_STORAGE_KEY, JSON.stringify(fix));
  } catch {}
}

export function getFreshPersistedGpsFix(
  maxAgeMs = 120_000,
  maxAccuracyM = 250,
): PersistedGpsFix | null {
  try {
    const raw = localStorage.getItem(LAST_GPS_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<PersistedGpsFix>;
    const lat = Number(parsed.lat);
    const lng = Number(parsed.lng);
    const recordedAt = Number(parsed.recordedAt);
    const accuracy =
      parsed.accuracy === null || parsed.accuracy === undefined
        ? null
        : Number(parsed.accuracy);
    const speed =
      parsed.speed === null || parsed.speed === undefined
        ? null
        : Number(parsed.speed);

    if (!isValidGpsCoordinate(lat, lng)) return null;
    if (
      !Number.isFinite(recordedAt) ||
      Date.now() - recordedAt < 0 ||
      Date.now() - recordedAt > maxAgeMs
    )
      return null;
    if (
      accuracy !== null &&
      (!Number.isFinite(accuracy) || accuracy > maxAccuracyM)
    )
      return null;
    return {
      lat,
      lng,
      accuracy,
      speed: speed !== null && Number.isFinite(speed) ? speed : null,
      recordedAt,
    };
  } catch {
    return null;
  }
}
// ─── Module-level singletons so tracking survives component unmounts ─────────

let nativeListener: PluginListenerHandle | null = null;
let webWatcherId: number | null = null;
let trackingStaffId: number | null = null;
let lastSentAt = 0;
let lastLat = 0;
let lastLng = 0;
let starting:Promise<void>|null=null;
let trackingError="";
let trackingGeneration=0;
let pointSending=false;
function trackingChanged(error=""){trackingError=error;if(typeof window!=="undefined")window.dispatchEvent(new Event("tmg-tracking-state"));}

const MIN_INTERVAL_MS = 25_000;
const MIN_DISTANCE_M = 20;

const API_BASE = (import.meta.env.VITE_API_BASE as string) || "";

function distanceMetres(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number,
) {
  const R = 6_371_000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export async function sendPoint(
  staffId: number,
  lat: number,
  lng: number,
  accuracy?: number | null,
  speed?: number | null,
  capturedAt=Date.now(),
) {
  let ownsPointDelivery=false;
  if (!isValidGpsCoordinate(lat, lng)) return;

  const now = Date.now();
  persistLastGpsFix({
    lat,
    lng,
    accuracy: accuracy ?? null,
    speed: speed ?? null,
    recordedAt: capturedAt,
  });
  if(Capacitor.isNativePlatform())return; // Native service owns acknowledged/offline delivery.
  const moved = distanceMetres(lastLat, lastLng, lat, lng);
  if (now - lastSentAt < MIN_INTERVAL_MS && moved < MIN_DISTANCE_M) return;

  try {
    const key=`tmg_gps_queue_${staffId}`;
    const pending=JSON.parse(localStorage.getItem(key)||"[]").filter((p:any)=>now-new Date(p.recordedAt).getTime()<2*60*60*1000);
    const point={staffId,lat:String(lat),lng:String(lng),accuracy:accuracy??null,speed:speed??null,
      heading:null,recordedAt:new Date(capturedAt).toISOString()};
    if(!pending.some((p:any)=>p.recordedAt===point.recordedAt))pending.push(point);
    localStorage.setItem(key,JSON.stringify(pending.slice(-60)));
    if(pointSending)return;
    pointSending=true;ownsPointDelivery=true;
    const generation=trackingGeneration;
    while(true){
    const queue=JSON.parse(localStorage.getItem(key)||"[]");
    if(!queue.length||trackingStaffId!==staffId||generation!==trackingGeneration)break;
    const response=await fetch(`${API_BASE}/api/staff/gps-track`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(queue[0]),
    });
    if(trackingStaffId!==staffId||generation!==trackingGeneration)return;
    if(response.status===401||response.status===403){await stopAllTracking();trackingChanged("Sign in again to resume shift tracking");return;}
    if(!response.ok)throw new Error("Location upload failed; active-shift points retained for retry");
    const saved=await response.json();
    if(saved.ok===false&&saved.reason==="not_clocked_in"){await stopAllTracking();return;}
    const remaining=JSON.parse(localStorage.getItem(key)||"[]").filter((p:any)=>p.recordedAt!==queue[0].recordedAt);
    localStorage.setItem(key,JSON.stringify(remaining));
    }
    lastSentAt=now;lastLat=lat;lastLng=lng;trackingChanged();
  } catch {
    trackingChanged("Location not confirmed saved; retained points retry on the next fix or reconnect");
  } finally {
    if(ownsPointDelivery)pointSending=false;
  }
}

// ─── Standalone stop (callable outside the hook, e.g. on logout) ─────────────

export async function stopAllTracking() {
  trackingGeneration++;
  if(trackingStaffId)try{localStorage.removeItem(`tmg_gps_queue_${trackingStaffId}`);}catch{}
  persistTrackingState(null);
  try {
    if (Capacitor.isNativePlatform()) {
      await TMGLocation.stopWatching();
      if (nativeListener) {
        await nativeListener.remove();
        nativeListener = null;
      }
    } else if (webWatcherId !== null) {
      navigator.geolocation?.clearWatch(webWatcherId);
      webWatcherId = null;
    }
  } catch {
    nativeListener = null;
    webWatcherId = null;
  }
  trackingStaffId = null;
  trackingChanged();
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useBackgroundLocation() {
  const [isTracking, setIsTracking] = useState(
    nativeListener !== null || webWatcherId !== null,
  );
  const [error,setError]=useState(trackingError);
  useEffect(()=>{
    const refresh=()=>{setIsTracking(nativeListener!==null||webWatcherId!==null);setError(trackingError);};
    window.addEventListener("tmg-tracking-state",refresh);
    const online=()=>{const fix=getFreshPersistedGpsFix();if(trackingStaffId&&fix)void sendPoint(trackingStaffId,fix.lat,fix.lng,fix.accuracy,fix.speed,fix.recordedAt);};
    window.addEventListener("online",online);
    return()=>{window.removeEventListener("tmg-tracking-state",refresh);window.removeEventListener("online",online);};
  },[]);

  async function startTracking(staffId: number) {
    if(starting)return starting;
    const generation=trackingGeneration;
    starting=(async()=>{
    const response=await fetch(`${API_BASE}/api/attendance/today`,{credentials:"include"});
    if(!response.ok){await stopAllTracking();throw new Error("Sign in again to verify your active shift");}
    const shift=await response.json();
    if(generation!==trackingGeneration)return;
    if(!shift||shift.clockOutAt||shift.userId!==staffId){await stopAllTracking();return;}
    if(trackingStaffId===staffId&&(nativeListener!==null||webWatcherId!==null))return;
    if(trackingStaffId&&trackingStaffId!==staffId)await stopAllTracking();

    trackingStaffId = staffId;
    lastLat = 0;
    lastLng = 0;
    lastSentAt = 0;

    try {
      if (Capacitor.isNativePlatform()) {
        // ── Native Android: TMGLocationPlugin (Java 17 foreground service) ──
        nativeListener = await startNativeTracker({
          addListener:TMGLocation.addListener.bind(TMGLocation),
          startWatching:()=>{
            if(generation!==trackingGeneration)throw new Error("Tracking start cancelled");
            return TMGLocation.startWatching({staffId,apiBase:API_BASE||window.location.origin});
          },
        },staffId,(loc) => {
          if(loc.error){void stopAllTracking().then(()=>trackingChanged(loc.error));return;}
          if (!trackingStaffId) return;
          sendPoint(trackingStaffId, loc.lat, loc.lng, loc.accuracy, loc.speed,loc.time);
        });
        if(generation!==trackingGeneration){
          await nativeListener.remove();nativeListener=null;await TMGLocation.stopWatching();return;
        }
        // Pass staffId so the service can persist it in SharedPreferences and
        // submit GPS points directly when the app is backgrounded/killed.
        // Also captures and refreshes the session cookie — critical after updates.
      } else {
        // ── Web fallback: standard watchPosition ─────────────────────────────
        if (!navigator.geolocation)throw new Error("Location is unavailable on this device");

        webWatcherId = navigator.geolocation.watchPosition(
          (pos) => {
            if (!trackingStaffId) return;
            sendPoint(
              trackingStaffId,
              pos.coords.latitude,
              pos.coords.longitude,
              pos.coords.accuracy,
              pos.coords.speed,
              pos.timestamp,
            );
          },
          (error) => {void stopAllTracking().then(()=>trackingChanged(error.code===1?"Location permission denied. Enable location and retry tracking.":"Location timed out. Check GPS and retry tracking."));},
          { enableHighAccuracy: true, timeout: 30_000, maximumAge: 5_000 },
        );
      }

      // Persist so GPS auto-resumes after app update/restart without waiting for queries
      persistTrackingState(staffId);
      setIsTracking(true);
      trackingChanged();
    } catch(error:any) {
      await stopAllTracking();trackingChanged(error.message||"Location tracking could not start");
      throw error;
    }
    })().finally(()=>{starting=null;});
    return starting;
  }

  async function stopTracking() {
    await stopAllTracking();
    setIsTracking(false);
  }

  return { isTracking, startTracking, stopTracking,trackingError:error };
}
