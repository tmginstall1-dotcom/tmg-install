import { useQuery } from "@tanstack/react-query";
import { DASHBOARD_QUOTES_KEY, DASHBOARD_QUOTES_PATH, type DashboardQuote } from "@shared/dashboard";
import { fetchJsonWithTimeout } from "@/lib/fetchJsonWithTimeout";

const API_BASE = (import.meta.env.VITE_API_BASE as string) || "";

export function useDashboardQuotes(enabled = true, poll = false) {
  return useQuery<DashboardQuote[]>({
    queryKey: DASHBOARD_QUOTES_KEY,
    enabled,
    queryFn: ({ signal }) => fetchJsonWithTimeout<DashboardQuote[]>(
      `${API_BASE}${DASHBOARD_QUOTES_PATH}`, { credentials: "include", signal },
    ),
    retry: (count, error: any) => {
      if (error?.status >= 400 && error.status < 500) return false;
      return count < 1;
    },
    retryDelay: 1_000,
    // Only the dashboard owns the polling timer. Each observer otherwise
    // installs a separate timer and can trigger redundant shell requests.
    refetchInterval: (query) => !poll ? false : query.state.data?.some(q =>
      ["deposit_requested", "final_payment_requested"].includes(q.status),
    ) ? 5_000 : 30_000,
  });
}