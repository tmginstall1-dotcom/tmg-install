import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { initMetaPixel } from "@/lib/metaPixel";
import { initGoogleAdsWhatsAppTracking } from "@/lib/googleAds";
import { captureLeadAttribution } from "@/lib/leadAttribution";

const rootEl = document.getElementById("root")!;
const readableFallback = rootEl.innerHTML;

function hideSplash() {
  const splash = document.getElementById("splash");
  if (!splash) return;
  splash.style.transition = "opacity 0.25s ease";
  splash.style.opacity = "0";
  setTimeout(() => splash.remove(), 300);
}

// Make the (now styled) app visible and fade the splash away, after the styled
// frame is committed (two RAFs).
function reveal() {
  document.documentElement.removeAttribute("data-app-booting");
  rootEl.style.visibility = "";
  requestAnimationFrame(() => requestAnimationFrame(() => hideSplash()));
}

// Performance strategy (the "/" homepage is a heavy client-rendered SPA):
//
// FCP/LCP come from the inline #splash in index.html — its giant "TMG" wordmark
// uses a SYSTEM font (no web font) so it paints instantly from HTML, and it is
// pixel-identical to the React hero (.hero-h1-responsive). Because the revealed
// hero matches the splash exactly, it never becomes a new/larger LCP candidate,
// so LCP stays locked to that early splash paint regardless of when React or the
// stylesheet finish.
//
// Two things to get right here:
//   1. FCP — do NOT run the heavy synchronous React render before the browser
//      has painted the splash. We yield with a double rAF first so the splash
//      paints, THEN mount.
//   2. CLS — in production the main stylesheet is non-blocking (see
//      server/static.ts). If we revealed #root before that CSS applied, the
//      unstyled->styled reflow would be recorded as a layout shift (even behind
//      the opaque splash). So we keep #root hidden until the stylesheet applies,
//      then reveal. In dev — or any page with no deferred stylesheet — CSS is
//      already present so we reveal immediately.
(function mountAndRevealWhenStyled() {
  const asyncCss = document.querySelector(
    "link[data-async-css]",
  ) as HTMLLinkElement | null;
  // `window.__cssReady` is flipped to true by the stylesheet's inline onload at
  // the exact moment it is applied to the screen (media print->all swap). That
  // global flag is the authoritative "styles are live" signal — independent of
  // whether we caught the link's `load` event in time.
  const isStyled = () => !asyncCss || (window as any).__cssReady === true;

  let done = false;
  const go = () => {
    if (done) return;
    done = true;
    document.getElementById("style-load-recovery")?.remove();
    reveal();
  };

  const mount = () => {
    // Keep the app hidden until the deferred stylesheet has applied so the
    // unstyled->styled reflow (behind the splash) is never counted as CLS.
    if (!isStyled()) rootEl.style.visibility = "hidden";
    (window as any).__appMounted = true;
    createRoot(rootEl).render(<App />);

    if (isStyled()) {
      go();
      return;
    }

    // Race-proof gate: poll the global flag every frame so we reveal the instant
    // CSS applies even if the link's `load` event fired before we listened.
    const poll = () => {
      if (done) return;
      if (isStyled()) {
        go();
        return;
      }
      requestAnimationFrame(poll);
    };
    requestAnimationFrame(poll);

    // Backups: the link's own load/error events (error so a failed stylesheet
    // can never leave the app permanently hidden) + an absolute last resort.
    asyncCss!.addEventListener("load", () => { if (isStyled()) go(); }, { once: true });
    const reportStyleFailure = () => {
      if (done || document.getElementById("style-load-recovery")) return;
      const recovery = document.createElement("div");
      recovery.id = "style-load-recovery";
      recovery.style.cssText = "position:fixed;inset:0;z-index:10000;overflow:auto;background:#fafaf7;color:#111;padding:24px;font:16px system-ui";
      const retry = document.createElement("a");
      retry.dataset.styleRetry = "true";
      retry.href = window.location.href;
      retry.textContent = "Page styles could not load. Reload this page.";
      retry.setAttribute("role", "alert");
      retry.style.cssText = "display:block;margin:24px 0;font:16px system-ui;color:#111";
      recovery.append(retry);
      // This is the server's already escaped public fallback, not customer data.
      const content = document.createElement("div");
      content.innerHTML = readableFallback;
      recovery.append(content);
      const enquiry = document.createElement("a");
      enquiry.href = "https://wa.me/6580880757";
      enquiry.textContent = "Ask TMG about your furniture on WhatsApp";
      recovery.append(enquiry);
      document.body.append(recovery);
      document.getElementById("splash")?.remove();
    };
    asyncCss!.addEventListener("error", reportStyleFailure, { once: true });
    // A failed stylesheet must not reveal unstyled content and manufacture CLS.
    // Keep the functional splash link available; a reload can recover the CSS.
    setTimeout(() => { if (isStyled()) go(); else reportStyleFailure(); }, 6000);
  };

  // Let the browser paint the inline splash FIRST (fast FCP) before running the
  // heavy synchronous React render. Two rAFs guarantee a committed paint.
  requestAnimationFrame(() => requestAnimationFrame(mount));
})();

// Google Ads WhatsApp click conversion tracking — installs a single global
// click listener; fires the "WhatsApp Click - Website" conversion for any
// WhatsApp link (wa.me / api.whatsapp.com / whatsapp:) anywhere on the site.
initGoogleAdsWhatsAppTracking();

// Capture gclid/gbraid/wbraid + UTM params + landing page/referrer on first
// load so the estimate wizard can attach them to lead submissions even after
// multi-step SPA navigation. Persisted to session/local storage.
captureLeadAttribution();

// Defer third-party tracking (Meta Pixel) until the browser is idle or the
// user first interacts — whichever happens first. Keeps the Facebook script
// off the critical path so it never competes with first paint / LCP.
(function deferMetaPixel() {
  let started = false;
  const run = () => {
    if (started) return;
    started = true;
    initMetaPixel();
  };
  const ric = (window as any).requestIdleCallback as
    | ((cb: () => void, opts?: { timeout: number }) => void)
    | undefined;
  if (typeof ric === "function") {
    ric(run, { timeout: 4000 });
  } else {
    setTimeout(run, 2500);
  }
  ["pointerdown", "keydown", "touchstart", "scroll"].forEach((evt) =>
    window.addEventListener(evt, run, { once: true, passive: true }),
  );
  // Also fire before the user leaves a quick no-interaction session so the
  // PageView still has a chance to be recorded.
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") run();
  });
  window.addEventListener("pagehide", run, { once: true });
})();
