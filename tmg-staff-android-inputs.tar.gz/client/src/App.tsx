import { Switch, Route, useLocation } from "wouter";
import { useEffect, lazy, Suspense, Component } from "react";
import type { ReactNode, ComponentType } from "react";
import { Capacitor } from "@capacitor/core";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import { Navbar } from "@/components/layout/Navbar";
import { StaffBottomNav } from "@/components/layout/StaffBottomNav";
import { AdminBottomNav } from "@/components/layout/AdminBottomNav";
import { AdminSidebar } from "@/components/layout/AdminSidebar";

import Landing from "@/pages/customer/LandingCinematic";

// ── Stale-deploy recovery ───────────────────────────────────────────────────
// Every route below is code-split into a content-hashed chunk (e.g.
// /assets/Dashboard-ab12cd.js). When a new version is published the hashes
// change and the old chunk filenames stop existing on the server. A browser
// (or installed PWA) still running the previous app shell then tries to load a
// chunk that 404s, the dynamic import() rejects, React throws, and the user is
// stuck on the "Something went wrong" screen.
//
// `shouldReloadOnce()` allows ONE automatic hard reload per short window. A
// reload fetches the fresh index.html (network-first in the service worker)
// plus the new chunks, which fixes the problem. The time guard prevents an
// infinite reload loop if the failure is a genuine code bug rather than a
// stale chunk.
function shouldReloadOnce(): boolean {
  try {
    const KEY = "tmg-chunk-reload-at";
    const now = Date.now();
    const last = Number(sessionStorage.getItem(KEY) || 0);
    if (now - last > 10000) {
      sessionStorage.setItem(KEY, String(now));
      return true;
    }
  } catch {
    // sessionStorage unavailable (private mode etc.) — fall through to no-reload.
  }
  return false;
}

// Bulletproof recovery: clear every Cache Storage entry and unregister all
// service workers, THEN hard-reload. A plain reload can be re-served the same
// stale app shell by a pinned service worker (common with installed iOS PWAs),
// which keeps pointing at chunk files a newer deploy removed. Wiping caches +
// workers first guarantees the reload comes straight from the network.
async function hardReload(): Promise<void> {
  try {
    if (typeof caches !== "undefined") {
      const keys = await caches.keys();
      await Promise.all(keys.map((k) => caches.delete(k)));
    }
  } catch {
    // caches API unavailable — fall through to plain reload.
  }
  try {
    if ("serviceWorker" in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map((r) => r.unregister()));
    }
  } catch {
    // service worker API unavailable — fall through to plain reload.
  }
  window.location.reload();
}

function isChunkLoadError(err: unknown): boolean {
  const msg = String((err as any)?.message || err || "");
  return (
    /Loading chunk|Loading CSS chunk|dynamically imported module|Importing a module script failed|Failed to fetch dynamically imported module|ChunkLoadError/i.test(
      msg,
    )
  );
}

// Wrap React.lazy so a failed chunk import triggers a guarded one-time reload
// instead of crashing straight into the error boundary.
function lazyWithReload<T extends ComponentType<any>>(
  factory: () => Promise<{ default: T }>,
) {
  return lazy(async () => {
    try {
      return await factory();
    } catch (err) {
      if (shouldReloadOnce()) {
        void hardReload();
        // Keep the Suspense fallback up while the page reloads.
        return await new Promise<{ default: T }>(() => {});
      }
      throw err;
    }
  });
}

const LandingClassic = lazyWithReload(() => import("@/pages/customer/Landing"));

const QuoteStatus = lazyWithReload(() => import("@/pages/customer/QuoteStatus"));
const StatusRedirect = lazyWithReload(() => import("@/pages/customer/StatusRedirect"));
const JobTracker = lazyWithReload(() => import("@/pages/customer/JobTracker"));
const EstimateWizard = lazyWithReload(() => import("@/pages/customer/Estimate"));
const PackageBooking = lazyWithReload(() => import("@/pages/customer/PackageBooking"));
const Terms = lazyWithReload(() => import("@/pages/customer/Terms"));
const Privacy = lazyWithReload(() => import("@/pages/customer/Privacy"));
const Invoice = lazyWithReload(() => import("@/pages/Invoice"));
const Login = lazyWithReload(() => import("@/pages/admin/Login"));
const AdminDashboard = lazyWithReload(() => import("@/pages/admin/Dashboard"));
const AdminQuoteDetail = lazyWithReload(() => import("@/pages/admin/QuoteDetail"));
const AdminSchedule = lazyWithReload(() => import("@/pages/admin/Schedule"));
const AdminExportPDF = lazyWithReload(() => import("@/pages/admin/ExportPDF"));
const AdminStaffManagement = lazyWithReload(() => import("@/pages/admin/StaffManagement"));
const AdminAnalytics = lazyWithReload(() => import("@/pages/admin/Analytics"));
const AdminSettings = lazyWithReload(() => import("@/pages/admin/Settings"));
const AdminBusinessRules = lazyWithReload(() => import("@/pages/admin/BusinessRules"));
const AdminQuickReplies = lazyWithReload(() => import("@/pages/admin/QuickReplies"));
const AdminConversations = lazyWithReload(() => import("@/pages/admin/Conversations"));
const AdminReceipts = lazyWithReload(() => import("@/pages/admin/Receipts"));
const AdminFaqManager = lazyWithReload(() => import("@/pages/admin/FaqManager"));
const AdminSeoPanel = lazyWithReload(() => import("@/pages/admin/SeoPanel"));
const AdminReviews = lazyWithReload(() => import("@/pages/admin/ReviewsManager"));
const AdminGGVJobs = lazyWithReload(() => import("@/pages/admin/GGVJobs"));
const AdminSubcontractors = lazyWithReload(() => import("@/pages/admin/Subcontractors"));
const AdminAIHub = lazyWithReload(() => import("@/pages/admin/ai/AIHub"));
const AdminAIAds = lazyWithReload(() => import("@/pages/admin/ai/AIAdsPanel"));
const AdminAISite = lazyWithReload(() => import("@/pages/admin/ai/AISitePanel"));
const AdminAIApprovals = lazyWithReload(() => import("@/pages/admin/ai/AIApprovalQueue"));
const AdminAIAudit = lazyWithReload(() => import("@/pages/admin/ai/AIAuditLog"));
const AdminAIConnectors = lazyWithReload(() => import("@/pages/admin/ai/AIConnectors"));
const AdminAIWhatsApp = lazyWithReload(() => import("@/pages/admin/ai/AIWhatsApp"));
const WhatsAppFirstPreview = lazyWithReload(() => import("@/pages/WhatsAppFirstPreview"));
const StaffDashboard = lazyWithReload(() => import("@/pages/staff/Dashboard"));
const StaffJobDetail = lazyWithReload(() => import("@/pages/staff/JobDetail"));
const StaffHR = lazyWithReload(() => import("@/pages/staff/HR"));

import { useAuth } from "@/hooks/use-auth";
import { useRouteSEO } from "@/hooks/use-seo";

function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="flex flex-col items-center gap-4">
        <div className="w-8 h-8 border-2 border-black/20 border-t-black rounded-full animate-spin" />
        <span className="text-[10px] font-black tracking-[0.2em] uppercase text-black/30">Loading</span>
      </div>
    </div>
  );
}

function AdminRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) return <PageLoader />;
  if (!user) { setLocation('/admin/login'); return null; }
  if (user.role !== 'admin') { setLocation('/staff'); return null; }
  return <Component />;
}

function StaffRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) return <PageLoader />;
  if (!user) { setLocation('/staff/login'); return null; }
  if (user.role === 'admin') { setLocation('/admin'); return null; }
  return <Component />;
}

function isNativeApp(): boolean {
  if (navigator.userAgent.includes("TMGStaffApp")) return true;
  try { if (Capacitor.isNativePlatform()) return true; } catch {}
  try { if ((window as any).Capacitor?.isNativePlatform?.()) return true; } catch {}
  return false;
}

function NativeRedirect() {
  const [location, setLocation] = useLocation();
  const { user, isLoading } = useAuth();
  useEffect(() => {
    if (!isNativeApp()) return;
    if (isLoading) return;
    if (location === "/" || location === "") {
      setLocation(user ? "/staff" : "/staff/login");
    }
  }, [location, setLocation, user, isLoading]);
  return null;
}

function AppResumeRefetcher() {
  useEffect(() => {
    if (!isNativeApp()) return;
    let cleanup: (() => void) | undefined;
    import("@capacitor/app").then(({ App: CapApp }) => {
      CapApp.addListener("appStateChange", ({ isActive }) => {
        if (isActive) {
          queryClient.invalidateQueries();
        }
      }).then((handle) => {
        cleanup = () => handle.remove();
      });
    }).catch(() => {});
    return () => { cleanup?.(); };
  }, []);
  return null;
}

function Router() {
  const [location] = useLocation();
  useRouteSEO(location);

  // Toggle the overscroll-bounce guard ONLY on screens that render a fixed
  // bottom nav (admin/staff app shells). This keeps native pull-to-refresh on
  // the customer-facing pages while stopping the bottom bar from being dragged
  // up/down by the rubber-band bounce on mobile.
  useEffect(() => {
    const hasBottomNav =
      (location.startsWith("/admin") && location !== "/admin/login") ||
      (location.startsWith("/staff") && location !== "/staff/login");
    const root = document.documentElement;
    root.classList.toggle("app-no-overscroll", hasBottomNav);
    return () => root.classList.remove("app-no-overscroll");
  }, [location]);

  return (
    <>
      <NativeRedirect />
      <AppResumeRefetcher />
      <Navbar />
      <AdminSidebar />
      <StaffBottomNav />
      <AdminBottomNav />
      <Suspense fallback={<PageLoader />}>
        <Switch>
          <Route path="/" component={Landing} />
          <Route path="/legacy-home" component={LandingClassic} />
          <Route path="/estimate" component={EstimateWizard} />
          <Route path="/book/:packageId" component={PackageBooking} />
          <Route path="/quotes/:id" component={QuoteStatus} />
          <Route path="/status/:refNo" component={StatusRedirect} />
          <Route path="/track/:referenceNo" component={JobTracker} />
          <Route path="/terms" component={Terms} />
          <Route path="/privacy" component={Privacy} />
          <Route path="/invoice/:refNo" component={Invoice} />

          <Route path="/admin/login" component={Login} />
          <Route path="/staff/login" component={Login} />

          <Route path="/admin">
            {() => <AdminRoute component={AdminDashboard} />}
          </Route>
          <Route path="/whatsapp-first-preview">
            {() => import.meta.env.DEV ? <WhatsAppFirstPreview /> : <AdminRoute component={WhatsAppFirstPreview} />}
          </Route>
          <Route path="/admin/schedule">
            {() => <AdminRoute component={AdminSchedule} />}
          </Route>
          <Route path="/admin/quotes/:id">
            {() => <AdminRoute component={AdminQuoteDetail} />}
          </Route>
          <Route path="/admin/export">
            {() => <AdminRoute component={AdminExportPDF} />}
          </Route>
          <Route path="/admin/staff">
            {() => <AdminRoute component={AdminStaffManagement} />}
          </Route>
          <Route path="/admin/analytics">
            {() => <AdminRoute component={AdminAnalytics} />}
          </Route>
          <Route path="/admin/settings">
            {() => <AdminRoute component={AdminSettings} />}
          </Route>
          <Route path="/admin/business-rules">
            {() => <AdminRoute component={AdminBusinessRules} />}
          </Route>
          <Route path="/admin/quick-replies">
            {() => <AdminRoute component={AdminQuickReplies} />}
          </Route>
          <Route path="/admin/conversations">
            {() => <AdminRoute component={AdminConversations} />}
          </Route>
          <Route path="/admin/whatsapp">
            {() => <AdminRoute component={AdminConversations} />}
          </Route>
          <Route path="/admin/receipts">
            {() => <AdminRoute component={AdminReceipts} />}
          </Route>
          <Route path="/admin/faq">
            {() => <AdminRoute component={AdminFaqManager} />}
          </Route>
          <Route path="/admin/seo">
            {() => <AdminRoute component={AdminSeoPanel} />}
          </Route>
          <Route path="/admin/reviews">
            {() => <AdminRoute component={AdminReviews} />}
          </Route>
          <Route path="/admin/ggv-jobs">
            {() => <AdminRoute component={AdminGGVJobs} />}
          </Route>
          <Route path="/admin/subcontractors">
            {() => <AdminRoute component={AdminSubcontractors} />}
          </Route>
          <Route path="/admin/ai">
            {() => <AdminRoute component={AdminAIHub} />}
          </Route>
          <Route path="/admin/ai/ads">
            {() => <AdminRoute component={AdminAIAds} />}
          </Route>
          <Route path="/admin/ai/site">
            {() => <AdminRoute component={AdminAISite} />}
          </Route>
          <Route path="/admin/ai/approvals">
            {() => <AdminRoute component={AdminAIApprovals} />}
          </Route>
          <Route path="/admin/ai/audit">
            {() => <AdminRoute component={AdminAIAudit} />}
          </Route>
          <Route path="/admin/ai/connectors">
            {() => <AdminRoute component={AdminAIConnectors} />}
          </Route>
          <Route path="/admin/ai/whatsapp">
            {() => <AdminRoute component={AdminAIWhatsApp} />}
          </Route>

          <Route path="/staff">
            {() => <StaffRoute component={StaffDashboard} />}
          </Route>
          <Route path="/staff/jobs/:id">
            {() => <StaffRoute component={StaffJobDetail} />}
          </Route>
          <Route path="/staff/hr">
            {() => <StaffRoute component={StaffHR} />}
          </Route>

          <Route component={NotFound} />
        </Switch>
      </Suspense>
    </>
  );
}

class ErrorBoundary extends Component<{ children: ReactNode }, { error: string | null }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(err: unknown) {
    return { error: String(err) };
  }
  componentDidCatch(err: unknown) {
    // A render-time chunk/dynamic-import failure means the deployed bundle moved
    // on. Force a guarded one-time reload to pick up the fresh app shell.
    if (isChunkLoadError(err) && shouldReloadOnce()) {
      void hardReload();
    }
  }
  render() {
    if (this.state.error) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-white p-8 text-center">
          <div className="text-4xl mb-4">⚠️</div>
          <h1 className="text-lg font-bold mb-2">Something went wrong</h1>
          <p className="text-sm text-gray-500 mb-6">Please reload to get the latest version.</p>
          <button
            className="px-4 py-2 bg-black text-white rounded text-sm"
            onClick={() => void hardReload()}
          >
            Reload
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
