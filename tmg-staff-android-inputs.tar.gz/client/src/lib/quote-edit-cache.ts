export async function refreshQuoteViews(client:any) {
  await client.invalidateQueries({predicate:(query:any)=>{
    const key=String(query.queryKey[0]||"");
    return key.startsWith("/api/quotes")||key.includes("/dashboard")||key.includes("/scheduling-review")||key==="scheduling-review";
  }});
}
