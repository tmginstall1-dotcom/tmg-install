/** Keep rapid taps one attempt even when an error response is immediate. */
export function createStaffSubmissionGate(clock=Date.now, cooldownMs=600) {
  let active=false, last=-Infinity;
  const remaining=()=>Math.max(0,cooldownMs-(clock()-last));
  return {
    busy:()=>active||remaining()>0,
    begin(){
      if(active||remaining()>0)return false;
      active=true;last=clock();return true;
    },
    remaining,
    end(){active=false;},
  };
}
