// Keep the deadline active through the response body, not just its headers.
// A mobile connection may receive headers successfully and then stop downloading.
export async function fetchJsonWithTimeout<T>(
  url: string,
  init: RequestInit = {},
  timeoutMs = 20_000,
): Promise<T> {
  const controller = new AbortController();
  const cancelled = new Promise<never>((_, reject) => {
    controller.signal.addEventListener("abort", () => {
      reject(controller.signal.reason ?? new Error("Request cancelled"));
    }, { once: true });
  });
  const forwardCancellation = () => controller.abort(init.signal?.reason);
  init.signal?.addEventListener("abort", forwardCancellation, { once: true });
  if (init.signal?.aborted) forwardCancellation();
  const timer = setTimeout(() => {
    controller.abort(new Error("The connection timed out. Please try again."));
  }, timeoutMs);

  try {
    const request = (async () => {
      const response = await fetch(url, { ...init, signal: controller.signal });
      if (!response.ok) {
        const error = new Error(`Request failed (${response.status})`) as Error & { status: number };
        error.status = response.status;
        throw error;
      }
      return await response.json() as T;
    })();
    return await Promise.race([request, cancelled]);
  } finally {
    clearTimeout(timer);
    init.signal?.removeEventListener("abort", forwardCancellation);
  }
}