import { trackEvent } from "@/hooks/use-tracker";
const GOOGLE_ADS_CLICK_SEND_TO = "AW-18012639714/ZcFhCJu1htAcEOKjjI1D";
const GOOGLE_ADS_FORM_SEND_TO = "AW-18012639714/zTxuCNC63IccEOKjjI1D";
const GOOGLE_ADS_CONVERSION_VALUE = 1.0;
const GOOGLE_ADS_CURRENCY = "SGD";

let initialized = false;
let lastLeadConversionAt = 0;
const sentFormIds = new Set<string>();

function conversionStores(): Storage[] {
  const stores: Storage[] = [];
  for (const name of ["localStorage", "sessionStorage"] as const) {
    try { if (window[name]) stores.push(window[name]); } catch { /* blocked storage */ }
  }
  return stores;
}

declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void;
  }
}

type LeadChannel = "whatsapp" | "phone" | "quote_form";

function isWhatsAppUrl(url: string): boolean {
  try {
    const parsed = new URL(url, window.location.href);
    const hostname = parsed.hostname.toLowerCase();
    return (
      parsed.protocol === "whatsapp:" ||
      hostname === "wa.me" ||
      hostname.endsWith(".wa.me") ||
      hostname === "api.whatsapp.com" ||
      hostname === "web.whatsapp.com"
    );
  } catch {
    return false;
  }
}

function isTelUrl(url: string): boolean {
  try {
    const parsed = new URL(url, window.location.href);
    return parsed.protocol === "tel:";
  } catch {
    return false;
  }
}

/* Returns the anchor + which lead channel it belongs to, or null when the
   clicked element is not a lead link (WhatsApp or phone). */
function findLeadAnchor(
  target: EventTarget | null,
): { anchor: HTMLAnchorElement; channel: LeadChannel } | null {
  if (!(target instanceof Element)) return null;
  const anchor = target.closest<HTMLAnchorElement>("a[href]");
  if (!anchor) return null;
  if (isWhatsAppUrl(anchor.href)) return { anchor, channel: "whatsapp" };
  if (isTelUrl(anchor.href)) return { anchor, channel: "phone" };
  return null;
}

export function reportLeadConversion(
  channel: LeadChannel,
  callback?: () => void,
  transactionId?: string,
  quoteTotal?: number | string | null,
): boolean {
  if (typeof window.gtag !== "function") return false;

  if (channel === "quote_form") {
    const id = transactionId?.trim();
    if (!id) return false; // Never count a button click or an unidentified lead.
    const key = `tmg_gads_form_fired:${id}`;
    const stores = conversionStores();
    const stored = stores.some(store => {
      try { return store.getItem(key) === GOOGLE_ADS_FORM_SEND_TO; } catch { return false; }
    });
    if (sentFormIds.has(id) || stored) return false;
    const total = quoteTotal == null || quoteTotal === "" ? NaN : Number(quoteTotal);
    window.gtag("event", "conversion", {
      send_to: GOOGLE_ADS_FORM_SEND_TO,
      value: Number.isFinite(total) && total >= 0 ? Math.round(total * 100) / 100 : GOOGLE_ADS_CONVERSION_VALUE,
      currency: GOOGLE_ADS_CURRENCY,
      lead_channel: channel,
      transaction_id: id,
      event_callback: callback,
    });
    sentFormIds.add(id);
    for (const store of stores) {
      try { store.setItem(key, GOOGLE_ADS_FORM_SEND_TO); } catch { /* Google also dedupes transaction_id */ }
    }
    return true;
  }

  // Contact clicks have their own action and throttle; they must never suppress
  // a successfully created quote, even when both happen in the same millisecond.
  const now = Date.now();
  if (now - lastLeadConversionAt < 800) {
    callback?.();
    return true;
  }
  lastLeadConversionAt = now;

  window.gtag("event", "conversion", {
    send_to: GOOGLE_ADS_CLICK_SEND_TO,
    value: GOOGLE_ADS_CONVERSION_VALUE,
    currency: GOOGLE_ADS_CURRENCY,
    lead_channel: channel,
    event_callback: callback,
    ...(transactionId ? { transaction_id: transactionId } : {}),
  });
  return true;
}

export function initGoogleAdsWhatsAppTracking(): void {
  if (initialized || typeof document === "undefined") return;
  initialized = true;

  document.addEventListener(
    "click",
    (event) => {
      const lead = findLeadAnchor(event.target);
      if (!lead) return;

      const { anchor, channel } = lead;
      // Internal contact intent is not a submitted/qualified lead. Do not count
      // staff links or private customer follow-up pages as acquisition clicks.
      if (/^\/(?:$|estimate(?:\/|$)|services\/|guides\/)/.test(window.location.pathname))
        trackEvent("contact_click", window.location.pathname, channel);
      const url = anchor.href;
      const opensNewContext =
        anchor.target === "_blank" ||
        event.ctrlKey ||
        event.metaKey ||
        event.shiftKey ||
        event.altKey ||
        event.button !== 0;

      /* tel: links must never be delayed or re-driven through
         window.location — the OS dialer intercepts the navigation natively
         and re-assigning location can cancel or double-trigger the dial
         prompt on some mobile browsers. Fire-and-forget is the correct
         pattern for tel:. */
      if (channel === "phone" || opensNewContext) {
        reportLeadConversion(channel);
        return;
      }

      // Same-tab WhatsApp navigation: give the conversion beacon a moment to
      // leave before we redirect, exactly as before.
      let opened = false;
      const openUrl = () => {
        if (opened) return;
        opened = true;
        window.location.href = url;
      };

      if (!reportLeadConversion(channel, openUrl)) return;

      event.preventDefault();
      window.setTimeout(openUrl, 700);
    },
    true,
  );
}
