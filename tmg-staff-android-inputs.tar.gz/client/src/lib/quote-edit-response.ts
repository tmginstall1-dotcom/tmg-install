/** Preserve an explicit HTTP rejection even when a proxy/browser cannot read JSON.
 * A successful response with an unreadable body is uncertain and must not be retried blindly.
 */
export async function readQuoteEditResponse(res: Response) {
  let data: any;
  try {
    data = JSON.parse(await res.text());
  } catch {
    if (!res.ok) {
      throw Object.assign(new Error(
        res.status === 409 || res.status === 422 || res.status === 400
          ? "The server rejected this change. Review the highlighted fields; your entered work is retained."
          : `The server could not complete this request (HTTP ${res.status}). Your entered work is retained.`
      ), { status: res.status });
    }
    throw new Error("The server response could not be read. Check the saved version and delivery status before sending again.");
  }
  if (!res.ok) {
    throw Object.assign(new Error(data?.message || "The server rejected this change."), {
      status: res.status,
      fieldErrors: data?.fieldErrors,
      requirements: data?.requirements,
      changedFields: data?.changedFields,
    });
  }
  if (!data || typeof data !== "object" || Array.isArray(data) || !data.id) {
    throw new Error("The server did not return the saved quotation. Check the saved version and delivery status before sending again.");
  }
  return data;
}
