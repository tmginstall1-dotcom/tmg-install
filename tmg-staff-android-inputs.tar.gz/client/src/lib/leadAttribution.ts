/**
 * Lead attribution capture + funnel analytics helpers.
 *
 * - captureLeadAttribution(): call on app boot. Reads gclid/gbraid/wbraid and
 *   utm_* params from the current URL, plus the landing page + referrer, and
 *   persists them in sessionStorage (localStorage fallback) so they survive
 *   the multi-step estimate flow and SPA navigation.
 * - getLeadAttribution(): returns whatever was captured (may be empty).
 * - trackFunnelEvent(): non-conversion dataLayer/gtag event for funnel
 *   analysis only. NEVER fires a Google Ads conversion (no send_to).
 */
import { estimateLandingContext } from "@shared/service-landings";

import { attributionSnapshot, ATTRIBUTION_VISIT_IDLE_MS, privateSafePath, campaignFields } from "@shared/enquiry-measurement";
const STORAGE_KEY = "tmg_lead_attribution";

export interface LeadAttribution {
  adMeasurementConsent?: "granted" | "denied" | "unknown";
  attributionCapturedAt?: string;
  attributionLastSeenAt?: string;
  attributionVisitId?: string;
  attributionRejectedReason?: "expired" | "age_unknown" | "invalid";
  gclid?: string;
  gbraid?: string;
  wbraid?: string;
  utmSource?: string;
  utmMedium?: string;
  utmCampaign?: string;
  utmTerm?: string;
  utmContent?: string;
  landingPage?: string;
  referrer?: string;
}

const PARAM_MAP: Array<[string, (typeof campaignFields)[number]]> = [
  ["gclid", "gclid"],
  ["gbraid", "gbraid"],
  ["wbraid", "wbraid"],
  ["utm_source", "utmSource"],
  ["utm_medium", "utmMedium"],
  ["utm_campaign", "utmCampaign"],
  ["utm_term", "utmTerm"],
  ["utm_content", "utmContent"],
];

function readStore(): LeadAttribution {
  for (const store of [safeStorage("session")]) {
    if (!store) continue;
    try {
      const raw = store.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw) as LeadAttribution;
    } catch { /* ignore */ }
  }
  return {};
}

function writeStore(data: LeadAttribution): void {
  const raw = JSON.stringify(data);
  for (const store of [safeStorage("session")]) {
    if (!store) continue;
    try { store.setItem(STORAGE_KEY, raw); } catch { /* ignore */ }
  }
}

function safeStorage(kind: "session" | "local"): Storage | null {
  try {
    if (typeof window === "undefined") return null;
    return kind === "session" ? window.sessionStorage : window.localStorage;
  } catch {
    return null;
  }
}

export function captureLeadAttribution(): void {
  if (typeof window === "undefined") return;
  try {
    let existing = readStore();
    const params = new URLSearchParams(window.location.search);
    let changed = false;
    const incoming: LeadAttribution = {};
    for (const [param, key] of PARAM_MAP) {
      const value = params.get(param);
      if (value && value.length <= (param.startsWith("utm_") ? 255 : 512)) incoming[key] = value;
    }
    const newCampaign = Object.keys(incoming).length > 0 && Object.entries(incoming).some(([key, value]) => existing[key as keyof LeadAttribution] !== value);
    const idle = Date.now() - Date.parse(existing.attributionLastSeenAt || "") > ATTRIBUTION_VISIT_IDLE_MS;
    // Replace the whole campaign, not one identifier mixed with another visit's UTM.
    // A reload of the same expired identifier must not reset its capture age.
    if (newCampaign || (!Object.keys(incoming).length && idle) || !existing.attributionCapturedAt) {
      existing = { ...incoming, attributionCapturedAt: new Date().toISOString(),
        attributionLastSeenAt: new Date().toISOString(),
        attributionVisitId: window.crypto?.randomUUID?.() || `visit-${Date.now()}` };
      changed = true;
    } else if (!idle) {
      existing.attributionLastSeenAt = new Date().toISOString();
      changed = true;
    }
    for (const [param, key] of PARAM_MAP) {
      const v = params.get(param);
      if (newCampaign && v && v.length <= (param.startsWith("utm_") ? 255 : 512) && existing[key] !== v) {
        existing[key] = v;
        changed = true;
      }
    }
    // Landing page + referrer: first-touch only (don't overwrite).
    if (!existing.landingPage) {
      existing.landingPage = estimateLandingContext(window.location.search).originatingServicePage ||
        window.location.pathname.slice(0, 512);
      changed = true;
    }
    if (!existing.referrer && document.referrer) {
      try {
        const ref = new URL(document.referrer);
        if (ref.hostname !== window.location.hostname) {
          existing.referrer = privateSafePath(document.referrer);
          changed = true;
        }
      } catch { /* ignore malformed referrer */ }
    }
    if (!existing.referrer && params.get("lead_referrer")) {
      try {
        const ref = new URL(params.get("lead_referrer")!);
        if ((ref.protocol === "https:" || ref.protocol === "http:") && ref.hostname !== window.location.hostname) {
          existing.referrer = privateSafePath(ref.href);
          changed = true;
        }
      } catch { /* ignore malformed forwarded referrer */ }
    }
    if (changed) writeStore(existing);
  } catch { /* attribution must never break the app */ }
}

export function getLeadAttribution(): LeadAttribution {
  const value = readStore();
  value.adMeasurementConsent = adMeasurementConsent();
  const status = attributionSnapshot(value as Record<string, unknown>).status;
  if (status === "captured" || status === "unattributed") {
    value.attributionLastSeenAt = new Date().toISOString();
    writeStore(value);
    return value;
  }
  // Retain capture time for an honest expired/unknown-age label, not active identifiers.
  const { attributionCapturedAt, attributionLastSeenAt, attributionVisitId } = value;
  return { attributionCapturedAt, attributionLastSeenAt, attributionVisitId, attributionRejectedReason: status, adMeasurementConsent:adMeasurementConsent() };
}

export function adMeasurementConsent(): "granted" | "denied" | "unknown" {
  if(typeof navigator!=="undefined" && ((navigator as any).globalPrivacyControl || navigator.doNotTrack==="1"))return "denied";
  try { const value=window.sessionStorage.getItem("tmg_ad_measurement_consent");return value==="granted"||value==="denied"?value:"unknown"; } catch{return "unknown";}
}
export function setAdMeasurementConsent(granted:boolean) {
  try{window.sessionStorage.setItem("tmg_ad_measurement_consent",granted?"granted":"denied");}catch{/* unknown stays ineligible */}
}

/**
 * Funnel-analysis event. Pushes to dataLayer (for GTM) and fires a plain gtag
 * event. This is NOT a conversion — no `send_to`, no value/currency — so it
 * can never pollute Google Ads conversion counts.
 */
export function trackFunnelEvent(
  eventName:
    | "estimate_intent_selected"
    | "estimate_step_completed"
    | "estimate_review_viewed"
    | "estimate_lead_prepared",
  params: Record<string, string | number | undefined> = {},
): void {
  if (typeof window === "undefined") return;
  const clean: Record<string, string | number> = {};
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== "") clean[k] = v;
  }
  try {
    const w = window as any;
    w.dataLayer = w.dataLayer || [];
    w.dataLayer.push({ event: eventName, ...clean });
  } catch { /* ignore */ }
  try {
    const gtag = (window as any).gtag;
    if (typeof gtag === "function") gtag("event", eventName, clean);
  } catch { /* ignore */ }
}
