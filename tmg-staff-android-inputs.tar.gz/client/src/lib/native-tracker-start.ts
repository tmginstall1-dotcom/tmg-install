export async function startNativeTracker(
  plugin:{addListener:(name:"location",callback:(value:any)=>void)=>Promise<{remove:()=>Promise<void>}>;startWatching:(options:{staffId:number})=>Promise<void>},
  staffId:number,callback:(value:any)=>void,
){
  const listener=await plugin.addListener("location",callback);
  try{await plugin.startWatching({staffId});return listener;}
  catch(error){await listener.remove().catch(()=>{});throw error;}
}
