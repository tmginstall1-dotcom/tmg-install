export class AttendanceAuthenticationError extends Error {
  constructor() { super("Sign in again to verify your attendance."); }
}

// Deliberately bypass the shared query function's legacy network-error -> null
// fallback: an unavailable response is never evidence that a shift ended.
export async function loadStaffAttendance(url: string, request: typeof fetch = fetch): Promise<any[]> {
  const response = await request(url, { credentials: "include" });
  if (response.status === 401 || response.status === 403) throw new AttendanceAuthenticationError();
  if (!response.ok) throw new Error("Attendance verification unavailable. Please retry.");
  const rows = await response.json();
  if (!Array.isArray(rows) || rows.some(row => !row || !Number.isInteger(row.id) ||
      !Number.isInteger(row.userId) || !Object.hasOwn(row, "clockOutAt") ||
      (row.clockOutAt !== null && (typeof row.clockOutAt !== "string" || !Number.isFinite(Date.parse(row.clockOutAt)))))) {
    throw new Error("Attendance response could not be verified. Please retry.");
  }
  return rows;
}

export function attendanceTrackingAction(query: {
  status: "pending" | "success" | "error";
  data?: any[];
  error?: unknown;
}, staffId: number): "start" | "stop" | "wait" {
  if (query.status === "error") return query.error instanceof AttendanceAuthenticationError ? "stop" : "wait";
  if (query.status !== "success" || !Array.isArray(query.data) ||
      query.data.some(row => row.userId !== staffId)) return "wait";
  return query.data.some(row => row.clockOutAt === null) ? "start" : "stop";
}
