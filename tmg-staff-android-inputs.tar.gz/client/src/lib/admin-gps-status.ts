export type ActiveGpsLocations = Record<string, { lat: string; lng: string; recordedAt: string }>;

export async function loadActiveGpsLocations(url: string, request: typeof fetch = fetch): Promise<ActiveGpsLocations> {
  const response = await request(url, { credentials: "include" });
  if (!response.ok) throw new Error(`Active GPS status unavailable (HTTP ${response.status}).`);
  const data = await response.json();
  if (!data || typeof data !== "object" || Array.isArray(data) ||
      Object.entries(data).some(([id, point]: [string, any]) =>
        !/^[1-9]\d*$/.test(id) || !point ||
        typeof point.lat !== "string" || !point.lat.trim() || !Number.isFinite(Number(point.lat)) || Math.abs(Number(point.lat)) > 90 ||
        typeof point.lng !== "string" || !point.lng.trim() || !Number.isFinite(Number(point.lng)) || Math.abs(Number(point.lng)) > 180 ||
        typeof point.recordedAt !== "string" || !Number.isFinite(Date.parse(point.recordedAt)))) {
    throw new Error("Active GPS status returned an invalid response.");
  }
  return data;
}

// React Query deliberately retains the last data on a refetch error. That data
// remains useful in its cache, but is not evidence of a currently active shift.
export function activeGpsSnapshot(query: {
  data?: ActiveGpsLocations;
  status: "pending" | "success" | "error";
}) {
  return {
    locations: query.status === "success" ? query.data ?? {} : {},
    unavailable: query.status === "error",
    pending: query.status === "pending",
  };
}
