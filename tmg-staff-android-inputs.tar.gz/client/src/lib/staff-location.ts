export function locationFailureMessage(code?:number) {
  if(code===1)return "Location permission was denied. Enable precise location for TMG in your device settings, then retry.";
  if(code===3)return "Location timed out: no fresh fix was received. Check location services and retry. Your photos, notes and signature are retained.";
  return "A fresh location is unavailable. Check device location services and retry. Your photos, notes and signature are retained.";
}

/** Each attempt requests fresh device evidence; never substitute a cached job fix. */
export function captureStaffLocation(geo:Pick<Geolocation,"getCurrentPosition">|undefined=typeof navigator==="undefined"?undefined:navigator.geolocation):
  Promise<{lat:number;lng:number}> {
  return new Promise((resolve,reject)=>{
    if(!geo)return reject(new Error(locationFailureMessage()));
    geo.getCurrentPosition(pos=>{
      const lat=pos.coords.latitude,lng=pos.coords.longitude;
      if(!Number.isFinite(lat)||!Number.isFinite(lng)||Math.abs(lat)>90||Math.abs(lng)>180 ||
        !Number.isFinite(pos.timestamp)||Date.now()-pos.timestamp>60_000||pos.timestamp>Date.now()+5000)
        return reject(new Error("The device returned an invalid or stale location. Retry location to obtain a fresh fix."));
      resolve({lat,lng});
    },error=>reject(new Error(locationFailureMessage(error.code))),
    {timeout:20000,enableHighAccuracy:true,maximumAge:0});
  });
}
