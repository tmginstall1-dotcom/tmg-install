import {format} from "date-fns";
import {singaporeDate} from "@shared/appointment";
export function singaporeCalendarDate(value:string|Date) {
  return new Date(`${singaporeDate(value)}T12:00:00`);
}
export function formatSingaporeDay(value:string|Date,pattern:string) {
  return format(singaporeCalendarDate(value),pattern);
}
export function isSingaporeCalendarToday(value:Date) {
  return format(value,"yyyy-MM-dd")===singaporeDate(new Date());
}
export function isSingaporeCalendarTomorrow(value:Date) {
  return format(value,"yyyy-MM-dd")===singaporeDate(new Date(Date.now()+86400000));
}
