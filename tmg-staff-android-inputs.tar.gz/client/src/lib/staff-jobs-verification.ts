export class StaffJobsAuthenticationError extends Error {
  constructor() { super("Sign in again to load your assigned jobs."); }
}
export const STAFF_JOBS_MEMORY_RETENTION_MS = 5 * 60_000;

/** Network failures are not an empty assignment list. Never persist this feed. */
export async function loadStaffJobs(url: string, signal?: AbortSignal, request: typeof fetch = fetch): Promise<any[]> {
  const response = await request(url, {credentials: "include", signal, cache: "no-store"});
  if (response.status === 401 || response.status === 403) throw new StaffJobsAuthenticationError();
  if (!response.ok) throw new Error("Assigned jobs could not be refreshed. Check your connection and retry.");
  const rows = await response.json();
  if (!Array.isArray(rows) || rows.some(row => !row || !Number.isInteger(row.id) || typeof row.status !== "string")) {
    throw new Error("Assigned jobs could not be verified. Please retry.");
  }
  return rows;
}

export function staffJobsView(query: {status: string; data?: any[]; error?: unknown}, authenticated: boolean) {
  const signIn = !authenticated || query.error instanceof StaffJobsAuthenticationError;
  return {
    signIn,
    jobs: signIn ? [] : query.data || [],
    stale: !signIn && query.status === "error" && Array.isArray(query.data),
    unavailable: !signIn && query.status === "error",
    loading: !signIn && query.status === "pending",
    verified: !signIn && query.status === "success",
  };
}
