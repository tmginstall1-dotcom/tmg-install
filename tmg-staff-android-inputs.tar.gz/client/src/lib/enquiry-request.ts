const key="tmg_pending_enquiry_request_v1";
const draftKey="tmg_pending_enquiry_draft_v1";
const draftLifetime=30*60*1000;
/** A short-lived, same-tab retry draft. Nothing is uploaded or stored on the
 * server by this helper; oversized photo payloads remain in the open form. */
export function savePendingEnquiryDraft(store:Pick<Storage,"setItem">|undefined,body:any,form:any,uncertain=false) {
  try {
    const text=JSON.stringify({at:Date.now(),body,form,uncertain});
    if(text.length>1_000_000)return false;
    store?.setItem(draftKey,text);
    return !!store;
  } catch {return false;}
}
export function readPendingEnquiryDraft(store:Pick<Storage,"getItem"|"removeItem">|undefined) {
  try {
    const raw=store?.getItem(draftKey);if(!raw)return null;
    const saved=JSON.parse(raw);
    if(!Number.isFinite(saved?.at)||saved.at>Date.now()||Date.now()-saved.at>draftLifetime||
      !Array.isArray(saved?.form?.services)||!Array.isArray(saved?.form?.items)||
      typeof saved?.body?.customer?.name!=="string") {
      store?.removeItem(draftKey);return null;
    }
    return saved as {body:any;form:any;at:number;uncertain?:boolean};
  } catch {try{store?.removeItem(draftKey);}catch{}return null;}
}
export function clearPendingEnquiryDraft(store:Pick<Storage,"removeItem">|undefined) {
  try{store?.removeItem(draftKey);}catch{}
}
/** Only an opaque UUID and payload hash persist; never customer text or fields. */
export async function enquiryRequestIdentity(body:unknown,store:Pick<Storage,"getItem"|"setItem">|undefined,
  previous:{id:string;fingerprint:string}|null,createId:()=>string) {
  const bytes=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(JSON.stringify(body)));
  const fingerprint=Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,"0")).join("");
  let saved=previous;
  if(!saved)try {saved=JSON.parse(store?.getItem(key)||"null");}catch{}
  const identity=saved?.fingerprint===fingerprint&&typeof saved.id==="string"
    ?saved:{id:createId(),fingerprint};
  try{store?.setItem(key,JSON.stringify(identity));}catch{}
  return identity;
}
export function clearEnquiryRequestIdentity(store:Pick<Storage,"removeItem">|undefined) {
  try{store?.removeItem(key);}catch{}
}

/** User-controlled scope only: calculated prices/route responses are not edits.
 * Also migrates the earlier incomplete retry snapshot from its exact body. */
export function recoverEnquiryForm(saved:{form:any;body:any}) {
  const f=saved.form||{},b=saved.body||{},m=b.leadMeta||{};
  const stops=Array.isArray(b.stops)?b.stops:[];
  const pickup=stops.find((s:any)=>s.kind==="pickup"),dropoff=stops.find((s:any)=>s.kind==="dropoff");
  const defaults:any={name:b.customer?.name||"",email:b.customer?.email||"",phone:b.customer?.phone||"",
    services:b.selectedServices||[],items:[],serviceAddress:b.serviceAddress||"",pickupAddress:b.pickupAddress||"",
    dropoffAddress:b.dropoffAddress||"",samePropertyMove:!!b.samePropertyMove,floors:[],accessDifficulty:b.accessDifficulty||"easy",
    slotDateStr:b.preferredDate||"",slotTime:b.preferredTimeWindow||"",leadNotes:m.leadNotes||"",promoCode:b.promoCode||"",
    promoDiscount:Number(b.promoDiscount)||0,promoStatus:b.promoCode&&Number(b.promoDiscount)>0?"restored":"idle",
    leadIntents:m.leadIntents||(m.leadIntent?[m.leadIntent]:[]),urgency:m.urgency||"",siteType:m.siteType||"",roomType:m.roomType||"",
    productLink:m.productLink||"",cartonCount:m.cartonCount?String(m.cartonCount):"",manualsAvailable:m.manualsAvailable||"",
    manualCategoryHint:m.manualCategoryHint||"",officeSeatCount:m.officeSeatCount?String(m.officeSeatCount):"",
    wallMounting:!!m.wallMounting,drillingRequired:!!m.drillingRequired,dismantleRequired:!!m.dismantleRequired,
    reinstallRequired:!!m.reinstallRequired,disposalRequired:!!m.disposalRequired,floorPlanAvailable:!!m.floorPlanAvailable,
    afterHoursRequired:!!m.afterHoursRequired,partitionsRequired:!!m.partitionsRequired,pedestalsRequired:!!m.pedestalsRequired,
    cableManagementRequired:!!m.cableManagementRequired,disposalMode:"dismantle_dispose",accessAnswered:false,stairsAnswer:null,
    extraStops:stops.filter((s:any)=>s!==pickup&&s!==dropoff).map((s:any)=>({...s,floor:s.floor||"",latLng:null})),
    primaryPickupStopId:pickup?.id||"recovered-pickup",primaryDropoffStopId:dropoff?.id||"recovered-dropoff",
    detectedPhotos:(b.detectedPhotos||[]).map((thumbnail:string)=>({thumbnail,names:[],count:0})),photoRouting:null};
  const restored=Object.fromEntries(Object.entries(defaults).map(([key,value])=>[key,f[key]===undefined?value:f[key]])) as any;
  restored.promoStatus=restored.promoCode&&Number(restored.promoDiscount)>0?"restored":"idle";
  // No selected promotion is null in a fresh form and "" after text-input
  // restoration. Neither represents a customer edit or a submitted promotion.
  restored.promoCode=restored.promoCode||"";
  return restored;
}
export function sameEnquiryForm(a:any,b:any) {
  const editable=(form:any)=>{
    const value=recoverEnquiryForm({form,body:{}});
    // Geocoding may finish after reload; it is not a deliberate scope edit.
    value.extraStops=value.extraStops.map((s:any)=>({id:s.id,kind:s.kind,address:s.address,floor:s.floor,hasLift:s.hasLift}));
    return value;
  };
  return JSON.stringify(editable(a))===JSON.stringify(editable(b));
}
export function retainEnquiryIdentity(status:number,previouslyUncertain:boolean) {
  return previouslyUncertain||status<400||status>=500||[408,409,425,429].includes(status);
}
