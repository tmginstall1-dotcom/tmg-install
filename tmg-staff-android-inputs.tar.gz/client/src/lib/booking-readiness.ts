import {singaporeDate} from "../../../shared/appointment";

export function bookingCapacityReason(note:string) {
  if(note.trim().length>=10)return note.trim();
  return "Crew availability reviewed against the recorded commitments."+
    (note.trim()?` Staff note: ${note.trim()}`:"");
}
export function schedulingDraftStorageKey(quoteId:number,identity:string|number|undefined) {
  return identity?`tmg:scheduling-review:${String(identity)}:${quoteId}`:null;
}
export function safeBookingError(error:unknown,fallback:string) {
  let message=error instanceof Error?error.message:"";
  if(!message||message.length>1200)return fallback;
  message=message.replace(/^\s*\d{3}\s*[:\-]\s*/,"").trim();
  if(/^[\[{]/.test(message)) {
    try {const parsed=JSON.parse(message);message=typeof parsed?.message==="string"?parsed.message:
      typeof parsed?.error==="string"?parsed.error:"";}
    catch{return fallback;}
  }
  if(!message||message.length>400||/[<>{}\[\]]/.test(message)||/failed query|sqlstate|insert into|update "\w+"|select .* from/i.test(message))
    return fallback;
  return message.replace(/\s+/g," ").trim()||fallback;
}
export function schedulingRequestMatches(quote:any,pending:{signature:string;key:string}|null|undefined,
  actorId:string|number|undefined,currentVersion:number) {
  if(!pending||actorId==null||!quote?.scheduledAt||!quote?.timeWindow)return false;
  let intake=quote.leadIntake,sent:any;
  try {if(typeof intake==="string")intake=JSON.parse(intake);sent=JSON.parse(pending.signature);}
  catch{return false;}
  const request=intake?.schedulingRequest;
  return ["booked","assigned","in_progress","at_pickup","in_transit","at_dropoff"].includes(quote.status)&&
    request?.requestKey===pending.key&&String(request?.actorId)===String(actorId)&&
    Number(request?.quoteVersion)===currentVersion&&Number(quote.version)===currentVersion&&
    Number(sent.expectedVersion)===currentVersion&&request.date===sent.date&&request.timeWindow===sent.timeWindow&&
    singaporeDate(quote.scheduledAt)===sent.date&&quote.timeWindow===sent.timeWindow;
}
