export function singaporeGpsDay(now = new Date()): string {
  return new Date(now.getTime() + 8 * 3600000).toISOString().slice(0, 10);
}

export function validGpsDay(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const time = new Date(value + "T00:00:00Z");
  return Number.isFinite(time.getTime()) && time.toISOString().slice(0, 10) === value;
}

export async function loadGpsHistory<T>(url: string, request: typeof fetch = fetch): Promise<T[]> {
  const response = await request(url, { credentials: "include" });
  if (!response.ok) throw new Error(`GPS history unavailable (HTTP ${response.status}). Please retry.`);
  const points = await response.json();
  if (!Array.isArray(points)) throw new Error("GPS history returned an invalid response. Please retry.");
  return points;
}

export function gpsElapsedSeconds(first: Date | null, last: Date | null, active: boolean, now: Date): number {
  return first ? Math.max(0, Math.floor(((active ? now : last ?? first).getTime() - first.getTime()) / 1000)) : 0;
}
