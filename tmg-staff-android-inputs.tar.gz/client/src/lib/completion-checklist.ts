// A selected tick is only an intention until the authorized server read agrees.
export function checklistLabels(value:unknown):string[] {
  const labels=(value as any)?.checkItems;
  if(!Array.isArray(labels)||labels.some(v=>typeof v!=="string"))
    throw new Error("The saved checklist could not be read. Retry loading it.");
  return [...new Set(labels)] as string[];
}
export function sameChecklist(a:string[],b:string[]) {
  return a.length===b.length&&a.every(label=>b.includes(label));
}
export function checklistReadiness(required:string[],saved:string[]|undefined,state:{
  loading:boolean;error:boolean;saving:boolean;unconfirmed:boolean;
}) {
  const missing=required.filter(label=>!saved?.includes(label));
  const ready=!!saved&&!state.loading&&!state.error&&!state.saving&&!state.unconfirmed&&!missing.length;
  return {ready,missing,savedCount:required.length-missing.length};
}
export async function persistChecklist(
  intended:string[],write:(labels:string[])=>Promise<unknown>,read:()=>Promise<unknown>,
) {
  let writeError:unknown;
  try {await write(intended);}catch(error){writeError=error;}
  // A response may be lost after the PATCH committed. Only an authoritative
  // read can recover it; never treat a failed request as an automatic success.
  const saved=checklistLabels(await read());
  if(!sameChecklist(saved,intended))
    throw writeError||new Error("The saved checklist differs from your selection. Review it and retry saving.");
  return saved;
}
