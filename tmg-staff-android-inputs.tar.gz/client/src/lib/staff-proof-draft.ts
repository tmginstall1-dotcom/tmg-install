// Device-local drafts are scoped to the signed-in account and job. They are not
// queued requests: a fresh authorized job response is required before restoring.
const DB="TMGStaffProofDrafts",STORE="drafts";
async function database():Promise<IDBDatabase>{
  return new Promise((resolve,reject)=>{
    const request=indexedDB.open(DB,1);
    request.onupgradeneeded=()=>request.result.createObjectStore(STORE);
    request.onsuccess=()=>resolve(request.result);
    request.onerror=()=>reject(new Error("Device draft storage is unavailable"));
  });
}
async function operation(mode:IDBTransactionMode,run:(store:IDBObjectStore)=>IDBRequest){
  const db=await database();
  try{return await new Promise<any>((resolve,reject)=>{
    const tx=db.transaction(STORE,mode),request=run(tx.objectStore(STORE));
    tx.oncomplete=()=>resolve(request.result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);
  });}finally{db.close();}
}
export const proofDraftKey=(userId:number,jobId:string|number)=>`${userId}:${jobId}`;
export const saveProofDraft=(key:string,value:any)=>operation("readwrite",s=>s.put({...value,savedAt:Date.now()},key));
export async function loadProofDraft(key:string){
  const value=await operation("readonly",s=>s.get(key));
  if(value&&Date.now()-value.savedAt>24*60*60*1000){await removeProofDraft(key);return null;}
  return value||null;
}
export const removeProofDraft=(key:string)=>operation("readwrite",s=>s.delete(key));
export const clearProofDrafts=()=>operation("readwrite",s=>s.clear());
export const proofDraftBelongsTo=(key:unknown,owner:number)=>
  Number.isSafeInteger(owner)&&owner>0&&typeof key==="string"&&key.startsWith(`${owner}:`);
// Session expiry is not explicit logout. Keep only the reauthenticated owner's
// drafts; never restore another account's photos/signature into a new login.
export async function retainProofDraftsForOwner(owner:number) {
  if(!Number.isSafeInteger(owner)||owner<=0)throw new Error("Authenticated draft owner required");
  const keys:IDBValidKey[]=await operation("readonly",s=>s.getAllKeys());
  for(const key of keys)if(!proofDraftBelongsTo(key,owner))
    await operation("readwrite",s=>s.delete(key));
}
