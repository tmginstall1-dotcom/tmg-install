export class QuoteDraftValidation extends Error {
  constructor(public fields: Record<string,string>) {
    super(Object.values(fields)[0] || "Check the highlighted fields.");
  }
}
const moneyFields=new Set(["transportFee","volumetricFee","goodwillDiscount","additionalTripCharge","afterOfficeSurchargeAmount"]);
const numberFields=new Set(["secondDayHours","secondDayCrewSize","cancellationNoticeHours"]);
// Appointment changes have a separate authenticated confirmation transaction.
const appointmentFields=new Set(["scheduledAt","timeWindow","status","timingMode","dismantleAt","dismantleTimeWindow","reinstallAt","reinstallTimeWindow"]);
const empty=(value:any)=>value==null||value===""?null:value;
/** Database-compatible placeholders; the workspace sends separate pending flags. */
export function pendingWorkspaceLine(item:any,saved?:any) {
  const quantityText=String(item.quantity??"").trim(),rateText=String(item.unitPrice??"").trim();
  if(quantityText&&(!/^\d+$/.test(quantityText)||Number(quantityText)<1))throw new Error("Enter a valid whole quantity.");
  if(rateText&&!/^\d+(\.\d{1,2})?$/.test(rateText))throw new Error("Enter a complete unit price.");
  const quantity=quantityText?Number(quantityText):Number.isInteger(Number(saved?.quantity))&&Number(saved?.quantity)>0?Number(saved.quantity):1;
  const rate=rateText?Number(rateText):Number.isFinite(Number(saved?.unitPrice))&&Number(saved?.unitPrice)>=0?Number(saved.unitPrice):0;
  return {...item,quantity,unitPrice:rate.toFixed(2),subtotal:(quantity*rate).toFixed(2)};
}
/** Keep typed values, but adopt the persisted line identities after replacement. */
export function quoteDraftLineKey(line:any,index:number) {
  return line.id!=null?`saved:${line.id}`:line._draftKey?`draft:${line._draftKey}`:`index:${index}`;
}
export function quoteDraftNotes(items:any[],sources:Record<string,string>={}) {
  return Object.fromEntries(items.map((line,index)=>[quoteDraftLineKey(line,index),
    sources[quoteDraftLineKey(line,index)]??sources[String(line.id)]??sources[String(index)]??""]));
}
export function removeQuoteLineFeedback(errors:Record<string,string>,requirements:Array<{field:string;message:string}>,removed:number) {
  const remap=(field:string)=>{
    if(/^rateReasons\./.test(field))return null;
    const match=field.match(/^items\.(\d+)(\..*)?$/);
    if(!match)return field;
    const index=Number(match[1]);
    return index===removed?null:`items.${index>removed?index-1:index}${match[2]||""}`;
  };
  return {
    errors:Object.fromEntries(Object.entries(errors).flatMap(([field,message])=>{const key=remap(field);return key?[[key,message]]:[];})),
    requirements:requirements.flatMap(requirement=>{const field=remap(requirement.field);return field?[{...requirement,field}]:[];}),
  };
}
export function reconcileWorkspaceDraft(draft:any,saved:any) {
  const rateReasons:Record<string,string>={};
  const items=draft.items.map((line:any,index:number)=>{
    const row=saved.items?.[index];if(!row)return line;
    const reason=draft.rateReasons?.[quoteDraftLineKey(line,index)]??draft.rateReasons?.[String(line.id??index)]??draft.rateReasons?.[String(index)]??"";
    const next={...line,id:row.id,quoteId:saved.id};
    rateReasons[quoteDraftLineKey(next,index)]=reason;
    return next;
  });
  return {...draft,items,rateReasons};
}
function same(key:string,a:any,b:any) {
  if(moneyFields.has(key)||numberFields.has(key))return Number(a||0)===Number(b||0)&&String(a)!==""&&String(b)!=="";
  return JSON.stringify(empty(a))===JSON.stringify(empty(b));
}
export function quoteDraftPayload(customer:any,quoteData:any,items:any[],initialCustomer:any,initialQuote:any) {
  const fields:Record<string,string>={};
  const customerUpdates=Object.fromEntries(Object.entries(customer).filter(([k,v])=>!same(k,v,initialCustomer[k])));
  const quoteUpdates:any=Object.fromEntries(Object.entries(quoteData).filter(([k,v])=>!appointmentFields.has(k)&&!same(k,v,initialQuote[k])));
  if("name" in customerUpdates&&!String(customerUpdates.name).trim())fields.name="Enter the customer name.";
  if("email" in customerUpdates&&customerUpdates.email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(customerUpdates.email).trim()))fields.email="Enter a valid email address, or leave it blank.";
  for(const [key,value] of Object.entries(quoteUpdates)) {
    if(moneyFields.has(key)&&!/^\d+(\.\d{1,2})?$/.test(String(value)))fields[key]=`${key}: enter a complete non-negative amount with at most 2 decimal places.`;
    if(numberFields.has(key)) {
      const n=Number(value),max=key==="secondDayCrewSize"?20:key==="cancellationNoticeHours"?720:Infinity;
      if(String(value).trim()===""||!Number.isFinite(n)||n<(key==="secondDayCrewSize"?1:0)||n>max||
        (key!=="secondDayHours"&&!Number.isInteger(n))||
        (key==="secondDayHours"&&!/^\d+(\.\d{1,2})?$/.test(String(value))))
        fields[key]=`Enter a valid ${key==="secondDayCrewSize"?"crew size (1–20)":key==="cancellationNoticeHours"?"notice period (0–720 hours)":"number of hours"}.`;
      else if(key!=="secondDayHours")quoteUpdates[key]=n;
    }
  }
  const normalized=items.map((item,i)=>{
    const description=String(item.detectedName||item.originalDescription||"");
    const quantity=Number(item.quantity),rate=String(item.unitPrice);
    if(!description.trim())fields[`items.${i}.detectedName`]=`Item ${i+1}: enter a description.`;
    if(!/^\d+$/.test(String(item.quantity).trim())||!Number.isInteger(quantity)||quantity<1)
      fields[`items.${i}.quantity`]=`Item ${i+1}: quantity must be a whole number of at least 1.`;
    if(!/^\d+(\.\d{1,2})?$/.test(rate))
      fields[`items.${i}.unitPrice`]=`Item ${i+1}: enter a complete unit price with at most 2 decimal places (zero is allowed).`;
    return {...item,quantity,unitPrice:rate,subtotal:(quantity*Number(rate)).toFixed(2)};
  });
  if(!items.length)fields.items="Add at least one item before saving this quotation.";
  if(Object.keys(fields).length)throw new QuoteDraftValidation(fields);
  return {customerUpdates,quoteUpdates,items:normalized};
}
export function changedSurcharge(current:any,initial:any) {
  return ["afterOfficeInvolved","afterOfficeSurchargeAmount","afterOfficeWaived","afterOfficeWaiverReason","additionalTripCharge"]
    .some(key=>!same(key,current[key],initial[key]))&&(current.afterOfficeInvolved||initial.timingMode==="split");
}
