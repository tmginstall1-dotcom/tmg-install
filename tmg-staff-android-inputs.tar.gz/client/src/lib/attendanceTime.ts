import {attendanceWorkTime,completedBreakMilliseconds} from "../../../shared/attendanceTime";

export function completedBreakMinutes(breaks: unknown): number {
  return Math.round(completedBreakMilliseconds(breaks)/60000);
}

// Format Singapore wall-clock components without the device's timezone/DST.
export function formatSingaporeAttendance(value: string | Date, pattern: string): string {
  const d=new Date(new Date(value).getTime()+8*3600000);
  if (!Number.isFinite(d.getTime())) return "Invalid time";
  const pad=(n:number)=>String(n).padStart(2,"0");
  const tokens:Record<string,string>={
    yyyy:String(d.getUTCFullYear()), MM:pad(d.getUTCMonth()+1),
    MMM:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][d.getUTCMonth()],
    EEE:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][d.getUTCDay()],
    dd:pad(d.getUTCDate()),d:String(d.getUTCDate()),HH:pad(d.getUTCHours()),
    h:String(d.getUTCHours()%12||12),mm:pad(d.getUTCMinutes()),a:d.getUTCHours()<12?"AM":"PM",
  };
  return pattern.replace(/yyyy|MMM|EEE|MM|dd|HH|mm|d|h|a/g,token=>tokens[token]);
}

export function closedShiftTime(log: {
  clockInAt: string | Date;
  clockOutAt?: string | Date | null;
  breaks?: unknown;
  deductionMinutes?: number | string | null;
}): { rawMinutes: number; breakMinutes: number; deductionMinutes: number; netMinutes: number } | null {
  if (!log.clockOutAt) return null;
  const start = new Date(log.clockInAt);
  const end = new Date(log.clockOutAt);
  if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime())) return null;
  const time=attendanceWorkTime(log);
  const rawMinutes = Math.floor(time.rawMs/60000);
  const breakMinutes = Math.round(time.breakMs/60000);
  const deduction = Number(log.deductionMinutes ?? 0);
  const deductionMinutes = Number.isFinite(deduction) ? Math.max(0, deduction) : 0;
  return {
    rawMinutes,
    breakMinutes,
    deductionMinutes,
    netMinutes: Math.floor(time.netMs/60000),
  };
}