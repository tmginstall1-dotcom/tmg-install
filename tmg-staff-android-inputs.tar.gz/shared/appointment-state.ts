/** Payment and date preferences are not appointment confirmation. */
export function hasConfirmedAppointment(q:any) {
  return ["booked","assigned","in_progress","at_pickup","in_transit","at_dropoff"].includes(q.status)
    && !!q.scheduledAt && !!q.timeWindow;
}
