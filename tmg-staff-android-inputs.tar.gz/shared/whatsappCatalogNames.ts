import {BLIND_CATALOG_ALIASES} from "./whatsappBlinds";
/** Governed synonyms only: no fuzzy similarity, colour-based or size-tier guesses. */
const normalize = (name:string) => name.normalize("NFKC").trim().toLowerCase()
  .replace(/×/g,"x").replace(/\s+/g," ");
const aliases:Record<string,string> = {
  ...BLIND_CATALOG_ALIASES,
  "book shelf":"Bookshelf",
  "freestanding bookshelf":"Bookshelf",
  "3 drawer chest":"Chest of Drawers (3-drawer)",
  "3-drawer chest":"Chest of Drawers (3-drawer)",
  "three drawer chest":"Chest of Drawers (3-drawer)",
  "3 drawer chest of drawers":"Chest of Drawers (3-drawer)",
  "chest of drawers (3 drawers)":"Chest of Drawers (3-drawer)",
  "5 drawer chest":"Chest of Drawers (5-drawer)",
  "5-drawer chest":"Chest of Drawers (5-drawer)",
  "five drawer chest":"Chest of Drawers (5-drawer)",
  "chest of drawers (5 drawers)":"Chest of Drawers (5-drawer)",
  "single office cubicle":"Office Cubicle Workstation (Single)",
  "single office cubicle workstation":"Office Cubicle Workstation (Single)",
  "office cubicle workstation (1500 x 1500)":"Office Cubicle Workstation (Single)",
  "office cubicle workstation (1500x1500)":"Office Cubicle Workstation (Single)",
  "office cubicle workstation (1500 x 1500 mm)":"Office Cubicle Workstation (Single)",
};
export function whatsappCatalogNameKeys(name:string):string[] {
  const key=normalize(name),canonical=aliases[key];
  return Array.from(new Set([key,...(canonical?[normalize(canonical)]:[])]));
}
export function sameWhatsappCatalogIdentity(requested:string,saved:string):boolean {
  return whatsappCatalogNameKeys(requested).includes(normalize(saved));
}
/** A generic construction may be refined by an independently verified photo.
 * This is not a pricing alias: generic drawers still cannot obtain a fixed rate.
 * The caller must establish a single current item and reject additional objects.
 */
export function verifiedPhotoRefinesGenericItem(requested:string,verified:string):boolean {
  const generic=normalize(requested),exact=normalize(verified);
  return ["chest of drawers","drawer chest","斗柜","抽屉柜"].includes(generic)&&
    /^chest of drawers \((?:3|5)-drawer\)$/.test(exact);
}
/** Reverse governed spelling forms for reading explicit item-bound counts only. */
export function whatsappCatalogSpellingAliases(name:string):string[] {
  const key=normalize(name),canonical=normalize(aliases[key]||name);
  return Array.from(new Set([key,canonical,...Object.entries(aliases)
    .filter(([,target])=>normalize(target)===canonical).map(([alias])=>alias)]));
}
