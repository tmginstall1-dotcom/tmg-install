// A generic drawer family is not enough to choose a model-specific labour
// rate. Discovery is allowed, but customer quoting needs specifications.
export function furnitureNeedsSpecificationReview(name: string): boolean {
  // Drawer count/size suffixes still describe a generic family, not an
  // approved specific model (e.g. IKEA MALM remains a distinct catalogue name).
  return /^(?:chest\s+of\s+drawers?|drawer\s+(?:unit|cabinet)|drawers?)\b/i.test(name.trim());
}
import { z } from "zod";

export const FURNITURE_CATEGORY_OPTIONS = [
  { value: "office_systems", label: "Office systems & fit-out" },
  { value: "workstations", label: "Workstations & cubicles" },
  { value: "desks_tables", label: "Desks & tables" },
  { value: "storage_wardrobes", label: "Storage & wardrobes" },
  { value: "beds_bedroom", label: "Beds & bedroom furniture" },
  { value: "seating", label: "Seating & sofas" },
  { value: "shelving", label: "Shelves & racking" },
  { value: "wall_mounted", label: "Wall-mounted furniture" },
  { value: "fixtures_specialty", label: "Fixtures & specialty items" },
  { value: "flat_pack", label: "IKEA, Taobao & flat-pack" },
  { value: "residential_furniture", label: "General home furniture" },
  { value: "commercial_furniture", label: "Commercial furniture" },
  { value: "relocation_reinstall", label: "Relocation & reinstallation" },
  { value: "unknown", label: "Furniture type to confirm" },
] as const;

export const FURNITURE_SEARCH_SYNONYMS: Record<string, string[]> = {
  cubicle: ["cubicles", "workstation", "workstations", "office partition", "panel partition", "modular workstation"],
  cubicles: ["cubicle", "workstation", "workstations", "office partition", "panel partition", "modular workstation"],
  workstation: ["workstations", "cubicle", "cubicles", "office partition", "panel partition", "modular workstation"],
  workstations: ["workstation", "cubicle", "cubicles", "office partition", "panel partition", "modular workstation"],
  partition: ["partitions", "office partition", "panel partition", "cubicle", "workstation"],
  partitions: ["partition", "office partition", "panel partition", "cubicle", "workstation"],
  taobao: ["taobao furniture", "flat pack", "flat-pack", "shopee", "lazada"],
  "taobao furniture": ["taobao", "flat pack", "flat-pack"],
  "flat pack": ["flat-pack", "taobao", "taobao furniture", "shopee", "lazada"],
  "flat-pack": ["flat pack", "taobao", "taobao furniture", "shopee", "lazada"],
  shopee: ["flat pack", "flat-pack", "taobao", "lazada"],
  lazada: ["flat pack", "flat-pack", "taobao", "shopee"],
  wardrobe: ["closet", "clothes cabinet", "sliding wardrobe", "hinged wardrobe", "pax"],
  "sliding wardrobe": ["sliding door wardrobe", "sliding-door wardrobe", "closet"],
  cabinet: ["cupboard", "storage cabinet", "sideboard", "credenza"],
  "kitchen cabinet": ["kitchen cupboard", "base cabinet", "wall cabinet", "pantry cabinet"],
  "shoe cabinet": ["shoe cupboard", "shoe storage", "shoe rack"],
  "tv console": ["media console", "entertainment console", "television console"],
  "bed frame": ["bedframe", "platform bed", "divan bed"],
  "storage bed": ["hydraulic bed", "drawer bed", "lift-up bed"],
  "bunk bed": ["double deck bed", "loft bed", "triple bunk"],
  table: ["dining table", "meeting table", "conference table", "coffee table"],
  "office desk": ["work desk", "computer table", "study desk"],
  pedestal: ["mobile pedestal", "drawer pedestal", "under desk drawers"],
  "filing cabinet": ["file cabinet", "document cabinet", "office filing"],
  shelf: ["shelving", "bookcase", "rack", "racking", "bedroom shelves", "bedroom shelf"],
  sofa: ["couch", "settee", "sectional"],
  chair: ["seat", "office chair", "dining chair", "armchair"],
  "bedside table": ["nightstand", "night stand", "bedside cabinet"],
  "chest of drawers": ["dresser", "drawers chest", "drawer cabinet"],
  "dressing table": ["vanity", "vanity table"],
  bookcase: ["bookshelf", "book shelf", "book shelves"],
  "children furniture": ["kids furniture", "children's furniture", "childrens furniture", "baby furniture", "nursery"],
  cot: ["crib", "baby cot"],
  "outdoor furniture": ["patio furniture", "garden furniture"],
  "storage rack": ["warehouse rack", "industrial shelving", "racking"],
  trolley: ["cart", "rolling cabinet"],
  "wall mounted": ["wall mount", "floating cabinet", "wall hung"],
  "folding bed": ["murphy bed", "wall bed"],
  mirror: ["round mirror", "circular mirror"],
};

function normalizeSearchText(value: string): string {
  return value.toLowerCase().replace(/[-_/]+/g, " ").replace(/\s+/g, " ").trim();
}

export function furnitureCatalogSearchMatches(
  query: string,
  fields: Array<string | null | undefined>,
): boolean {
  const normalizedQuery = normalizeSearchText(query);
  if (!normalizedQuery) return true;
  const content = normalizeSearchText(fields.filter(Boolean).join(" "));
  const queryWords = normalizedQuery.split(" ").filter(Boolean);
  // Discovery only: aliases never select a price or certify a catalogue match.
  // Make the relationships bidirectional (e.g. couch → sofa as well as sofa → couch).
  const aliases = Object.entries(FURNITURE_SEARCH_SYNONYMS)
    .filter(([term,variants])=>[term,...variants].some(value=>normalizeSearchText(value)===normalizedQuery))
    .flatMap(([term,variants])=>[term,...variants]);
  const singular=(word:string)=>word.endsWith("ies")?`${word.slice(0,-3)}y`:word.endsWith("s")&&!word.endsWith("ss")?word.slice(0,-1):word;
  return (
    queryWords.every(word => content.includes(word)) ||
    queryWords.every(word => content.includes(singular(word))) ||
    aliases.some(alias => {
      const normalizedAlias = normalizeSearchText(alias);
      return content.includes(normalizedAlias) ||
        normalizedAlias.split(" ").every(word => content.includes(word));
    })
  );
}

export const furnitureCategorySchema = z.enum(
  FURNITURE_CATEGORY_OPTIONS.map(option => option.value) as [
    (typeof FURNITURE_CATEGORY_OPTIONS)[number]["value"],
    ...(typeof FURNITURE_CATEGORY_OPTIONS)[number]["value"][],
  ],
);
export type FurnitureCategory = z.infer<typeof furnitureCategorySchema>;

export const leadPrioritySchema = z.enum(["high", "medium", "low"]);
export type LeadPriority = z.infer<typeof leadPrioritySchema>;

export const salesPathSchema = z.enum([
  "office_project",
  "dismantling_specialist",
  "installation_quote",
  "relocation_reinstall",
  "relocation_only",
  "manual_review",
]);
export type RecommendedSalesPath = z.infer<typeof salesPathSchema>;

export const serviceIntentSchema = z.enum([
  "office_installation",
  "dismantling",
  "flatpack_installation",
  "residential_installation",
  "relocation_reinstall",
  "relocation_only",
  "disposal",
  "manual_review",
]);
export type FurnitureServiceIntent = z.infer<typeof serviceIntentSchema>;

export interface FurnitureLeadInput {
  itemText?: string | string[];
  filename?: string;
  customerNotes?: string;
  selectedJobType?: string;
  selectedServices?: string[];
  roomType?: string;
  siteType?: string;
  sellerProductLink?: string;
  manualCategoryHint?: string;
  officeSeatCount?: number;
}

export interface FurnitureLeadRouting {
  category: FurnitureCategory;
  categoryLabel: string;
  serviceIntent: FurnitureServiceIntent;
  priority: LeadPriority;
  recommendedSalesPath: RecommendedSalesPath;
  confidence: "high" | "medium" | "low";
  requiresReview: boolean;
  signals: string[];
}

const CATEGORY_PATTERNS: Array<{
  category: FurnitureCategory;
  pattern: RegExp;
  signal: string;
}> = [
  { category: "workstations", pattern: /\b(workstation|cubicle|bench desk|desk cluster|office partition|partition panel|panel partition|screen panel|desk system)\b/i, signal: "workstation/cubicle" },
  { category: "office_systems", pattern: /\b(office fit-?out|meeting pod|phone booth|reception counter|conference room|boardroom|office system|floor plan)\b/i, signal: "office system" },
  { category: "flat_pack", pattern: /\b(ikea|taobao|shopee|lazada|castlery|flat[ -]?pack|cartons?|assembly manual)\b/i, signal: "flat-pack retailer" },
  { category: "storage_wardrobes", pattern: /\b(wardrobe|closet|pax|sliding[- ]door|clothes cabinet|kitchen cabinet|pantry cabinet|shoe cabinet|shoe cupboard|tv console|media console|filing cabinet|file cabinet|cabinet|cupboard|credenza|pedestal|locker|sideboard|drawer|dresser|shoe rack|storage)\b/i, signal: "storage/wardrobe" },
  { category: "beds_bedroom", pattern: /\b(bed ?frame|storage bed|hydraulic bed|platform bed|bed|bunk|double deck|loft|headboard|nightstand|bedside|cot|crib|tatami|murphy)\b/i, signal: "bedroom furniture" },
  { category: "seating", pattern: /\b(sofa|couch|chair|stool|bench|recliner|armchair|chaise|seating)\b/i, signal: "seating" },
  { category: "shelving", pattern: /\b(shelf|shelving|bookcase|bookshelf|storage rack|boltless rack|rack|racking|kallax|billy|ivar)\b/i, signal: "shelving/racking" },
  { category: "wall_mounted", pattern: /\b(wall mount|wall-mounted|floating shelf|curtain track|curtain rod|mirror installation|pegboard|drilling)\b/i, signal: "wall mounting" },
  { category: "fixtures_specialty", pattern: /\b(gym|treadmill|exercise bike|pool table|piano|vanity|bathroom fixture|kitchen island|pod|booth)\b/i, signal: "specialty fixture" },
  { category: "desks_tables", pattern: /\b(office desk|computer table|study desk|desk|dining table|conference table|meeting table|coffee table|console table|table|sit-stand)\b/i, signal: "desk/table" },
  { category: "commercial_furniture", pattern: /\b(retail|warehouse|school|clinic|restaurant|commercial|auditorium)\b/i, signal: "commercial site" },
  { category: "residential_furniture", pattern: /\b(home|bedroom|living room|dining room|hdb|condo|residential)\b/i, signal: "residential site" },
];

function normalizeText(value: string | string[] | undefined): string {
  return Array.isArray(value) ? value.join(" ") : (value || "");
}

export function furnitureCategoryLabel(value: string | null | undefined): string {
  return FURNITURE_CATEGORY_OPTIONS.find(option => option.value === value)?.label ?? "";
}

export function classifyFurnitureLead(input: FurnitureLeadInput): FurnitureLeadRouting {
  const services = new Set((input.selectedServices || []).map(service => service.toLowerCase()));
  const jobType = (input.selectedJobType || "").toLowerCase();
  const context = [
    normalizeText(input.itemText),
    input.filename,
    input.customerNotes,
    input.selectedJobType,
    input.roomType,
    input.siteType,
    input.sellerProductLink,
  ].filter(Boolean).join(" ");

  const manualHint = furnitureCategorySchema.safeParse(input.manualCategoryHint);
  let category: FurnitureCategory = manualHint.success ? manualHint.data : "unknown";
  const signals: string[] = manualHint.success ? ["manual category hint"] : [];

  if (!manualHint.success) {
    const match = CATEGORY_PATTERNS.find(rule => rule.pattern.test(context));
    if (match) {
      category = match.category;
      signals.push(match.signal);
    }
  }

  const officeSignal =
    category === "office_systems" ||
    category === "workstations" ||
    input.siteType === "office" ||
    jobType.includes("office") ||
    (input.officeSeatCount || 0) > 0;
  const dismantleSignal =
    services.has("dismantle") ||
    services.has("dismantle_install") ||
    services.has("dismantle_dispose") ||
    jobType.includes("dismantl");
  const reinstallSignal =
    services.has("dismantle_install") ||
    jobType.includes("reinstall") ||
    jobType === "relocation_dr";
  const relocationSignal = services.has("relocate") || jobType.includes("relocation");
  const disposalSignal =
    services.has("dispose") ||
    services.has("dismantle_dispose") ||
    jobType.includes("disposal");
  const flatpackSignal =
    category === "flat_pack" ||
    jobType.includes("taobao") ||
    /\b(ikea|taobao|flat[ -]?pack)\b/i.test(context);

  if (officeSignal) signals.push("office lead");
  if (dismantleSignal) signals.push("dismantling requested");
  if (relocationSignal) signals.push("relocation requested");
  if (reinstallSignal) signals.push("reinstallation requested");

  let serviceIntent: FurnitureServiceIntent;
  let priority: LeadPriority;
  let recommendedSalesPath: RecommendedSalesPath;

  if (disposalSignal) {
    // The disposal wizard uses the combined "dismantle_dispose" service.
    // Disposal must therefore win over the generic dismantling signal.
    serviceIntent = "disposal";
    priority = "medium";
    recommendedSalesPath = "manual_review";
  } else if (officeSignal) {
    serviceIntent = "office_installation";
    priority = "high";
    recommendedSalesPath = "office_project";
  } else if (dismantleSignal && !relocationSignal) {
    serviceIntent = "dismantling";
    priority = "high";
    recommendedSalesPath = "dismantling_specialist";
  } else if (relocationSignal && (reinstallSignal || dismantleSignal)) {
    serviceIntent = "relocation_reinstall";
    priority = "high";
    recommendedSalesPath = "relocation_reinstall";
    if (category === "unknown") category = "relocation_reinstall";
  } else if (relocationSignal) {
    serviceIntent = "relocation_only";
    priority = "low";
    recommendedSalesPath = "relocation_only";
  } else if (flatpackSignal) {
    serviceIntent = "flatpack_installation";
    priority = "medium";
    recommendedSalesPath = "installation_quote";
    if (category === "unknown") category = "flat_pack";
  } else if (services.has("install") || jobType.includes("install")) {
    serviceIntent = "residential_installation";
    priority = "medium";
    recommendedSalesPath = "installation_quote";
  } else {
    serviceIntent = "manual_review";
    priority = "medium";
    recommendedSalesPath = "manual_review";
  }

  const hasSpecificItemSignal = category !== "unknown" && category !== "residential_furniture";
  const confidence: FurnitureLeadRouting["confidence"] = manualHint.success
    ? "high"
    : hasSpecificItemSignal
      ? "medium"
      : "low";
  const requiresReview =
    category === "unknown" ||
    serviceIntent === "manual_review" ||
    confidence === "low";

  return {
    category,
    categoryLabel: furnitureCategoryLabel(category),
    serviceIntent,
    priority,
    recommendedSalesPath,
    confidence,
    requiresReview,
    signals: Array.from(new Set(signals)),
  };
}