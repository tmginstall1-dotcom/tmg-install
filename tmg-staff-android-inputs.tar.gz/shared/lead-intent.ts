import { z } from "zod";
import {
  furnitureCategorySchema,
  leadPrioritySchema,
  salesPathSchema,
  serviceIntentSchema,
} from "./furnitureTaxonomy";

/**
 * Lead intent / lead-quality metadata shared between the estimate wizard
 * (client), the /api/quotes/wizard endpoint, and the WhatsApp handoff.
 * Keep client + server in lockstep by importing from this file only.
 */

export const LEAD_INTENT_OPTIONS = [
  { value: "office_furniture_install", label: "Office furniture installation", services: ["install"] },
  { value: "office_workstation_install", label: "Office workstation installation", services: ["install"] },
  { value: "furniture_dismantling", label: "Furniture dismantling", services: ["dismantle"] },
  { value: "taobao_flatpack_install", label: "Taobao / flat-pack installation", services: ["install"] },
  { value: "residential_install", label: "Residential furniture installation", services: ["install"] },
  { value: "relocation_dr", label: "Relocation with dismantle & reinstall", services: ["relocate"] },
  { value: "disposal_removal", label: "Disposal / removal", services: ["dismantle_dispose"] },
] as const;

export type LeadIntentValue = (typeof LEAD_INTENT_OPTIONS)[number]["value"];

export const URGENCY_OPTIONS = [
  { value: "same_day", label: "Same day" },
  { value: "1_2_days", label: "1–2 days" },
  { value: "this_week", label: "This week" },
  { value: "flexible", label: "Flexible" },
] as const;

export const ITEM_COUNT_OPTIONS = [
  { value: "1", label: "1 item" },
  { value: "2_3", label: "2–3 items" },
  { value: "4_6", label: "4–6 items" },
  { value: "7_plus", label: "7+ items" },
  { value: "office_project", label: "Office project" },
] as const;

export const SITE_TYPE_OPTIONS = [
  { value: "home", label: "Home" },
  { value: "office", label: "Office" },
  { value: "retail", label: "Retail" },
  { value: "warehouse", label: "Warehouse" },
  { value: "other", label: "Other" },
] as const;

export const ROOM_TYPE_OPTIONS = [
  { value: "bedroom", label: "Bedroom" },
  { value: "living_dining", label: "Living / dining" },
  { value: "study", label: "Study" },
  { value: "office_floor", label: "Office floor" },
  { value: "meeting_room", label: "Meeting room" },
  { value: "retail_showroom", label: "Retail / showroom" },
  { value: "warehouse", label: "Warehouse" },
  { value: "other", label: "Other" },
] as const;

export const MANUALS_OPTIONS = [
  { value: "yes", label: "Manuals available" },
  { value: "no", label: "No manuals" },
  { value: "unsure", label: "Not sure" },
] as const;

export function leadIntentLabel(value: string | null | undefined): string {
  if (!value) return "";
  return LEAD_INTENT_OPTIONS.find(o => o.value === value)?.label ?? "";
}

export function leadIntentLabels(values: string[] | null | undefined): string {
  return (values || []).map(leadIntentLabel).filter(Boolean).join(", ");
}

/** Keep legacy single-intent consumers useful without letting click order
 * demote an office/workstation or dismantling lead behind a Taobao label. */
export function primaryLeadIntent(values: string[] | null | undefined): string {
  const selected = values || [];
  const priority = [
    "office_workstation_install",
    "office_furniture_install",
    "furniture_dismantling",
    "taobao_flatpack_install",
    "residential_install",
    "relocation_dr",
    "disposal_removal",
  ];
  return priority.find(value => selected.includes(value)) || selected[0] || "";
}

export function urgencyLabel(value: string | null | undefined): string {
  if (!value) return "";
  return URGENCY_OPTIONS.find(o => o.value === value)?.label ?? "";
}

export function itemCountLabel(value: string | null | undefined): string {
  if (!value) return "";
  return ITEM_COUNT_OPTIONS.find(o => o.value === value)?.label ?? "";
}

export function siteTypeLabel(value: string | null | undefined): string {
  if (!value) return "";
  return SITE_TYPE_OPTIONS.find(o => o.value === value)?.label ?? "";
}

/** Optional lead-quality metadata posted with a wizard quote submission. */
export const leadMetaSchema = z.object({
  leadIntent: z.string().max(60).optional(),
  leadIntents: z.array(z.string().max(60)).max(LEAD_INTENT_OPTIONS.length).optional(),
  urgency: z.string().max(30).optional(),
  itemCountRange: z.string().max(30).optional(),
  siteType: z.string().max(30).optional(),
  leadNotes: z.string().max(600).optional(),
  roomType: z.string().max(40).optional(),
  productLink: z.string().max(1000).optional(),
  cartonCount: z.number().int().min(0).max(10000).optional(),
  manualsAvailable: z.enum(["yes", "no", "unsure"]).optional(),
  wallMounting: z.boolean().optional(),
  drillingRequired: z.boolean().optional(),
  dismantleRequired: z.boolean().optional(),
  reinstallRequired: z.boolean().optional(),
  disposalRequired: z.boolean().optional(),
  officeSeatCount: z.number().int().min(0).max(10000).optional(),
  floorPlanAvailable: z.boolean().optional(),
  afterHoursRequired: z.boolean().optional(),
  partitionsRequired: z.boolean().optional(),
  pedestalsRequired: z.boolean().optional(),
  cableManagementRequired: z.boolean().optional(),
  manualCategoryHint: furnitureCategorySchema.optional(),
  photoDetectedCategory: furnitureCategorySchema.optional(),
  detectedCategory: furnitureCategorySchema.optional(),
  serviceIntent: serviceIntentSchema.optional(),
  jobPriority: leadPrioritySchema.optional(),
  recommendedSalesPath: salesPathSchema.optional(),
  detectionConfidence: z.enum(["high", "medium", "low"]).optional(),
  detectionNeedsReview: z.boolean().optional(),
  landingPage: z.string().max(512).optional(),
  originatingServicePage: z.string().max(512).optional(),
  referrer: z.string().max(512).optional(),
  gclid: z.string().max(512).optional(),
  attributionCapturedAt: z.string().max(40).optional(),
  adMeasurementConsent: z.enum(["granted","denied","unknown"]).optional(),
  attributionLastSeenAt: z.string().max(40).optional(),
  attributionVisitId: z.string().max(100).optional(),
  attributionRejectedReason: z.enum(["expired", "age_unknown", "invalid"]).optional(),
  gbraid: z.string().max(512).optional(),
  wbraid: z.string().max(512).optional(),
  utmSource: z.string().max(255).optional(),
  utmMedium: z.string().max(255).optional(),
  utmCampaign: z.string().max(255).optional(),
  utmTerm: z.string().max(255).optional(),
  utmContent: z.string().max(255).optional(),
});

export type LeadMeta = z.infer<typeof leadMetaSchema>;

/**
 * Human-readable internal summary of the lead metadata — appended to the
 * quote's internal notes so admins (and Ads analysis exports) can see lead
 * quality context. Returns "" when there is nothing worth recording.
 */
export function buildLeadMetaSummary(meta: LeadMeta | null | undefined): string {
  if (!meta) return "";
  const lines: string[] = [];
  const intents = leadIntentLabels(meta.leadIntents);
  const intent = intents || leadIntentLabel(meta.leadIntent);
  if (intent) lines.push(`${meta.leadIntents && meta.leadIntents.length > 1 ? "Lead intents" : "Lead intent"}: ${intent}`);
  const urg = urgencyLabel(meta.urgency);
  if (urg) lines.push(`Urgency: ${urg}`);
  const cnt = itemCountLabel(meta.itemCountRange);
  if (cnt) lines.push(`Item count: ${cnt}`);
  const site = siteTypeLabel(meta.siteType);
  if (site) lines.push(`Site type: ${site}`);
  if (meta.leadNotes?.trim()) lines.push(`Customer notes: ${meta.leadNotes.trim().slice(0, 600)}`);
  if (meta.roomType) lines.push(`Room / work area: ${meta.roomType}`);
  if (meta.productLink) lines.push(`Seller / product link: ${meta.productLink}`);
  if (meta.cartonCount != null) lines.push(`Cartons: ${meta.cartonCount}`);
  if (meta.manualsAvailable) lines.push(`Assembly manuals: ${meta.manualsAvailable}`);
  const scope: string[] = [];
  if (meta.wallMounting) scope.push("wall mounting");
  if (meta.drillingRequired) scope.push("drilling");
  if (meta.dismantleRequired) scope.push("dismantle");
  if (meta.reinstallRequired) scope.push("reinstall");
  if (meta.disposalRequired) scope.push("disposal");
  if (scope.length) lines.push(`Requested scope: ${scope.join(", ")}`);
  const office: string[] = [];
  if (meta.officeSeatCount != null) office.push(`${meta.officeSeatCount} seats`);
  if (meta.floorPlanAvailable) office.push("floor plan available");
  if (meta.afterHoursRequired) office.push("after-hours work");
  if (meta.partitionsRequired) office.push("partitions");
  if (meta.pedestalsRequired) office.push("pedestals");
  if (meta.cableManagementRequired) office.push("cable management");
  if (office.length) lines.push(`Office scope: ${office.join(", ")}`);
  if (meta.detectedCategory) lines.push(`Lead category: ${meta.detectedCategory}`);
  if (meta.serviceIntent) lines.push(`Service intent: ${meta.serviceIntent}`);
  if (meta.jobPriority) lines.push(`Priority: ${meta.jobPriority}`);
  if (meta.recommendedSalesPath) lines.push(`Sales path: ${meta.recommendedSalesPath}`);
  if (meta.detectionConfidence) {
    lines.push(`Detection confidence: ${meta.detectionConfidence}${meta.detectionNeedsReview ? " (review required)" : ""}`);
  }
  const attribution: string[] = [];
  if (meta.utmSource) attribution.push(`source=${meta.utmSource}`);
  if (meta.utmMedium) attribution.push(`medium=${meta.utmMedium}`);
  if (meta.utmCampaign) attribution.push(`campaign=${meta.utmCampaign}`);
  if (meta.utmTerm) attribution.push(`term=${meta.utmTerm}`);
  if (meta.utmContent) attribution.push(`content=${meta.utmContent}`);
  if (meta.gclid) attribution.push(`gclid=${meta.gclid}`);
  if (meta.originatingServicePage) attribution.push(`service page=${meta.originatingServicePage}`);
  if (meta.gbraid) attribution.push(`gbraid=${meta.gbraid}`);
  if (meta.wbraid) attribution.push(`wbraid=${meta.wbraid}`);
  if (attribution.length) lines.push(`Attribution: ${attribution.join(", ")}`);
  if (meta.landingPage) lines.push(`Landing page: ${meta.landingPage}`);
  if (meta.referrer) lines.push(`Referrer: ${meta.referrer}`);
  if (!lines.length) return "";
  return `— Lead details (from estimate wizard) —\n${lines.join("\n")}`;
}
