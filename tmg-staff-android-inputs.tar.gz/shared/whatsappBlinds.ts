import type {FirstFacts} from "./whatsappFirst";

/** Specific construction synonyms only. "Korean blinds" is not a construction. */
export const BLIND_CATALOG_ALIASES:Record<string,string>={};
for(const [canonical,names] of [
  ["Roller Blind (per window)",["roller blind","roller blinds","卷帘","卷簾"]],
  ["Venetian Blind (per window)",["venetian blind","venetian blinds","百叶帘","百葉簾"]],
  ["Roman Blind (per window)",["roman blind","roman blinds","罗马帘","羅馬簾"]],
  ["Vertical Blind (per window)",["vertical blind","vertical blinds","垂直帘"]],
  ["Day and Night or Zebra Blind (per window)",["zebra","zebra blind","zebra blinds",
    "day and night blind","day and night blinds","day/night blinds","day & night blinds",
    "combi blind","combi blinds","korean zebra blinds","korean combi blinds","斑马帘","斑馬簾","日夜帘","日夜簾"]],
] as const)for(const name of names)BLIND_CATALOG_ALIASES[name]=canonical;

const normalized=(name:string)=>name.normalize("NFKC").trim().toLowerCase().replace(/\s+/g," ");
export const isBlindItem=(name:string)=>/\bblinds?\b|卷帘|卷簾|斑马帘|斑馬簾|百叶帘|百葉簾|罗马帘|羅馬簾|垂直帘/i.test(name);
export function specificBlindName(name:string):string|undefined {
  const key=normalized(name);
  return BLIND_CATALOG_ALIASES[key]||Object.values(BLIND_CATALOG_ALIASES).find(n=>normalized(n)===key);
}
export function blindTypeQuestion(name:string,language?:string):string|undefined {
  if(!isBlindItem(name)||specificBlindName(name)||/\bmotor(?:ised|ized)\b/i.test(name))return;
  if(language==="zh")return "请问是卷帘、斑马帘/日夜帘，还是其他款式？不确定的话，可以发照片或产品链接。";
  return "Are these roller, zebra/day-and-night or another type of blind? A photo or product link is fine if you're unsure.";
}
/** A short answer to a single current blind's type question refines that item.
 * No fuzzy names, negated/conditional answers, other items or prior-job counts. */
export function refineBlindAnswer(initial:FirstFacts,update:FirstFacts,text:string):FirstFacts {
  const old=initial.items?.length===1?initial.items[0]:undefined;
  if(!old||!isBlindItem(old.name)||update.newJob||
    /\b(?:also|another|additional|plus|new job|new request)\b|另外|另一个/i.test(text)||
    (update.items?.length||0)>1||update.items?.some(i=>!isBlindItem(i.name)&&!specificBlindName(i.name)))return update;
  const answer=normalized(text).replace(/^(?:they are|these are|it is|it's|是的|是)\s*[,，]?\s*/i,"")
    .replace(/^manual\s+/i,"").replace(/[.!。]+$/,"");
  const counted=answer.match(/^(\d+)\s*(?:x|pcs?|pieces?|sets?|windows?|个|套|扇)?\s*(.+)$/i);
  const name=specificBlindName(counted?.[2]||answer);
  if(!name)return update;
  const incoming=update.items?.[0];
  return {...update,items:[{...old,...incoming,key:old.key,name,
    quantity:counted?Number(counted[1]):old.quantity??incoming?.quantity,
    unit:old.unit??incoming?.unit,
    serviceType:old.serviceType&&old.serviceType!=="unspecified"?old.serviceType:incoming?.serviceType||"unspecified",
    catalogItemId:undefined,ambiguity:undefined,identityEvidence:text}]};
}
