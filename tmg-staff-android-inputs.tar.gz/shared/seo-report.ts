export interface SeoHomepage {
  title:string; description:string; keywords:string; canonical:string;
  ogTitle:string; ogDescription:string; ogImage:string; twitterCard:string;
  schemaTypes:string[]; sameAs:string[]; sitemapUrls:number; robotsOk:boolean;
  googleAdsPresent:boolean; ga4Present:boolean;
}
export interface SeoReport {
  measuredAt:string;
  source:string;
  homepage:SeoHomepage;
  sitemap:{status:number; entries:{url:string;priority:string;freq:string}[]};
  robots:{status:number;body:string};
  searchConsole:{configured:boolean; measurementsAvailable:false};
  googleIndexing:null;
  googleRankings:null;
}
