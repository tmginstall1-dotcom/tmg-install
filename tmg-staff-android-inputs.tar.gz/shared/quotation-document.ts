import {formatItemDescription,formatItemServiceLabel} from "../client/src/lib/itemLabel";
import {getJobSchedule,requiresFullUpfront,splitDepositFinal,PricingConfig,calcSecondDayContinuation} from "./pricing";
import {getQuoteTerms} from "./terms";
import {quotationDocumentStyles} from "./quotation-document-style";
import {offerDate} from "./quotation-validity";
import {customerDocumentNote,customerQuotationNote,isReviewQuotation,isUnpricedReviewItem,isTransportPricingPending} from "./quotation-document-notes";
// Extracted from the existing manual quotation template. Saved figures only; no catalogue repricing.
export function renderSavedQuoteDocument(quote: any, options: { forceDocType?: "QUOTATION" | "DELIVERY ORDER"; origin?: string; qrImage?: string; paidTotal?: number } = {}): string {
 const forceDocType=options.forceDocType;
 const q = quote;
 const review=isReviewQuotation(q);
 const validityBlocked=q.offerValidity&&!["valid","accepted"].includes(q.offerValidity.status);
 const customerNotes=q.leadIntake?.coordinatorRelease ? "" : customerQuotationNote(q);
 const items = (q.items || []) as any[];
 const services = Array.from(new Set(items.map(item=>formatItemServiceLabel(item,items)).filter(Boolean)));
 // Labour overage clause only applies to relocation jobs (where unpacking,
 // re-arranging and on-site decisions commonly extend crew time). Pure
 // installation jobs are charged on agreed scope only.
 const hasRelocation = (items || []).some((i: any) => i.serviceType === 'relocate');
 // Scheduled on-site time for this job, computed with the SAME engine the web
 // estimate uses, so the printed quote shows the included man-hours that the
 // Standard Terms & Conditions below refer to.
 const printSchedule = getJobSchedule({
   items: (items || []).map((i: any) => ({
     serviceType: i.serviceType,
     quantity: Number(i.quantity) || 1,
     volumeM3: i.volumeM3,
     carryOnly: i.carryOnly,
   })),
   totalVolumeM3: Number((q as any).totalVolumeM3) || undefined,
   distanceKm: Number(q.distanceKm) || 0,
   isRelocation: hasRelocation,
   crewSize: Number((q as any).secondDayCrewSize) || undefined,
 });
 const fmtHrs = (n: number) => (n % 1 === 0 ? `${n}` : n.toFixed(1));
 const printManHours = fmtHrs(printSchedule.scheduledHours * printSchedule.crewSize);
 const printCrewRate = printSchedule.overtimePerManPerHour * printSchedule.crewSize;
 // Single shared source of truth for the customer-facing terms — identical
 // wording to the web estimate and the standalone /terms page.
 const quoteTerms: import("./terms").QuoteTerm[] = q.offerTerms || getQuoteTerms({ isRelocation: hasRelocation }).map(t=>
   t.title==="Quote validity"?{...t,body:q.offerValidity?.message||"Validity evidence requires staff review; no issue date or expiry has been inferred."}:t);
 const scheduledDate = q.scheduledAt ? new Date(q.scheduledAt).toLocaleDateString("en-SG", { weekday: "long", year: "numeric", month: "long", day: "numeric" }) : null;
 const address = (q as any).samePropertyMove
 ? (q.pickupAddress || q.serviceAddress || "—")
 : (q.pickupAddress ? `${q.pickupAddress} → ${q.dropoffAddress}` : (q.serviceAddress || "—"));

 // Escape user-controlled values before interpolation into the printable
 // HTML template (this template is opened via window.open in the admin's
 // browser, so unescaped customer/billing input would be an XSS risk).
 const esc = (v: any) => String(v ?? "")
 .replace(/&/g, "&amp;")
 .replace(/</g, "&lt;")
 .replace(/>/g, "&gt;")
 .replace(/"/g, "&quot;")
 .replace(/'/g, "&#39;");

 const cleared = options.paidTotal ?? Number(q.clearedPaidTotal ?? 0);
 const isFullyPaid = cleared >= Number(q.total) && Number(q.total)>0;
 const isDepositPaid = cleared > 0 && !isFullyPaid;
 const totalAmt = Number(q.total || 0);
 const fullPayDoc = requiresFullUpfront(totalAmt);
 // Full-payment (under-threshold) jobs are always total / 0 — ignore any stale or
 // legacy stored split so the printable doc matches the site-wide rule.
 const depositAmt = fullPayDoc ? totalAmt : (Number(q.depositAmount || 0) > 0 ? Number(q.depositAmount) : Number(splitDepositFinal(totalAmt).depositAmount));
 const balanceAmt = Math.max(0,totalAmt-cleared);

 // Decide what kind of document this print is. Commercial customers
 // pay against an INVOICE (B2B norm: vendor issues invoice, customer
 // pays per terms). Residential customers receive a QUOTATION first
 // and only get an INVOICE / RECEIPT once the job is done.
 //
 // • QUOTATION — pre-deposit, awaiting customer approval
 // • JOB ORDER — residential, deposit cleared, work scheduled
 // • TAX INVOICE — commercial booked-and-onwards, OR any job that
 // has reached the completion / paid stages
 const isCommercialDoc = (q.invoiceType === "commercial");
 const PRE_BOOKING = ['submitted', 'under_review', 'approved', 'deposit_requested'];
 const COMPLETED = ['job_completed', 'completed', 'final_paid', 'closed', 'final_payment_requested', 'awaiting_final_payment'];
 let docType: "QUOTATION" | "JOB ORDER" | "TAX INVOICE" | "DELIVERY ORDER" | "REVIEW DRAFT";
 if (isFullyPaid || COMPLETED.includes(q.status)) docType = "TAX INVOICE";
 else if (isCommercialDoc && !PRE_BOOKING.includes(q.status)) docType = "TAX INVOICE";
 else if (!PRE_BOOKING.includes(q.status)) docType = "JOB ORDER";
 else docType = "QUOTATION";
 // A Delivery Order is an explicit, on-demand document the admin prints to get
 // the customer's sign-off that the items / services were delivered and
 // installed. It is a proof-of-delivery / scope doc — no prices, no payment.
 if (forceDocType) docType = forceDocType;
 if(review && docType!=="DELIVERY ORDER")docType="REVIEW DRAFT";
 const isInvoiceDoc = docType === "TAX INVOICE";
 const isDeliveryOrder = docType === "DELIVERY ORDER";

 // Human-friendly status label for the masthead meta row.
 const statusLabel = (() => {
 if (isFullyPaid) return "PAID";
 if (q.status === "final_payment_requested" || q.status === "awaiting_final_payment") return "FINAL PAYMENT DUE";
 if (q.status === "completed" || q.status === "job_completed") return "COMPLETED";
 if (q.status === "closed") return "CLOSED";
 if (isDepositPaid) return "DEPOSIT RECEIVED";
 if (q.status === "booked" || q.status === "scheduled" || q.status === "in_progress" || q.status === "at_pickup" || q.status === "in_transit" || q.status === "at_dropoff") return "BOOKED";
 if (q.status === "booking_pending") return "BOOKING PENDING";
 if (q.status === "deposit_requested") return fullPayDoc?"PAYMENT REQUESTED":"DEPOSIT REQUESTED";
 if (q.status === "approved") return "APPROVED";
 if (q.status === "under_review") return "UNDER REVIEW";
 if (q.status === "submitted") return "SUBMITTED";
 if (q.status === "cancelled") return "CANCELLED";
 return String(q.status || "—").toUpperCase().replace(/_/g, " ");
 })();
 const termsLabel = review ? "Pricing pending staff review" : isDeliveryOrder ? "Delivery & Acceptance" : isInvoiceDoc ? "Net 30" : (docType === "JOB ORDER" ? (fullPayDoc ? "Paid in Full" : "50% Deposit Paid") : (fullPayDoc ? "Full Payment" : "50% Deposit"));
 // Stable invoice number: TMG-MOJN5PS9 → INV-MOJN5PS9
 const refTail = String(q.referenceNo || "").replace(/^TMG-?/i, "");
 const invoiceNo = `INV-${refTail || q.id}`;
 // Stable delivery-order number: TMG-MOJN5PS9 → DO-MOJN5PS9
 const deliveryOrderNo = `DO-${refTail || q.id}`;
 // The headline reference shown in the masthead / footer depends on the kind
 // of document being printed.
 const docNo = isInvoiceDoc ? invoiceNo : isDeliveryOrder ? deliveryOrderNo : q.referenceNo;
 const issuedDate = isFullyPaid && q.finalPaidAt
 ? new Date(q.finalPaidAt).toLocaleDateString("en-SG", { year: "numeric", month: "long", day: "numeric" })
 : q.offerValidity?.issuedAt ? offerDate(q.offerValidity.issuedAt) : "Not established";
 // Net 30 payment terms for commercial invoices
 const dueDate = (() => {
 const base = isFullyPaid && q.finalPaidAt ? new Date(q.finalPaidAt) : new Date();
 base.setDate(base.getDate() + 30);
 return base.toLocaleDateString("en-SG", { year: "numeric", month: "long", day: "numeric" });
 })();
 const quotationTerms = quoteTerms.map((t) => `<li><strong>${esc(t.title)}.</strong> ${esc(t.body)}</li>`);
 const quotationTermCount = quotationTerms.length;
 const quotationTermsBeforeFinal = quotationTerms.slice(0, -1).join("\n ");
 const quotationFinalTerms = quotationTerms.at(-1) || "";
 const quotationGstTerm = `<li>All prices are in Singapore Dollars (SGD) and are <strong>not subject to GST</strong> (we are not GST-registered).</li>`;
 const quotationSignature = `
 <div class="sig-box">
   <div class="sig-line"></div>
   <div class="sig-label sig-label-center">
     <span class="sig-name">Customer</span>Signature &amp; Date
   </div>
 </div>`;
 const keepSignatureWithTerms = docType === "QUOTATION" && !review;
 const quotationTermsMarkup = keepSignatureWithTerms
 ? `${quotationTermsBeforeFinal ? `<ol>${quotationTermsBeforeFinal}</ol>` : ""}
 <div class="tnc-final-group">
   <ol start="${Math.max(1, quotationTermCount)}">${quotationFinalTerms}${quotationGstTerm}</ol>
   ${quotationSignature}
 </div>`
 : `<ol>${quotationTerms.join("\n ")}` + `${quotationGstTerm}</ol>`;

 const html = `<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8" />
 <title>${esc(q.referenceNo)} · ${esc(docType)}</title>
 <style>${quotationDocumentStyles}
 /* Keep the accounting-stationery header inside A4 even for long reference numbers.
    The brand column may shrink; the metadata column must not set the grid's min-content width. */
 .letterhead { grid-template-columns: 56px minmax(0, 1fr) minmax(0, 210px); }
 .lh-doc { min-width: 0; max-width: 100%; }
 .lh-doc .ref-value, .lh-doc .sub-ref, .lh-doc .meta-grid .v {
   overflow-wrap: anywhere; word-break: break-word; white-space: normal;
 }
 .lh-doc .meta-grid { width: 100%; grid-template-columns: max-content minmax(0, 1fr); justify-content: stretch; }
 .tnc-ref, .tnc-ref strong, .footer-ref, .footer-ref strong {
   overflow-wrap: anywhere; word-break: break-word; white-space: normal;
 }
 /* Keep quotation terms legible and in one reading column. The long legal
    block may split naturally, while its last clauses and customer signature
    stay together as a deliberate close to the offer. */
 .quotation-document .tnc { page-break-inside: auto !important; break-inside: auto !important; }
 .quotation-document .tnc h3 { font-size: 12px; line-height: 1.4; gap: 8px 12px; }
 .quotation-document .tnc h3 .tnc-title { font-size: 14px; }
 .quotation-document .tnc ol { column-count: 1 !important; column-gap: 0; column-rule: 0; padding-left: 19px; }
 .quotation-document .tnc li { font-size: 12px !important; line-height: 1.4 !important; margin-bottom: 7px !important; }
 .quotation-document .tnc-final-group {
   display: grid; grid-template-columns: minmax(0, 1fr) minmax(190px, 220px);
   align-items: end; gap: 12px; margin-top: 5px;
   page-break-inside: avoid; break-inside: avoid;
 }
 .quotation-document .tnc-final-group ol { margin: 0; }
 .quotation-document .tnc-final-group .sig-box { min-height: 58px; padding: 6px 10px; }
 .quotation-document .tnc-final-group .sig-line { height: 20px; margin-bottom: 4px; }
 .quotation-document .tnc-final-group .sig-label { max-width: 100%; font-size: 12px; line-height: 1.4; }
 .footer.footer-no-signature { grid-template-columns: 1fr; }
 @media print {
   .quotation-document .tnc ol { column-count: 1 !important; }
   .quotation-document .tnc-final-group { page-break-inside: avoid; break-inside: avoid; }
 }
 </style>
</head>
<body>
 <div class="print-toolbar" role="toolbar" aria-label="Document toolbar">
   <span class="pt-title">${esc(docType)} · ${esc(q.referenceNo || "")}</span>
   <span class="pt-actions">
     <button type="button" onclick="window.print()">Print / Save PDF</button>
     <button type="button" class="pt-primary" onclick="window.close(); setTimeout(function(){ try{ history.back(); }catch(e){} }, 100);">Close ✕</button>
   </span>
 </div>
 <div class="doc-body${keepSignatureWithTerms ? " quotation-document" : ""}">

 <!-- Letterhead — three-column accounting-stationery masthead -->
 <div class="letterhead">
 <div class="lh-mark"><div class="wm">TMG<span class="dot">.</span></div></div>
 <div class="lh-brand">
 <div class="lh-coname">The Moving Guy Pte Ltd</div>
 <div class="lh-tag">Furniture Installation · Singapore</div>
 <div class="lh-addr">
 <strong>UEN 202424156H</strong><span class="sep">·</span>160 Robinson Road #14-04,<br/>
 Singapore 068914<br/>
 <span class="nowrap">+65 8088 0757</span><br/>
 <span class="nowrap">sales@tmginstall.com<span class="sep">·</span>tmginstall.com</span>
 </div>
 </div>
 <div class="lh-doc">
 <div class="type${docType === "DELIVERY ORDER" ? " type-long" : ""}">${docType}</div>
 <div class="ref-block">
 <div class="ref-value">${esc(docNo)}</div>
 ${(isInvoiceDoc || isDeliveryOrder) ? `<div class="sub-ref">Job Ref · ${esc(q.referenceNo)}</div>` : ""}
 </div>
 <div class="meta-grid">
 <div class="k">Issued</div><div class="v">${esc(issuedDate)}</div>
 ${q.offerValidity?.expiresAt?`<div class="k">Offer deadline</div><div class="v">${esc(offerDate(q.offerValidity.expiresAt))}</div>`:""}
 <div class="k">Version</div><div class="v">${esc(q.version || 1)}</div>
 ${(isInvoiceDoc && !isFullyPaid) ? `<div class="k">Due</div><div class="v">${esc(dueDate)}</div>` : ""}
 <div class="k">Terms</div><div class="v">${esc(termsLabel)}</div>
 <div class="k">Status</div><div class="v status">${esc(statusLabel)}</div>
 </div>
 </div>
 </div>

 ${(() => {
 const isCommercial = (q.invoiceType === "commercial");
 const billingCompanyName = q.billingCompanyName || q.customer?.companyName || "";
 const billingCompanyUen = q.billingCompanyUen || q.customer?.companyUen || "";
 const billingAddress = q.billingAddress || q.customer?.billingAddress || address || "";
 const showCustomerEmail = q.customer?.email && !q.customer.email.includes("@tmginstall.com");
 const escAddr = (v: any) => esc(v).replace(/\n/g, "<br/>");
 const billToHtml = isCommercial
 ? `
 <p class="name">${esc(billingCompanyName || q.customer?.name || "—")}</p>
 ${billingCompanyUen ? `<p class="kv"><span class="k">UEN</span><span class="v">${esc(billingCompanyUen)}</span></p>` : ""}
 ${billingAddress ? `<p class="kv"><span class="k">Address</span><span class="v">${escAddr(billingAddress)}</span></p>` : ""}
 ${q.customer?.name && billingCompanyName ? `<p class="kv" style="margin-top:6px;"><span class="k">Attn</span><span class="v">${esc(q.customer.name)}</span></p>` : ""}
 ${q.customer?.phone ? `<p class="kv"><span class="k">Phone</span><span class="v">${esc(q.customer.phone)}</span></p>` : ""}
 ${showCustomerEmail ? `<p class="kv"><span class="k">Email</span><span class="v">${esc(q.customer.email)}</span></p>` : ""}
 ${q.poNumber ? `<p class="kv" style="margin-top:6px;"><span class="k">PO No.</span><span class="v">${esc(q.poNumber)}</span></p>` : ""}
 `
 : `
 <p class="name">${esc(q.customer?.name || "—")}</p>
 ${billingAddress ? `<p class="kv"><span class="k">Address</span><span class="v">${escAddr(billingAddress)}</span></p>` : ""}
 ${q.customer?.phone ? `<p class="kv"><span class="k">Phone</span><span class="v">${esc(q.customer.phone)}</span></p>` : ""}
 ${showCustomerEmail ? `<p class="kv"><span class="k">Email</span><span class="v">${esc(q.customer.email)}</span></p>` : ""}
 `;
 return `
 <div class="parties">
 <div class="party">
 <div class="party-label">Billed To${isCommercial ? " · Commercial" : ""}</div>
 ${billToHtml}
 </div>
 <div class="party">
 <div class="party-label">Engagement</div>
 <p class="kv"><span class="k">Service At</span><span class="v">${esc(address)}</span></p>
 ${scheduledDate ? `<p class="kv"><span class="k">Scheduled</span><span class="v">${esc(scheduledDate)}${q.timeWindow ? ` · ${esc(q.timeWindow)}` : ""}</span></p>` : ""}
 ${services.length ? `<p class="kv"><span class="k">Services</span><span class="v">${esc(services.join(", "))}</span></p>` : ""}
 ${customerNotes ? `<p class="kv"><span class="k">Notes</span><span class="v">${esc(customerNotes)}</span></p>` : ""}
 </div>
 </div>`;
 })()}

 <table class="items">
 <thead>
 <tr>
 <th>Description</th>
 <th>Qty</th>
 ${isDeliveryOrder ? "" : `<th>Unit Price (S$)</th>
 <th>Amount (S$)</th>`}
 </tr>
 </thead>
 <tbody>
 ${items.length > 0
 ? items.map((item: any) => `
 <tr>
 <td>
 ${esc(formatItemDescription(item, items))}
 ${customerDocumentNote(item.remark) ? `<div class="item-remark">${esc(customerDocumentNote(item.remark))}</div>` : ""}
 </td>
 <td>${item.quantity}</td>
 ${isDeliveryOrder ? "" : `<td>${isUnpricedReviewItem(q,item) ? "Pending review" : Number(item.unitPrice || 0).toFixed(2)}</td>
 <td>${isUnpricedReviewItem(q,item) ? "Pending review" : Number(item.subtotal || 0).toFixed(2)}</td>`}
 </tr>`).join("")
 : `<tr><td colspan="${isDeliveryOrder ? 2 : 4}" style="text-align:center;color:#94a3b8;padding:24px;font-style:italic;">No line items</td></tr>`
 }
 </tbody>
 </table>

 ${validityBlocked&&!review?`<p style="margin:18px 0;font-weight:700;">${esc(q.offerValidity.message)} No new acceptance or payment may be initiated using this offer.</p>`:""}
 ${review ? `<p style="margin:18px 0;font-weight:700;">Review draft — not a fixed or payable quotation. Staff must confirm the scope and approved prices before payment is requested. Any appointment date/time needs staff confirmation.</p>
 <div class="totals"><div class="totals-row"><span>Known priced components (not a final total)</span><strong>S$${items.reduce((sum,item)=>sum+(isUnpricedReviewItem(q,item)?0:Number(item.subtotal||0)),0).toFixed(2)}</strong></div>
 ${isTransportPricingPending(q)?`<div class="totals-row"><span>Transport / access</span><span>Pricing pending</span></div>`:""}
 <div class="totals-row"><span>Final quotation total</span><strong>Pending scope / pricing confirmation</strong></div></div>
 ${q.leadIntake?.facts?.relocationMode==="full"?`<p>Dismantling and reassembly labour components do not confirm transport-inclusive pricing. Transport, route and access charges remain pending unless expressly listed and confirmed.</p>`:""}
 ` : isDeliveryOrder ? `
 <div style="margin-top:18px;border:1px solid #d1d5db;background:#fafafa;border-radius:4px;padding:12px 14px;">
 <div style="font-size:8.5px;text-transform:uppercase;letter-spacing:0.28em;font-weight:700;color:#6b7280;">Work Completion Confirmation</div>
 <div style="font-size:11px;color:#374151;line-height:1.6;margin-top:6px;">The work listed above has been completed at the service address according to the scope stated for each item. Please check the received scope against this list and sign below to acknowledge completion in good order.</div>
 </div>
 ` : `
 <div class="totals-wrap">
 <div class="totals">
 ${Number(q.discount || 0) > 0 ? `<div class="totals-row"><span class="k">Discount</span><span>−S$${Number(q.discount).toFixed(2)}</span></div>` : ""}
 ${(Number(q.transportFee || 0) - Number((q as any).volumetricFee || 0)) > 0 ? `<div class="totals-row"><span class="k">Transport</span><span>S$${(Number(q.transportFee || 0) - Number((q as any).volumetricFee || 0)).toFixed(2)}</span></div>` : ""}
 ${Number((q as any).volumetricFee || 0) > 0 ? `<div class="totals-row"><span class="k">Volumetric Handling</span><span>S$${Number((q as any).volumetricFee).toFixed(2)}</span></div>` : ""}
 ${Number(q.promoDiscount || 0) > 0 ? `<div class="totals-row"><span class="k">Promo · ${esc(q.promoCode || "")}</span><span>−S$${Number(q.promoDiscount).toFixed(2)}</span></div>` : ""}
 ${Number((q as any).goodwillDiscount || 0) > 0 ? `<div class="totals-row"><span class="k">Goodwill discount${(q as any).goodwillReason ? ` · ${esc((q as any).goodwillReason)}` : ""}</span><span>−S$${Number((q as any).goodwillDiscount).toFixed(2)}</span></div>` : ""}
 ${(q as any).secondDayContinuation ? `<div class="totals-row"><span class="k">Second-day continuation${Number((q as any).secondDayHours) > 0 ? ` · ${Number((q as any).secondDayCrewSize) || PricingConfig.secondDay.defaultCrewSize} men × ${Number((q as any).secondDayHours)}h` : ""}</span><span>S$${calcSecondDayContinuation(!!(q as any).secondDayContinuation, (q as any).secondDayHours || 0, (q as any).secondDayCrewSize).fee.toFixed(2)}</span></div>` : ""}
 <div class="totals-row grand"><span class="k">Total</span><span>S$${Number(q.total || 0).toFixed(2)}</span></div>
 ${isFullyPaid ? `
 <div class="paid-stamp">
 <div class="big">Paid in Full</div>
 <div class="sub">Both deposit and balance received. Thank you for your business.</div>
 <div class="paid-split">
 <span>Deposit · <strong>S$${depositAmt.toFixed(2)}</strong></span>
 <span>Balance · <strong>S$${balanceAmt.toFixed(2)}</strong></span>
 </div>
 </div>` : isDepositPaid ? `
 <div class="totals-row" style="margin-top:6px;color:var(--green);">
 <span class="k" style="color:var(--green);">Verified payment received</span><span style="color:var(--green);">−S$${cleared.toFixed(2)}</span>
 </div>
 <div class="amount-due">
 <div class="lbl-wrap">
 <div class="lbl">Amount outstanding</div>
 <div class="due-date">According to the payment terms above; appointment requires staff confirmation${isInvoiceDoc && !isFullyPaid ? ` · by ${esc(dueDate)}` : ""}</div>
 </div>
 <div class="amt">S$${balanceAmt.toFixed(2)}</div>
 </div>` : validityBlocked ? `<p>No new payment is requested. Offer validity needs staff review.</p>` : `
 <div class="amount-due">
 <div class="lbl-wrap">
 <div class="lbl">${isInvoiceDoc ? "Amount Due" : fullPayDoc ? "Full payment required" : "Deposit required"}</div>
 ${isInvoiceDoc ? `<div class="due-date">By ${esc(dueDate)} · Net 30</div>` : `<div class="due-date">${fullPayDoc ? "Full payment required; appointment needs staff confirmation" : "50% deposit required; appointment needs staff confirmation"}</div>`}
 </div>
 <div class="amt">S$${(isInvoiceDoc ? totalAmt : depositAmt).toFixed(2)}</div>
 </div>`}
 </div>
 </div>

 <!-- Payment Details -->
 ${isFullyPaid || validityBlocked ? "" : `
 <div class="payment-section">
 <div class="payment-details">
 <h3>Payment Details${isDepositPaid ? ' — Balance Due' : ''}</h3>
 <dl class="pay-grid">
 <dt>Bank</dt><dd>OCBC Bank</dd>
 <dt>Account No.</dt><dd>596-795617-001</dd>
 <dt>Account Name</dt><dd>The Moving Guy Pte. Ltd.</dd>
 <dt>Currency</dt><dd>SGD</dd>
 <dt>PayNow (UEN)</dt><dd>202424156H</dd>
 </dl>
 <div class="pay-note">
 Please include the reference <strong>${esc(isInvoiceDoc ? invoiceNo : q.referenceNo)}</strong> in your payment remarks.
 ${isInvoiceDoc ? `Email remittance advice to <strong>sales@tmginstall.com</strong>.` : ""}
 </div>
 </div>
 <div class="qr-block">
 <div class="qr-frame"><img src="${esc(options.qrImage || `${options.origin || ""}/paynow-qr.png`)}" alt="PayNow QR Code" width="150" height="150" /></div>
 <div class="qr-label">Scan to Pay · PayNow</div>
 <div class="qr-sub">UEN 202424156H</div>
 </div>
 </div>`}
 ${docType==="QUOTATION"&&!review ? `<p style="font-size:10px;line-height:1.5;margin:12px 0;overflow-wrap:anywhere">
 Review this quotation, accept the current terms and view the unchanged payment balance:
 <a href="https://tmginstall.com/quotes/${encodeURIComponent(q.id)}?ref=${encodeURIComponent(q.referenceNo)}&amp;version=${encodeURIComponent(q.version)}">Open customer quotation v${esc(q.version)}</a>.
 Payment does not book an appointment; staff must confirm the date and time.
 </p>` : ""}
 `}

 <!-- Included on-site time (relocation quotes / job orders only) -->
 ${(!isInvoiceDoc && !isDeliveryOrder && hasRelocation) ? `
 <div style="margin-top:18px;border:1px solid #e5e7eb;background:#f9fafb;border-radius:4px;padding:10px 12px;">
 <div style="font-size:11px;color:#374151;line-height:1.5;">
 <strong>Included on-site time:</strong> ${printSchedule.crewSize} mover${printSchedule.crewSize !== 1 ? "s" : ""} × ${fmtHrs(printSchedule.scheduledHours)} hour${fmtHrs(printSchedule.scheduledHours) === "1" ? "" : "s"} = <strong>${printManHours} man-hours</strong>.
 </div>
 <div style="font-size:11px;color:#6b7280;line-height:1.5;margin-top:2px;">
 Extra time beyond this is $${printSchedule.overtimePerManPerHour} per mover, per hour (= $${printCrewRate}/hour for your ${printSchedule.crewSize}-person crew), billed in ${printSchedule.blockMinutes}-minute blocks.
 </div>
 </div>` : ""}

 <!-- Terms & Conditions -->
 <div class="tnc">
 <h3>
 <span class="tnc-title">Terms &amp; Conditions</span>
 <span class="tnc-ref">${isInvoiceDoc ? "Invoice" : isDeliveryOrder ? "Delivery Order" : "Quotation"} <strong>${esc(docNo)}</strong>${(isInvoiceDoc || isDeliveryOrder) ? ` · Job ${esc(q.referenceNo)}` : ""}</span>
 <span class="tnc-link">Full version: <a href="https://tmginstall.com/terms" target="_blank">tmginstall.com/terms</a></span>
 </h3>
 ${review ? `<ol><li>This is a scope review, not a fixed-price quotation or payment request. Staff will confirm the work and approved charges before issuing a formal quotation.</li><li>Every appointment date and time requires staff confirmation. No appointment is reserved by this review.</li></ol>` : isDeliveryOrder ? `<ol>
 <li>This Delivery Order records completion of the work listed above according to each item’s stated scope at the service address.</li>
 <li>Please inspect all items on delivery. By signing below, the customer acknowledges receipt and that the work was completed in good order.</li>
 <li>Any defect or shortfall must be reported in writing within <strong>7 days</strong> of the delivery date shown above.</li>
 <li>The Moving Guy Pte Ltd is not liable for pre-existing damage to furniture, walls, or fixtures.</li>
 <li>This document is a delivery acknowledgement only — it is not a tax invoice or a receipt.</li>
 </ol>` : isInvoiceDoc ? `<ol>
 <li><strong>Payment Terms:</strong> Net 30 days from invoice date${isFullyPaid ? "" : ` — payment due by <strong>${esc(dueDate)}</strong>`}. Please quote the invoice number <strong>${esc(invoiceNo)}</strong> in the payment remarks.</li>
 <li>Late payments may incur a <strong>1.5% per month</strong> administrative charge on the outstanding balance.</li>
 <li>Goods and services described above have been delivered / completed as agreed. Any defect claim must be raised in writing within <strong>7 days</strong> of completion.</li>
 <li><strong>On-site Charges:</strong> Any additional drilling requested on site is <strong>S$5 per hole</strong>. Wall-anchor / fastening hardware supplied on site is charged at cost.${hasRelocation ? ` For relocation work, extra labour beyond the agreed scope is <strong>S$50/hr per crew member</strong>.` : ""}</li>
 <li>Transport fee applies for locations outside central Singapore or where lift access is unavailable. Long-carry &gt; 30 m or stairs without lift access incurs an additional fee, quoted on site before work proceeds.</li>
 <li>The Moving Guy Pte Ltd is not liable for pre-existing damage to furniture, walls, or fixtures.</li>
 <li>Any additional work not stated in this invoice has been agreed upon separately in writing.</li>
 <li>All prices are in Singapore Dollars (SGD) and are <strong>not subject to GST</strong> (The Moving Guy Pte Ltd is not GST-registered).</li>
 <li>By making payment, the customer is deemed to have read and accepted our full Terms &amp; Conditions at <a href="https://tmginstall.com/terms" target="_blank">tmginstall.com/terms</a>.</li>
 </ol>` : quotationTermsMarkup}
 </div>

 <div class="footer${keepSignatureWithTerms ? " footer-no-signature" : ""}">
 <div>
 <div class="thanks">${isInvoiceDoc ? "Thank you for your business." : isDeliveryOrder ? "Thank you — please retain this for your records." : "We appreciate the opportunity to quote for you."}</div>
 <div class="footer-ref">${isInvoiceDoc ? "Invoice" : isDeliveryOrder ? "Delivery Order" : "Quotation"} <strong>${esc(docNo)}</strong>${(isInvoiceDoc || isDeliveryOrder) ? ` · Job ${esc(q.referenceNo)}` : ""} · For ${esc(q.customer?.name || "—")} · Issued ${esc(issuedDate)}</div>
 <p>Generated ${esc(new Date().toLocaleDateString("en-SG", { year: "numeric", month: "long", day: "numeric" }))} · The Moving Guy Pte Ltd · UEN 202424156H · Vehicle GBM550L<br/>+65 8088 0757 · sales@tmginstall.com · <a href="https://tmginstall.com" target="_blank">tmginstall.com</a> · Terms: <a href="https://tmginstall.com/terms" target="_blank">tmginstall.com/terms</a></p>
 </div>
 ${keepSignatureWithTerms ? "" : `<div class="sig-box">
 ${isInvoiceDoc ? `
 <div class="company-stamp" aria-hidden="true">
 <svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
 <defs>
 <!-- Top text path: r=42, sweep=1 (clockwise via top). Glyphs extend
 OUTWARD from the path, sitting in the band r=42..r=49.5. -->
 <path id="tmgStampTopArc" d="M 18,60 A 42,42 0 0 1 102,60" fill="none" />
 <!-- Bottom text path: r=53, sweep=0 = counterclockwise via BOTTOM
 (sweep=1 wrongly went via top, putting text upside-down on top).
 Going left-to-right via bottom, text glyphs sit ABOVE the path
 = toward center, occupying band r=47..r=53. Reads upright. -->
 <path id="tmgStampBottomArc" d="M 7,60 A 53,53 0 0 0 113,60" fill="none" />
 </defs>
 <!-- Outer thick ring -->
 <circle cx="60" cy="60" r="56" fill="none" stroke="#15407a" stroke-width="2.4" />
 <!-- Inner thin ring -->
 <circle cx="60" cy="60" r="39" fill="none" stroke="#15407a" stroke-width="0.9" />
 <!-- Top curved text: company name -->
 <text fill="#15407a" font-family="Helvetica, Arial, sans-serif" font-weight="700" font-size="7.4" letter-spacing="1.3">
 <textPath xlink:href="#tmgStampTopArc" href="#tmgStampTopArc" startOffset="50%" text-anchor="middle">
 THE MOVING GUY PTE LTD
 </textPath>
 </text>
 <!-- Bottom curved text: UEN \u00B7 SINGAPORE -->
 <text fill="#15407a" font-family="Helvetica, Arial, sans-serif" font-weight="700" font-size="6" letter-spacing="1.5">
 <textPath xlink:href="#tmgStampBottomArc" href="#tmgStampBottomArc" startOffset="50%" text-anchor="middle">
 UEN 202424156H \u00B7 SINGAPORE
 </textPath>
 </text>
 <!-- Center block: thin rules safely inside inner ring r=39 -->
 <line x1="32" y1="55" x2="88" y2="55" stroke="#15407a" stroke-width="0.6" />
 <line x1="32" y1="76" x2="88" y2="76" stroke="#15407a" stroke-width="0.6" />
 <text x="60" y="65" text-anchor="middle" fill="#15407a" font-family="Helvetica, Arial, sans-serif" font-weight="800" font-size="8.6" letter-spacing="1.3">AUTHORISED</text>
 <text x="60" y="73" text-anchor="middle" fill="#15407a" font-family="Helvetica, Arial, sans-serif" font-weight="600" font-size="5.4" letter-spacing="1.4">SIGNATORY</text>
 </svg>
 </div>
 <div class="sig-line"></div>
 <div class="sig-label">
 <span class="sig-name">The Moving Guy Pte Ltd</span>Authorised Signatory
 </div>` : `
 <div class="sig-line"></div>
 <div class="sig-label sig-label-center">
 <span class="sig-name">${isDeliveryOrder ? "Received in good order by" : "Customer"}</span>${isDeliveryOrder ? "Name · Signature · Date" : "Signature &amp; Date"}
 </div>`}
 </div>`}
 </div>

 </div><!-- /.doc-body -->


</body>
</html>`;

 return html;
}
