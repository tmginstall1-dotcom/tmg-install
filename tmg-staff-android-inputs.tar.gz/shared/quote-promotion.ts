import {isWrappingRollupLine} from "./pricing";

/** Owner-approved TMG50 basis: strictly over $150 of work, never logistics. */
export function tmg50Eligibility(items: Array<{serviceType?:string|null;subtotal?:unknown;detectedName?:unknown;originalDescription?:unknown}>) {
  const work=items.filter(i=>i.serviceType!=="discount"&&!isWrappingRollupLine(String(i.detectedName||""))&&!isWrappingRollupLine(String(i.originalDescription||"")));
  const excluded=work.some(i=>i.serviceType==="relocate"||i.serviceType==="dismantle");
  const eligibleCents=work.filter(i=>["install","manual","align","fit_castors","uncarton","place"].includes(String(i.serviceType)))
    .reduce((sum,i)=>sum+Math.round(Number(i.subtotal||0)*100),0);
  return {eligible:!excluded&&Number.isFinite(eligibleCents)&&eligibleCents>15000,
    workAmount:eligibleCents/100,
    reason:excluded?"TMG50 does not apply to relocation or dismantling/reassembly work.":"TMG50 requires eligible work charges above S$150; transport and call-out are excluded."};
}
export function invalidTmg50(q:{promoCode?:unknown;promoDiscount?:unknown;items?:any[]}) {
  return String(q.promoCode||"").trim().toUpperCase()==="TMG50"&&Number(q.promoDiscount)>0&&!tmg50Eligibility(q.items||[]).eligible;
}
