export type IntakeLine = {
  key: string; name: string; quantity?: number; unit?: "item" | "set";
  separateIdentity?:boolean;
  serviceType: string; catalogItemId?: number; evidence?: "description" | "photo";
  ambiguity?: string; phase?: string; widthEvidence?:import("./furnitureWidthEvidence").WidthEvidence;
  itemLocation?:string;
  relocationMode?: "carry" | "full" | "reinstall_only";
  samePropertyMove?: boolean;
  specialNotes?: string;
  /** Retained current-job text explicitly names this item for moving. */
  retainedMoveEvidence?: boolean;
  retainedDismantling?: boolean;
  identityEvidence?: string;
  floorLevel?: number; hasLift?: boolean; accessNotes?: string;
  jobAddress?: string; toAddress?: string; destinationFloor?: number; destinationLift?: boolean;
};
export type FirstFacts = {
  /** Customer-declared total; never a replacement for per-line quantities. */
  quantity?:number;
  customerName?: string; customerEmail?: string; phone?: string; language?: "en" | "zh";
  jobAddress?: string; toAddress?: string; floorLevel?: number; hasLift?: boolean;
  destinationFloor?: number; destinationLift?: boolean; accessNotes?: string;
  accessDifficulty?: "easy" | "medium" | "hard"; itemLocation?: string;
  items?: IntakeLine[]; photos?: string[]; productLinks?: string[]; manuals?: string[];
  evidence?:Array<{kind:"pdf"|"text_document"|"photo"|"product_link";source:string;readable:boolean;text?:string}>;
  serviceType?: string; relocationMode?: "carry" | "full" | "reinstall_only";
  distanceKm?: number; samePropertyMove?: boolean; preferredDate?: string;
  movementKind?: "room_to_room" | "same_building" | "vehicle";
  sameLevel?: boolean;
  pickupLiftFit?: boolean | "unknown";
  destinationLiftFit?: boolean | "unknown";
  alternativeDates?: string[]; preferredTimeWindow?: string; specialNotes?: string;
  phases?: string[]; extraVisits?: number; addOns?: string[]; promoCode?: string;
  deferredUntil?: string; newJob?: boolean; previousJobReference?: string;
  /** Set only when the current customer explicitly starts a separate enquiry. */
  explicitNewEnquiry?: boolean;
  replaceItems?: boolean;
  replacementItemKey?: string;
  removeItemKeys?: string[];
  itemClarification?: string;
  locationClarification?:string;
  wardrobeIdentity?:{key:string;single:boolean;quantity?:number;twoDoors?:boolean;mirrorObserved?:boolean;verifiedSubtype?:boolean;serviceType?:string;full?:boolean};
  evidenceIssues?:Array<{source:string;itemKey?:string;question:string}>;
  retainedReview?:{statements:string[];preserveFinancials?:boolean;kind?:"alternatives";staffSources?:Array<{id:number;at:string}>};
};
export function singaporeDate(at: Date | string): string {
  return new Date(new Date(at).getTime() + 8 * 3600_000).toISOString().slice(0, 10);
}
export function dateIssue(date: string, at: Date | string): string | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(Date.parse(date))) return "Please confirm the date.";
  const [year, month, day] = date.split("-").map(Number);
  const parsed = new Date(Date.UTC(year, month - 1, day));
  if (parsed.toISOString().slice(0, 10) !== date) return "Please confirm the date.";
  if (date < singaporeDate(at)) return "That date has passed. Which future date works?";
  if (parsed.getUTCDay() === 0) return "Our crews do not work on Sundays. Please choose another date.";
  if (date === singaporeDate(at)) return "Same-day work needs our team’s confirmation; it is not reserved.";
  return null;
}
const months = ["january","february","march","april","may","june","july","august","september","october","november","december"];
export function extractDates(text: string, at: Date | string): { dates: string[]; issues: string[] } {
  // "Photo 2 may be another item" is an indexed photo plus a modal verb,
  // not a request for 2 May. Keep actual dates elsewhere in the same text.
  text=text.replace(/\b(?:photo|image|picture|attachment|file|item)\s*(?:#|no\.?\s*)?\d{1,3}\b/gi,"");
  // A stated clock reference is not a request to work on that date.
  text=text.replace(/\b(?:today|current date)\s*(?:is|:)?\s*\d{1,2}\s+(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4}\b[.]?/gi,"");
  const year = Number(singaporeDate(at).slice(0, 4));
  const dates: string[] = [], issues: string[] = [];
  for (const match of Array.from(text.matchAll(/\b(?:(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\s+)?(\d{1,2})\s+(January|February|March|April|May|June|July|August|September|October|November|December)(?:\s+(\d{4}))?\b/gi))) {
    const date = `${match[4] || year}-${String(months.indexOf(match[3].toLowerCase()) + 1).padStart(2, "0")}-${match[2].padStart(2, "0")}`;
    dates.push(date);
    const issue = dateIssue(date, at);
    if (issue) issues.push(issue);
    if (match[1] && new Date(`${date}T12:00:00+08:00`).toLocaleDateString("en-US", { weekday: "long", timeZone: "Asia/Singapore" }).toLowerCase() !== match[1].toLowerCase()) {
      issues.push(`The weekday does not match ${date}. Please confirm the intended date.`);
    }
  }
  for (const match of Array.from(text.matchAll(/\b20\d{2}-\d{2}-\d{2}\b/g))) {
    dates.push(match[0]); const issue = dateIssue(match[0], at); if (issue) issues.push(issue);
  }
  const statedChineseYear=text.match(/(20\d{2})年/)?.[1]||String(year);
  for(const match of text.matchAll(/(?:(20\d{2})年)?(\d{1,2})月(\d{1,2})日/g)) {
    const date=`${match[1]||statedChineseYear}-${match[2].padStart(2,"0")}-${match[3].padStart(2,"0")}`;
    dates.push(date);const issue=dateIssue(date,at);if(issue)issues.push(issue);
  }
  if (/\btomorrow\b|明天/i.test(text)) dates.push(singaporeDate(new Date(new Date(at).getTime() + 86400_000)));
  if (/\btoday\b|今天/i.test(text)) dates.push(singaporeDate(at));
  const weekdays=["sunday","monday","tuesday","wednesday","thursday","friday","saturday"];
  const anchor=new Date(`${singaporeDate(at)}T12:00:00+08:00`);
  for(const m of text.matchAll(/\b(?:(next|this)\s+)?(Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday)\b(?!\s+\d)/gi)) {
    const target=weekdays.indexOf(m[2].toLowerCase());
    let offset=(target-anchor.getUTCDay()+7)%7;
    if(m[1]?.toLowerCase()==="next"||/\bnext week\b/i.test(text))offset=((8-anchor.getUTCDay())%7||7)+(target+6)%7;
    if(!m[1]&&offset===0)offset=7;
    dates.push(singaporeDate(new Date(anchor.getTime()+offset*86400000)));
  }
  for(const m of text.matchAll(/(下周|下星期|本周|这周|周|星期)([一二三四五六日天])/g)) {
    const target="日一二三四五六".indexOf(m[2]==="天"?"日":m[2]);
    let offset=(target-anchor.getUTCDay()+7)%7;
    if(m[1].startsWith("下"))offset=((8-anchor.getUTCDay())%7||7)+(target+6)%7;
    dates.push(singaporeDate(new Date(anchor.getTime()+offset*86400000)));
  }
  if(/\bnext week\b|下周|下星期/i.test(text)&&!dates.length)issues.push("Which day next week works for you? Please confirm the Singapore date.");
  for(const m of text.matchAll(/\b(\d{1,2})\s*(?:\/|or|and)\s*(\d{1,2})\s+(January|February|March|April|May|June|July|August|September|October|November|December)(?:\s+(\d{4}))?/gi)) {
    const month=String(months.indexOf(m[3].toLowerCase())+1).padStart(2,"0");
    const first=`${m[4]||year}-${month}-${m[1].padStart(2,"0")}`,second=`${m[4]||year}-${month}-${m[2].padStart(2,"0")}`;
    dates.unshift(first);dates.push(second);
    for(const date of [first,second]){const issue=dateIssue(date,at);if(issue)issues.push(issue);}
  }
  return { dates: Array.from(new Set(dates)), issues: Array.from(new Set(issues)) };
}
export function parseItemList(text: string, serviceType = "install"): IntakeLine[] {
  const lines: IntakeLine[] = [];
  let phase: string | undefined;
  for (const raw of text.split("\n")) {
    const floor = raw.match(/^\s*(?:level|floor)\s+(\d+)\s*$/i);
    if (floor) { phase = `Level ${floor[1]}`; continue; }
    const match = raw.match(/^\s*[-•⁠]?\s*(\d+)\s*[x×]\s*(.+)$/i);
    if (!match) continue;
    const nested = match[2].match(/^(\d+)\s+(.+)$/);
    const name = (nested ? nested[2] : match[2]).replace(/\s*\([^)]*\)\s*$/, "").trim();
    lines.push({ key: `${phase || ""}:${name.toLowerCase()}`, name,
      quantity: nested ? undefined : Number(match[1]), unit: /\bset\b/i.test(name) ? "set" : "item",
      serviceType, phase, ambiguity: nested ? `Does “${match[1]} x ${match[2]}” mean ${nested[1]} individual ${name}, or one set?` : undefined });
  }
  return lines;
}
export function mergeFirstFacts(previous: FirstFacts, update: FirstFacts): FirstFacts {
  const base = update.newJob ? {
    phone: previous.phone, customerName: previous.customerName, customerEmail: previous.customerEmail,
    language: previous.language, previousJobReference: previous.previousJobReference,
  } : previous;
  const result = { ...base, ...Object.fromEntries(Object.entries(update).filter(([,v]) => v !== undefined && v !== null && v !== "")) } as FirstFacts;
  // Turn instructions are not customer facts. Persisting them resets every
  // subsequent name/photo/quantity message into yet another enquiry.
  delete result.newJob;
  delete result.replaceItems;
  delete result.replacementItemKey;
  delete result.removeItemKeys;
  if(update.itemClarification==="")delete result.itemClarification;
  for (const key of ["photos", "productLinks", "manuals", "addOns", "phases"] as const) {
    if (update[key]) result[key] = Array.from(new Set([...(base[key] || []), ...update[key]!]));
  }
  if (update.items) {
    const replaceAll=update.replaceItems&&(base.items?.length||0)<=1;
    const byKey = new Map((replaceAll ? [] : base.items || []).filter(line=>
      line.key!==update.replacementItemKey&&!update.removeItemKeys?.includes(line.key)).map(line => [line.key, line]));
    for (const line of update.items) {
      const identities=Array.from(byKey.values()).filter(old=>!line.separateIdentity&&old.name.trim().toLowerCase()===line.name.trim().toLowerCase()
        &&old.serviceType===line.serviceType&&old.phase===line.phase&&(!old.unit||!line.unit||old.unit===line.unit));
      const old = byKey.get(line.key)||(identities.length===1?identities[0]:undefined);
      const key=old?.key||line.key;
      byKey.set(key, { ...old, ...Object.fromEntries(Object.entries(line).filter(([field,v]) => v !== undefined&&
        !(field==="quantity"&&(!Number.isInteger(v)||Number(v)<=0))&&
        !(field==="serviceType"&&v==="unspecified"&&old?.serviceType&&old.serviceType!=="unspecified"))),key,
        ...(old?.name!==undefined&&old.name!==line.name&&(!line.catalogItemId||line.catalogItemId===old.catalogItemId)?{catalogItemId:undefined}:{}),
        ...(line.quantity && !line.ambiguity ? { ambiguity: old?.ambiguity&&/width|measurement/i.test(old.ambiguity)&&!line.widthEvidence?old.ambiguity:undefined } : {}),
        ...(line.ambiguity&&/width|measurement/i.test(line.ambiguity)&&!line.widthEvidence?{widthEvidence:undefined}:{}) } as IntakeLine);
    }
    result.items = Array.from(byKey.values());
  } else if(update.removeItemKeys?.length) {
    result.items=(base.items||[]).filter(line=>!update.removeItemKeys!.includes(line.key));
  }
  return result;
}
export function scopeHash(facts: FirstFacts): string {
  // Whitelist commercial/document scope. Extraction confidence, chat summaries,
  // attachment counts and scheduling must not invalidate an accepted quote.
  const fields: Array<keyof FirstFacts> = ["customerName", "customerEmail", "jobAddress", "toAddress", "floorLevel", "hasLift",
    "destinationFloor", "destinationLift", "accessNotes", "accessDifficulty", "itemLocation", "serviceType",
    "relocationMode", "distanceKm", "samePropertyMove", "specialNotes", "phases", "extraVisits", "addOns", "promoCode"];
  const scope: Record<string, unknown> = Object.fromEntries(fields.filter(key => facts[key] !== undefined).map(key => [key, facts[key]]));
  scope.items = facts.items?.map(({ key, name, quantity, unit, serviceType, catalogItemId, ambiguity, phase,widthEvidence,itemLocation,relocationMode,samePropertyMove,specialNotes,floorLevel,hasLift,accessNotes,jobAddress,toAddress,destinationFloor,destinationLift }) =>
    ({ key, name, quantity, unit, serviceType, catalogItemId, ambiguity, phase,widthCm:widthEvidence?.cm,relocationMode,samePropertyMove,specialNotes,
      ...Object.fromEntries(Object.entries({floorLevel,hasLift,accessNotes,jobAddress,toAddress,destinationFloor,destinationLift}).filter(([k,v])=>v!==undefined&&v!==(facts as any)[k])),
      ...(itemLocation&&itemLocation!==facts.itemLocation?{itemLocation}:{}) })).sort((a, b) => a.key.localeCompare(b.key));
  return JSON.stringify(scope);
}
export function pricingQuestions(facts: FirstFacts): string[] {
  const questions: string[] = [];
  if(facts.itemClarification)questions.push(facts.itemClarification);
  if (!facts.items?.length) questions.push("Which furniture item needs work? A photo or model helps.");
  for (const line of facts.items || []) {
    if (line.ambiguity) questions.push(line.ambiguity);
    else if (!line.quantity) questions.push(`How many ${line.name}, and is the count individual items or sets?`);
    if (!line.serviceType||line.serviceType==="unspecified") questions.push(`What work is needed for ${line.name}?`);
  }
  const relocation = facts.items?.some(line => line.serviceType === "relocate");
  if (relocation) {
    const moving=facts.items!.filter(line=>line.serviceType==="relocate");
    if(moving.length>1&&moving.some(line=>line.relocationMode)&&moving.some(line=>!line.relocationMode))
      for(const line of moving.filter(line=>!line.relocationMode))questions.push(`For ${line.name}, do you need moving only, dismantling and reassembly, or reassembly of already dismantled items?`);
    else if (!facts.relocationMode&&!moving.every(line=>line.relocationMode)) questions.push("Do you need dismantling and reassembly, moving only, or reassembly of already dismantled items?");
    if(facts.samePropertyMove&&!facts.jobAddress)questions.push("What is the service address for this on-site work?");
    else if (!facts.jobAddress || (!facts.toAddress && !facts.samePropertyMove)) questions.push("What are the pickup and destination addresses?");
    if(facts.movementKind==="room_to_room") {
      if(facts.sameLevel===undefined)questions.push("Are both rooms on the same level, or are stairs involved?");
    } else {
    if (facts.floorLevel === undefined) questions.push(facts.hasLift===undefined?"Which pickup floor, and can the furniture fit in the lift?":"Which pickup floor?");
    else if(facts.hasLift===undefined)questions.push("Is a suitable lift available at pickup?");
    if ((!facts.samePropertyMove||facts.movementKind==="same_building")&&facts.destinationFloor===undefined)questions.push(facts.destinationLift===undefined?"Which destination floor, and is a suitable lift available?":"Which destination floor?");
    else if((!facts.samePropertyMove||facts.movementKind==="same_building")&&facts.destinationLift===undefined)questions.push("Is a suitable lift available at the destination?");
    if(facts.pickupLiftFit==="unknown"||facts.destinationLiftFit==="unknown")
      questions.push("Can the furniture or its dismantled components safely fit in the lift, or would stairs be needed?");
    else if(facts.pickupLiftFit===false||facts.destinationLiftFit===false)
      questions.push("Since the furniture cannot use the lift, which stair route and carrying work will be needed?");
    }
    if (facts.accessDifficulty === undefined) questions.push(facts.samePropertyMove?
      "Are there any steps, narrow passages or difficult carrying sections along the indoor route?":
      "Are there stairs, a long carry, loading-bay restrictions or narrow passages?");
    if (!facts.samePropertyMove && facts.distanceKm === undefined) questions.push("The transport route distance still needs checking.");
  }
  const assemblyItems=(facts.items||[]).filter(item=>item.serviceType==="install"||item.serviceType==="dismantle_install");
  if (!relocation && assemblyItems.length) {
    if(facts.locationClarification)questions.push(facts.locationClarification);
    else if(!facts.itemLocation) {
      if((facts.items?.length||0)>1)for(const item of assemblyItems) {
        if(!item.itemLocation)questions.push(`For ${item.name}, is it in the assembly room, or is carrying needed?`);
      } else questions.push("Is the furniture already in the room where it will be assembled, or must we carry it there?");
    }
  }
  return questions;
}
export function isPriceIntent(text: string): boolean {
  return /\b(price|cost|charge|how much|quote|quotation|estimate)\b|多少钱|报价|费用|价钱/i.test(text);
}
export function isDeferred(text: string): boolean {
  return /(?:send|share|provide|check).{0,25}(?:later|tomorrow|next week)|(?:I['’]?ll|I will).{0,10}send.{0,25}(?:model|photos?|product\s+link|document)|(?:photos?|product\s+links?|documents?|manuals?).{0,25}(?:coming later|to follow)|(?:will|shall).{0,20}(?:get back|update)|稍后|迟点|晚点|明天发|待定|vendor.{0,25}(?:tbc|confirm)/i.test(text);
}
export function safeCoordinatorText(text: string): boolean {
  return !/\b(?:the customer|customer has not|waiting for customer|awaiting customer|human_review_required|qualifying|new_lead|booking_pending|coordination plan|missing facts|ai state|system prompt)\b|客户尚未回复|等待客户输入/i.test(text);
}
