import type {IntakeLine} from "./whatsappFirst";
import {whatsappCatalogSpellingAliases} from "./whatsappCatalogNames";

const families:Array<[RegExp,string]>=[
  [/mattress|床垫/i,"mattresses?|床垫"],
  [/^drawer$|drawer set|set.*drawer/i,"(?:set(?: of)?\\s+)?drawers?|抽屉柜"],
  [/bookshelf|bookshelves|bookcase|书架|书柜/i,"bookshel(?:f|ves)|bookcases?|书架|书柜"],
  [/chest.*drawer|drawer.*chest|斗柜|抽屉柜/i,"chests?(?: of drawers)?|drawer chests?|斗柜|抽屉柜"],
  [/bunk|loft|双层床|三层床/i,"bunk beds?|loft beds?|双层床|三层床"],
  [/wardrobe|衣柜|衣橱/i,"wardrobes?|衣柜|衣橱"],
  [/workstation|cubicle|工位/i,"workstations?|(?:office )?cubicles?|工位"],
  [/desk|table|书桌|桌子/i,"desks?|tables?|书桌|桌子"],
  [/cabinet|cupboard|柜/i,"cabinets?|cupboards?|柜子"],
  [/sofa|沙发/i,"sofas?|沙发"],
  [/bed|床/i,"beds?|床"],
  [/chair|椅/i,"chairs?|椅子"],
  [/bench|长凳/i,"benches|bench|长凳"],
  [/shelf|shelves|rack|货架/i,"shel(?:f|ves)|racks?|货架"],
];
const words=["zero","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve"];
function count(token:string):number|undefined {
  if(/^\d+$/.test(token))return Number(token);
  if(/^(?:a|an|a single)$/i.test(token))return 1;
  const n=words.indexOf(token.toLowerCase());if(n>=0)return n;
  const chinese:Record<string,number>={"零":0,"一":1,"二":2,"两":2,"三":3,"四":4,"五":5,"六":6,"七":7,"八":8,"九":9};
  if(token in chinese)return chinese[token];
  if(token.includes("十")){const [t,u]=token.split("十");return (t?chinese[t]:1)*10+(u?chinese[u]:0);}
}
const escape=(s:string)=>s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&").replace(/\s+/g,"\\s+");
/** A count attached to THIS object, not a dimension, photo count, or another item. */
export function lineQuantityEvidence(text:string,line:IntakeLine,lines:IntakeLine[],previous?:number):{quantity?:number;conflicting?:boolean;ambiguous?:boolean} {
  text=text.normalize("NFKC").split(/\b(?:new job|new request|current job|this job)\b|新订单|这次/gi).at(-1)!;
  text=text.split(/[;\n.]/).filter(s=>!/\b(?:last|previous|completed) job\b|上次|上一单/i.test(s)).join("\n");
  // Connected furniture can contain several family nouns. "One cabinet"
  // still counts a cabinet with an attached desk, provided no other cabinet
  // competes for that evidence. Never borrow another line's count.
  const uniqueFamilies=families.filter(([pattern])=>pattern.test(line.name)&&lines.filter(l=>pattern.test(l.name)).length===1);
  const names=whatsappCatalogSpellingAliases(line.name).map(name=>escape(name)+(/(?:chest|cabinet|desk|chair|workstation)$/.test(name)?"s?":""));
  const noun=`(?:${[...names,...uniqueFamilies.map(([,noun])=>noun)].join("|")})`;
  const token=`(?:a single|${words.slice(1).join("|")}|an|a|\\d{1,4})`;
  const modifier="(?:(?:\\d+[- ](?:drawer|door|person|seater)|single|king|queen|existing|old|additional|extra|another|small|large|dining|leather|teak|modular|mobile)\\s+)*";
  const leading=new RegExp(`\\b(${token})\\s*(?:(x|×|units?|items?|sets?)\\s*(?:of\\s+)?)?${modifier}(${noun})(?=$|[\\s,.;:!?])`,"gi");
  const trailing=new RegExp(`${noun}\\s*(?:x|×|:|qty|quantity|数量)\\s*[:：=]?\\s*(\\d{1,4}|[一二三四五六七八九十两]+)(?:个|件|套|张)?(?=$|[\\s,.;:!?。])`,"gi");
  const chinese=new RegExp(`([一二三四五六七八九十两\\d]+)[个件套张组]\\s*${noun}`,"g");
  const values=new Set<number>();
  // Explicit coordinated singular: one bed frame AND mattress, not a default
  // count borrowed from a bed or a dimension.
  if(/mattress|床垫/i.test(line.name)&&lines.filter(l=>/mattress|床垫/i.test(l.name)).length===1&&
    /\b(?:1|one|a)\s+(?:(?:king|queen|single|double)\s+)?bed(?:\s+frame)?\s*(?:and|\+|with)\s*(?:(?:a|one|1)\s+)?mattress\b/i.test(text))
    values.add(1);
  let negated=false;
  let ambiguous=false;
  const accept=(m:RegExpMatchArray,token:string)=>{
    const before=text.slice(Math.max(0,m.index!-32),m.index);
    if(/(?:\bnot|\bdon't need|\bdo not need|不是|不要)\s*$/i.test(before)){negated=true;return;}
    let n=count(token);
    if(/(?:\badd|\banother|\badditional|\bextra|\balso)\s*$/i.test(before)||/\b(additional|extra|another)\b/i.test(m[0])) {
      if(previous===undefined)return;
      if(n)n+=previous;
    }
    if(n&&Number.isInteger(n)&&n<=10000)values.add(n);
  };
  for(const m of text.matchAll(leading)){
    // An indexed document row "1 Bookshelf Qty: 2" must use Qty, not row 1.
    if(/^\s*(?:qty|quantity|数量)\s*[:：=]?\s*[\d一二三四五六七八九十两]/i.test(text.slice(m.index!+m[0].length)))continue;
    // A plural alone does not distinguish "3-drawer chests" from three chests.
    if(!m[2]&&/^drawer chests?$/i.test(m[3])&&count(m[1])!==1){ambiguous=true;continue;}
    accept(m,m[1]);
  }
  for(const m of text.matchAll(trailing))accept(m,m[1]);
  for(const m of text.matchAll(chinese))accept(m,m[1]);
  if(lines.length===1) {
    const standalone=text.trim().match(new RegExp(`^(${token}|[一二三四五六七八九十两]+)\\s*(?:units?|items?|sets?|个|件|套|张)[.!。]?$`,"i"));
    if(standalone){const n=count(standalone[1]);if(n)values.add(n);}
  }
  return {quantity:values.size===1?Array.from(values)[0]:undefined,
    conflicting:values.size>1||negated&&values.size===0,
    ambiguous:ambiguous&&values.size===0};
}
export function explicitLineQuantity(text:string,line:IntakeLine,lines:IntakeLine[],previous?:number):number|undefined {
  return lineQuantityEvidence(text,line,lines,previous).quantity;
}
