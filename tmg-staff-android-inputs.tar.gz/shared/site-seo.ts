import { PACKAGES } from "./packages";
import { HOME_FAQS } from "./home-faqs";

export const SITE_ORIGIN = "https://tmginstall.com";
export const SITE_IMAGE_ALT = "TMG Install for furniture installation, assembly and dismantling in Singapore";
export const SERVICE_PAGES: Array<{ slug: string; label: string; priority: number }> = [
  { slug: "furniture-installation-singapore", label: "Furniture Installation & Assembly", priority: 0.97 },
  { slug: "office-furniture-installation-singapore", label: "Office Furniture Installation", priority: 0.95 },
  { slug: "office-workstation-installation-singapore", label: "Office Workstation Installation", priority: 0.96 },
  { slug: "furniture-dismantling-singapore", label: "Furniture Dismantling", priority: 0.94 },
  { slug: "wardrobe-dismantling-singapore", label: "Wardrobe Dismantling", priority: 0.93 },
  { slug: "taobao-furniture-installation-singapore", label: "Taobao Furniture Assembly & Installation", priority: 0.82 },
  { slug: "ikea-assembly-singapore", label: "IKEA Assembly Singapore", priority: 0.9 },
  { slug: "wardrobe-installation-singapore", label: "Wardrobe Installation", priority: 0.9 },
  { slug: "bed-assembly-singapore", label: "Bed Assembly Singapore", priority: 0.9 },
  { slug: "tv-mounting-singapore", label: "TV Mounting Singapore", priority: 0.9 },
  { slug: "sofa-assembly-singapore", label: "Sofa Assembly Singapore", priority: 0.9 },
  { slug: "mattress-installation-singapore", label: "Mattress Setup & Disposal", priority: 0.85 },
  { slug: "castlery-furniture-assembly-singapore", label: "Castlery Furniture Assembly", priority: 0.9 },
  { slug: "lazada-furniture-installation-singapore", label: "Lazada Furniture Installation", priority: 0.85 },
  { slug: "shopee-furniture-installation-singapore", label: "Shopee Furniture Installation", priority: 0.85 },
  { slug: "gym-equipment-installation-singapore", label: "Gym Equipment Installation", priority: 0.85 },
  { slug: "furniture-repair-adjustment-singapore", label: "Furniture Repair & Adjustment", priority: 0.8 },
  { slug: "furniture-relocation-singapore", label: "Furniture Relocation", priority: 0.75 },
  { slug: "hdb-moving-services-singapore", label: "HDB Moving Services", priority: 0.7 },
  { slug: "condo-moving-services-singapore", label: "Condo Moving Services", priority: 0.7 },
];
export const GUIDE_PAGES: Array<{ slug: string; label: string; priority: number }> = [
  { slug: "furniture-installation-cost-singapore", label: "Furniture Installation Cost Guide", priority: 0.85 },
  { slug: "ikea-assembly-cost-singapore", label: "IKEA Assembly Cost Guide", priority: 0.85 },
  { slug: "tmg-install-vs-traditional-movers", label: "TMG Install vs Traditional Movers", priority: 0.75 },
  { slug: "hdb-vs-condo-moving-singapore", label: "HDB vs Condo Moving Guide", priority: 0.65 },
];
export const GUIDE_SUMMARIES: Record<string, string> = {
  "furniture-installation-cost-singapore": "See which item, service, access and site details affect a properly scoped installation estimate.",
  "ikea-assembly-cost-singapore": "Prepare the product name, quantities, photos or manual, and access details before requesting an estimate.",
  "tmg-install-vs-traditional-movers": "Compare installation, transport and DIY by the exact work included in each written quotation.",
  "hdb-vs-condo-moving-singapore": "Plan service-lift bookings, building access, permits and timing around staff-confirmed appointments.",
};
export const HOME_SEO = {
  title: "Furniture Installation, Assembly & Dismantling Singapore | TMG Install",
  description: "Furniture installation, assembly and dismantling in Singapore for homes and offices. Send photos or an item list for an itemised quote from TMG Install.",
};
export const SITE_BUSINESS = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "@id": `${SITE_ORIGIN}/#business`,
  name: "TMG Install",
  legalName: "The Moving Guy Pte Ltd",
  url: SITE_ORIGIN,
  telephone: "+6580880757",
  email: "sales@tmginstall.com",
  image: `${SITE_ORIGIN}/og-image.png`,
  address: { "@type": "PostalAddress", addressLocality: "Singapore", addressCountry: "SG" },
  areaServed: { "@type": "Country", name: "Singapore" },
};
export const SITE_WEBSITE = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  "@id": `${SITE_ORIGIN}/#website`,
  name: "TMG Install",
  url: `${SITE_ORIGIN}/`,
  publisher: { "@id": `${SITE_ORIGIN}/#business` },
};
export function homePageJsonLd(): object[] {
  return [
    SITE_BUSINESS,
    SITE_WEBSITE,
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: HOME_FAQS.map(faq => ({
        "@type": "Question",
        name: faq.q,
        acceptedAnswer: { "@type": "Answer", text: faq.a },
      })),
    },
  ];
}

export const PUBLIC_SERVICE_LINKS = [
  { slug: "furniture-installation-singapore", label: "Furniture installation & assembly" },
  { slug: "office-furniture-installation-singapore", label: "Office furniture installation" },
  { slug: "office-workstation-installation-singapore", label: "Office workstation installation" },
  { slug: "furniture-dismantling-singapore", label: "Furniture dismantling" },
  { slug: "wardrobe-dismantling-singapore", label: "Wardrobe dismantling" },
  { slug: "taobao-furniture-installation-singapore", label: "Taobao furniture assembly & installation" },
  { slug: "ikea-assembly-singapore", label: "IKEA furniture assembly" },
  { slug: "furniture-relocation-singapore", label: "Furniture relocation support" },
] as const;

export const PUBLIC_PAGE_SEO: Record<string, { title: string; description: string }> = {
  "/": HOME_SEO,
  "/guides": {
    title: "Furniture Planning Guides Singapore | TMG Install",
    description: "Read TMG Install planning guides for furniture installation costs, IKEA assembly, quotation scope, and HDB or condo access in Singapore.",
  },
  "/estimate": {
    title: "Furniture Installation Quote Singapore | TMG Install",
    description: "Get a furniture installation or dismantling estimate in Singapore. Add items, quantities and access details for office, workstation, wardrobe or Taobao work.",
  },
  "/terms": {
    title: "Service & Booking Terms Singapore | TMG Install",
    description: "Read TMG Install's Singapore service and booking terms, including scope, access, payment, cancellation and installation or dismantling arrangements.",
  },
  "/privacy": {
    title: "Privacy Policy Singapore | TMG Install",
    description: "How TMG Install handles customer details, quote enquiries, booking information and website data for furniture services in Singapore.",
  },
};
for (const pkg of PACKAGES) {
  PUBLIC_PAGE_SEO[`/book/${pkg.id}`] = {
    title: `${pkg.name} Booking Singapore | TMG Install`,
    description: `Request the ${pkg.name} package in Singapore. Review the included scope and share your preferred date and site details before booking confirmation.`,
  };
}

/** Allowlisted marketing pages only. Customer links and unknown routes are private. */
export function publicPageSeo(path: string) {
  return PUBLIC_PAGE_SEO[path];
}

export function shouldNoIndex(path: string): boolean {
  return !publicPageSeo(path) && path !== "/services" &&
    !SERVICE_PAGES.some(page => path === `/services/${page.slug}`) &&
    !GUIDE_PAGES.some(page => path === `/guides/${page.slug}`);
}