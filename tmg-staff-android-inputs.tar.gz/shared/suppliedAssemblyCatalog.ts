// Assembly of supplied, correctly sized furniture only. These explicit names
// reuse approved labour families; they do not include fabrication or lighting.
export const SUPPLIED_ASSEMBLY_DEFINITIONS = [
  {
    name: "Metal Sideboard (standard flat-pack assembly)",
    sku: "METAL-SIDEBOARD-R63-INSTALL",
    sourceSku: "SIDE-BUF-INSTALL",
  },
  {
    name: "Bar Counter (supplied, freestanding assembly)",
    sku: "SUPPLIED-BAR-COUNTER-R63-INSTALL",
    sourceSku: "KIT-BARCNT-INSTALL",
  },
  {
    name: "Bar Chair / Counter Stool (standard assembly)",
    sku: "BAR-CHAIR-R63-INSTALL",
    sourceSku: "BARSTL-INSTALL",
  },
] as const;
