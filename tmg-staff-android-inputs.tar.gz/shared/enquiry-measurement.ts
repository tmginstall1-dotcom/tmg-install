export const ATTRIBUTION_MAX_AGE_MS = 30 * 24 * 60 * 60 * 1000;
export const ATTRIBUTION_VISIT_IDLE_MS = 30 * 60 * 1000;
export const QUALIFICATION_DEFINITION = "A genuine Singapore installation or dismantling enquiry: staff has reviewed the requested work and quantities, a usable customer contact, and suitability or remaining clarification. This is not price approval, payment or appointment confirmation.";
export const campaignFields = ["gclid", "gbraid", "wbraid", "utmSource", "utmMedium", "utmCampaign", "utmTerm", "utmContent"] as const;
export type AttributionSnapshot = {
  consent: "granted" | "denied" | "unknown";
  status: "captured" | "unattributed" | "expired" | "age_unknown" | "invalid";
  capturedAt: string | null;
  ageMs: number | null;
  visitId: string | null;
  source: string | null;
  context: Record<string, string>;
  measurement: "browser evidence; not verified by Google";
};

export function privateSafePath(value: unknown): string | undefined {
  if (typeof value !== "string" || !value) return undefined;
  try {
    const url = new URL(value, "https://tmginstall.com");
    if (!/^https?:$/.test(url.protocol) || url.username || url.password) return undefined;
    return (value.startsWith("/") ? url.pathname : url.origin + url.pathname).slice(0, 512);
  } catch { return undefined; }
}

export function attributionSnapshot(meta: Record<string, unknown> = {}, now = Date.now()): AttributionSnapshot {
  const tagged = campaignFields.some(key => typeof meta[key] === "string" && !!String(meta[key]).trim());
  const captured = typeof meta.attributionCapturedAt === "string" ? Date.parse(meta.attributionCapturedAt) : NaN;
  const lastSeen = typeof meta.attributionLastSeenAt === "string" ? Date.parse(meta.attributionLastSeenAt) : NaN;
  const ageMs = Number.isFinite(captured) ? Math.max(0, now - captured) : null;
  let status: AttributionSnapshot["status"] = tagged ? "captured" : "unattributed";
  if (!tagged && ["expired", "age_unknown", "invalid"].includes(String(meta.attributionRejectedReason))) status = meta.attributionRejectedReason as AttributionSnapshot["status"];
  if (tagged && !Number.isFinite(captured)) status = "age_unknown";
  else if (tagged && (captured > now + 300_000 || !Number.isFinite(lastSeen) || lastSeen < captured || lastSeen > now + 300_000)) status = "invalid";
  else if (tagged && (now - captured > ATTRIBUTION_MAX_AGE_MS || now - lastSeen > ATTRIBUTION_VISIT_IDLE_MS)) status = "expired";
  const context: Record<string, string> = {};
  if (status === "captured") {
    for (const key of campaignFields) if (typeof meta[key] === "string" && String(meta[key]).trim()) context[key] = String(meta[key]).trim().slice(0, key.endsWith("clid") || key.endsWith("braid") ? 512 : 255);
  }
  for (const key of ["landingPage", "referrer", "originatingServicePage"]) {
    const path = privateSafePath(meta[key]);
    if (path) context[key] = path;
  }
  const source = status !== "captured" ? null : context.gclid || context.gbraid || context.wbraid ? "google_ads" : context.utmSource || "campaign_tagged";
  return {
    consent: meta.adMeasurementConsent === "granted" ? "granted" : meta.adMeasurementConsent === "denied" ? "denied" : "unknown",
    status, capturedAt: Number.isFinite(captured) ? new Date(captured).toISOString() : null,
    ageMs, visitId: typeof meta.attributionVisitId === "string" ? meta.attributionVisitId.slice(0, 100) : null,
    source, context, measurement: "browser evidence; not verified by Google",
  };
}

/** Only new intake is sanitised. Never rewrites an old enquiry or guesses its age. */
export function normalizeNewLeadIntake(meta: Record<string, unknown> | null | undefined, now = Date.now()) {
  const result = { ...(meta || {}) };
  const snapshot = attributionSnapshot(result, now);
  for (const key of [...campaignFields, "landingPage", "referrer", "originatingServicePage"]) delete result[key];
  Object.assign(result, snapshot.context);
  result.attributionSnapshot = snapshot;
  return result;
}
