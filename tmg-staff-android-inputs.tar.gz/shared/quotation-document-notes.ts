/** Presentation filtering: never mutate the saved intake/audit or staff notes. */
export function hasGeneratedReviewNotes(q:any) {
  return q?.leadIntake?.source==="whatsapp_first_review" &&
    /^\s*REVIEW DRAFT\s*[—-]\s*NOT A FIXED/i.test(String(q?.notes||""));
}
export function hasHistoricalReviewNotes(q:any) {
  return hasGeneratedReviewNotes(q) && !!q?.leadIntake?.internalAssessment?.at;
}
export function customerQuotationNote(q:any) {
  // Legacy generated blocks contain unprefixed internal questions. Filtering
  // just their first line leaks stale diagnostics. Retain the original in admin.
  return hasGeneratedReviewNotes(q) ? "" : customerDocumentNote(q?.notes);
}
export function isTransportPricingPending(q:any) {
  return isReviewQuotation(q) && Number(q?.transportFee||0)===0 &&
    (q?.leadIntake?.missingCharges||[]).some((reason:unknown)=>
      /address|route|distance|lift|floor|stairs|access|loading|carry|transport/i.test(String(reason)));
}
export function isReviewQuotation(q:any) {
  if(q?.leadIntake?.staffFinalized===true&&q?.leadIntake?.quoteFixed===true&&q?.leadIntake?.approval?.actorId&&!q?.requiresManualReview)return false;
  return !!q?.requiresManualReview || q?.leadIntake?.quoteFixed===false ||
    /^\s*REVIEW DRAFT\s*[—-]\s*NOT A FIXED/i.test(String(q?.notes||""));
}
export function isUnpricedReviewItem(q:any,item:any) {
  return isReviewQuotation(q)&&Number(item?.subtotal||0)===0&&
    (/UNPRICED REVIEW LINE/i.test(String(item?.originalDescription||""))||
      String(item?.remark||"").startsWith("Pending item review:")||
      // Older intake drafts predate the explicit unpriced marker. An absent
      // catalogue rate is not evidence of free work; intentional saved manual
      // zero rates and genuine zero-priced catalogue lines remain unchanged.
      !item?.catalogItemId&&item?.serviceType!=="manual"&&Number(item?.unitPrice||0)===0);
}
export function customerDocumentNote(value:unknown) {
  return String(value||"").split(/\r?\n/).filter(line=>
    !/^\s*(?:REVIEW DRAFT|Pending item review\s*:|internal(?: note| summary| routing)?\s*[:—-]|review reason\s*:|missing (?:facts|fields|measurements)\s*:|photo clarification\s*:|ai (?:confidence|diagnostic)|lead (?:routing|priority)\s*:)/i.test(line)).join("\n").trim();
}
