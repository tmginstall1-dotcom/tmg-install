/** Operational requirements only: no customer pricing or financial state. */
export const INSTALL_CHECKLIST = [
  "Verify customer name & job reference", "Confirm items list with customer",
  "Inspect items for existing damage", "Complete each item's stated work scope",
  "Leave the work area tidy within the agreed scope", "Walk-through completed with customer",
  "Customer confirms satisfaction",
];
export const RELOCATION_PICKUP_CHECKLIST = [
  "Verify customer name & job reference", "Floor protection laid at pickup",
  "All items photographed before moving (condition record)", "Items wrapped / padded as needed",
  "Lift padded (if applicable)", "All items loaded into vehicle",
];
export const RELOCATION_DROPOFF_CHECKLIST = [
  "Floor protection laid at dropoff", "Items unloaded & placed as per customer instruction",
  "Reinstalled / reassembled where applicable", "Packaging removed / disposed",
  "Walk-through completed with customer", "Customer confirms satisfaction",
];
export function completionChecklist(relocation:boolean) {
  return relocation ? [...new Set([...RELOCATION_PICKUP_CHECKLIST,...RELOCATION_DROPOFF_CHECKLIST])] : INSTALL_CHECKLIST;
}
export function staffChecklistVisibility(job:any, relocation:boolean) {
  const pending=job.status==="evidence_pending"||job.completion?.status==="evidence_pending";
  return {
    show:pending||(relocation?["at_pickup","in_transit","at_dropoff","completed"]:["in_progress","completed"]).includes(job.status),
    dropoff:relocation&&(pending||["at_dropoff","completed"].includes(job.status)),
  };
}
export const historicalWorkEndStates = ["completed","closed","final_paid"];
export function completionEvidenceState(q:any) {
  const proof=q?.leadIntake?.completionProof;
  const submitted=["completed","closed","final_paid","final_payment_requested"].includes(q?.status)
    && proof?.protocol===1 && proof?.jobId===q.id && proof?.stage==="completed"
    && Number.isInteger(proof.eventId) && proof.photos?.length>0 && !!proof.signatureSha256;
  return {
    status:submitted?"submitted":historicalWorkEndStates.includes(q?.status)?"evidence_pending":"not_submitted",
    submittedAt:submitted?proof.submittedAt:null, actorId:submitted?proof.actorId:null,
    photoCount:submitted?proof.photos.length:0,
    adminConfirmation:q?.leadIntake?.adminCompletionConfirmation?.protocol===1
      ?q.leadIntake.adminCompletionConfirmation:null,
    missing:submitted?[]:["Completion-stage photos verified and saved","Completed work checklist","Customer name and sign-off"],
  };
}
export function staffWorkStage(q:any) {
  if(["final_paid","closed"].includes(q.status))
    return completionEvidenceState(q).status==="submitted"?"completed":"evidence_pending";
  if(q.status==="final_payment_requested"){
    if(completionEvidenceState(q).status==="submitted")return "completed";
    const history=[...(q.updates||[])].sort((a:any,b:any)=>+new Date(b.createdAt)-+new Date(a.createdAt));
    return history.find((u:any)=>["in_progress","at_pickup","in_transit","at_dropoff"].includes(u.statusChange))?.statusChange
      ||(q.assignedStaffId||q.assignedTeamId?"assigned":"booked");
  }
  return q.status;
}
