export const ENTERTAINMENT_FEATURE_WALL_NAMES = {
  standard: "Entertainment Feature Wall (up to 200 cm)",
  large: "Entertainment Feature Wall (201–300 cm)",
  extraLarge: "Entertainment Feature Wall (301–400 cm / glass cabinets)",
  oversized: "Entertainment Feature Wall (over 400 cm / custom)",
} as const;

export type EntertainmentFeatureWallTier = keyof typeof ENTERTAINMENT_FEATURE_WALL_NAMES;

export interface EntertainmentFeatureWallDetection {
  name: string;
  widthCm?: number | null;
  fullHeight?: boolean;
  hasGlassCabinets?: boolean;
}

const FEATURE_WALL_PATTERN =
  /\b(entertainment feature wall|entertainment wall|media feature wall|media wall|tv wall unit|television wall unit|full[- ]height entertainment unit)\b/i;

export function classifyEntertainmentFeatureWall(
  detection: EntertainmentFeatureWallDetection,
): string | null {
  const exactTier = Object.values(ENTERTAINMENT_FEATURE_WALL_NAMES)
    .find(name => name.toLowerCase() === detection.name.trim().toLowerCase());
  if (exactTier) return exactTier;
  if (!FEATURE_WALL_PATTERN.test(detection.name)) return null;

  const widthCm = Number(detection.widthCm);
  if (Number.isFinite(widthCm) && widthCm > 0) {
    if (widthCm > 400) return ENTERTAINMENT_FEATURE_WALL_NAMES.oversized;
    if (widthCm > 300) return ENTERTAINMENT_FEATURE_WALL_NAMES.extraLarge;
    if (widthCm > 200) return ENTERTAINMENT_FEATURE_WALL_NAMES.large;
    return ENTERTAINMENT_FEATURE_WALL_NAMES.standard;
  }

  // Product photos do not always print dimensions. Two full-height glass
  // display towers imply the same assembly/handling complexity as the 3–4 m
  // tier; a full-height wall system without glass defaults to the middle tier.
  if (detection.fullHeight && detection.hasGlassCabinets) {
    return ENTERTAINMENT_FEATURE_WALL_NAMES.extraLarge;
  }
  if (detection.fullHeight || detection.hasGlassCabinets) {
    return ENTERTAINMENT_FEATURE_WALL_NAMES.large;
  }
  return ENTERTAINMENT_FEATURE_WALL_NAMES.standard;
}

export const ENTERTAINMENT_FEATURE_WALL_VISION_GUIDE = `
ENTERTAINMENT / TV WALL SYSTEMS — SIZE AND CONSTRUCTION DETERMINE THE CATALOG TIER:
- "TV Console" means ONLY a low freestanding cabinet, usually 40–60 cm tall. Do not use it for a full-height wall system.
- An entertainment feature wall has a central TV-console section plus tall side towers, overhead cabinets, shelving, display cabinets, or a full-height connected carcass.
- Read printed dimensions from product-listing images. Treat the printed TOTAL width as widthCm, not the width of only the centre console.
- Use these exact catalog names:
  • total width up to 200 cm → "${ENTERTAINMENT_FEATURE_WALL_NAMES.standard}"
  • total width 201–300 cm → "${ENTERTAINMENT_FEATURE_WALL_NAMES.large}"
  • total width 301–400 cm, or a full-height system with two glass display towers when width is unavailable → "${ENTERTAINMENT_FEATURE_WALL_NAMES.extraLarge}"
  • total width over 400 cm or clearly bespoke/custom-built → "${ENTERTAINMENT_FEATURE_WALL_NAMES.oversized}"
- Glass-door towers, integrated lighting, many hinged doors/drawers, and a 220 cm full-height carcass are part of ONE feature-wall item, not separate cheap TV consoles.
- Example: a listing marked 360 cm total width × 220 cm high with a 200 cm centre TV cabinet and two 80 cm glass-door side cabinets is ONE "${ENTERTAINMENT_FEATURE_WALL_NAMES.extraLarge}", quantity 1.
`;