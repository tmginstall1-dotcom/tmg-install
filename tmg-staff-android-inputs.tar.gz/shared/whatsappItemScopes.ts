import type {FirstFacts} from "./whatsappFirst";
/** Item-bound text evidence; a sofa's route must never become a bed's route. */
export function applyItemScopes(facts:FirstFacts,text:string):FirstFacts {
 const items=facts.items?.map(i=>({...i}));
 if(!items?.length)return facts;
 for(const clause of text.split(/[;；。\n]|(?:\bplus\b|\band also\b)/i)) {
   const named=items.filter(i=>clause.toLowerCase().includes(i.name.toLowerCase())||
     [/sofa|沙发/i,/bed|床/i,/cabinet|cupboard|柜/i,/workstation|工位/i].some(r=>r.test(clause)&&r.test(i.name)));
   if(named.length!==1)continue;
   const item=named[0];
   if(/dismantl.{0,40}reassembl|拆.{0,12}装/i.test(clause))item.relocationMode="full";
   else if(/(?:transport|carry|move|moving).{0,30}(?:only|no (?:assembly|dismantl))|只搬/i.test(clause)&&
     !/no (?:need )?(?:to )?carry|don't need.{0,10}carry|不需要搬|不用搬/i.test(clause)) {
     item.relocationMode="carry";item.serviceType="relocate";
   }
   if(/(?:between|to|another).{0,15}rooms?|room.to.room|same (?:level|home|property)|同.{0,3}(?:屋|层)|另一个房间/i.test(clause)) {
     item.samePropertyMove=true;
     if(item.relocationMode)item.serviceType="relocate";
   }
   else if(/between.{0,12}(?:houses|homes|addresses)|different (?:address|house)|两.{0,3}(?:地址|住家)/i.test(clause))item.samePropertyMove=false;
 }
 const moving=items.filter(i=>i.serviceType==="relocate");
 const external=moving.filter(i=>i.samePropertyMove===false);
 const routed={...facts};
 if(external.length===1)for(const key of ["jobAddress","toAddress","floorLevel","hasLift","destinationFloor","destinationLift"] as const) {
   if(routed[key]===undefined&&external[0][key]!==undefined)(routed as any)[key]=external[0][key];
 }
 return {...routed,items,...(moving.some(i=>i.samePropertyMove===false)?{samePropertyMove:false}:{}),
   ...(moving.length===1&&moving[0].relocationMode?{relocationMode:moving[0].relocationMode}:{})};
}
