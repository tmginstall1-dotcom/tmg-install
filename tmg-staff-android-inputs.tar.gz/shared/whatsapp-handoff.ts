import { z } from "zod";

export const TMG_BUSINESS_PHONE = "6580880757";

export const handoffItemSchema = z.object({
  name: z.string().min(1).max(500),
  quantity: z.number().int().min(1).max(9999),
  requiresReview: z.boolean().optional(),
  dimensions: z.string().max(300).optional(),
  details: z.string().max(2000).optional(),
  productLink: z.string().max(2000).optional(),
});

export const handoffPayloadSchema = z.object({
  source: z.string().min(1).max(40).default("estimate_step5"),
  services: z.array(z.string().min(1).max(40)).max(8).default([]),
  serviceLabels: z.array(z.string().min(1).max(60)).max(8).default([]),
  pickupAddress: z.string().max(300).optional().default(""),
  dropoffAddress: z.string().max(300).optional().default(""),
  serviceAddress: z.string().max(300).optional().default(""),
  isRelocation: z.boolean().default(false),
  liftAvailable: z.string().max(20).optional().default(""),
  floorLevel: z.string().max(20).optional().default(""),
  stairsAnswer: z.string().max(20).optional().default(""),
  items: z.array(handoffItemSchema).max(50).default([]),
  slotDate: z.string().max(40).optional().default(""),
  slotLabel: z.string().max(60).optional().default(""),
  estimatedTotal: z.number().min(0).max(1_000_000).optional(),
  requiresReview: z.boolean().optional(),
  customerName: z.string().max(120).optional().default(""),
  customerPhone: z.string().max(40).optional().default(""),
  customerEmail: z.string().max(160).optional().default(""),
  promoCode: z.string().max(40).optional().default(""),
  pageContext: z.string().max(120).optional().default(""),
  originatingServicePage: z.string().max(512).optional().default(""),
  // Lead-quality metadata (labels, already humanized by the client). Optional
  // so existing callers keep working unchanged.
  leadIntent: z.string().max(60).optional().default(""),
  leadIntents: z.array(z.string().max(60)).max(7).optional().default([]),
  urgency: z.string().max(30).optional().default(""),
  itemCountRange: z.string().max(30).optional().default(""),
  siteType: z.string().max(30).optional().default(""),
  roomType: z.string().max(40).optional().default(""),
  productLink: z.string().max(1000).optional().default(""),
  cartonCount: z.number().int().min(0).max(10000).optional(),
  manualsAvailable: z.string().max(20).optional().default(""),
  requestedScope: z.array(z.string().max(40)).max(8).optional().default([]),
  officeDetails: z.array(z.string().max(80)).max(8).optional().default([]),
  detectedCategory: z.string().max(60).optional().default(""),
  jobPriority: z.string().max(20).optional().default(""),
  recommendedSalesPath: z.string().max(60).optional().default(""),
});

export type HandoffPayload = z.infer<typeof handoffPayloadSchema>;
export type HandoffItem = z.infer<typeof handoffItemSchema>;

function joinNonEmpty(parts: Array<string | false | null | undefined>, sep = "\n"): string {
  return parts.filter((p): p is string => Boolean(p && p.length)).join(sep);
}

function formatItems(items: HandoffItem[]): string {
  if (!items.length) return "";
  const max = 8;
  const visible = items.slice(0, max).map(i => joinNonEmpty([
    `\u2022 ${i.name} \u00d7${i.quantity}${i.requiresReview ? " — pricing pending team review" : ""}`,
    i.dimensions ? `  Dimensions: ${i.dimensions}` : "",
    i.details ? `  Details: ${i.details}` : "",
    i.productLink ? `  Product: ${i.productLink}` : "",
  ]));
  if (items.length > max) visible.push(`\u2022 \u2026 +${items.length - max} more`);
  return visible.join("\n");
}

function formatAccess(p: HandoffPayload): string {
  const bits: string[] = [];
  if (p.liftAvailable) bits.push(`lift: ${p.liftAvailable}`);
  if (p.floorLevel) bits.push(`floor: ${p.floorLevel}`);
  if (p.stairsAnswer) bits.push(`stairs: ${p.stairsAnswer}`);
  return bits.join(", ");
}

/**
 * Canonical formatter for the WhatsApp handoff message. Used both client-side
 * (to build the wa.me URL the customer actually opens) and server-side (to log
 * the same text into the admin inbox/audit trail). Keep formatting identical
 * across callers so the admin sees exactly what the customer sees.
 */
export function buildHandoffMessage(payload: HandoffPayload): string {
  const services = payload.serviceLabels.length
    ? payload.serviceLabels.join(", ")
    : payload.services.join(", ");

  const address = payload.isRelocation
    ? joinNonEmpty([
        payload.pickupAddress ? `Pickup: ${payload.pickupAddress}` : "",
        payload.dropoffAddress ? `Dropoff: ${payload.dropoffAddress}` : "",
      ])
    : (payload.serviceAddress ? `Address: ${payload.serviceAddress}` : "");

  const access = formatAccess(payload);
  const intentText = payload.leadIntents.length
    ? payload.leadIntents.join(", ")
    : payload.leadIntent;
  const intentLine = intentText
    ? `${payload.leadIntents.length > 1 ? "Job types" : "Job type"}: ${intentText}`
    : "";
  const detailBits: string[] = [];
  if (payload.originatingServicePage) detailBits.push(`service page: ${payload.originatingServicePage}`);
  if (payload.urgency) detailBits.push(`urgency: ${payload.urgency}`);
  if (payload.itemCountRange) detailBits.push(`items: ${payload.itemCountRange}`);
  if (payload.siteType) detailBits.push(`site: ${payload.siteType}`);
  const detailLine = detailBits.length ? `Details: ${detailBits.join(", ")}` : "";
  const areaLine = payload.roomType ? `Room / work area: ${payload.roomType}` : "";
  const productLine = payload.productLink ? `Product link: ${payload.productLink}` : "";
  const cartonLine = payload.cartonCount != null
    ? `Packing: ${payload.cartonCount} carton${payload.cartonCount === 1 ? "" : "s"}${payload.manualsAvailable ? `, manuals: ${payload.manualsAvailable}` : ""}`
    : (payload.manualsAvailable ? `Assembly manuals: ${payload.manualsAvailable}` : "");
  const scopeLine = payload.requestedScope.length ? `Requested scope: ${payload.requestedScope.join(", ")}` : "";
  const officeLine = payload.officeDetails.length ? `Office details: ${payload.officeDetails.join(", ")}` : "";
  const itemsBlock = formatItems(payload.items);
  const slotLine = payload.slotLabel ? `Preferred date/time (staff confirmation required): ${payload.slotLabel}` : "";
  const totalLine = typeof payload.estimatedTotal === "number" && payload.estimatedTotal > 0
    ? `${payload.requiresReview ? "Priced portion only; complete price pending review" : "Estimated total"}: $${payload.estimatedTotal.toFixed(2)}`
    : "";
  const promoLine = payload.promoCode ? `Promo applied: ${payload.promoCode}` : "";
  const nameLine = payload.customerName ? `Name: ${payload.customerName}` : "";
  const phoneLine = payload.customerPhone ? `Phone: ${payload.customerPhone}` : "";
  const emailLine = payload.customerEmail ? `Email: ${payload.customerEmail}` : "";

  return joinNonEmpty([
    "Hi TMG Install \u2014 I started a quote on your site and would like to confirm:",
    "",
    services ? `Service: ${services}` : "",
    intentLine,
    detailLine,
    address,
    access ? `Access: ${access}` : "",
    areaLine,
    productLine,
    cartonLine,
    scopeLine,
    officeLine,
    slotLine,
    "",
    itemsBlock ? "Items:" : "",
    itemsBlock,
    "",
    totalLine,
    promoLine,
    "",
    nameLine,
    phoneLine,
    emailLine,
    "",
    "I can also send photos of my furniture for a more accurate quote.",
  ]);
}

export function buildHandoffWaUrl(payload: HandoffPayload, businessPhone: string = TMG_BUSINESS_PHONE): string {
  const text = buildHandoffMessage(payload);
  return `https://wa.me/${businessPhone}?text=${encodeURIComponent(text)}`;
}
