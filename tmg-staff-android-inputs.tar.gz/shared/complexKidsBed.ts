export const TRIPLE_BUNK_LOFT_BED_NAME =
  "Triple Bunk / Loft Bed with Desk, Storage & Top Cabinet";

export interface ComplexKidsBedDetection {
  name: string;
  sleepingCapacity?: number | null;
  hasDesk?: boolean;
  hasStorage?: boolean;
  hasStairStorage?: boolean;
  hasTopCabinet?: boolean;
}

const TRIPLE_BED_PATTERN =
  /\b(triple|three[- ]?person|three[- ]?sleeper|3[- ]?person)\b.*\b(bunk|loft|bed)\b|\b(bunk|loft)\b.*\b(triple|three[- ]?person|three[- ]?sleeper|3[- ]?person)\b/i;

export function classifyComplexKidsBed(
  detection: ComplexKidsBedDetection,
): string | null {
  if (detection.name.trim().toLowerCase() === TRIPLE_BUNK_LOFT_BED_NAME.toLowerCase()) {
    return TRIPLE_BUNK_LOFT_BED_NAME;
  }

  const isBunkOrLoft = /\b(bunk|loft|high bed)\b/i.test(detection.name);
  const hasThreeSleepingPlaces = Number(detection.sleepingCapacity) >= 3;
  const isTriple = TRIPLE_BED_PATTERN.test(detection.name) || hasThreeSleepingPlaces;
  const fullIntegratedSystem =
    detection.hasDesk === true &&
    detection.hasStorage === true &&
    detection.hasTopCabinet === true &&
    (detection.hasStairStorage === true || isTriple);

  return isBunkOrLoft && (isTriple || fullIntegratedSystem)
    ? TRIPLE_BUNK_LOFT_BED_NAME
    : null;
}

export const COMPLEX_KIDS_BED_VISION_GUIDE = `
COMPLEX KIDS' BUNK / LOFT BEDS — CONFIGURATION DETERMINES THE CATALOG TIER:
- "Bunk Bed (with Storage Drawers)" is only for a normal two-tier bunk with built-in drawers or a storage staircase. Do not use it for an integrated three-person bedroom system.
- Use "${TRIPLE_BUNK_LOFT_BED_NAME}" for ONE connected system with three sleeping places (for example an upper single bunk above a lower double bed) AND combinations of a desk, storage staircase, drawers/shelves, wardrobe section, or an overhead/top cabinet.
- This complex integrated system is ONE catalog item, quantity 1 — do not split the top bunk, lower bed, desk, drawers, stairs, and cabinet into cheap separate items.
- Look for printed listing text such as "three-person bed", "triple bunk", "upper/lower three-person bed", or "100 cm + top cabinet". Count sleeping places, not visible bed frames.
- When returning this item, include sleepingCapacity, hasDesk, hasStorage, hasStairStorage, and hasTopCabinet in the JSON whenever they are visible.
`;