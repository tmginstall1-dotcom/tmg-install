/** Read-only money projection. Receipt visibility is NOT allocation authority. */
export function financialBasis(q:any) {
  const cents=(n:any)=>Math.round(Number(n)*100);
  const rows=Array.isArray(q?.payments)?q.payments:[];
  let gross=0,refunds=0,credit=0,applied=0,prior=0,unallocated=0;
  for(const r of rows) {
    const n=cents(r.amount);
    if(!Number.isFinite(n))continue;
    const noncash=["credit","noncash_credit","waiver"].includes(r.method);
    const cash=n>0&&!noncash,refund=n<0&&r.method==="stripe_refund";
    if(noncash&&n>0)credit+=n;
    if(cash)gross+=n;
    if(refund)refunds-=n;
    const eligible=q?.leadIntake?.coordinatorRelease
      ?r.quoteVersion===q.version||q.version===1&&r.quoteVersion==null
      :r.quoteVersion!==0;
    if(eligible&&(cash||refund))applied+=n;
    if(!eligible&&(cash||refund)) {
      if(r.quoteVersion===0||r.quoteVersion==null)unallocated+=n;
      else prior+=n;
    }
  }
  // No new allocation policy: retain old receipts and hold collection until
  // existing authority establishes their application to the proposed revision.
  const reconciliationRequired=prior!==0||unallocated!==0;
  const accepted=q?.termsAcceptedAt&&q.termsAcceptedVersion===q.version&&
    Math.abs(Number(q.termsAcceptedAmount)-Number(q.total))<.005
    ?{version:q.version,total:Number(q.termsAcceptedAmount)}
    :q?.leadIntake?.acceptedFinancialBasis;
  const acceptedCredit=accepted?rows.reduce((sum:number,r:any)=>{
    const n=cents(r.amount);
    return sum+(r.quoteVersion===accepted.version&&Number.isFinite(n)&&
      (n>0&&!["credit","noncash_credit","waiver"].includes(r.method)||n<0&&r.method==="stripe_refund")?n:0);
  },0):0;
  const acceptedBalance=accepted&&Number.isFinite(Number(accepted.total))&&
    !(accepted.version===q.version&&reconciliationRequired)
    ?Math.max(0,cents(accepted.total)-acceptedCredit)/100:null;
  return {grossReceived:gross/100,settledRefunds:refunds/100,
    priceReductions:Math.round((Number(q?.discount||0)+Number(q?.promoDiscount||0)+Number(q?.goodwillDiscount||0))*100)/100,
    netReceived:(gross-refunds)/100,noncashCredits:credit/100,
    applied:Math.max(0,applied)/100,priorRevisionNet:prior/100,
    unallocatedNet:unallocated/100,reconciliationRequired,
    acceptedVersion:accepted?.version??null,acceptedTotal:accepted?.total??null,
    acceptedBalance,proposedTotal:Number(q?.total)||0,
    message:"Earlier-revision or unallocated funds need staff reconciliation. Review the original receipt and accepted agreement in payment activity; do not request payment again."};
}
