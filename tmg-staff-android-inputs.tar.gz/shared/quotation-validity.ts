export type OfferStatus = "draft" | "valid" | "expired" | "review" | "accepted" | "withdrawn" | "superseded";
export type OfferValidity = {
  status: OfferStatus;
  message: string;
  issuedAt?: string;
  expiresAt?: string;
  policyLabel?: string;
};
export function offerActionAllowed(value?: OfferValidity): boolean {
  return value?.status === "valid" || value?.status === "accepted";
}
export function offerDate(value?: string): string {
  if (!value) return "Not established";
  return new Intl.DateTimeFormat("en-SG", {
    timeZone: "Asia/Singapore", year:"numeric",month:"short",day:"numeric",
    hour:"2-digit",minute:"2-digit",second:"2-digit",fractionalSecondDigits:3,
    hourCycle:"h23",timeZoneName:"short",
  }).format(new Date(value));
}
