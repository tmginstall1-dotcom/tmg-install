// =============================================================================
// TMG Install — Central Pricing Engine
// All tunable constants live in PricingConfig. Never scatter magic numbers.
// =============================================================================

// --------------------------------------------------------------------------
// Configuration
// --------------------------------------------------------------------------
export const PricingConfig = {
  callout: {
    fee: 39.90,   // SGD — applied to every non-relocation job (replaces the old $180 minimum)
  },
  fallback: {
    dismantleMultiplier: 0.6,        // dismantle       = install * 0.6 when no catalog entry
    relocateMultiplier: 1.5,         // relocate        = install * 1.5 when no catalog entry
    disposeMultiplier: 0.65,         // dispose-only    = install * 0.65 when no catalog entry
    dismantleDisposeMultiplier: 0.95, // dismantle+dispose bundle = install * 0.95 when no catalog entry
    dismantleInstallMultiplier: 0.96, // dismantle+reinstall bundle = install * (1+0.6) * (1-40%) when no catalog entry
    genericFallback: 150,            // SGD per unit when absolutely no catalog price found
    relocateDRDiscount: 0.40,        // D&R labor discount for relocation — 40% off install+dismantle (bundled with transport)
    drCarryFallbackMultiplier: 0.90, // When install/dismantle prices missing: D&R = Carry × this (~bundle-discounted equivalent)
    reinstallOnlyCarryFallbackMultiplier: 0.45, // When install price missing: Reinstall-only = Carry × this (~half the D&R fallback — assembly at destination only)
  },
  bulkDiscount: [
    { minQty: 100, pct: 0.15 },
    { minQty: 50,  pct: 0.10 },
    { minQty: 10,  pct: 0.05 },
    { minQty: 1,   pct: 0.00 },
  ] as { minQty: number; pct: number }[],
  // Per-hole line items (e.g. "Walk-in / Built-in Wardrobe (per hole)") are
  // priced per drilled hole, so a single 120-hole job is really one wardrobe,
  // not 120 separate items. To stop a single wardrobe from instantly hitting
  // the 100+ tier, each per-hole unit is weighted at 1/5 of a regular item
  // when picking the bulk-discount tier. Example: 120 holes → 24 weighted
  // → falls in the 10+ tier (5%) instead of the 100+ tier (15%).
  perHoleBulkWeight: 0.2,
  floor: {
    perFloorNoLift: 15,   // SGD per floor above ground without lift
    perFloorWithLift: 5,  // SGD per floor above ground with lift
  },
  access: {
    mediumPct: 0.10, // +10% of labor-after-discount
    hardPct: 0.20,   // +20% of labor-after-discount
  },
  transport: {
    vanBase: 28,        // Base fare (includes first 3 km)
    helperFee: 30,      // Driver + 1 helper surcharge (standard for furniture jobs)
    includedKm: 3,      // First 3 km included in van base fare
    ratePerKm: 0.50,    // Per km after first 3 km
    cbdSurcharge: 5,    // CBD area surcharge (Mon–Sat 6:30am–8:30pm)
    get minFee() { return this.vanBase + this.helperFee; }, // $58 minimum
  },
  overtime: {
    // Overtime is measured against each job's own SCHEDULED crew-hours (derived
    // from the job scope — see getJobSchedule), not a flat window. capMinutes is
    // only a fallback when no per-job schedule is supplied.
    capMinutes: 120,    // Fallback included minutes when no scheduled time is given
    blockMinutes: 30,   // Charge in 30-minute blocks once the scheduled time is used up
    // Live rate is computed per job as crewSize × overtime.perPersonHourlyRate
    // ($50 per mover, per hour) → e.g. 2 movers = $50 per 30-min block, 3 movers = $75.
    perPersonHourlyRate: 50, // SGD per mover, per hour beyond scheduled crew time
    blockRate: 30,      // Legacy 2-crew default (unused by live calc); rate now scales with crew size
    // NO cap — every extra hour is fully recovered at $50 per mover per hour.
  },
  hiace: {
    capacityM3: 6.0,  // Toyota Hiace usable cargo volume per trip (cubic metres)
  },
  multiStop: {
    // Multi-stop relocation — flat fee charged for every stop BEYOND the first
    // pickup and the first drop-off. Singapore June-2026 market: full-service
    // movers ~$50/extra location, app platforms +$8–$17/stop. TMG is van/budget
    // tier, so $30 sits sensibly between the two. ONE configurable constant —
    // never hard-code the per-stop fee inline.
    additionalStopFee: 30, // SGD per extra stop
  },
  carryHandling: {
    // Tiered per-cubic-metre crew labour fee for Carry Only jobs, on top of
    // the transport fee. Transport covers van + 2 movers for up to 2 hours,
    // which is fine for a few items — but a large carry load (many items,
    // multiple trips) burns real crew time the transport fee alone doesn't
    // recover. Tiered rate keeps small Singapore jobs price-competitive with
    // Lalamove-style services while still recovering crew time on big multi-
    // trip moves. Only counts volume from non-special-handling carry-only
    // items (special-handling SKUs already keep their full catalog rate).
    //
    // Tier breakdown — applied as a marginal rate (like income tax bands):
    //   0.00 – 2.00 m³  →  $10 / m³   (small carries, competitive)
    //   2.00 – 5.00 m³  →  $15 / m³   (mid-size loads)
    //   5.00 m³+        →  $20 / m³   (big multi-trip jobs)
    perM3: 20, // legacy field kept for backwards compatibility; tiered rate below is the source of truth
    tiers: [
      { upTo: 2,        ratePerM3: 10 },
      { upTo: 5,        ratePerM3: 15 },
      { upTo: Infinity, ratePerM3: 20 },
    ] as Array<{ upTo: number; ratePerM3: number }>,
  },
  wrapping: {
    // Optional bubble-wrap & corner-protection charge per item. Customer can
    // tick "Wrap this item" on any line in the estimate wizard; we charge a
    // flat $10 per wrapped UNIT (i.e. $10 × quantity). Covers materials +
    // wrap time on site.
    perItem: 10,
  },
  deposit: {
    pct: 0.50, // 50% deposit, 50% final
    // Site-wide rule: jobs cheaper than this threshold must be paid IN FULL to
    // confirm the booking (no 50/50 split). Jobs at or above it keep the usual
    // 50% deposit now + 50% final after the job is done.
    fullPaymentThreshold: 150,
  },
  secondDay: {
    // Second-Day Continuation — when a single-day job spills into the next day
    // because of on-site access delays (loading-bay parking, lift congestion).
    // The crew has to be re-dispatched (van + movers) and a fresh slot burned.
    returnFee: 120,            // SGD flat re-mobilisation fee charged once when the job continues to Day 2
    perPersonHourlyRate: 50,   // SGD per mover, per hour of actual Day-2 on-site time ($50/person/hr; matches the overtime rate)
    defaultCrewSize: 2,        // standard van crew = 2 movers; admin can raise this per job for bigger teams
    hourlyRate: 100,           // legacy effective 2-man rate (perPersonHourlyRate × defaultCrewSize) — kept for back-compat
  },
  splitJob: {
    // Same-day split timing — e.g. dismantle in the morning, reinstall in the
    // evening. If the gap between two on-site sessions on the SAME Singapore day
    // is longer than this, the crew effectively makes a second trip, so one
    // standard mobilisation fee (callout.fee = $39.90) is added per extra trip.
    // Second-day continuation (the next calendar day) is handled separately above
    // at the higher $120 re-mobilisation rate.
    sameDayGapHours: 3,
  },
  // --------------------------------------------------------------------------
  // Cost-floor / margin guard — the "never lose money" safety net.
  // --------------------------------------------------------------------------
  // We estimate the real cost of running a job (crew time × loaded hourly cost
  // + the van/fuel portion of transport) and work out the lowest price that
  // still leaves the target profit margin. If a quote is priced below that
  // floor, the engine FLAGS it for admin review (warn-only — it never silently
  // changes the customer's price). All numbers are tunable here.
  //
  // The loaded mover cost is based on TMG's own crew cost rate ($30/mover/hour)
  // so the floor is grounded in real business numbers, not guesses. This is a
  // COST basis and is independent of the customer-facing overtime rate (which is
  // higher — see overtime.perPersonHourlyRate).
  costFloor: {
    enabled: true,
    marginPct: 0.30,             // target profit as a % of price (30% = aggressive/competitive)
    loadedMoverHourlyCost: 30,   // SGD — fully-loaded cost per mover per hour (wages + on-costs)
    defaultCrewSize: 2,          // standard van crew
    absoluteMinJobPrice: 0,      // SGD — no hard minimum; TMG takes small jobs too. Margin guard still applies.
    enforce: false,              // false = warn only (admin decides); true = would auto-raise
    // Crew-time estimate model (hours):
    baseHours: 1.0,              // fixed setup + load/unload + paperwork per job
    hoursPerM3: 0.6,             // handling time per cubic metre carried
    hoursPerDRItem: 0.75,        // extra time per dismantle-&-reinstall (relocate) item
    hoursPerCarryItem: 0.15,     // extra time per carry-only relocate item
    hoursPerLaborItem: 0.4,      // extra time per install / dismantle / dispose item
    travelHoursPerKm: 0.04,      // round-trip driving + buffer (~25 km/h effective)
  },
};

// --------------------------------------------------------------------------
// Bulk-discount weighting helper
// --------------------------------------------------------------------------
// Per-hole units (e.g. wall-hung wardrobes priced per drilled hole) shouldn't
// flood the bulk-discount tier table — a single 120-hole wardrobe is one job,
// not 120 items. This helper applies the perHoleBulkWeight to such lines so
// tier selection reflects "true item count" rather than physical hole count.
// --------------------------------------------------------------------------
// Full-payment threshold helper
// --------------------------------------------------------------------------
// Single source of truth for the "small job = pay in full" rule used across the
// pricing engine, server routes, emails and UI. A job whose grand total is below
// this threshold must be paid IN FULL up front to confirm the booking; there is
// no separate final payment. Jobs at or above it keep the 50% deposit + 50%
// final split.
export const FULL_PAYMENT_THRESHOLD = PricingConfig.deposit.fullPaymentThreshold;

/** True when a job total is small enough that it must be paid in full up front. */
export function requiresFullUpfront(total: number): boolean {
  const t = typeof total === "number" ? total : parseFloat(String(total ?? 0));
  return isFinite(t) && t > 0 && t < FULL_PAYMENT_THRESHOLD;
}

export function bulkWeightedQty(items: { name: string; quantity: number }[]): number {
  const w = PricingConfig.perHoleBulkWeight;
  return items.reduce((sum, it) => {
    const isPerHole = /per hole/i.test(it.name || "");
    return sum + (it.quantity || 0) * (isPerHole ? w : 1);
  }, 0);
}

// --------------------------------------------------------------------------
// Reconciled quote-total helper
// --------------------------------------------------------------------------
// SINGLE SOURCE OF TRUTH for the formula that recomputes a quote's grand total
// from its stored parts when it is edited. `editQuote` (server/storage.ts) and
// the reconciliation tests must both go through this helper so the test asserts
// the REAL production arithmetic and can never silently drift from it.
//
//   total = subtotal − discount − promo − goodwill + transportFee + secondDayFee
//           + additionalTripCharge + afterOfficeSurcharge
//
// where, for a multi-stop quote, subtotal = laborSubtotal and the transportFee
// column holds the FULL logistics bucket (transport + volumetric + extra-stop
// fee = logisticsSubtotal). additionalTripCharge (e.g. split dismantle/reinstall
// timing) and afterOfficeSurcharge (work continuing past the office cutoff) are
// flat per-job add-ons that flow through to balance/PayNow/Stripe like the
// second-day fee. The result is clamped at 0 and rounded to cents.
export interface QuoteTotalParts {
  subtotal: number;        // sum of non-discount line items (labour for multi-stop)
  transportFee?: number;   // transportFee column = logisticsSubtotal for multi-stop
  discount?: number;       // stored bulk / service discount
  promoDiscount?: number;
  goodwillDiscount?: number;
  secondDayFee?: number;
  additionalTripCharge?: number;
  afterOfficeSurcharge?: number;
}

// The customer wizard charges bubble-wrap protection INSIDE the logistics
// bucket (transportFee column) but ALSO persists a visible "Wrapping
// Protection (N units)" roll-up line item so admins/crew can see the charge.
// That roll-up line is DISPLAY-ONLY: any code that recomputes the quote
// subtotal from line items MUST exclude it, or the wrapping fee gets counted
// twice (once in subtotal, once inside transportFee) and the total jumps on
// every edit/save. Single source of truth for identifying that line:
export function isWrappingRollupLine(name: string | null | undefined): boolean {
  return /^wrapping protection\b/i.test((name || "").trim());
}

export function reconcileQuoteTotal(parts: QuoteTotalParts): number {
  const subtotal = Number(parts.subtotal) || 0;
  const transportFee = Number(parts.transportFee) || 0;
  const discount = Number(parts.discount) || 0;
  const promoDiscount = Number(parts.promoDiscount) || 0;
  const goodwillDiscount = Number(parts.goodwillDiscount) || 0;
  const secondDayFee = Number(parts.secondDayFee) || 0;
  const additionalTripCharge = Number(parts.additionalTripCharge) || 0;
  const afterOfficeSurcharge = Number(parts.afterOfficeSurcharge) || 0;
  return round2(
    Math.max(
      0,
      subtotal - discount - promoDiscount - goodwillDiscount + transportFee + secondDayFee
        + additionalTripCharge + afterOfficeSurcharge,
    ),
  );
}

// --------------------------------------------------------------------------
// Deposit / balance helpers — SINGLE SOURCE OF TRUTH for settlement math
// --------------------------------------------------------------------------
// The customer-facing deposit, final amount and outstanding balance were
// previously recomputed inline across many server routes and the email layer,
// so a rule change could silently miss a surface. These helpers centralise the
// arithmetic so every surface (Stripe links, WhatsApp, email, invoice PDF,
// admin views) and the reconciliation tests share one rule and can never drift.
//
// All three respect the site-wide full-payment threshold: jobs below it are paid
// IN FULL up front (deposit = total, final = 0), so they never carry a final
// balance even on stale/legacy rows. Jobs at/above it keep the 50% deposit +
// 50% final split.

/**
 * Split a grand total into the up-front deposit and the remaining final amount.
 * Returns both values as 2-decimal strings ready for storage.
 */
export function splitDepositFinal(grandTotal: number): { depositAmount: string; finalAmount: string } {
  const totalCents = isFinite(grandTotal) && grandTotal > 0 ? Math.round(grandTotal * 100) : 0;
  const depositCents = requiresFullUpfront(totalCents / 100)
    ? totalCents : Math.round(totalCents * PricingConfig.deposit.pct);
  // Round the initial amount ONCE, then take the exact remaining cents.
  // Independently formatting two unrounded halves can collect a cent too much
  // or too little on odd-cent totals.
  return { depositAmount: (depositCents / 100).toFixed(2), finalAmount: ((totalCents - depositCents) / 100).toFixed(2) };
}

/**
 * Resolve the effective deposit baseline for a quote when the stored
 * depositAmount is missing/zero (legacy or manually-created rows). Small jobs are
 * paid in full up front (deposit = total), so the fallback must NOT be a naive
 * 50% split for those — otherwise an under-threshold job with no stored amounts
 * would wrongly appear to still owe a balance.
 */
export function depositPaidFallback(total: number, storedDeposit?: string | null): number {
  const t = isFinite(total) && total > 0 ? total : 0;
  // Threshold is the source of truth: under-threshold jobs are ALWAYS paid in
  // full up front, so the upfront charge must equal the total even if a
  // stale/legacy or manually-entered split is stored on the row. Only fall back
  // to the stored deposit (then the configured percentage) for jobs at/above it.
  if (requiresFullUpfront(t)) return t;
  const stored = parseFloat(storedDeposit || "0");
  if (stored > 0) return stored;
  return t * PricingConfig.deposit.pct;
}

/**
 * Single source of truth for the outstanding FINAL balance on a quote.
 * Under-threshold jobs are normally paid in full up front, so they usually have
 * no final balance and we return 0. EXCEPTION: when a surcharge/add-on is added
 * AFTER full payment (e.g. an on-site item or an after-office fee) the total is
 * raised above the amount actually collected, reopening a genuine balance even
 * though the new total is still under the threshold. We detect that by a real
 * recorded deposit that no longer covers the (raised) total — a normal
 * full-upfront job has deposit == total and stays at 0, and legacy rows with no
 * stored deposit also stay at 0. For jobs at/above the threshold we use the
 * stored finalAmount (or total − deposit), then subtract any partial payments
 * already recorded in the ledger.
 */
export function finalBalanceOutstanding(
  total: number,
  storedFinal?: string | null,
  storedDeposit?: string | null,
  ledgerPaid: number = 0,
  ledgerIncludesInitial: boolean = false,
): number {
  const t = isFinite(total) && total > 0 ? total : 0;
  if(ledgerIncludesInitial)return Math.max(0,Math.round((t-Math.max(0,Number.isFinite(ledgerPaid)?ledgerPaid:0))*100)/100);
  const storedFin = parseFloat(storedFinal || "0");
  const rawDeposit = parseFloat(storedDeposit || "0");
  // A surcharge added after a small job was paid in full reopens a real balance:
  // the recorded deposit is a genuine, positive amount that no longer covers the
  // now-higher total. Only then do we skip the full-upfront short-circuit.
  const reopenedUnderThreshold =
    requiresFullUpfront(t) && rawDeposit > 0.005 && rawDeposit < t - 0.005;
  if (requiresFullUpfront(t) && !reopenedUnderThreshold) return 0;
  const deposit = reopenedUnderThreshold ? rawDeposit : depositPaidFallback(t, storedDeposit);
  const baseBalance = storedFin > 0 ? storedFin : Math.max(0, t - deposit);
  const paid = isFinite(ledgerPaid) && ledgerPaid > 0 ? ledgerPaid : 0;
  return Math.max(0, baseBalance - paid);
}

/**
 * True when a quote is settled in a single up-front payment (no 50/50 split):
 * either it is under the full-payment threshold, or the stored deposit already
 * covers the whole total (e.g. a manually fully-paid job). Used by display
 * surfaces to swap "deposit + balance" wording for "payable in full".
 */
export function isFullPaymentQuote(total: number | string | null | undefined, deposit?: number | string | null): boolean {
  const t = Number(total) || 0;
  const d = Number(deposit) || 0;
  return requiresFullUpfront(t) || (t > 0 && d >= t - 0.005);
}

// --------------------------------------------------------------------------
// Input / output types
// --------------------------------------------------------------------------

export type ServiceType = 'install' | 'dismantle' | 'relocate' | 'dispose' | 'dismantle_dispose' | 'dismantle_install';

export interface PricingCatalogEntry {
  name: string;
  serviceType: ServiceType;
  basePrice: number;
}

export interface PricingItem {
  name: string;
  serviceType: ServiceType;
  quantity: number;
  unitPrice: number; // 0 = no catalog price available (will trigger fallback)
  volumeM3?: number; // cubic metres per unit (optional — used for trip calculation)
  carryOnly?: boolean; // Carry-only relocate flag (informational; per-item labor still charged from catalog basePrice). Skips fallback so unmatched carry items default to $0 instead of generic estimate.
  sku?: string; // Optional catalog SKU — used to detect SPECIAL_HANDLING items so the carry-cap rule can skip them.
  wrap?: boolean; // Customer opted in to bubble-wrap protection for this item. Charged $10 × quantity via wrapping fee.
}

export interface PricingFloor {
  level: number; // floor number (0 = ground)
  hasLift: boolean;
}

export interface PricingInput {
  items: PricingItem[];
  needsRelocation: boolean;
  floors: PricingFloor[];
  accessDifficulty: 'easy' | 'medium' | 'hard';
  distanceKm: number;
  catalogEntries?: PricingCatalogEntry[]; // full catalog for fallback multiplier lookup
  /**
   * Same-Property Move — items are physically shifted within the SAME address
   * (e.g. between rooms, between floors of the same condo, during a renovation).
   *
   * When true, the engine:
   *   • adds the $39.90 mobilisation & coordination fee (crew still needs to be
   *     dispatched even though no transport is involved), AND
   *   • SKIPS the transport / distance fee entirely (no van rental, no km charge),
   *   • but KEEPS the $20/m³ carry-handling fee for carry-only items so heavy
   *     shifts still pay for the crew labour they consume.
   *
   * `needsRelocation` should also be true so the existing per-item carry / D&R
   * pricing branches continue to apply.
   */
  samePropertyMove?: boolean;
  /**
   * Multi-stop relocation — number of stops BEYOND the first pickup and first
   * drop-off, i.e. (pickups − 1) + (dropoffs − 1), clamped at 0. Default 0 so
   * single-leg quotes produce exactly the same numbers as before.
   */
  extraStops?: number;
}

export interface ItemLine {
  name: string;
  serviceType: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  fallbackUsed: boolean;
  volumeM3?: number;
}

export interface FeeLine {
  label: string;
  amount: number;
}

/**
 * Result of the cost-floor / margin check for a job. `belowFloor` is the signal
 * that a quote would not make the target margin — the UI surfaces this as a
 * warning so the admin can raise the price or accept it knowingly.
 */
export interface JobMargin {
  enabled: boolean;
  estimatedHours: number;   // estimated crew-hours for the job
  crewSize: number;         // movers assumed
  estimatedCost: number;    // crew labour + vehicle cost (SGD)
  marginFloor: number;      // cost / (1 - targetMargin)
  absoluteMin: number;      // hard minimum job price
  costFloor: number;        // max(absoluteMin, marginFloor) — the safe minimum price
  grandTotal: number;       // what the job is actually priced at
  belowFloor: boolean;      // true = priced below the safe minimum (loss risk)
  shortfall: number;        // how far below the floor (0 if healthy)
  marginPct: number;        // target margin used
  actualMarginPct: number;  // realised margin at the current price
}

export interface PricingResult {
  itemLines: ItemLine[];
  feeLines: FeeLine[];
  discountLine: { label: string; amount: number } | null;
  laborSubtotal: number;
  logisticsSubtotal: number;
  volumetricFee: number;        // per-m³ handling portion of logisticsSubtotal (0 if none)
  discountAmount: number;
  grandTotal: number;
  depositAmount: number;
  finalAmount: number;
  requiresAdminReview: boolean;
  reviewReasons: string[];
  // Volume / trip data
  totalVolumeM3: number;        // sum of all item volumes (0 if no volume data)
  numTrips: number;             // Toyota Hiace trips needed (1 if no volume data)
  hasVolumeData: boolean;       // true if at least one item has volumeM3
  margin: JobMargin;            // cost-floor / margin guard result
}

// --------------------------------------------------------------------------
// Helpers
// --------------------------------------------------------------------------

function round2(n: number): number {
  if (!isFinite(n) || isNaN(n)) return 0;
  return Math.round(n * 100) / 100;
}

/**
 * Second-Day Continuation charge.
 *
 * Used when a job scheduled for a single day cannot finish and the crew must
 * return the next day because of on-site access delays (loading-bay parking,
 * lift congestion, etc.). The charge has two parts:
 *   • a flat return / re-mobilisation fee (van + crew re-dispatch + fresh slot)
 *   • an hourly charge for the actual Day-2 crew time worked
 * Hours are recorded after Day 2 finishes, so the admin never has to guess the
 * duration up front.
 */
export function calcSecondDayContinuation(enabled: boolean, hours: number | string, crewSize?: number | string) {
  const cfg = PricingConfig.secondDay;
  // Crew size is admin-adjustable per job (bigger jobs go out with more movers).
  // Falls back to the standard 2-man van crew so old quotes keep their pricing.
  const crew = Math.max(1, Math.round(Number(crewSize) || cfg.defaultCrewSize));
  // Effective hourly rate = per-mover rate × number of movers on Day 2.
  const hourlyRate = round2(cfg.perPersonHourlyRate * crew);
  if (!enabled) {
    return { enabled: false, returnFee: 0, hours: 0, crewSize: crew, perPersonHourlyRate: cfg.perPersonHourlyRate, hourlyRate, labour: 0, fee: 0 };
  }
  const h = Math.max(0, Number(hours) || 0);
  const labour = round2(h * hourlyRate);
  return {
    enabled: true,
    returnFee: cfg.returnFee,
    hours: h,
    crewSize: crew,
    perPersonHourlyRate: cfg.perPersonHourlyRate,
    hourlyRate,
    labour,
    fee: round2(cfg.returnFee + labour),
  };
}

/* -------------------------------------------------------------------------- */
/* On-Site Time Clock                                                         */
/* -------------------------------------------------------------------------- */

/** One on-site session, recorded when staff tap "Arrived" / "Going off site". */
export interface SiteVisit {
  arrivedAt: string;       // ISO timestamp when staff arrived on site
  leftAt?: string | null;  // ISO timestamp when they went off site (null = still on site)
  byUserId?: number;       // staff user who recorded it
}

export interface SiteTimeVisit {
  arrivedAt: string;
  leftAt: string | null;
  hours: number;           // closed-session duration in hours (0 while still on site)
  open: boolean;           // true = on site now (no leftAt yet)
}

export interface SiteTimeDay {
  date: string;            // YYYY-MM-DD in Singapore time
  label: string;           // e.g. "Mon, 8 Jun"
  dayNumber: number;       // 1 = first day on site, 2 = next day, ...
  visits: SiteTimeVisit[];
  hours: number;           // total closed-session hours that day
}

export interface SiteTimeSummary {
  days: SiteTimeDay[];
  day1Hours: number;       // hours on the first on-site day
  secondDayHours: number;  // total hours on every day AFTER the first
  totalHours: number;      // all on-site hours
  hasOpenVisit: boolean;   // someone is currently checked in on site
  spansMultipleDays: boolean;
}

const SITE_TZ = "Asia/Singapore";

function sgDateKey(iso: string): string {
  // en-CA renders as YYYY-MM-DD, which sorts correctly as a string.
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: SITE_TZ, year: "numeric", month: "2-digit", day: "2-digit",
  }).format(new Date(iso));
}

function sgDateLabel(iso: string): string {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: SITE_TZ, weekday: "short", day: "numeric", month: "short",
  }).format(new Date(iso));
}

const DAY_MS = 24 * 60 * 60 * 1000;

// Singapore is a fixed UTC+8 with no daylight saving, so the start of any SGT
// calendar day is an exact instant and every SGT day is exactly 24h long.
function sgDayStartMs(dateKey: string): number {
  return new Date(`${dateKey}T00:00:00.000+08:00`).getTime();
}

/**
 * Group raw on-site sessions into per-day totals (Singapore time).
 *
 * Day 1 is the first calendar date the crew was on site; any later date counts
 * toward Second-Day Continuation. A session that runs past midnight is split at
 * the Singapore day boundary so each day gets only the hours actually worked
 * that day (e.g. 23:00–01:00 → 1h on Day 1, 1h on Day 2). Open sessions (no
 * leftAt yet) contribute 0 hours until the staff member taps "Going off site".
 */
export function computeSiteTime(visits?: SiteVisit[] | null): SiteTimeSummary {
  const list = Array.isArray(visits) ? visits.filter(v => v && v.arrivedAt) : [];
  const sorted = [...list].sort(
    (a, b) => new Date(a.arrivedAt).getTime() - new Date(b.arrivedAt).getTime(),
  );

  // Accumulate raw (unrounded) hours per SGT day, plus per-day display segments.
  const byDate = new Map<string, SiteTimeDay>();
  let hasOpenVisit = false;

  const ensureDay = (dateKey: string, anchorIso: string): SiteTimeDay => {
    let day = byDate.get(dateKey);
    if (!day) {
      day = { date: dateKey, label: sgDateLabel(anchorIso), dayNumber: 0, visits: [], hours: 0 };
      byDate.set(dateKey, day);
    }
    return day;
  };

  for (const v of sorted) {
    const open = !v.leftAt;
    if (open) {
      hasOpenVisit = true;
      const key = sgDateKey(v.arrivedAt);
      ensureDay(key, v.arrivedAt).visits.push({ arrivedAt: v.arrivedAt, leftAt: null, hours: 0, open: true });
      continue;
    }

    const startMs = new Date(v.arrivedAt).getTime();
    const endMs = new Date(v.leftAt!).getTime();
    if (!(endMs > startMs)) {
      // Zero / negative duration — record as a 0h segment on the arrival day.
      const key = sgDateKey(v.arrivedAt);
      ensureDay(key, v.arrivedAt).visits.push({ arrivedAt: v.arrivedAt, leftAt: v.leftAt!, hours: 0, open: false });
      continue;
    }

    // Walk the session day-by-day in SGT, clipping to each day's boundary.
    let cursor = startMs;
    while (cursor < endMs) {
      const cursorIso = new Date(cursor).toISOString();
      const key = sgDateKey(cursorIso);
      const nextBoundary = sgDayStartMs(key) + DAY_MS;
      const segEnd = Math.min(endMs, nextBoundary);
      const hrs = (segEnd - cursor) / 3_600_000;
      const day = ensureDay(key, cursorIso);
      day.visits.push({
        arrivedAt: new Date(cursor).toISOString(),
        leftAt: new Date(segEnd).toISOString(),
        hours: round2(hrs),
        open: false,
      });
      day.hours += hrs;
      cursor = segEnd;
    }
  }

  const days = Array.from(byDate.values()).sort((a, b) => (a.date < b.date ? -1 : 1));
  days.forEach((d, i) => { d.dayNumber = i + 1; d.hours = round2(d.hours); });

  const day1Hours = days[0]?.hours ?? 0;
  const secondDayHours = round2(days.slice(1).reduce((s, d) => s + d.hours, 0));
  const totalHours = round2(days.reduce((s, d) => s + d.hours, 0));

  return { days, day1Hours, secondDayHours, totalHours, hasOpenVisit, spansMultipleDays: days.length > 1 };
}

/** Minutes since Singapore midnight for an ISO instant. */
function sgMinutesOfDay(iso: string): number {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: SITE_TZ, hour: "2-digit", minute: "2-digit", hour12: false,
  }).formatToParts(new Date(iso));
  const h = Number(parts.find(p => p.type === "hour")?.value || "0");
  const m = Number(parts.find(p => p.type === "minute")?.value || "0");
  return h * 60 + m;
}

/** Parse a "HH:mm" cutoff into minutes-since-midnight (defaults to 17:30 = 5:30pm). */
function parseHHmm(s?: string | null): number {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(s || "").trim());
  if (!m) return 17 * 60 + 30;
  return Number(m[1]) * 60 + Number(m[2]);
}

export interface TimingFlags {
  sameDaySplit: boolean;    // a same-day gap longer than the threshold between sessions
  extraTrips: number;       // number of qualifying same-day gaps (each = one extra mobilisation)
  longestGapHours: number;  // the largest qualifying same-day gap, in hours (0 if none)
  afterOffice: boolean;     // any on-site session ran past the after-office cutoff
  spansMultipleDays: boolean;
  totalHours: number;
  secondDayHours: number;
}

/**
 * Inspect the on-site sessions and flag the situations that carry a surcharge so
 * the admin can review and confirm them:
 *   • a SAME-DAY split (two sessions on one SGT day with a gap > sameDayGapHours)
 *     → the crew makes an extra mobilisation trip,
 *   • work running past the after-office cutoff (default 17:30 / 5:30pm SGT).
 * Pure/derived — it never mutates anything and never bills on its own.
 */
export function detectTimingFlags(
  visits?: SiteVisit[] | null,
  opts?: { sameDayGapHours?: number; afterOfficeCutoff?: string },
): TimingFlags {
  const gapHours = Number(opts?.sameDayGapHours ?? PricingConfig.splitJob.sameDayGapHours) || 3;
  const cutoffMin = parseHHmm(opts?.afterOfficeCutoff);
  const summary = computeSiteTime(visits);

  // Closed sessions only, grouped by SGT calendar day, in start order.
  const closed = (Array.isArray(visits) ? visits : [])
    .filter(v => v && v.arrivedAt && v.leftAt)
    .map(v => ({ start: new Date(v.arrivedAt).getTime(), end: new Date(v.leftAt!).getTime(), arrivedAt: v.arrivedAt, leftAt: v.leftAt! }))
    .filter(v => v.end > v.start)
    .sort((a, b) => a.start - b.start);

  const byDay = new Map<string, typeof closed>();
  for (const v of closed) {
    const key = sgDateKey(v.arrivedAt);
    const arr = byDay.get(key) || [];
    arr.push(v);
    byDay.set(key, arr);
  }

  let extraTrips = 0;
  let longestGapMs = 0;
  for (const arr of Array.from(byDay.values())) {
    for (let i = 1; i < arr.length; i++) {
      const gapMs = arr[i].start - arr[i - 1].end;
      if (gapMs > gapHours * 3_600_000) {
        extraTrips += 1;
        if (gapMs > longestGapMs) longestGapMs = gapMs;
      }
    }
  }

  const afterOffice = closed.some(
    v => sgMinutesOfDay(v.leftAt) > cutoffMin || sgMinutesOfDay(v.arrivedAt) >= cutoffMin,
  );

  return {
    sameDaySplit: extraTrips > 0,
    extraTrips,
    longestGapHours: round2(longestGapMs / 3_600_000),
    afterOffice,
    spansMultipleDays: summary.spansMultipleDays,
    totalHours: summary.totalHours,
    secondDayHours: summary.secondDayHours,
  };
}

/**
 * Compute the Dismantle & Reinstall (D&R) price for a relocation item.
 *
 * Business logic:
 *   • D&R = (install + dismantle) × (1 - relocateDRDiscount)   — 40% off bundle deal.
 *     This is INTENTIONALLY discounted: customer commits to the full service
 *     (dismantle + transport + reinstall) and gets a combo rate.
 *   • Carry Only is priced separately by raw weight/labor — it can be HIGHER
 *     than D&R for heavy 2-man items like king bed frames or massage chairs,
 *     because the customer skips assembly work but pays for pure heavy carry.
 *   • Fallback: if install/dismantle prices are missing, D&R ≈ carry × 0.90
 *     (still bundle-discounted relative to standalone carry).
 *
 * @param installPrice    Catalog install price (omit if not present)
 * @param dismantlePrice  Catalog dismantle price (omit if not present)
 * @param carryPrice      Catalog relocate (Carry Only) price
 */
/**
 * SKUs of items that physically WON'T fit in a standard HDB lift when intact,
 * OR require 3+ movers, OR need special handling (corner protection, hoist, etc.).
 *
 * For these items we cannot quote a "carry-and-go" price honestly — the
 * customer needs an on-site survey. The catalog UI shows a clear warning
 * badge instead of just a price.
 */
export const SPECIAL_HANDLING_SKUS: ReadonlySet<string> = new Set([
  // Won't fit in standard HDB / condo lift when intact
  "KB-RELOCATE",            // King bed frame intact (~2m × 2.1m)
  "PAX-RELOCATE",           // IKEA Pax wardrobe intact
  "LSOFA-RELOCATE",         // L-shaped / corner sofa
  "L-DESK-RELOCATE",        // L-shaped executive desk
  "CT-RELOCATE",            // Conference table
  "CT-01",                  // Conference table (alt SKU)

  // Heavy 2–3 man + corner protection / floor protection
  "MASS-RELOCATE",          // Massage chair (premium models 80–130 kg)
  "FRIDGE4-RELOCATE",       // 4-door French refrigerator
  "STND-RELOCATE",          // Sit-stand desk (motor unit, fragile)

  // Specialty — always needs survey
  "PIANO-UP-RELOCATE",      // Upright piano
  "PIANO-GR-RELOCATE",      // Grand piano
  "POOL-RELOCATE",          // Pool / billiard table
  "SAFE-RELOCATE",          // Safe / gun safe
  "PHONE-BOOTH-RELOCATE",   // Solo phone booth
  "DUO-BOOTH-RELOCATE",     // Duo phone booth
  "POD4-RELOCATE",          // 4-person meeting pod

  // Large kitchen islands
  "IKEA-KI-M-RELOCATE",     // Medium kitchen island
  "IKEA-KI-L-RELOCATE",     // Large kitchen island
]);

/**
 * Returns true if the given SKU needs a site survey / special handling.
 * The UI should show a "Won't fit in lift / needs survey" badge instead of
 * presenting the carry-only price as a casual walk-and-go option.
 */
export function requiresSpecialHandling(sku?: string | null): boolean {
  if (!sku) return false;
  return SPECIAL_HANDLING_SKUS.has(sku);
}

export function computeDRPrice(installPrice?: number, dismantlePrice?: number, carryPrice?: number): number {
  const cfg = PricingConfig.fallback;
  if (installPrice && dismantlePrice) {
    return round2((installPrice + dismantlePrice) * (1 - cfg.relocateDRDiscount));
  }
  // No install/dismantle data — fall back to carry × multiplier (still bundle-discounted)
  const carry = carryPrice && carryPrice > 0 ? carryPrice : 0;
  return round2(carry * cfg.drCarryFallbackMultiplier);
}

/**
 * "Already dismantled" relocation pricing (relocateMode 'reinstall_only').
 *
 * The customer's item is already dismantled, so we skip the dismantle charge
 * entirely and bill only the reinstallation (assembly at destination) at the
 * full install catalog rate. There is NO 40% bundle discount here — that
 * discount is specifically for the dismantle + reinstall PAIR.
 *
 * When the install catalog price is missing, fall back to carry ×
 * reinstallOnlyCarryFallbackMultiplier (half of the D&R carry fallback,
 * since only the assembly half of the work happens).
 */
export function computeReinstallOnlyPrice(installPrice?: number, carryPrice?: number): number {
  const cfg = PricingConfig.fallback;
  if (installPrice && installPrice > 0) return round2(installPrice);
  const carry = carryPrice && carryPrice > 0 ? carryPrice : 0;
  return round2(carry * cfg.reinstallOnlyCarryFallbackMultiplier);
}

/**
 * Single source of truth for the "no promo stacking on relocation" rule.
 *
 * The Dismantle-&-Reinstall (D&R) bundle rate ("Relocation: D&R bundle rate
 * applied — 40% off install + dismantle combined") is itself a promotional
 * discount. Per company policy a general promo code (e.g. TMG50) CANNOT be
 * combined with it. This returns true when the cart contains at least one
 * relocate item priced on the D&R bundle (relocateMode 'full', which is also
 * the default when no mode is set). Carry-only relocations get NO bundle
 * discount, so they are not blocked here and may still use a promo code.
 *
 * Every surface that applies a promo (customer wizard server route, the
 * /api/promo/validate endpoint, and the Estimate UI) must consult this helper
 * so the rule is enforced identically and a promo never stacks on the bundle.
 */
export function relocationBundleBlocksPromo(
  items: { serviceType?: string | null; relocateMode?: string | null }[],
): boolean {
  return items.some(
    (i) =>
      i.serviceType === "relocate" &&
      i.relocateMode !== "carry" &&
      // "Already dismantled" (reinstall-only) items get NO bundle discount —
      // they pay the full install rate — so they don't block promo codes.
      i.relocateMode !== "reinstall_only",
  );
}

/**
 * Effective Carry-Only price.
 *
 * Rule: for normal items, Carry Only labour is $0 — the transport fee
 * already includes a 2-man crew for up to 2 hours (see PricingConfig.
 * overtime.capMinutes), so charging per-item labour on top double-bills
 * the customer. The job IS fundamentally "van + 2 movers loading and
 * unloading"; no extra per-item work happens in carry mode.
 *
 * Heavy / oversized items in SPECIAL_HANDLING_SKUS (king bed, PAX,
 * L-sofa, massage chair, piano, fridge, etc.) keep their catalog rate
 * because they genuinely need a 3rd mover, corner protection, hoisting,
 * or specialty equipment that goes beyond the standard 2-man crew.
 *
 * (installPrice and dismantlePrice are accepted for backward compat with
 * the previous D&R-cap signature but are no longer used.)
 */
export function effectiveCarryPrice(
  _installPrice: number | undefined,
  _dismantlePrice: number | undefined,
  carryPrice: number,
  sku?: string | null,
): number {
  if (!(carryPrice > 0)) return 0;
  if (requiresSpecialHandling(sku)) return round2(carryPrice);
  // Normal item — labour is bundled into the transport fee.
  return 0;
}

/** Transport pricing — 2.4m Van (Toyota Hiace), Singapore
 *  Base $28 (first 3 km) + $0.50/km after + $30 helper = $58 minimum
 */
export function calcTransportFee(distanceKm: number): number {
  const cfg = PricingConfig.transport;
  const extraKm = Math.max(0, distanceKm - cfg.includedKm);
  const rawFee = cfg.vanBase + cfg.helperFee + extraKm * cfg.ratePerKm;
  return round2(Math.max(cfg.minFee, rawFee));
}

/** Number of Toyota Hiace trips needed for a given total volume (min 1). */
export function calcNumTrips(totalVolumeM3: number): number {
  const vol = isFinite(totalVolumeM3) && totalVolumeM3 > 0 ? totalVolumeM3 : 0;
  if (vol <= 0) return 1;
  return Math.max(1, Math.ceil(vol / PricingConfig.hiace.capacityM3));
}

/**
 * Tiered per-m³ volumetric handling fee (marginal bands, like income-tax).
 * Single source of truth so both computePricing and the multi-stop admin
 * helper produce identical numbers.
 */
export function calcVolumetricHandlingFee(volumeM3: number): number {
  const vol = isFinite(volumeM3) && volumeM3 > 0 ? volumeM3 : 0;
  if (vol <= 0) return 0;
  let remaining = vol;
  let prevCap = 0;
  let rawFee = 0;
  for (const tier of PricingConfig.carryHandling.tiers) {
    if (remaining <= 0) break;
    const bandSize = tier.upTo - prevCap;
    const taken = Math.min(remaining, bandSize);
    rawFee += taken * tier.ratePerM3;
    remaining -= taken;
    prevCap = tier.upTo;
  }
  return round2(rawFee);
}

// Quote lines do not store a volume. Resolve relocation volume from the
// catalog identity (or one unambiguous exact relocate name) before charging it.
// An unresolved line must not silently become a zero-volume free carry.
export function relocationVolumeFromCatalog(
  items: Array<{ serviceType: string; quantity?: number; catalogItemId?: number | null; detectedName?: string | null; originalDescription?: string | null }>,
  catalog: Array<{ id: number; name: string; serviceType: string; volumeM3?: string | number | null; active?: boolean | null }>,
): { volumeM3: number; volumetricFee: number; unresolved: string[] } {
  let volumeM3 = 0;
  const unresolved: string[] = [];
  for (const item of items) {
    if (item.serviceType !== "relocate" ||
        isWrappingRollupLine(item.detectedName) || isWrappingRollupLine(item.originalDescription)) continue;
    const name = (item.detectedName || item.originalDescription || "").replace(/\s*\(wrapped\)\s*$/i, "").trim();
    const byId = item.catalogItemId != null
      ? catalog.find(c => c.id === item.catalogItemId && c.serviceType === "relocate")
      : undefined;
    const matches = !byId ? catalog.filter(c =>
      c.active !== false && c.serviceType === "relocate" && c.name.trim().toLowerCase() === name.toLowerCase()) : [];
    const row = byId || (matches.length === 1 ? matches[0] : undefined);
    const unitVolume = Number(row?.volumeM3);
    const quantity = item.quantity ?? 1;
    if (!Number.isFinite(unitVolume) || unitVolume <= 0 ||
        !Number.isInteger(Number(quantity)) || Number(quantity) < 1) {
      unresolved.push(name || "Unnamed item");
      continue;
    }
    volumeM3 += unitVolume * Number(quantity);
  }
  volumeM3 = round2(volumeM3);
  return { volumeM3, volumetricFee: calcVolumetricHandlingFee(volumeM3), unresolved };
}

/**
 * Multi-stop additional-stop fee. `extraStops` = stops beyond the first pickup
 * and first drop-off, i.e. (pickups − 1) + (dropoffs − 1), clamped at 0.
 * Single configurable rate lives in PricingConfig.multiStop.additionalStopFee.
 */
export function calcAdditionalStopFee(extraStops: number): number {
  const n = Math.max(0, Math.floor(extraStops || 0));
  return round2(n * PricingConfig.multiStop.additionalStopFee);
}

export interface MultiStopPriceInput {
  laborSubtotal: number;   // sum of the manual line-item handling/D&R labour
  totalVolumeM3: number;   // total load volume across all stops
  distanceKm: number;      // FULL multi-stop route distance (pickups → drop-offs)
  extraStops: number;      // stops beyond first pickup + first drop-off
  samePropertyMove?: boolean; // when true, skip transport/distance entirely
  // The three surcharges below live INSIDE the transportFee bucket in the
  // customer engine (computePricing). The admin recalculator must include
  // them too, or recalculating a quote silently drops them and the total
  // goes DOWN (floor/stairs, bubble-wrap and access fees vanish).
  floors?: { level: number; hasLift: boolean }[]; // per-stop floor levels (skipped for same-property)
  wrappedUnits?: number;   // units with bubble-wrap protection ($/unit)
  accessDifficulty?: 'easy' | 'medium' | 'hard';  // % surcharge on labour
  laborDiscount?: number;  // bulk/labour discount — access % is charged on (labour − discount), matching computePricing
}

export interface MultiStopPriceResult {
  laborSubtotal: number;
  transportFee: number;       // per-trip transport × trips (0 for same-property)
  volumetricFee: number;      // tiered per-m³ handling
  additionalStopFee: number;  // extra-stop fee
  numTrips: number;
  logisticsSubtotal: number;  // transport + volumetric + additionalStop (stored in transportFee column)
  grandTotal: number;         // laborSubtotal + logisticsSubtotal
  breakdown: FeeLine[];       // human-readable lines for the admin UI
}

/**
 * Admin "Calculate price" helper for a multi-stop relocation. Reuses the same
 * transport / volumetric / additional-stop primitives as computePricing so the
 * suggested total is consistent with the rest of the engine. The admin can
 * always override the suggested grand total.
 */
export function computeMultiStopRelocationPrice(input: MultiStopPriceInput): MultiStopPriceResult {
  const laborSubtotal = round2(Math.max(0, input.laborSubtotal || 0));
  const totalVolumeM3 = round2(Math.max(0, input.totalVolumeM3 || 0));
  const distanceKm = Math.max(0, input.distanceKm || 0);
  const numTrips = calcNumTrips(totalVolumeM3);

  const breakdown: FeeLine[] = [];

  let transportFee = 0;
  if (!input.samePropertyMove) {
    const feePerTrip = calcTransportFee(distanceKm);
    transportFee = round2(feePerTrip * numTrips);
    breakdown.push({
      label: numTrips > 1
        ? `Transport / Relocation Logistics (${numTrips} trips × $${feePerTrip.toFixed(0)})`
        : 'Transport / Relocation Logistics',
      amount: transportFee,
    });
  }

  const volumetricFee = calcVolumetricHandlingFee(totalVolumeM3);
  if (volumetricFee > 0) {
    breakdown.push({ label: `Volumetric Handling (${totalVolumeM3.toFixed(2)} m³)`, amount: volumetricFee });
  }

  const additionalStopFee = calcAdditionalStopFee(input.extraStops);
  if (additionalStopFee > 0) {
    const n = Math.max(0, Math.floor(input.extraStops || 0));
    breakdown.push({
      label: `Additional Stops (${n} × $${PricingConfig.multiStop.additionalStopFee})`,
      amount: additionalStopFee,
    });
  }

  // Floor / stairs surcharge — same rule as computePricing: skipped for
  // same-property moves (one building, one lift), otherwise per storey.
  let floorSurcharge = 0;
  if (!input.samePropertyMove && input.floors?.length) {
    floorSurcharge = round2(input.floors.reduce((s, f) => {
      const lvl = Math.max(0, Math.floor(f.level || 0));
      if (lvl === 0) return s;
      const rate = f.hasLift ? PricingConfig.floor.perFloorWithLift : PricingConfig.floor.perFloorNoLift;
      return s + lvl * rate;
    }, 0));
    if (floorSurcharge > 0) {
      breakdown.push({ label: 'Stairs / Floor Access', amount: floorSurcharge });
    }
  }

  // Wrapping protection — flat $/unit, same as computePricing. The visible
  // "Wrapping Protection (N units)" line item is display-only; the money
  // lives in this bucket, so dropping it here would drop the charge.
  const wrappedUnits = Math.max(0, Math.round(input.wrappedUnits || 0));
  const wrappingFee = round2(wrappedUnits * PricingConfig.wrapping.perItem);
  if (wrappingFee > 0) {
    breakdown.push({
      label: `Wrapping Protection (${wrappedUnits} ${wrappedUnits === 1 ? 'item' : 'items'} × $${PricingConfig.wrapping.perItem})`,
      amount: wrappingFee,
    });
  }

  // Access difficulty surcharge — % of labour AFTER discount, same base as
  // computePricing (which charges it on laborAfterDiscount).
  const accessBase = Math.max(0, laborSubtotal - round2(Math.max(0, input.laborDiscount || 0)));
  let accessSurcharge = 0;
  if (input.accessDifficulty === 'medium') {
    accessSurcharge = round2(accessBase * PricingConfig.access.mediumPct);
  } else if (input.accessDifficulty === 'hard') {
    accessSurcharge = round2(accessBase * PricingConfig.access.hardPct);
  }
  if (accessSurcharge > 0) {
    breakdown.push({
      label: `Access Difficulty (${input.accessDifficulty === 'medium' ? 'Moderate' : 'Difficult'})`,
      amount: accessSurcharge,
    });
  }

  const logisticsSubtotal = round2(transportFee + volumetricFee + additionalStopFee + floorSurcharge + wrappingFee + accessSurcharge);
  const grandTotal = round2(laborSubtotal + logisticsSubtotal);

  return {
    laborSubtotal,
    transportFee,
    volumetricFee,
    additionalStopFee,
    numTrips,
    logisticsSubtotal,
    grandTotal,
    breakdown,
  };
}

export interface OvertimeResult {
  blocks: number;              // number of 30-min blocks charged
  charge: number;              // total overtime charge (SGD), NO cap
  includedMinutes: number;     // scheduled allowance used for this job
  crewSize: number;            // movers on site (drives the per-block rate)
  ratePerBlock: number;        // SGD per 30-min block = crew × $50 × 0.5
  overtimePerManPerHour: number; // SGD per mover, per hour ($50)
  overMinutes: number;         // minutes worked beyond the scheduled allowance
}

/**
 * Calculate the overtime charge for a job that runs beyond its SCHEDULED time.
 *
 * - `includedMinutes` is the job's own scheduled crew time (from getJobSchedule).
 *   When omitted it falls back to the flat overtime.capMinutes (back-compat).
 * - The per-block rate scales with `crewSize`: crew × $50/mover/hr, billed in
 *   30-minute blocks. There is NO cap — overruns are fully recovered.
 */
export function calcOvertimeCharge(
  actualMinutes: number,
  opts?: { includedMinutes?: number; crewSize?: number },
): OvertimeResult {
  const cfg = PricingConfig.overtime;
  const crew = Math.max(1, Math.round(Number(opts?.crewSize) || PricingConfig.secondDay.defaultCrewSize));
  const includedMinutes = opts?.includedMinutes != null && opts.includedMinutes >= 0
    ? opts.includedMinutes
    : cfg.capMinutes;
  const overtimePerManPerHour = cfg.perPersonHourlyRate;
  const ratePerBlock = round2(crew * overtimePerManPerHour * (cfg.blockMinutes / 60));

  if (actualMinutes <= includedMinutes) {
    return { blocks: 0, charge: 0, includedMinutes, crewSize: crew, ratePerBlock, overtimePerManPerHour, overMinutes: 0 };
  }
  const overMinutes = actualMinutes - includedMinutes;
  const blocks = Math.ceil(overMinutes / cfg.blockMinutes);
  const charge = round2(blocks * ratePerBlock); // NO cap — full recovery
  return { blocks, charge, includedMinutes, crewSize: crew, ratePerBlock, overtimePerManPerHour, overMinutes };
}

export interface JobSchedule {
  crewSize: number;            // movers assigned (defaults to standard van crew)
  scheduledHours: number;      // on-site time we plan for, rounded up to nearest 0.5h
  scheduledMinutes: number;    // scheduledHours × 60 — the overtime allowance
  overtimePerManPerHour: number; // SGD per mover, per hour beyond scheduled time
  blockMinutes: number;        // overtime billing block size (30 min)
  ratePerBlock: number;        // SGD per 30-min block = crew × $50 × 0.5
}

/**
 * Work out the customer-facing SCHEDULE for a job: how many movers for how long.
 * Scheduled time comes from the job SCOPE (estimateCrewHours), NOT from dividing
 * the price — dividing the price over-promises free hours. Rounded UP to the
 * nearest half-hour so we never under-promise on-site time.
 */
export function getJobSchedule(args: {
  items: { serviceType: string; quantity: number; volumeM3?: number | null; carryOnly?: boolean }[];
  totalVolumeM3?: number;
  distanceKm?: number;
  isRelocation?: boolean;
  crewSize?: number;
}): JobSchedule {
  const crew = Math.max(1, Math.round(Number(args.crewSize) || PricingConfig.costFloor.defaultCrewSize));
  const rawHours = estimateCrewHours({
    items: args.items,
    totalVolumeM3: args.totalVolumeM3,
    distanceKm: args.distanceKm,
    isRelocation: args.isRelocation,
  });
  const scheduledHours = Math.max(0.5, Math.ceil(rawHours * 2) / 2);
  const scheduledMinutes = Math.round(scheduledHours * 60);
  const overtimePerManPerHour = PricingConfig.overtime.perPersonHourlyRate;
  const blockMinutes = PricingConfig.overtime.blockMinutes;
  const ratePerBlock = round2(crew * overtimePerManPerHour * (blockMinutes / 60));
  return { crewSize: crew, scheduledHours, scheduledMinutes, overtimePerManPerHour, blockMinutes, ratePerBlock };
}

/**
 * Estimate how many crew-hours a job will realistically take. Used by the
 * cost-floor guard to work out the real cost of running the job. Gracefully
 * handles missing volume data by leaning on per-item time estimates.
 */
export function estimateCrewHours(args: {
  items: { serviceType: string; quantity: number; volumeM3?: number | null; carryOnly?: boolean }[];
  totalVolumeM3?: number;
  distanceKm?: number;
  isRelocation?: boolean;
}): number {
  const c = PricingConfig.costFloor;
  const items = args.items || [];
  let hours = c.baseHours;

  // Volume-based handling time (use provided total, else sum item volumes).
  const vol = args.totalVolumeM3 != null && args.totalVolumeM3 > 0
    ? args.totalVolumeM3
    : items.reduce((s, it) => {
        const v = it.volumeM3 != null && isFinite(it.volumeM3) && it.volumeM3 > 0 ? it.volumeM3 : 0;
        return s + v * Math.max(1, Math.round(it.quantity || 1));
      }, 0);
  if (vol > 0) hours += c.hoursPerM3 * vol;

  // Per-item handling time (D&R relocations are the most labour-intensive).
  for (const it of items) {
    const qty = Math.max(1, Math.round(it.quantity || 1));
    let per: number;
    if (it.serviceType === 'relocate') {
      per = it.carryOnly ? c.hoursPerCarryItem : c.hoursPerDRItem;
    } else {
      per = c.hoursPerLaborItem;
    }
    hours += per * qty;
  }

  // Travel time for relocations (round trip + buffer).
  if (args.isRelocation && args.distanceKm && args.distanceKm > 0) {
    hours += c.travelHoursPerKm * args.distanceKm;
  }

  return round2(hours);
}

/**
 * Cost-floor / margin guard. Estimates the real cost of a job and the lowest
 * price that still hits the target margin, then compares it to the quoted
 * grand total. Pure + side-effect free so it can run identically on the server,
 * in the customer estimate wizard, and in the admin quote screen.
 */
export function evaluateJobMargin(args: {
  items: { serviceType: string; quantity: number; volumeM3?: number | null; carryOnly?: boolean }[];
  grandTotal: number;
  totalVolumeM3?: number;
  distanceKm?: number;
  isRelocation?: boolean;
  crewSize?: number;
}): JobMargin {
  const c = PricingConfig.costFloor;
  const crew = Math.max(1, Math.round(Number(args.crewSize) || c.defaultCrewSize));
  const hours = estimateCrewHours({
    items: args.items,
    totalVolumeM3: args.totalVolumeM3,
    distanceKm: args.distanceKm,
    isRelocation: args.isRelocation,
  });

  const crewCost = crew * hours * c.loadedMoverHourlyCost;

  // Vehicle cost = van base + per-km fuel (the helper's labour is already counted
  // in crewCost, so we deliberately exclude the transport helperFee here to avoid
  // double-counting). Only relocations incur a vehicle cost.
  let vehicleCost = 0;
  if (args.isRelocation) {
    const t = PricingConfig.transport;
    const extraKm = Math.max(0, (args.distanceKm || 0) - t.includedKm);
    vehicleCost = t.vanBase + extraKm * t.ratePerKm;
  }

  const estimatedCost = round2(crewCost + vehicleCost);
  const marginFloor = c.marginPct < 1 ? round2(estimatedCost / (1 - c.marginPct)) : estimatedCost;
  const costFloor = round2(Math.max(c.absoluteMinJobPrice, marginFloor));
  const gt = round2(Number(args.grandTotal) || 0);
  const belowFloor = c.enabled && gt > 0 && gt < costFloor;
  const actualMarginPct = gt > 0 ? round2((gt - estimatedCost) / gt) : 0;

  return {
    enabled: c.enabled,
    estimatedHours: hours,
    crewSize: crew,
    estimatedCost,
    marginFloor,
    absoluteMin: c.absoluteMinJobPrice,
    costFloor,
    grandTotal: gt,
    belowFloor,
    shortfall: belowFloor ? round2(costFloor - gt) : 0,
    marginPct: c.marginPct,
    actualMarginPct,
  };
}

/** Look up a catalog install price for an item name (for fallback multipliers). */
function findInstallPrice(itemName: string, catalogEntries?: PricingCatalogEntry[]): number | null {
  if (!catalogEntries || catalogEntries.length === 0) return null;
  const lc = itemName.toLowerCase().trim();
  const entry = catalogEntries.find(e =>
    e.serviceType === 'install' && (
      e.name.toLowerCase().trim() === lc ||
      e.name.toLowerCase().includes(lc) ||
      lc.includes(e.name.toLowerCase().trim())
    )
  );
  return entry && entry.basePrice > 0 ? entry.basePrice : null;
}

// --------------------------------------------------------------------------
// Main pricing function
// --------------------------------------------------------------------------

export function computePricing(input: PricingInput): PricingResult {
  const cfg = PricingConfig;
  const reviewReasons: string[] = [];
  let requiresAdminReview = false;
  for (const item of input.items) {
    if (!Number.isSafeInteger(item.quantity) || item.quantity <= 0)
      throw new RangeError("Item quantity must be a positive whole number.");
    if (!Number.isFinite(item.unitPrice) || item.unitPrice < 0)
      throw new RangeError("Item unit price must be a finite, non-negative SGD amount.");
  }
  if (input.distanceKm !== undefined &&
      (!Number.isFinite(input.distanceKm) || input.distanceKm < 0))
    throw new RangeError("Route distance must be finite and non-negative.");
  if (input.needsRelocation && input.floors.some(f =>
    !Number.isSafeInteger(f.level) || f.level < 0 || typeof f.hasLift !== "boolean"))
    throw new RangeError("Relocation floor levels and lift availability must be valid.");

  // ── A) Resolve effective unit price per item ────────────────────────────

  const itemLines: ItemLine[] = input.items.map(item => {
    const qty = Math.max(1, Math.round(item.quantity));
    // Carry Only mode now charges the catalog basePrice (passed in via item.unitPrice).
    // Heavy items like king beds & massage chairs need 2-man labour even without dismantle —
    // a flat $0 was undercharging these jobs vs. Singapore market rates.
    let unitPrice = item.unitPrice;
    let fallbackUsed = false;

    // Fairness cap: for non-special-handling items, Carry Only can never cost
    // more than the full D&R bundle (otherwise the customer pays more for
    // less work — see screenshots of single/queen bed at $80/$130 carry vs.
    // $63/$84 D&R). Look up install + dismantle prices from the catalog and
    // delegate the cap to effectiveCarryPrice().
    if (item.carryOnly && unitPrice > 0 && !requiresSpecialHandling(item.sku)) {
      const inst = findInstallPrice(item.name, input.catalogEntries);
      const dis  = (input.catalogEntries || []).find(e =>
        e.serviceType === 'dismantle' && e.name.toLowerCase().trim() === item.name.toLowerCase().trim()
      );
      const dismantlePrice = dis && dis.basePrice > 0 ? dis.basePrice : undefined;
      const installPrice   = inst && inst > 0 ? inst : undefined;
      unitPrice = effectiveCarryPrice(installPrice, dismantlePrice, unitPrice, item.sku);
    }

    // Ordinary carry-only labour is deliberately rolled into logistics. Its
    // approved positive input may therefore become a legitimate zero work line.
    if (!(unitPrice > 0) && !(item.carryOnly && item.unitPrice > 0)) {
      fallbackUsed = true;
      // An absent price is not authority to apply the legacy generic rate or
      // infer a different service's price. Callers resolve approved catalogue
      // rates/bundles first; staff-approved amounts are supplied explicitly.
      unitPrice = 0;
      requiresAdminReview = true;
      reviewReasons.push(`Approved ${item.serviceType} price needed for: ${item.name}`);
    }

    unitPrice = round2(unitPrice);
    if (isNaN(unitPrice) || !isFinite(unitPrice)) {
      unitPrice = 0;
      requiresAdminReview = true;
      reviewReasons.push(`Price calculation error for: ${item.name}`);
    }

    return {
      name: item.name,
      serviceType: item.serviceType,
      quantity: qty,
      unitPrice,
      subtotal: round2(unitPrice * qty),
      fallbackUsed,
      volumeM3: item.volumeM3,
    };
  });

  // ── B) Labor subtotal ───────────────────────────────────────────────────

  const laborSubtotal = round2(itemLines.reduce((s, l) => s + l.subtotal, 0));

  // ── C) Bulk discount (applies to labor only) ────────────────────────────

  const totalQty = itemLines.reduce((s, l) => s + l.quantity, 0);
  const weightedQty = bulkWeightedQty(itemLines.map(l => ({ name: l.name, quantity: l.quantity })));
  const discountPct = [...cfg.bulkDiscount].sort((a, b) => b.minQty - a.minQty)
    .find(t => weightedQty >= t.minQty)?.pct ?? 0;
  const discountAmount = round2(laborSubtotal * discountPct);
  const discountLine = discountAmount > 0
    ? { label: `Bulk Discount (${Math.round(discountPct * 100)}%)`, amount: -discountAmount }
    : null;

  const laborAfterDiscount = round2(laborSubtotal - discountAmount);

  // ── D) Volume / trip calculation ────────────────────────────────────────

  const hasVolumeData = itemLines.some(l => l.volumeM3 != null && l.volumeM3! > 0);
  const totalVolumeM3 = hasVolumeData
    ? round2(itemLines.reduce((s, l) => s + (l.volumeM3 ?? 0) * l.quantity, 0))
    : 0;
  const numTrips = calcNumTrips(totalVolumeM3);

  // ── E) Fee lines ────────────────────────────────────────────────────────

  const feeLines: FeeLine[] = [];

  // Mobilisation & coordination fee
  //   • Non-relocation jobs (install / dismantle / dispose): $39.90 — replaces
  //     the old $180 minimum with a transparent base fee.
  //   • Same-Property Move: ALSO $39.90 — crew still needs to be dispatched
  //     to the site even though no transport is involved.
  //   • Regular relocation (between two addresses): no mobilisation fee; the
  //     transport fee already covers crew dispatch + 2-hour service window.
  if (!input.needsRelocation || input.samePropertyMove) {
    feeLines.push({ label: 'Mobilisation & Coordination', amount: cfg.callout.fee });
  }

  // Transport fee (regular relocation only — NOT same-property move) — multiplied by number of trips
  if (input.needsRelocation && !input.samePropertyMove) {
    const feePerTrip = calcTransportFee(input.distanceKm);
    const transportFee = round2(feePerTrip * numTrips);
    if (numTrips > 1) {
      feeLines.push({
        label: `Transport / Relocation Logistics (${numTrips} trips × $${feePerTrip.toFixed(0)})`,
        amount: transportFee,
      });
    } else {
      feeLines.push({ label: 'Transport / Relocation Logistics', amount: transportFee });
    }
    if (input.distanceKm === 0) {
      requiresAdminReview = true;
      reviewReasons.push('Distance calculation failed — transport fee is provisional at minimum rate');
    }
  }

  // Multi-stop additional-stop fee — flat charge per stop beyond the first
  // pickup + first drop-off. Default 0 (single-leg) so existing quotes are
  // unchanged. Skipped for same-property moves (no transport / extra legs).
  if (input.needsRelocation && !input.samePropertyMove) {
    const extraStops = Math.max(0, Math.floor(input.extraStops || 0));
    const additionalStopFee = calcAdditionalStopFee(extraStops);
    if (additionalStopFee > 0) {
      feeLines.push({
        label: `Additional Stops (${extraStops} × $${cfg.multiStop.additionalStopFee})`,
        amount: additionalStopFee,
      });
    }
  }

  // Volumetric handling fee — per-m³ crew labour charge for ALL relocation
  // items (both Carry Only AND full Dismantle-&-Reinstall), regardless of
  // pricing mode. Applies to regular relocations (where it offsets crew time
  // beyond the 2-hour transport window) AND Same-Property Moves (where it IS
  // the primary handling charge since there's no transport fee at all).
  //
  // Why D&R items also pay this fee: the catalog D&R price covers ASSEMBLY
  // labour (unbolt at origin, re-bolt at destination), but the physical
  // carry-out / carry-in work between truck and unit is a separate cost that
  // scales with the load's cubic footprint — exactly what the tiered $/m³
  // table is designed to recover. Without it, big D&R loads were silently
  // absorbing real crew time the flat fees alone didn't cover.
  //
  // Special-handling SKUs (king bed, Pax, piano, phone booths, etc.) are
  // excluded — those items already keep their full catalog rate which has
  // the heavy-handling premium baked in, so charging again would double-bill.
  let volumetricFeeOut = 0;
  if (input.needsRelocation) {
    const volumetricM3 = round2(
      input.items.reduce((s, it) => {
        if (it.serviceType !== 'relocate') return s;
        if (requiresSpecialHandling(it.sku)) return s;
        // Clamp volume — a tampered/negative client payload must not reduce
        // the handling fee. Non-finite values are treated as zero.
        const rawVol = it.volumeM3 ?? 0;
        const vol = isFinite(rawVol) && rawVol > 0 ? rawVol : 0;
        const qty = Math.max(1, Math.round(it.quantity));
        return s + vol * qty;
      }, 0),
    );
    if (volumetricM3 > 0) {
      // Apply marginal tiered rate — like income tax bands.
      // 0–2 m³ at $10, 2–5 m³ at $15, 5+ m³ at $20. (Shared helper so the
      // multi-stop admin calculator produces identical numbers.)
      const volumetricFee = calcVolumetricHandlingFee(volumetricM3);
      volumetricFeeOut = volumetricFee;
      if (volumetricFee > 0) {
        // Blended rate label = total fee ÷ total volume.
        // Reads as "Volumetric Handling (1.50 m³ × $10)" for small loads and
        // "Volumetric Handling (6.00 m³ × $15 blended)" once tiers kick in.
        const blendedRate = volumetricFee / volumetricM3;
        const allOneTier = volumetricM3 <= cfg.carryHandling.tiers[0].upTo;
        const rateLabel = allOneTier
          ? `$${cfg.carryHandling.tiers[0].ratePerM3}`
          : `$${blendedRate.toFixed(2)} blended`;
        feeLines.push({
          label: `Volumetric Handling (${volumetricM3.toFixed(2)} m³ × ${rateLabel}/m³)`,
          amount: volumetricFee,
        });
      }
    }
  }

  // Floor / stairs surcharge.
  // NOT charged for same-property moves: there's only one building, so the crew
  // uses the same lift/stairs to both load and unload — stacking a per-storey
  // charge (and billing the unit's absolute floor as if items are hauled up that
  // many storeys, when a lift does that work) double-counts. The real effort of
  // an internal same-property move is already covered by the D&R labour + the
  // $20/m³ volumetric handling fee; genuinely tough internal stairs are captured
  // by the Access Difficulty (Moderate/Difficult) surcharge below instead.
  const floorSurcharge = !input.needsRelocation || input.samePropertyMove ? 0 : input.floors.reduce((s, f) => {
    const lvl = Math.max(0, Math.floor(f.level));
    if (lvl === 0) return s;
    const rate = f.hasLift ? cfg.floor.perFloorWithLift : cfg.floor.perFloorNoLift;
    return s + lvl * rate;
  }, 0);
  if (floorSurcharge > 0) {
    feeLines.push({ label: 'Stairs / Floor Access', amount: round2(floorSurcharge) });
  }

  // Wrapping protection — optional per-item bubble-wrap charge.
  // Customer ticks "Wrap" on any line they want protected; we charge a flat
  // $10 per UNIT (so qty 3 with wrap = $30). Applies to any service type
  // (install, dismantle, relocate, etc.) — not gated by needsRelocation.
  const wrappedCount = input.items.reduce((s, it) => {
    if (!it.wrap) return s;
    const qty = Math.max(1, Math.round(it.quantity));
    return s + qty;
  }, 0);
  if (wrappedCount > 0 && cfg.wrapping.perItem > 0) {
    const wrappingFee = round2(wrappedCount * cfg.wrapping.perItem);
    if (wrappingFee > 0) {
      feeLines.push({
        label: `Wrapping Protection (${wrappedCount} ${wrappedCount === 1 ? 'item' : 'items'} × $${cfg.wrapping.perItem})`,
        amount: wrappingFee,
      });
    }
  }

  // Access difficulty surcharge (based on labor after discount)
  let accessSurcharge = 0;
  if (input.needsRelocation && input.accessDifficulty === 'medium') {
    accessSurcharge = round2(laborAfterDiscount * cfg.access.mediumPct);
  } else if (input.needsRelocation && input.accessDifficulty === 'hard') {
    accessSurcharge = round2(laborAfterDiscount * cfg.access.hardPct);
  }
  if (accessSurcharge > 0) {
    feeLines.push({
      label: `Access Difficulty (${input.accessDifficulty === 'medium' ? 'Moderate' : 'Difficult'})`,
      amount: accessSurcharge,
    });
  }

  // ── F) Totals ───────────────────────────────────────────────────────────

  const logisticsSubtotal = round2(feeLines.reduce((s, f) => s + f.amount, 0));
  const grandTotal = round2(laborAfterDiscount + logisticsSubtotal);
  // Small jobs (below the threshold) must be paid IN FULL up front — the
  // "deposit" becomes the whole total and there is no final payment. Larger
  // jobs keep the usual 50% deposit + 50% final split.
  const split = splitDepositFinal(grandTotal);
  const depositAmount = Number(split.depositAmount);
  const finalAmount = Number(split.finalAmount);

  // ── G) Margin / cost-floor guard (warn-only) ────────────────────────────
  const margin = evaluateJobMargin({
    items: input.items,
    grandTotal,
    totalVolumeM3,
    distanceKm: input.distanceKm,
    isRelocation: input.needsRelocation,
  });
  if (margin.enabled && margin.belowFloor) {
    requiresAdminReview = true;
    reviewReasons.push(
      `Below cost floor — priced $${grandTotal.toFixed(2)} vs safe minimum $${margin.costFloor.toFixed(2)} ` +
      `(target ${Math.round(margin.marginPct * 100)}% margin on ~${margin.estimatedHours}h crew time). ` +
      `Short by $${margin.shortfall.toFixed(2)}.`,
    );
  }

  return {
    itemLines,
    feeLines,
    discountLine,
    laborSubtotal,
    logisticsSubtotal,
    volumetricFee: volumetricFeeOut,
    discountAmount,
    grandTotal,
    depositAmount,
    finalAmount,
    requiresAdminReview,
    reviewReasons,
    totalVolumeM3,
    numTrips,
    hasVolumeData,
    margin,
  };
}

// --------------------------------------------------------------------------
// Staff meal (dinner) allowance — single source of truth for payslip + P&L
// --------------------------------------------------------------------------
/** Flat dinner allowance amount (SGD) paid on any qualifying day. */
export const MEAL_ALLOWANCE_AMOUNT = 8;

/** Date the current dinner-allowance policy takes effect (Singapore time, UTC+8). */
export const MEAL_ALLOWANCE_RULE_FROM = new Date("2026-07-01T00:00:00+08:00").getTime();

/**
 * Per-day staff dinner allowance, in SGD.
 *
 * Policy (from 1 Jul 2026): no lunch allowance; pay a flat S$8 on any day whose
 * overtime is 2 hours or more. Before 1 Jul 2026 the legacy rule applies (S$8 on
 * any day with more than 3h overtime) so historical pay is never changed.
 *
 * @param dayStart      the day's clock-in time (Date or ISO string)
 * @param dailyOtHours  that day's overtime hours (net of breaks/deductions)
 */
export function mealAllowanceForDay(dayStart: Date | string, dailyOtHours: number): number {
  const t = (typeof dayStart === "string" ? new Date(dayStart) : dayStart).getTime();
  const qualifies = t >= MEAL_ALLOWANCE_RULE_FROM
    ? dailyOtHours >= 2   // current policy: dinner allowance from 2h OT
    : dailyOtHours > 3;   // legacy policy (before 1 Jul 2026)
  return qualifies ? MEAL_ALLOWANCE_AMOUNT : 0;
}

// --------------------------------------------------------------------------
// First-job arrival rule — staff must reach the FIRST job location by 09:00 SGT
// --------------------------------------------------------------------------
/**
 * The time (Singapore, UTC+8) staff are expected to be physically AT the first
 * job location — not just reporting at the van. Reporting at the van at 09:00
 * still means arriving late, because driving time comes after.
 */
export const FIRST_JOB_ARRIVAL_DEADLINE_SGT = "09:00";

/**
 * Grace window (minutes) before an arrival counts as late. Absorbs GPS jitter
 * and small traffic variance so the flag only fires on genuinely late starts.
 */
export const FIRST_JOB_ARRIVAL_GRACE_MIN = 10;

/**
 * How many minutes after the 09:00 SGT deadline the crew reached the first job.
 * Negative/zero means on time or early. Timezone-safe regardless of server TZ:
 * 09:00 SGT === (09:00 − 8h) UTC on the workday's Singapore calendar day.
 *
 * The deadline is anchored to `dayAnchor` (the attendance clock-in time) so that
 * GPS stops detected after SGT midnight — e.g. from sparse/late points — are
 * still measured against the SAME workday's 09:00, not the next day's. When no
 * anchor is given it falls back to the arrival's own SGT calendar day.
 *
 * @param arrival    the GPS-detected first-job arrival time
 * @param dayAnchor  the workday reference (attendance clock-in); optional
 */
export function firstJobMinutesLate(arrival: Date | string, dayAnchor?: Date | string): number {
  const a = (typeof arrival === "string" ? new Date(arrival) : arrival).getTime();
  if (!isFinite(a)) return 0;
  const anchorMs = dayAnchor != null
    ? (typeof dayAnchor === "string" ? new Date(dayAnchor) : dayAnchor).getTime()
    : a;
  const base = isFinite(anchorMs) ? anchorMs : a;
  const sgt = new Date(base + 8 * 3600 * 1000); // workday date in SGT wall-clock
  const y = sgt.getUTCFullYear(), m = sgt.getUTCMonth(), d = sgt.getUTCDate();
  const [hh, mm] = FIRST_JOB_ARRIVAL_DEADLINE_SGT.split(":").map(Number);
  const deadlineUtc = Date.UTC(y, m, d, hh - 8, mm, 0); // 09:00 SGT in UTC
  return Math.round((a - deadlineUtc) / 60000);
}

/** Summarise a PricingResult for storage in the quotes table. */
export function pricingToQuoteFields(result: PricingResult) {
  return {
    subtotal: result.laborSubtotal.toFixed(2),
    discount: result.discountAmount.toFixed(2),
    transportFee: result.logisticsSubtotal.toFixed(2),
    volumetricFee: result.volumetricFee.toFixed(2),
    total: result.grandTotal.toFixed(2),
    depositAmount: result.depositAmount.toFixed(2),
    finalAmount: result.finalAmount.toFixed(2),
  };
}
