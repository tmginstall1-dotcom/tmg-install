export type PublicReviewData = {
  reviews: Array<{ id: number; author: string; text: string; source?: string | null; featured?: boolean }>;
  ratingValue?: string;
  ratingCount?: string;
  ratingConfigured?: boolean;
};

/** Use the existing Google destination; never invent one or render an unsafe URL. */
export function googleReviewViewUrl(raw?: string | null): string | undefined {
  if (!raw) return undefined;
  try {
    const url = new URL(raw);
    if (url.protocol !== "https:" || url.username || url.password ||
        !["g.page", "maps.app.goo.gl", "google.com", "www.google.com", "maps.google.com", "search.google.com"].includes(url.hostname)) {
      return undefined;
    }
    url.pathname = url.pathname.replace(/\/review\/?$/, "");
    return url.toString();
  } catch { return undefined; }
}

/** The public API is already restricted to admin-published reviews. */
export function publicGoogleReviewProof(data?: PublicReviewData, destination?: string | null) {
  const seen = new Set<number>();
  const reviews = (data?.reviews ?? []).filter(review => {
    if (review.featured === false || review.source?.toLowerCase() !== "google" || !review.author?.trim() ||
        !review.text?.trim() || !Number.isInteger(review.id) || review.id <= 0 || seen.has(review.id)) return false;
    seen.add(review.id);
    return true;
  }).slice(0, 3).map(({ id, author, text }) => ({ id, author, text }));
  const value = Number(data?.ratingValue);
  const count = Number(data?.ratingCount);
  const ratingSummary = data?.ratingConfigured && Number.isFinite(value) && value > 0 && value <= 5 &&
    Number.isInteger(count) && count > 0 ? { value: value.toFixed(1), count } : undefined;
  return { reviews, ratingSummary, googleReviewUrl: googleReviewViewUrl(destination) };
}
