/** Reporting only: never changes a saved source or treats clicks as customers. */
export function quoteSourceCounts(quotes: ReadonlyArray<{ sourceChannel?: string | null }>) {
  const counts = new Map<string | null, number>();
  for (const quote of quotes) {
    const channel = quote.sourceChannel?.trim() ? quote.sourceChannel : null;
    counts.set(channel, (counts.get(channel) ?? 0) + 1);
  }
  return Array.from(counts, ([channel, count]) => ({ channel, count }));
}

export function quoteSourceLabel(channel: string | null | undefined): string {
  if (channel == null) return "Unknown (not recorded)";
  if (!channel.trim()) return "Unknown (blank source)";
  const known: Record<string, string> = {
    web: "Website (web)", website: "Website (website)",
    whatsapp: "WhatsApp", gogovan: "GogoVan", phone: "Phone",
    admin: "Admin", manual: "Manual", partner: "Partner",
  };
  return known[channel] ?? `Unknown source: ${channel}`;
}

export function quoteSourceColor(channel: string | null): string {
  return ({ whatsapp: "#25d366", web: "#18181b", website: "#18181b",
    gogovan: "#f97316", phone: "#3b82f6", admin: "#8b5cf6",
    manual: "#8b5cf6", partner: "#f97316" } as Record<string, string>)[channel ?? ""] ?? "#94a3b8";
}

/** Raw events in the selected period, NOT unique leads or a session cohort. */
export function websiteEventTotals(events: ReadonlyArray<{ event: string; page?: string | null }>) {
  return [
    { step: "Landing page views", count: events.filter(e => e.event === "page_view" && e.page === "/").length },
    { step: "Estimate start events", count: events.filter(e => e.event === "wizard_start").length },
    { step: "Submitted estimate events", count: events.filter(e => e.event === "wizard_submit").length },
  ];
}
