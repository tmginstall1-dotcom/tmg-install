import type {FirstFacts,IntakeLine} from "./whatsappFirst";

const wardrobe=(name:string)=>/\bwardrobe\b|衣柜/i.test(name);
const added=(text:string)=>!/\b(?:not|no)\s+(?:an?\s+)?(?:another|additional|second|extra)\s+wardrobe|不是另一个衣柜/i.test(text)&&
  /\b(?:also|another|additional|second|extra)\b.{0,45}\bwardrobe\b|\b(?:plus|and)\s+(?:one|1|another)\b.{0,25}\bwardrobe\b|另外.*衣柜/i.test(text);
const newJob=(text:string)=>/\bnew (?:job|request|order)\b|新订单/i.test(text);
const componentReview="Please confirm the mirrored sliding wardrobe's construction and catalogue applicability from the original photos before fixing its labour rate; handwritten measurement units are not verified.";
const oneCount=(text:string)=>/^\s*(?:1|one)\s*(?:only|sets?)[\s.!，。]|^\s*(?:1|one)\s*(?:only|sets?)\s*$|\b(?:1|one)\s+wardrobe\b/i.test(text);
const twoDoors=(text:string)=>/\b(?:2|two)\s*(?:slid(?:e|es|ing)?\s*)?doors?\b|两.*推拉门/i.test(text);
const doorAlias=(name:string)=>/^(?:(?:\d+|one|two)[ -]+)?(?:mirror(?:ed)?\s+)?(?:slid(?:e|es|ing)?\s+)?doors?(?:\s+sets?)?$/i.test(name.trim());
const doorClarification=(text:string)=>/^(?:(?:1|one)\s+sets?\s+)?(?:2|two)\s+(?:slid(?:e|es|ing)?\s+)?(?:mirror(?:ed)?\s+)?doors?$|^(?:1|one)\s+(?:only|sets?)$/i
  .test(text.replace(/[.,，。]/g," ").trim().replace(/\s+/g," ").replace(/^actually\s+/i,""));
const movingWork=(text:string)=>/\bdismantl\w*|\bdisassembl\w*/i.test(text)&&
  /\bdeliver\w*|\banother (?:house|property|address)|\btransport/i.test(text)&&/\b(?:re)?install\w*|\breassembl\w*/i.test(text);

/** Identity continuity, not a pricing alias. Only a uniquely targeted current
 * wardrobe can absorb subtype/view refinements. Additional objects stay separate. */
export function wardrobeUpdate(previous:FirstFacts,update:FirstFacts,text:string,verified:IntakeLine[]=[]):FirstFacts {
  const old:FirstFacts=update.newJob?{}:previous;
  const prior=(old.items||[]).filter(l=>wardrobe(l.name));
  // Captured real extraction called "1 sets . 2 slides door" a new
  // "2 sliding door set". This is an attribute answer for one wardrobe.
  if(old.items?.length===1&&prior.length===1&&old.wardrobeIdentity?.single!==false&&doorClarification(text))
    update={...update,items:update.items?.map(l=>doorAlias(l.name)?
      {...l,key:prior[0].key,name:prior[0].name}:l)};
  const incoming=(update.items||[]).filter(l=>wardrobe(l.name));
  if(prior.length&&!incoming.length&&update.items?.some(l=>!wardrobe(l.name))&&!wardrobe(text))
    return update; // a bed/chair correction must not apply its count to the wardrobe
  if(!prior.length&&!incoming.length&&!wardrobe(text))return update;
  if(added(text)) {
    const items=update.items?.map(l=>wardrobe(l.name)&&incoming.length===1?{...l,
      key:`${l.key}:additional-${prior.length+1}`,separateIdentity:true}:l);
    return {...update,items,wardrobeIdentity:{key:"",single:false}};
  }
  if(old.wardrobeIdentity?.single===false||prior.length>1&&!old.wardrobeIdentity?.single)
    return update;
  if(!prior.length&&!incoming.length)update={...update,items:[{
    key:":wardrobe",name:"Wardrobe",serviceType:/dismantl/i.test(text)?"dismantle":"unspecified"
  }]};
  const candidates=(update.items||[]).filter(l=>wardrobe(l.name));
  const context=old.wardrobeIdentity;
  const anchor=prior[0]||candidates[0];
  if(!anchor)return update;
  const photos=(update.evidence||old.evidence||[]).filter(e=>e.kind==="photo"&&e.readable&&
    (!update.newJob||update.photos?.includes(e.source))&&wardrobe(e.text||"")&&!/;/.test(e.text||""));
  const names=[...prior,...candidates].map(l=>l.name).concat(photos.map(e=>e.text||""));
  const mirror=context?.mirrorObserved||names.some(n=>/mirror/i.test(n))||/\bmirror(?:ed)?\b|镜面/i.test(text);
  const doors=twoDoors(text)||names.some(n=>/2-door|two.door/i.test(n))||context?.twoDoors;
  const sliding=names.some(n=>/slid/i.test(n))||/\bslid(?:es?|ing)\b/i.test(text);
  const count=text.match(/^\s*(\d+|one|two)\s*(?:only|sets?)\b|(?:^|\b)(\d+|one|two)\s+wardrobes?\b/i);
  const number=count?.[1]||count?.[2];
  const correctedQuantity=/\b(?:actually|make it|change (?:it|quantity) to|instead)\s+\d+\b/i.test(text)&&
    !/\bdoors?\b/i.test(text)?candidates.find(l=>l.quantity)?.quantity:undefined;
  const quantity=number?({one:1,two:2}[number.toLowerCase()]||Number(number)):correctedQuantity||
    context?.quantity||anchor.quantity||candidates.find(l=>l.quantity)?.quantity;
  const service=movingWork(text)?"relocate":
    /\b(?:just|only)\s+(?:dismantl|disassembl)|\bdismantl\w*\s+only\b/i.test(text)?"dismantle":
    /\b(?:install|assembl)\w*\s+only\b/i.test(text)?"install":
    context?.serviceType||candidates.find(l=>l.serviceType!=="unspecified")?.serviceType||anchor.serviceType;
  const full=movingWork(text)||context?.full;
  const sameSiteCorrection=(old.items?.length===1||wardrobe(text))&&
    /\bsame (?:home|house|flat|property)|\bbetween rooms\b|\banother room\b/i.test(text)&&
    !/\b(?:not|isn't)\s+(?:the\s+)?same\b/i.test(text);
  const sameProperty=sameSiteCorrection?true:movingWork(text)?false:
    old.samePropertyMove??update.samePropertyMove??anchor.samePropertyMove;
  const statedSubtype=wardrobe(text)&&/\bfree[- ]?standing\b|独立式/i.test(text)&&
    !/\bnot\s+(?:a\s+)?free[- ]?standing\b|\bbuilt[- ]?in\b/i.test(text)&&
    /\bmirror(?:ed)?\b|镜面/i.test(text)&&
    /\b(?:2|two)[- ]+(?:sliding\s+)?(?:mirror(?:ed)?\s+)?doors?\b|两.*推拉门/i.test(text)&&/\bcm\b|centimet|厘米/i.test(text);
  const verifiedSubtype=context?.verifiedSubtype||
    (update.wardrobeIdentity?.key===(context?.key||anchor.key)&&update.wardrobeIdentity?.verifiedSubtype)||
    statedSubtype||verified.some(l=>wardrobe(l.name)&&
    (!mirror||/mirror/i.test(l.name))&&(!doors||/2-door/i.test(l.name)));
  const name=sliding&&doors?`Sliding Door Wardrobe (2-door${mirror?" / Mirror":""})`:
    sliding?"Sliding Door Wardrobe":anchor.name;
  const line:IntakeLine={...anchor,...candidates[0],key:context?.key||anchor.key,name,quantity,
    serviceType:service,relocationMode:full?"full":anchor.relocationMode,
    ...(full?{samePropertyMove:sameProperty}:{}),
    ...(name!==anchor.name?{catalogItemId:undefined}:{}),
  };
  const issues=(update.evidenceIssues||old.evidenceIssues||[]).filter(issue=>{
    if(verifiedSubtype&&issue.question===componentReview)return false;
    const photo=photos.find(p=>p.source===issue.source);
    return !(quantity===1&&photo&&/possible furniture is.+(?:connected unit|separate pieces)/i.test(issue.question));
  });
  if(mirror&&doors&&!verifiedSubtype&&!issues.some(i=>i.question===componentReview))
    issues.push({source:photos[0]?.source||"retained-wardrobe-observation",itemKey:line.key,question:componentReview});
  const out:FirstFacts={...update,items:[...(update.items||old.items||[]).filter(l=>!wardrobe(l.name)),line],
    wardrobeIdentity:{key:line.key,single:true,quantity,twoDoors:!!doors,mirrorObserved:!!mirror,
      verifiedSubtype:!!verifiedSubtype,serviceType:service,full:!!full},
    evidenceIssues:issues,
    ...(full?{relocationMode:"full",samePropertyMove:sameProperty}:{}),
    removeItemKeys:[...(update.removeItemKeys||[]),...prior.filter(l=>l.key!==line.key).map(l=>l.key)],
  };
  if(quantity===1&&photos.length&&(!update.photos?.length||update.photos.every(s=>photos.some(p=>p.source===s))))
    out.addOns=(update.addOns||old.addOns||[]).filter(x=>!/^The photo may relate to one of the listed objects;/.test(x));
  if((out.itemClarification||old.itemClarification)?.startsWith("Which existing item does this correction replace?"))
    out.itemClarification=""; // mergeFirstFacts explicitly consumes this resolved prompt.
  const floor=text.match(/\bpick\s*up\s+(?:floor|level)\s*(\d+)\b/i);
  if(floor)out.floorLevel=Number(floor[1]);
  // A conditional fit requirement is not proof of a usable lift. Nor may a
  // later model carry that inference forward without explicit confirmation.
  if(old.hasLift===undefined&&!/\b(?:with|has|have|no|without)\s+(?:a\s+)?lift\b|有电梯|没有电梯/i.test(text))
    delete out.hasLift;
  return out;
}

/** Bounded retained current-job evidence only; no model call or historic replay. */
export function recoverWardrobeIdentity(facts:FirstFacts,turns:Array<{body:string;mediaUrl?:string|null}>) {
  const reset=turns.findLastIndex(t=>newJob(t.body));
  const current=reset<0?turns:turns.slice(reset);
  const bodies=current.map(t=>t.body);
  const lines=(facts.items||[]).filter(l=>wardrobe(l.name));
  if(!lines.length||!bodies.some(t=>/\bthis wardrobe\b/i.test(t))||!bodies.some(oneCount)||
    bodies.some(added)||lines.some(l=>l.separateIdentity))return facts;
  const sources=new Set(current.map(t=>t.mediaUrl).filter(Boolean));
  const evidence=(facts.evidence||[]).filter(e=>e.kind!=="photo"||sources.has(e.source));
  const anchor=lines.find(l=>l.name==="Wardrobe")||lines[0];
  const recoverDoorAlias=current.some(t=>doorClarification(t.body))&&
    !current.some(t=>/\b(?:also|another|additional|extra)\b.{0,35}\bdoors?\b/i.test(t.body));
  let result:FirstFacts={...facts,items:[...(facts.items||[]).filter(l=>!wardrobe(l.name)&&!(recoverDoorAlias&&doorAlias(l.name))),{...anchor,quantity:1,catalogItemId:undefined}],
    wardrobeIdentity:facts.wardrobeIdentity?.single?{...facts.wardrobeIdentity,key:anchor.key}:undefined,evidence,itemClarification:undefined};
  if(bodies.some(t=>/as long as.{0,30}fit.{0,20}lift/i.test(t))&&
    !bodies.some(t=>/\b(?:with|has|have|no|without)\s+(?:a\s+)?lift\b/i.test(t)))delete result.hasLift;
  for(const text of bodies) {
    const update=wardrobeUpdate(result,{items:lines,evidence,photos:facts.photos},text);
    result={...result,...update,items:update.items||result.items};
  }
  return result;
}

/** Derived only from this item's confirmed work, never a manual remark rewrite. */
export function wardrobeWorkRemark(facts:FirstFacts,line:IntakeLine) {
  return wardrobe(line.name)&&line.serviceType==="relocate"&&
    (line.relocationMode||facts.relocationMode)==="full"&&
    (line.samePropertyMove??facts.samePropertyMove)===false
    ? "Dismantle the wardrobe, transport to another property, and reassemble."
    : undefined;
}
