import { computeDRPrice } from "./pricing";

export const CABINET_FORMS = ["base", "wall", "tall", "full_wall"] as const;
export const CABINET_DOOR_TYPES = ["solid", "glass", "open", "mixed"] as const;
export const CABINET_SIZE_TIERS = ["standard", "large"] as const;

export type CabinetForm = typeof CABINET_FORMS[number];
export type CabinetDoorType = typeof CABINET_DOOR_TYPES[number];
export type CabinetSizeTier = typeof CABINET_SIZE_TIERS[number];

export interface CabinetDetection {
  name: string;
  isCabinet?: boolean;
  cabinetForm?: CabinetForm | null;
  cabinetDoorType?: CabinetDoorType | null;
  cabinetSizeTier?: CabinetSizeTier | null;
  cabinetModuleCount?: number | null;
  widthCm?: number | null;
  hasGlassDoors?: boolean;
  hasSolidDoors?: boolean;
  hasOpenShelves?: boolean;
}

export interface CabinetVisionItem extends Omit<CabinetDetection, "name"> {
  name?: string;
  type?: string;
  quantity?: number;
  qty?: number;
}

export interface CanonicalCabinetVisionItem {
  name: string;
  quantity: number;
  classifiedCabinet: string | null;
  requiresReview: boolean;
}

const FORM_LABELS: Record<CabinetForm, string> = {
  base: "Base Cabinet",
  wall: "Wall-Mounted Cabinet",
  tall: "Tall Cabinet",
  full_wall: "Full-Wall Cabinet System",
};

const DOOR_LABELS: Record<CabinetDoorType, string> = {
  solid: "Solid Doors",
  glass: "Glass Doors",
  open: "Open Shelves",
  mixed: "Mixed Glass / Solid / Open",
};

const SIZE_LABELS: Record<CabinetSizeTier, string> = {
  standard: "Standard",
  large: "Large / Complex",
};

export function getCabinetCatalogName(
  form: CabinetForm,
  doorType: CabinetDoorType,
  sizeTier: CabinetSizeTier,
): string {
  return `${FORM_LABELS[form]} (${DOOR_LABELS[doorType]}, ${SIZE_LABELS[sizeTier]})`;
}

export const CABINET_CATALOG_NAMES = CABINET_FORMS.flatMap(form =>
  CABINET_DOOR_TYPES.flatMap(doorType =>
    CABINET_SIZE_TIERS.map(sizeTier => getCabinetCatalogName(form, doorType, sizeTier)),
  ),
);

const EXCLUDED_SPECIALIST_CABINET =
  /\b(wardrobe|closet|pax|shoe|filing|locker|display cabinet|china cabinet|medicine cabinet|mirror cabinet|bathroom vanity|kitchen|salon|entertainment|media wall|tv wall|feature wall|wine rack|bar cabinet)\b/i;

function inferForm(name: string): CabinetForm | null {
  if (/\b(full[- ]?wall|wall[- ]to[- ]wall|connected cabinet wall|cabinet wall system|floor[- ]to[- ]ceiling cabinet system)\b/i.test(name)) {
    return "full_wall";
  }
  if (/\b(wall[- ]mounted|wall[- ]hung|upper cabinet|overhead cabinet)\b/i.test(name)) return "wall";
  if (/\b(tall cabinet|tower cabinet|pantry cabinet|floor[- ]to[- ]ceiling cabinet)\b/i.test(name)) return "tall";
  if (/\b(base cabinet|low cabinet|sideboard|buffet cabinet|credenza)\b/i.test(name)) return "base";
  return null;
}

function inferDoorType(detection: CabinetDetection): CabinetDoorType | null {
  if (detection.cabinetDoorType && CABINET_DOOR_TYPES.includes(detection.cabinetDoorType)) {
    return detection.cabinetDoorType;
  }
  const signals = [
    detection.hasGlassDoors === true,
    detection.hasSolidDoors === true,
    detection.hasOpenShelves === true,
  ].filter(Boolean).length;
  if (signals >= 2) return "mixed";
  if (detection.hasGlassDoors) return "glass";
  if (detection.hasOpenShelves) return "open";
  if (detection.hasSolidDoors) return "solid";

  const name = detection.name;
  if (/\b(mixed|glass.*solid|solid.*glass|doors?.*open shelves?|open shelves?.*doors?)\b/i.test(name)) return "mixed";
  if (/\bglass[- ]door|glass cabinet|glass doors?\b/i.test(name)) return "glass";
  if (/\b(open shelving|open shelves|open cabinet|no doors?)\b/i.test(name)) return "open";
  if (/\b(solid[- ]door|hinged[- ]door|swing[- ]door|solid doors?)\b/i.test(name)) return "solid";
  return null;
}

function inferSizeTier(detection: CabinetDetection, form: CabinetForm): CabinetSizeTier {
  const moduleCount = Number(detection.cabinetModuleCount);
  const widthCm = Number(detection.widthCm);
  if (
    detection.cabinetSizeTier === "large" ||
    (Number.isFinite(moduleCount) && moduleCount >= 4) ||
    (Number.isFinite(widthCm) && widthCm > 240) ||
    /\b(large|extra[- ]large|complex|wide|wall[- ]to[- ]wall|full[- ]wall)\b/i.test(detection.name) ||
    form === "full_wall"
  ) {
    return "large";
  }
  return "standard";
}

export function classifyCabinet(detection: CabinetDetection): string | null {
  const exact = CABINET_CATALOG_NAMES.find(
    name => name.toLowerCase() === detection.name.trim().toLowerCase(),
  );
  if (exact) return exact;

  if (EXCLUDED_SPECIALIST_CABINET.test(detection.name)) return null;
  if (detection.isCabinet !== true && !/\b(cabinet|cupboard|sideboard|credenza)\b/i.test(detection.name)) {
    return null;
  }

  const form =
    detection.cabinetForm && CABINET_FORMS.includes(detection.cabinetForm)
      ? detection.cabinetForm
      : inferForm(detection.name);
  const doorType = inferDoorType(detection);

  // "Cabinet" alone is genuinely ambiguous. Keep the existing generic catalog
  // fallback rather than inventing a precise form or door construction.
  if (!form || !doorType) return null;

  return getCabinetCatalogName(form, doorType, inferSizeTier(detection, form));
}

/**
 * Normalises the two AI response shapes used by estimator (`name`/`quantity`)
 * and WhatsApp (`type`/`qty`) before applying the shared cabinet classifier.
 */
export function canonicalizeCabinetVisionItem(
  item: CabinetVisionItem,
): CanonicalCabinetVisionItem {
  const rawName = String(item.name ?? item.type ?? "").trim();
  const rawQuantity = Number(item.quantity ?? item.qty);
  const quantity = Number.isFinite(rawQuantity)
    ? Math.max(1, Math.min(50, Math.floor(rawQuantity)))
    : 1;
  const classifiedCabinet = classifyCabinet({ ...item, name: rawName });

  return {
    name: classifiedCabinet || rawName,
    quantity,
    classifiedCabinet,
    requiresReview: item.isCabinet === true && !classifiedCabinet,
  };
}

export function selectCabinetCatalogGroup<T>(
  canonical: CanonicalCabinetVisionItem,
  exactCanonicalGroup: T | null,
  fuzzyGroup: T | null,
): T | null {
  if (canonical.requiresReview) return null;
  if (canonical.classifiedCabinet) return exactCanonicalGroup;
  return fuzzyGroup;
}

const BASE_INSTALL_PRICES: Record<CabinetForm, Record<CabinetDoorType, [number, number]>> = {
  base: {
    solid: [80, 120],
    glass: [100, 150],
    open: [65, 100],
    mixed: [110, 165],
  },
  wall: {
    solid: [90, 145],
    glass: [120, 180],
    open: [75, 120],
    mixed: [130, 200],
  },
  tall: {
    solid: [110, 170],
    glass: [145, 220],
    open: [90, 140],
    mixed: [150, 240],
  },
  full_wall: {
    solid: [280, 520],
    glass: [360, 650],
    open: [230, 430],
    mixed: [400, 700],
  },
};

const VOLUMES: Record<CabinetForm, [number, number]> = {
  base: [0.5, 0.9],
  wall: [0.35, 0.7],
  tall: [0.7, 1.2],
  full_wall: [1.5, 2.8],
};

const FORM_SKU: Record<CabinetForm, string> = {
  base: "BASE",
  wall: "WALL",
  tall: "TALL",
  full_wall: "FULL",
};
const DOOR_SKU: Record<CabinetDoorType, string> = {
  solid: "SOLID",
  glass: "GLASS",
  open: "OPEN",
  mixed: "MIXED",
};

const round5 = (value: number) => Math.round(value / 5) * 5;

export interface CabinetCatalogDefinition {
  name: string;
  skuBase: string;
  form: CabinetForm;
  doorType: CabinetDoorType;
  sizeTier: CabinetSizeTier;
  volumeM3: number;
  install: number;
  dismantle: number;
  relocate: number;
  dispose: number;
  dismantleDispose: number;
}

export const CABINET_CATALOG_DEFINITIONS: CabinetCatalogDefinition[] =
  CABINET_FORMS.flatMap(form =>
    CABINET_DOOR_TYPES.flatMap(doorType =>
      CABINET_SIZE_TIERS.map((sizeTier, sizeIndex) => {
        const install = BASE_INSTALL_PRICES[form][doorType][sizeIndex];
        return {
          name: getCabinetCatalogName(form, doorType, sizeTier),
          skuBase: `CAB-${FORM_SKU[form]}-${DOOR_SKU[doorType]}-${sizeTier === "large" ? "LG" : "STD"}`,
          form,
          doorType,
          sizeTier,
          volumeM3: VOLUMES[form][sizeIndex],
          install,
          dismantle: round5(install * 0.72),
          relocate: computeDRPrice(install, round5(install * 0.72)),
          dispose: round5(install * 0.5),
          dismantleDispose: round5(install * 0.9),
        };
      }),
    ),
  );

export const CABINET_VISION_GUIDE = `
GENERAL CABINET SYSTEMS — CLASSIFY FORM, DOORS, AND SIZE BEFORE CHOOSING A CATALOG ITEM:
- Apply this section to general storage cabinets/cupboards. Keep wardrobes/PAX, shoe cabinets, filing/locker units, bathroom mirror cabinets/vanities, kitchen worktop cabinets, display cabinets, salon cabinets, bar/wine cabinets, and entertainment/media feature walls in their existing specialist catalog families.
- cabinetForm:
  • "base" = freestanding low/waist-height cabinet, sideboard, buffet, or credenza
  • "wall" = upper/overhead cabinet fixed above the floor
  • "tall" = one tall freestanding or floor-to-ceiling tower cabinet
  • "full_wall" = one connected composition spanning a wall with multiple base/upper/tall sections; count the whole connected run as quantity 1
- cabinetDoorType:
  • "solid" = opaque hinged/swing doors dominate
  • "glass" = glass-front doors dominate
  • "open" = open shelves/niches with no doors dominate
  • "mixed" = two or more of glass doors, solid doors, open niches, or substantial drawer banks occur in the same connected unit
- cabinetSizeTier: "large" when wider than 240 cm, four or more modules/bays, floor-to-ceiling/full-wall, or visibly complex; otherwise "standard".
- Return cabinetModuleCount as the visible number of cabinet bays/modules when countable, plus hasGlassDoors, hasSolidDoors, and hasOpenShelves.
- A connected base + upper + tower arrangement is ONE full_wall item, not separate cheap cabinets. Example: a wide storage wall with lower cupboards/drawers, upper solid doors, two glass display bays, and open lit niches → isCabinet true, cabinetForm "full_wall", cabinetDoorType "mixed", cabinetSizeTier "large", quantity 1.
- If form or door treatment is genuinely unclear, do not guess a precise tier; return the ordinary generic cabinet description so it can be reviewed/fall back safely.
`;