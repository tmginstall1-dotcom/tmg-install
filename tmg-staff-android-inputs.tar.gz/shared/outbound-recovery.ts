/** Internal notes share the legacy outbound column but are never provider attempts. */
export function isOutboundAttempt(message: {
  direction?: string; sentBy?: string | null; wamid?: string | null; deliveryContext?: unknown; hasDispatchContext?: boolean;
}) {
  if (message.direction !== "outbound") return false;
  const author = (message.sentBy ?? "").trim().toLowerCase();
  if (author === "note" || author.startsWith("note:") || author === "internal") return false;
  // Legacy system rows are internal diagnostics, unless actual dispatch evidence exists.
  return author !== "system" || Boolean(message.wamid || message.deliveryContext || message.hasDispatchContext);
}
