import type { Customer, Quote } from "./schema";

export type DashboardQuote = Pick<Quote,
  "id" | "referenceNo" | "status" | "total" | "createdAt" |
  "scheduledAt" | "timeWindow" | "preferredDate" | "preferredTimeWindow" |
  "serviceAddress" | "pickupAddress" | "sourceChannel"
> & {
  customer: Pick<Customer, "name" | "phone" | "email"> | null;
  ggv?: { jobNo: string | null; actualPrice: string | null; remarks: string | null };
};

export const DASHBOARD_QUOTES_PATH = "/api/admin/dashboard/quotes";
// Remains under the quote prefix so existing create/edit/payment invalidations
// also refresh dashboard cards, navigation badges and quick search.
export const DASHBOARD_QUOTES_KEY = ["/api/quotes", "dashboard-summary"] as const;