import type { Customer, Quote } from "./schema";

export type DashboardQuote = Pick<Quote,
  "id" | "referenceNo" | "status" | "total" | "createdAt" |
  "scheduledAt" | "timeWindow" | "preferredDate" | "preferredTimeWindow" |
  "serviceAddress" | "pickupAddress" | "sourceChannel"
> & {
  adminCompletion?: {confirmedAt:string; evidencePending:boolean; outstanding:number; received:number; settled:boolean; financialReviewRequired:boolean} | null;
  enquiryOutcome?: string|null;
  attentionExcluded?: boolean;
  enquiryView?: "active"|"archive"|"backlog"|"project"|"operations";
  eligibility?: {
    hasPayments: boolean;
    hasAcceptedAgreement: boolean;
    hasConfirmedBooking: boolean;
    isProject: boolean;
  };
  customer: Pick<Customer, "name" | "phone" | "email"> | null;
  ggv?: { jobNo: string | null; actualPrice: string | null; remarks: string | null };
};

// These are subsets, not interchangeable totals. Missing authoritative
// projection is not evidence that an old cached row is a new enquiry.
export const isDashboardRetailAttention = (q: Pick<DashboardQuote,"enquiryView">) =>
  q.enquiryView === "active";
export const isDashboardNewRequest = (q: Pick<DashboardQuote,"status"|"enquiryView">) =>
  isDashboardRetailAttention(q) && ["submitted","under_review"].includes(q.status);
export const isDashboardDepositDue = (q: Pick<DashboardQuote,"status"|"enquiryView">) =>
  ["active","operations"].includes(q.enquiryView||"") && ["deposit_requested","approved"].includes(q.status);
export const isDashboardFinalPaymentDue = (q: Pick<DashboardQuote,"status"|"enquiryView"|"adminCompletion">) =>
  q.enquiryView === "operations" && (["completed","final_payment_requested"].includes(q.status)
    ||q.status==="closed"&&!!q.adminCompletion&&!q.adminCompletion.financialReviewRequired&&q.adminCompletion.outstanding>0);

// Retain historical reporting, but never infer new admin-confirmed funds from closure.
export const dashboardClosedCollected = (q:Pick<DashboardQuote,"total"|"adminCompletion">) =>
  q.adminCompletion ? q.adminCompletion.received : Number(q.total||0);

// Forecast only: do not use this subset for historical revenue or funnel metrics.
// Keep open project and operational work, but not inactive enquiry dispositions.
export function dashboardPipelineValue(quotes: readonly Pick<DashboardQuote,"status"|"total"|"enquiryView">[]): number {
  return quotes
    .filter(q => !["closed","cancelled","final_paid"].includes(q.status)
      && q.enquiryView !== "archive" && q.enquiryView !== "backlog")
    .reduce((sum, q) => sum + Number(q.total || 0), 0);
}

export const DASHBOARD_QUOTES_PATH = "/api/admin/dashboard/quotes";
// Remains under the quote prefix so existing create/edit/payment invalidations
// also refresh dashboard cards, navigation badges and quick search.
export const DASHBOARD_QUOTES_KEY = ["/api/quotes", "dashboard-summary"] as const;