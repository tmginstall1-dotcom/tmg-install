export function singaporeDate(value:string|Date):string {
  const d=new Date(value);
  if(Number.isNaN(d.getTime()))return "";
  const parts=new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Singapore",year:"numeric",month:"2-digit",day:"2-digit"}).formatToParts(d);
  const pick=(name:string)=>parts.find(p=>p.type===name)?.value;
  return `${pick("year")}-${pick("month")}-${pick("day")}`;
}
export function validAppointment(date:string,timeWindow:string):boolean {
  if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!/^(?:[01]\d|2[0-3]):[0-5]\d-(?:[01]\d|2[0-3]):[0-5]\d$/.test(timeWindow))return false;
  const d=new Date(`${date}T12:00:00+08:00`);
  return !Number.isNaN(d.getTime())&&singaporeDate(d)===date&&timeWindow.slice(0,5)<timeWindow.slice(6);
}
