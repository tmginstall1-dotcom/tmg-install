export type AttendanceTimes = {
  clockInAt: string | Date;
  clockOutAt?: string | Date | null;
  breaks?: unknown;
  deductionMinutes?: number | string | null;
};

const stamp = (value: unknown): number =>
  typeof value === "string" || value instanceof Date ? new Date(value).getTime() : NaN;

// Union intervals rather than charging the same unpaid minute twice. Bounds
// protect legacy displays from breaks outside the shift; writes are stricter.
export function completedBreakMilliseconds(
  breaks: unknown, start = -Infinity, end = Infinity, includeOpen = false,
): number {
  if (!Array.isArray(breaks)) return 0;
  const intervals: [number, number][] = [];
  for (const b of breaks) {
    const a = stamp(b?.startAt);
    const z = b?.endAt == null && includeOpen ? end : stamp(b?.endAt);
    if (!Number.isFinite(a) || !Number.isFinite(z) || z <= a) continue;
    const left = Math.max(a, start), right = Math.min(z, end);
    if (right > left) intervals.push([left, right]);
  }
  intervals.sort((a,b)=>a[0]-b[0]);
  let total=0, left=0, right=0, active=false;
  for (const [a,z] of intervals) {
    if (!active) {left=a;right=z;active=true;}
    else if (a<=right) right=Math.max(right,z);
    else {total+=right-left;left=a;right=z;}
  }
  return total+(active?right-left:0);
}

export function assertAttendanceIntervals(log: AttendanceTimes): void {
  const start=stamp(log.clockInAt), end=log.clockOutAt == null ? null : stamp(log.clockOutAt);
  if (!Number.isFinite(start)) throw new Error("Invalid clock-in date/time");
  if (end !== null && (!Number.isFinite(end) || end <= start))
    throw new Error("Clock-out must be after clock-in");
  const deduction=Number(log.deductionMinutes ?? 0);
  if (!Number.isFinite(deduction) || deduction<0)
    throw new Error("Working-time deduction must be a non-negative number");
  if (log.breaks != null && !Array.isArray(log.breaks)) throw new Error("Invalid break records");
  const intervals: [number,number][] = [];
  let open=0;
  for (const [index,b] of (Array.isArray(log.breaks)?log.breaks:[]).entries()) {
    const a=stamp(b?.startAt), z=b?.endAt == null ? null : stamp(b?.endAt);
    if (!Number.isFinite(a) || (z !== null && (!Number.isFinite(z) || z<=a)))
      throw new Error(`Break ${index+1}: end must be after a valid start`);
    if (a<start || (end !== null && (a>=end || (z !== null && z>end))))
      throw new Error(`Break ${index+1}: must be inside the clock-in/out interval`);
    if (z===null) {
      if (end!==null) throw new Error(`Break ${index+1}: set an end time before closing this shift or generating payroll`);
      open++;
    }
    intervals.push([a,z??Infinity]);
  }
  if (open>1) throw new Error("Only one break can be left open");
  intervals.sort((a,b)=>a[0]-b[0]);
  for (let i=1;i<intervals.length;i++)
    if (intervals[i][0]<intervals[i-1][1]) throw new Error("Break times must not overlap");
}

export function attendanceWorkTime(log: AttendanceTimes, now?: string | Date) {
  const start=stamp(log.clockInAt), end=stamp(log.clockOutAt ?? now);
  const rawMs=Number.isFinite(start)&&Number.isFinite(end)?Math.max(0,end-start):0;
  const breakMs=rawMs?completedBreakMilliseconds(log.breaks,start,end,true):0;
  const deduction=Number(log.deductionMinutes??0);
  const deductionMs=Number.isFinite(deduction)?Math.max(0,deduction)*60000:0;
  const grossMs=Math.max(0,rawMs-breakMs);
  return {rawMs,breakMs,deductionMs,grossMs,netMs:Math.max(0,grossMs-deductionMs)};
}

// datetime-local inputs must represent Singapore, not the operator's device TZ.
export function singaporeInputValue(value: string | Date): string {
  const ms=stamp(value);
  return Number.isFinite(ms)?new Date(ms+8*3600000).toISOString().slice(0,16):"";
}
export function singaporeInputToIso(value: string): string {
  const ms=stamp(value+"+08:00");
  if (!Number.isFinite(ms)) throw new Error("Enter a valid Singapore date and time");
  return new Date(ms).toISOString();
}

// Staff amendments correct the times on the existing shift, not its calendar
// dates. Genuine date recovery belongs in the authorised attendance editor.
// Compare each endpoint separately so an existing overnight shift stays valid.
export function attendanceAmendmentDateError(
  original: { clockInAt: string | Date; clockOutAt?: string | Date | null },
  requested: { clockInAt?: string | Date | null; clockOutAt?: string | Date | null },
): string | null {
  for (const key of ["clockInAt", "clockOutAt"] as const) {
    const next=requested[key], before=original[key];
    if (next==null) continue;
    if (!Number.isFinite(stamp(next))) return "Enter a valid Singapore date and time";
    if (before!=null && singaporeInputValue(before).slice(0,10)!==singaporeInputValue(next).slice(0,10))
      return "Time amendments must keep the same Singapore date as the original clock-in and clock-out. Correct the time and resubmit. A genuine date correction requires the admin attendance editor.";
  }
  return null;
}
