import { canonicalizeCabinetVisionItem } from "./cabinetClassification";
import { classifyComplexKidsBed } from "./complexKidsBed";
import { classifyEntertainmentFeatureWall } from "./entertainmentFeatureWall";
import { classifyIntegratedStorageDesk, STORAGE_DESK_VISION_GUIDE } from "./integratedStorageDesk";
import {
  classifyFurnitureLead,
  type FurnitureCategory,
  type FurnitureLeadInput,
} from "./furnitureTaxonomy";

export type FurniturePhotoConfidence = "high" | "medium" | "low";

export interface FurniturePhotoVisionItem {
  name?: string;
  type?: string;
  quantity?: number;
  qty?: number;
  confidence?: FurniturePhotoConfidence;
  ambiguous?: boolean;
  quantityCertain?: boolean;
  candidateTypes?: string[];
  notes?: string;
  widthCm?: number;
  fullHeight?: boolean;
  hasGlassCabinets?: boolean;
  sleepingCapacity?: number;
  hasDesk?: boolean;
  hasAttachedDesk?: boolean;
  hasStorage?: boolean;
  hasStairStorage?: boolean;
  hasTopCabinet?: boolean;
  isCabinet?: boolean;
  cabinetForm?: "base" | "wall" | "tall" | "full_wall";
  cabinetDoorType?: "solid" | "glass" | "open" | "mixed";
  cabinetSizeTier?: "standard" | "large";
  cabinetModuleCount?: number;
  hasGlassDoors?: boolean;
  hasSolidDoors?: boolean;
  hasOpenShelves?: boolean;
  photoIsScreenshot?: boolean;
}

export interface FurniturePhotoCatalogGroup {
  name: string;
  category?: string | null;
}

export type FurniturePhotoReviewReason =
  | "no_furniture"
  | "low_confidence"
  | "ambiguous_item"
  | "multiple_items"
  | "quantity_uncertain"
  | "photo_text_mismatch"
  | "manual_category_mismatch"
  | "flatpack_identity_uncertain"
  | "screenshot_or_embedded_image"
  | "exact_catalog_match_required";

export interface FurniturePhotoAssessmentItem {
  detectedName: string;
  canonicalName: string;
  quantity: number;
  confidence: FurniturePhotoConfidence;
  candidateCategories: FurnitureCategory[];
  candidateTypes: string[];
  exactCatalogName: string | null;
}

export interface FurniturePhotoAssessment {
  safeToPrice: boolean;
  requiresClarification: boolean;
  reason: FurniturePhotoReviewReason | null;
  customerMessage: string | null;
  candidateCategories: FurnitureCategory[];
  items: FurniturePhotoAssessmentItem[];
  finalCanonicalItem: string | null;
  mismatchDetail: string | null;
}

export const FURNITURE_PHOTO_IDENTIFICATION_GUIDE = `
PHOTO IDENTIFICATION SAFETY:
- Identify visible construction, not the cheapest plausible catalog item.
- Distinguish wardrobes (hinged vs sliding), kitchen cabinets, shoe cabinets, TV consoles, filing cabinets, pedestals, shelves/racks, storage beds, bunk/loft beds, sofas/chairs, dining tables, office desks/workstations, and standalone office partitions.
- A workstation includes its attached partition panels; list partitions separately only when they are standalone.
- A low TV console is not a full entertainment feature wall. A tall clothes wardrobe is not a generic cabinet. A storage bed is not a plain bed frame.
- IKEA/Taobao/flat-pack is provenance, not an exact item identity. If the model/name or construction is unclear, mark it ambiguous and suggest likely candidateTypes instead of guessing.
- If the uploaded image is a phone/browser/app screenshot, product listing page, or contains furniture only inside a small embedded thumbnail, set photoIsScreenshot=true. Do not identify or price the thumbnail as if it were a clear original furniture photo.
- confidence MUST be high, medium, or low. Use high only when the defining visual features are clear.
- Set ambiguous=true when two or more materially different item types remain plausible.
- Set quantityCertain=false when the number of separate units/frames/workstations cannot be counted reliably.
- Never use customer caption, filename, selected category, or seller context to override conflicting visual evidence; report the visual result so the server can request clarification.
${STORAGE_DESK_VISION_GUIDE}
`;

const GENERIC_ITEM = /\b(furniture|item|unit|thing|flat[ -]?pack|taobao|ikea|cabinet|wardrobe|bed|table|desk|chair|shelf|rack)\b/i;
const GENERIC_ONLY = /^(?:furniture|item|unit|thing|flat[ -]?pack|taobao(?: furniture)?|ikea(?: furniture)?|cabinet|wardrobe|bed|table|desk|chair|shelf|rack)$/i;

function normalized(value: string | null | undefined): string {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
}

function unique<T>(values: T[]): T[] {
  return Array.from(new Set(values));
}

function categoriesCompatible(a: FurnitureCategory, b: FurnitureCategory): boolean {
  if (a === b) return true;
  if (a === "flat_pack" || b === "flat_pack") return true;
  const groups: FurnitureCategory[][] = [
    ["office_systems", "workstations", "desks_tables", "commercial_furniture"],
    ["storage_wardrobes", "shelving", "residential_furniture"],
    ["beds_bedroom", "residential_furniture"],
    ["seating", "residential_furniture", "commercial_furniture"],
  ];
  return groups.some(group => group.includes(a) && group.includes(b));
}

function classifyWithoutManual(itemText: string, context: FurnitureLeadInput): FurnitureCategory {
  return classifyFurnitureLead({ ...context, manualCategoryHint: undefined, itemText }).category;
}

function canonicalizeVisionName(item: FurniturePhotoVisionItem): string {
  const rawName = String(item.name ?? item.type ?? "").trim();
  const cabinet = canonicalizeCabinetVisionItem({ ...item, name: rawName });
  const kidsBed = classifyComplexKidsBed({
    name: rawName,
    sleepingCapacity: item.sleepingCapacity,
    hasDesk: item.hasDesk,
    hasStorage: item.hasStorage,
    hasStairStorage: item.hasStairStorage,
    hasTopCabinet: item.hasTopCabinet,
  });
  const featureWall = classifyEntertainmentFeatureWall({
    name: rawName,
    widthCm: item.widthCm,
    fullHeight: item.fullHeight,
    hasGlassCabinets: item.hasGlassCabinets,
  });
  return kidsBed || featureWall || classifyIntegratedStorageDesk(item) || cabinet.classifiedCabinet || rawName;
}

export function buildFurniturePhotoClarification(reason: FurniturePhotoReviewReason): string {
  if (reason === "multiple_items" || reason === "quantity_uncertain") {
    return "I can see more than one item, but I don’t want to count or price the wrong pieces. Could you list each item and quantity, or send one clear photo per item?";
  }
  if (reason === "photo_text_mismatch" || reason === "manual_category_mismatch") {
    return "The photo and item description seem to show different furniture. Could you confirm the item name, or send the seller link or one clearer full-item photo?";
  }
  if (reason === "flatpack_identity_uncertain") {
    return "This looks like an IKEA, Taobao, or flat-pack item, but the exact model is unclear. Could you send the seller link or product name?";
  }
  if (reason === "screenshot_or_embedded_image") {
    return "This looks like a screenshot or an embedded product thumbnail rather than a clear original furniture photo. Could you upload the original photo of the furniture, or send the seller link or product name?";
  }
  if (reason === "no_furniture") {
    return "I couldn’t clearly identify an installable furniture item in this photo. Could you send one clearer full-item photo or the item name?";
  }
  return "I can’t identify this item confidently enough to price it safely. Could you send the item name, seller link, dimensions, or one clearer full-item photo?";
}

export function assessFurniturePhotoEvidence(input: {
  items: FurniturePhotoVisionItem[];
  catalogGroups: FurniturePhotoCatalogGroup[];
  context?: FurnitureLeadInput & { customerItemText?: string };
}): FurniturePhotoAssessment {
  const context = input.context || {};
  const exactCatalog = new Map(
    input.catalogGroups.map(group => [normalized(group.name), group]),
  );
  const items = input.items
    .filter(item => String(item.name ?? item.type ?? "").trim())
    .map(item => {
      const detectedName = String(item.name ?? item.type ?? "").trim();
      const canonicalName = canonicalizeVisionName(item);
      const rawQuantity = Number(item.quantity ?? item.qty);
      const quantity = Number.isFinite(rawQuantity) ? Math.max(1, Math.min(300, Math.floor(rawQuantity))) : 1;
      const confidence = item.confidence || "low";
      const category = classifyWithoutManual(canonicalName, context);
      const candidateTypes = unique((item.candidateTypes || []).map(String).filter(Boolean));
      const candidateCategories = unique([
        category,
        ...candidateTypes.map(candidate => classifyWithoutManual(candidate, context)),
      ]).filter(categoryValue => categoryValue !== "unknown");
      return {
        detectedName,
        canonicalName,
        quantity,
        confidence,
        candidateCategories,
        candidateTypes,
        exactCatalogName: exactCatalog.get(normalized(canonicalName))?.name || null,
        ambiguous: item.ambiguous === true || candidateTypes.length > 1,
        // Missing, fractional, zero or implausible counts must not silently
        // become a confident single-item quote.
        quantityCertain: item.quantityCertain !== false && Number.isInteger(rawQuantity) && rawQuantity > 0 && rawQuantity <= 300,
        photoIsScreenshot: item.photoIsScreenshot === true,
      };
    });

  const candidateCategories = unique(items.flatMap(item => item.candidateCategories));
  let reason: FurniturePhotoReviewReason | null = null;
  let mismatchDetail: string | null = null;

  if (items.some(item => item.photoIsScreenshot)) {
    reason = "screenshot_or_embedded_image";
  } else if (items.length === 0) {
    reason = "no_furniture";
  } else if (items.some(item => item.confidence !== "high")) {
    reason = "low_confidence";
  } else if (items.some(item => item.ambiguous)) {
    reason = "ambiguous_item";
  } else if (items.length > 1) {
    reason = "multiple_items";
  }

  const photoCategory = candidateCategories[0] || "unknown";
  const customerText = String(context.customerItemText || context.customerNotes || "").trim();
  if (!reason && customerText) {
    const textCategory = classifyWithoutManual(customerText, {});
    if (
      textCategory !== "unknown" &&
      !categoriesCompatible(photoCategory, textCategory)
    ) {
      reason = "photo_text_mismatch";
      mismatchDetail = `photo=${photoCategory}; text=${textCategory}`;
    }
  }

  if (!reason && context.manualCategoryHint) {
    const manualCategory = classifyFurnitureLead({ manualCategoryHint: context.manualCategoryHint }).category;
    if (
      manualCategory !== "unknown" &&
      !categoriesCompatible(photoCategory, manualCategory)
    ) {
      reason = "manual_category_mismatch";
      mismatchDetail = `photo=${photoCategory}; manual=${manualCategory}`;
    }
  }

  const only = items[0];
  const flatpackContext = /\b(ikea|taobao|shopee|lazada|flat[ -]?pack)\b/i.test([
    only?.detectedName,
    context.sellerProductLink,
    customerText,
    context.filename,
  ].filter(Boolean).join(" "));
  if (
    !reason &&
    flatpackContext &&
    only &&
    (GENERIC_ONLY.test(only.detectedName) || (!only.exactCatalogName && GENERIC_ITEM.test(only.detectedName)))
  ) {
    reason = "flatpack_identity_uncertain";
  }

  if (!reason && items.some(item => !item.exactCatalogName)) {
    reason = "exact_catalog_match_required";
  }
  if (!reason && items.some(item => !item.quantityCertain)) {
    reason = "quantity_uncertain";
  }

  const publicItems = items.map(({
    ambiguous: _ambiguous,
    quantityCertain: _quantityCertain,
    photoIsScreenshot: _photoIsScreenshot,
    ...item
  }) => item);
  return {
    safeToPrice: reason === null && publicItems.length === 1,
    requiresClarification: reason !== null,
    reason,
    customerMessage: reason ? buildFurniturePhotoClarification(reason) : null,
    candidateCategories,
    items: publicItems,
    finalCanonicalItem: reason === null ? publicItems[0]?.exactCatalogName || null : null,
    mismatchDetail,
  };
}