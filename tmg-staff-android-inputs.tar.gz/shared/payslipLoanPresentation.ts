// Presentation only: never infer repayments or change a stored loan balance.
function money(value: unknown): number | undefined {
  if (typeof value !== "number" && typeof value !== "string") return undefined;
  if (typeof value === "string" && !value.trim()) return undefined;
  const amount = Number(value);
  return Number.isFinite(amount) && amount >= 0 ? amount : undefined;
}

const sg = (amount: number) =>
  `S$ ${amount.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`;

export function payslipLoanPresentation(
  loan: { remainingBalance: unknown; monthlyRepayment: unknown },
  deduction: unknown,
) {
  const balance = money(loan.remainingBalance);
  const repayment = money(loan.monthlyRepayment);
  const deducted = money(deduction);
  return {
    outstanding: balance === undefined ? "Balance unavailable" : sg(balance),
    repayment: deducted === undefined ? "Deduction unavailable"
      : deducted === 0 ? "No deduction this month"
      : repayment !== undefined && repayment > 0 ? sg(repayment)
      : "See loan deduction",
  };
}

export function staffLoanStatus(loan: { remainingBalance: unknown; isActive: boolean }) {
  const balance = money(loan.remainingBalance);
  if (balance === undefined) return "Balance unavailable";
  if (balance === 0) return "No outstanding balance";
  return loan.isActive ? "Outstanding" : "Outstanding · repayment paused";
}
