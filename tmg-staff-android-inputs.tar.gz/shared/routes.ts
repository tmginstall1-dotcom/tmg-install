import { z } from 'zod';
import { 
  insertUserSchema, users,
  insertCustomerSchema, customers,
  insertCatalogItemSchema, catalogItems,
  insertQuoteSchema, quotes,
  insertQuoteItemSchema, quoteItems,
  insertJobUpdateSchema, jobUpdates,
  quoteRequestSchema,
  quoteStopSchema,
  QuoteResponse
} from './schema';
import { leadMetaSchema } from './lead-intent';

export const errorSchemas = {
  validation: z.object({ message: z.string(), field: z.string().optional() }),
  notFound: z.object({ message: z.string() }),
  internal: z.object({ message: z.string() }),
};

export const api = {
  auth: {
    login: {
      method: 'POST' as const,
      path: '/api/auth/login' as const,
      input: z.object({ username: z.string(), password: z.string() }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.validation,
      }
    },
    me: {
      method: 'GET' as const,
      path: '/api/auth/me' as const,
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.validation,
      }
    },
    logout: {
      method: 'POST' as const,
      path: '/api/auth/logout' as const,
      responses: {
        200: z.object({ message: z.string() }),
      }
    }
  },
  catalog: {
    list: {
      method: 'GET' as const,
      path: '/api/catalog' as const,
      input: z.object({ search: z.string().optional() }).optional(),
      responses: { 200: z.array(z.custom<typeof catalogItems.$inferSelect>()) }
    }
  },
  quotes: {
    list: {
      method: 'GET' as const,
      path: '/api/quotes' as const,
      input: z.object({ status: z.string().optional() }).optional(),
      responses: { 200: z.array(z.custom<QuoteResponse>()) }
    },
    get: {
      method: 'GET' as const,
      path: '/api/quotes/:id' as const,
      responses: { 200: z.custom<QuoteResponse>(), 404: errorSchemas.notFound }
    },
    createFromCustomer: { // AI Quote generation
      method: 'POST' as const,
      path: '/api/quotes/request' as const,
      input: quoteRequestSchema,
      responses: { 201: z.custom<QuoteResponse>(), 400: errorSchemas.validation }
    },
    updateStatus: {
      method: 'PATCH' as const,
      path: '/api/quotes/:id/status' as const,
      input: z.object({ status: z.string(), note: z.string().optional(), gpsLat: z.number().optional(), gpsLng: z.number().optional(), photoUrl: z.string().optional(), assignedStaffId: z.number().int().positive().nullable().optional(), assignedTeamId: z.number().int().positive().nullable().optional() }),
      responses: { 200: z.custom<QuoteResponse>(), 400: errorSchemas.validation }
    },
    updatePayment: {
      method: 'PATCH' as const,
      path: '/api/quotes/:id/payment' as const,
      input: z.object({ paymentType: z.enum(['deposit', 'final']), amount: z.string() }),
      responses: { 200: z.custom<QuoteResponse>() }
    },
    updateBooking: {
      method: 'PATCH' as const,
      path: '/api/quotes/:id/booking' as const,
      input: z.object({ scheduledAt: z.string(), timeWindow: z.string() }),
      responses: { 200: z.custom<QuoteResponse>() }
    },
    wizard: {
      method: 'POST' as const,
      path: '/api/quotes/wizard' as const,
      input: z.object({
        requestId: z.string().uuid().optional(),
        customer: z.object({
          name: z.string().min(1),
          email: z.string().trim().toLowerCase().email("Please enter a valid email address (e.g. name@email.com)"),
          phone: z.string().min(1),
        }),
        selectedServices: z.array(z.enum(['install', 'dismantle', 'relocate', 'dispose', 'dismantle_dispose', 'dismantle_install'])).min(1),
        serviceAddress: z.string().min(1),
        pickupAddress: z.string().optional(),
        dropoffAddress: z.string().optional(),
        accessDifficulty: z.enum(['easy', 'medium', 'hard']).optional(),
        floorsInfo: z.string().optional(),
        // Multi-stop relocation (ADDITIVE) — ordered list of pickup + drop-off
        // stops. Omitted / empty for single-leg quotes (legacy behaviour).
        stops: z.array(quoteStopSchema).optional(),
        items: z.array(z.object({
          catalogItemId: z.number().optional(),
          quantity: z.number().int().min(1).max(9999),
          serviceType: z.enum(['install', 'dismantle', 'relocate', 'dispose', 'dismantle_dispose', 'dismantle_install']),
          unitPrice: z.number().finite().min(0),
          itemName: z.string().min(1),
          sku: z.string().optional(),
          relocateMode: z.enum(['carry', 'full', 'reinstall_only']).optional(),
          wrap: z.boolean().optional(), // customer opted into bubble-wrap protection ($10/unit)
          requiresReview: z.boolean().optional(), // AI could not safely map this item to a priced catalog row
          detectionToken: z.string().max(4000).optional(), // signed server provenance for photo detections
          // Multi-stop links — which pickup this item comes from / drop-off it
          // goes to, referencing stops[].id. Null/omitted on single-leg quotes.
          fromStopId: z.string().optional(),
          toStopId: z.string().optional(),
        })).max(200),
        customItems: z.array(z.object({
          description: z.string().trim().min(1).max(500),
          serviceType: z.enum(['install', 'dismantle', 'relocate', 'dispose', 'dismantle_dispose', 'dismantle_install']),
          quantity: z.number().int().min(1).max(9999),
          details: z.string().max(2000).optional(),
          dimensions: z.string().max(300).optional(),
          productLink: z.string().max(2000).url().refine(s => /^https?:\/\//i.test(s), "Use an http or https product link").optional(),
          photo: z.string().max(700000).regex(/^data:image\/(?:jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/).optional(),
        })).max(100).optional(),
        logisticsFee: z.number().finite().min(0).optional(),   // total of transport + floor + access surcharges
        discount: z.number().finite().min(0).optional(),       // bulk discount amount
        distanceKm: z.number().finite().min(0).optional(),     // auto-computed route distance (relocation only)
        samePropertyMove: z.boolean().optional(),     // true = items shifted within the SAME address (no transport, $39.90 mobilisation applies)
        detectedPhotoUrl: z.string().optional(), // compressed thumbnail from AI photo scan
        detectedPhotos: z.array(z.string().max(700000).regex(/^data:image\/(?:jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/)).max(10).optional(),
        preferredDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),      // slot chosen in wizard
        preferredTimeWindow: z.string().optional(), // e.g. '09:00-12:00'
        promoCode: z.string().optional(),           // validated promo code applied by customer
        promoDiscount: z.number().min(0).optional(), // SGD discount from promo
        // Lead-quality metadata for Ads analysis (intent(s), urgency, UTM/GCLID
        // attribution). Optional — old clients simply omit it.
        leadMeta: leadMetaSchema.optional(),
      }),
      responses: { 201: z.custom<QuoteResponse>(), 400: errorSchemas.validation }
    }
  },
  distance: {
    calculate: {
      method: 'POST' as const,
      path: '/api/distance' as const,
      input: z.object({
        // Legacy single-leg inputs (kept for back-compat).
        pickupAddress: z.string().min(1).optional(),
        dropoffAddress: z.string().min(1).optional(),
        pickupLat: z.number().optional(),
        pickupLng: z.number().optional(),
        dropoffLat: z.number().optional(),
        dropoffLng: z.number().optional(),
        // Multi-stop: an ordered list of waypoints (pickups then drop-offs).
        // When 2+ are supplied, the route distance is the sum across the whole
        // chain in the given order. Takes precedence over pickup/dropoff.
        waypoints: z.array(z.object({
          address: z.string().min(1),
          lat: z.number().optional(),
          lng: z.number().optional(),
        })).optional(),
      }),
      responses: {
        200: z.object({ distanceKm: z.number(), routeFound: z.boolean(), error: z.string().optional() }),
      }
    }
  },
  staff: {
    list: {
      method: 'GET' as const,
      path: '/api/staff' as const,
      responses: { 200: z.array(z.custom<typeof users.$inferSelect>()) }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
