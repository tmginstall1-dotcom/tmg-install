import type {CatalogItem} from "./schema";
import {sameWhatsappCatalogIdentity} from "./whatsappCatalogNames";

/** Suggestions are not authority to overwrite a saved/manual rate or price logistics. */
export function detectAdminCatalogRate(
  item:{detectedName?:unknown;originalDescription?:unknown;serviceType?:unknown;unitPrice?:unknown;catalogItemId?:unknown;remark?:unknown},
  catalog:CatalogItem[],
):{entry?:CatalogItem;reason:string} {
  if(String(item.unitPrice??"").trim()!=="")
    return {reason:"Saved or manually entered rate retained."};
  if(item.serviceType==="relocate")
    return {reason:"Moving rates depend on the work and logistics. Select the applicable catalogue entry."};
  if(item.serviceType==="install" &&
    /\b(?:alignment only|adjustment only|pre[- ]?assembled|castor fitting|fit castor|uncartoning only|no assembly|carry only)\b/i
      .test(`${item.detectedName||""} ${item.originalDescription||""} ${item.remark||""}`))
    return {reason:"Partial work is described. Confirm its work type and applicable rate; a full installation rate is not assumed."};
  const name=String(item.detectedName||item.originalDescription||"").trim();
  const candidates=catalog.filter(c=>c.active===true&&c.serviceType===item.serviceType&&
    sameWhatsappCatalogIdentity(name,c.name)&&
    (!item.catalogItemId || String(c.id)===String(item.catalogItemId)));
  if(candidates.length>1)return {reason:"More than one approved entry matches. Select the applicable catalogue rate."};
  const entry=candidates[0];
  if(!entry||!Number.isFinite(Number(entry.basePrice))||Number(entry.basePrice)<=0)
    return {reason:"No unique approved rate detected. Choose a catalogue item or enter an authorised custom rate."};
  return {entry,reason:"Approved catalogue rate detected."};
}

export function fillDetectedAdminRate<T extends {
  detectedName?:unknown;originalDescription?:unknown;serviceType?:unknown;unitPrice?:unknown;
  catalogItemId?:unknown;quantity?:unknown;
}>(item:T,catalog:CatalogItem[]):T {
  const {entry}=detectAdminCatalogRate(item,catalog);
  if(!entry)return item;
  const unitPrice=Number(entry.basePrice).toFixed(2);
  return {...item,catalogItemId:entry.id,unitPrice,
    subtotal:(Number(unitPrice)*Number(item.quantity||0)).toFixed(2),
    volumeM3:entry.volumeM3 == null ? null : Number(entry.volumeM3)};
}
