/** Owner-approved wording. Neither approval nor this registry authorises a send. */
export const QUOTATION_TEMPLATE_PROPOSALS=[
  {name:"tmg_requested_quotation_en",language:"en_GB",category:"UTILITY",
    body:"Your requested TMG Install quotation {{1}} is ready. Review the itemised work, total and terms at {{2}}. If something needs correcting, reply here and our team will review it. Any requested appointment date or time still needs staff confirmation. Payment does not automatically book a slot."},
  {name:"tmg_requested_quotation_zh",language:"zh_CN",category:"UTILITY",
    body:"您向 TMG Install 查询的报价单 {{1}} 已备妥。请通过 {{2}} 查看项目、总额和条款。如需更改，请回复，我们的团队会核对。您提出的预约日期和时间须由工作人员确认，付款不会自动确认预约。"},
] as const;
export function exactQuotationProposal(template:any):boolean {
  return QUOTATION_TEMPLATE_PROPOSALS.some(p=>template?.name===p.name&&template?.language===p.language&&
    template?.category===p.category&&template?.components?.filter((c:any)=>c.type==="BODY").length===1&&
    template.components.find((c:any)=>c.type==="BODY").text===p.body);
}
