import type {FirstFacts} from "./whatsappFirst";

type Side="pickup"|"destination"|"both";
const uncertain=(clause:string)=>/\b(?:if|maybe|not sure|whether|might|unsure)\b/i.test(clause);
const negative=(clause:string)=>/\b(?:no|not|without|isn't|is not|aren't|are not|cannot|can't)\b/i.test(clause);
const sideOf=(clause:string):Side=>/\b(?:both|shared)\b/i.test(clause)?"both":
  /\b(?:destination|drop[- ]?off|delivery)\b/i.test(clause)?"destination":
  /\b(?:pickup|collection|origin)\b/i.test(clause)?"pickup":"both";

/** Evaluate separate current assertions in conversational order. Negation and
 * uncertainty belong to the particular route, floor, lift or fit assertion;
 * uncertainty about fit is not evidence that an existing lift disappeared. */
export function movementFacts(facts:FirstFacts,text:string):FirstFacts {
  const next:FirstFacts={...facts};
  const clauses=text.split(/[,;.!?\n]|\b(?:but|however|now|actually|correction)\b/i).map(s=>s.trim()).filter(Boolean);
  const applyLift=(side:Side,value:boolean)=>{
    if(side!=="destination")next.hasLift=value;
    if(side!=="pickup")next.destinationLift=value;
  };
  const applyFit=(side:Side,value:boolean|"unknown")=>{
    if(side!=="destination")next.pickupLiftFit=value;
    if(side!=="pickup")next.destinationLiftFit=value;
  };
  for(const clause of clauses) {
    const historical=/\b(?:originally|previously|used to|old address)\b/i.test(clause);
    const room=/\b(?:another|other|different)\s+room\b.{0,55}\b(?:same house|same home|same unit)\b|\b(?:room[- ]to[- ]room|between rooms|within the same home)\b/i.test(clause);
    const building=/\bsame (?:block|building)\b/i.test(clause);
    const externalMatch=clause.match(/\b(?:different|another|new)\s+(?:house|home|address|building)\b/i);
    const external=!!externalMatch&&!/\b(?:not|no)\s*$/i.test(clause.slice(0,externalMatch.index));
    const requiresVehicle=/\b(?:vehicle|van|lorry) (?:is )?(?:required|needed)\b/i.test(clause)&&!negative(clause);
    if(!historical&&!uncertain(clause)&&!/\bnot (?:the )?same (?:home|house|block|building)\b/i.test(clause)&&
      (room||building||external||requiresVehicle)) {
      const kind=external||requiresVehicle?"vehicle":room?"room_to_room":"same_building";
      if(next.movementKind&&next.movementKind!==kind) {
        delete next.sameLevel;delete next.pickupLiftFit;delete next.destinationLiftFit;
        delete next.hasLift;delete next.destinationLift;
        delete next.floorLevel;delete next.destinationFloor;
      }
      next.movementKind=kind;next.samePropertyMove=kind!=="vehicle";
      if(kind==="room_to_room"){delete next.toAddress;delete next.destinationFloor;delete next.destinationLift;}
      if(kind!=="vehicle")delete next.distanceKm;
    }
    if(historical)continue;
    if(next.movementKind==="room_to_room"&&!uncertain(clause)) {
      if(/\b(?:not on|not|isn't on|aren't on) (?:the )?same (?:floor|level)\b|\bdifferent (?:floors|levels)\b|\bstairs (?:are )?(?:required|involved)\b|\bupstairs\b.{0,40}\bdownstairs\b|\bdownstairs\b.{0,40}\bupstairs\b/i.test(clause))
        next.sameLevel=false;
      else if(/\bsame (?:floor|level)\b|\b(?:no|without) (?:steps|stairs)\b/i.test(clause))next.sameLevel=true;
    }
    const floors=clause.match(/\b(?:from|pickup(?: on)?)\s+(?:the\s+)?(\d+)(?:st|nd|rd|th)?(?:\s+floor)?\s*(?:to|,?\s*destination)\s+(?:the\s+)?(\d+)(?:st|nd|rd|th)?(?:\s+floor)?\b/i);
    const floorContext=/\b(?:floors?|levels?)\b/i.test(clause)||
      (building||next.movementKind==="same_building")&&(clause.match(/\d+(?:st|nd|rd|th)\b/gi)||[]).length>=2;
    if(floors&&floorContext&&!uncertain(clause)){next.floorLevel=Number(floors[1]);next.destinationFloor=Number(floors[2]);}
    const singleFloor=clause.match(/\b(?:floor|level)\s*(\d+)|(\d+)(?:st|nd|rd|th)\s*floor/i);
    if(singleFloor&&!floors&&!uncertain(clause)&&/\b(?:pickup|destination|drop[- ]?off|collection)\b/i.test(clause))
      next[sideOf(clause)==="destination"?"destinationFloor":"floorLevel"]=Number(singleFloor[1]||singleFloor[2]);
    const lift=/\blifts?\b/i.test(clause),fit=/\b(?:fit|fits|fitting|too small|big enough)\b/i.test(clause);
    const side=sideOf(clause)==="both"&&next.movementKind==="vehicle"?"pickup":sideOf(clause);
    if(lift&&fit) {
      applyFit(side,uncertain(clause)?"unknown":!negative(clause)&&!/\btoo small\b/i.test(clause));
      // Availability is a separate fact. A no-fit statement does not erase it.
    } else if((lift||/\bstairs only\b/i.test(clause))&&!uncertain(clause)) {
      if(/\b(?:no|without) (?:a )?lift\b|\bnot (?:by|using) (?:the )?lift\b|\bstairs only\b/i.test(clause))applyLift(side,false);
      else if(/\b(?:(?:suitable )?lift (?:is )?available|(?:by|in the|using the|with|has|have) (?:a )?lifts?|lift transfer)\b/i.test(clause))applyLift(side,true);
    }
  }
  next.items=next.items?.map(i=>i.serviceType==="relocate"?{...i,
    ...(next.samePropertyMove===undefined?{}:{samePropertyMove:next.samePropertyMove}),
    ...(next.floorLevel===undefined?{}:{floorLevel:next.floorLevel}),
    ...(next.destinationFloor===undefined?{}:{destinationFloor:next.destinationFloor}),
    ...(next.hasLift===undefined?{}:{hasLift:next.hasLift}),
    ...(next.destinationLift===undefined?{}:{destinationLift:next.destinationLift}),
  }:i);
  return next;
}
