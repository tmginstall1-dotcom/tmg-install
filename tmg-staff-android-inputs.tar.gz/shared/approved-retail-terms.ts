/**
 * Owner approval recorded 22 October 2026, not inferred from public copy.
 * Applies only when a new standard retail offer is explicitly issued.
 * Not authority to reprice, retrofit legacy issue dates, or replace agreements.
 */
export const APPROVED_RETAIL_OFFER_POLICY = Object.freeze({
  id: "retail-offer-validity-2026-10-22",
  label: "Standard retail offer — 14 calendar days (Asia/Singapore)",
  validityDays: 14,
  effectiveAt: "2026-10-22T00:00:00+08:00",
  approvalRef: "owner-approval-2026-10-22",
});
export function singaporeOfferDeadline(issuedAt: Date, days: number): Date {
  // Singapore UTC+08 has no daylight-saving transition. Preserve its local
  // wall-clock time across calendar dates, including month/year boundaries.
  const local=new Date(issuedAt.getTime()+8*3600_000);
  local.setUTCDate(local.getUTCDate()+days);
  return new Date(local.getTime()-8*3600_000);
}
