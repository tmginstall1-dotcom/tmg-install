export const PENDING_ENQUIRIES_URL = "/admin?view=enquiries";
export function isPendingEnquiry(quote: { status: string }) {
  return ["submitted", "under_review"].includes(quote.status);
}
