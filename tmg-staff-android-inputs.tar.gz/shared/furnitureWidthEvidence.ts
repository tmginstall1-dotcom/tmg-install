export type WidthEvidence = {cm:number;source:string};
const family=(name:string)=>/\b(desk|table)\b/i.test(name)?"desk":
  /\b(wall|entertainment)\b/i.test(name)?"wall":/\b(wardrobe|pax)\b/i.test(name)?"wardrobe":
  /\b(cabinet|drawer|dresser|storage)\b/i.test(name)?"cabinet":/\b(bed|bunk|loft)\b/i.test(name)?"bed":"";
const anchors:Record<string,RegExp>={
  desk:/\b(desk|table)\b/i,wall:/\b(wall|entertainment)\b/i,wardrobe:/\b(wardrobe|pax)\b/i,
  cabinet:/\b(cabinet|drawer|dresser|storage)\b/i,bed:/\b(bed|bunk|loft)\b/i,
};
/** Current-message, item-scoped physical evidence only; ranges are not measurements. */
export function currentItemWidth(name:string,text:string,itemCount:number):WidthEvidence|undefined {
  const target=family(name);
  const identifier=name.replace(/\([^)]*\)/g,"").trim().match(/\b(cabinet|wardrobe|desk|table|bed|wall)\s+([A-Za-z0-9_-]+)$/i)?.[0].toLowerCase();
  for(const segment of text.split(/[;\n]|(?<!\d)[.!](?!\d)/)) {
    if(/\b(last|old|previous|prior|completed|finished)\b[^;\n]*\b(job|order)\b|\b(job|order)\b[^;\n]*(completed|finished)|上次|上个|已完成/i.test(segment))continue;
    const mentioned=Object.entries(anchors).filter(([,pattern])=>pattern.test(segment)).map(([key])=>key);
    if(mentioned.length && (!target||!mentioned.includes(target)||mentioned.some(key=>key!==target)))continue;
    if(!mentioned.length && itemCount!==1)continue;
    const labels=[...segment.matchAll(/\b(?:cabinet|wardrobe|desk|table|bed|wall)\s+[A-Za-z0-9_-]+\b/gi)]
      .filter(match=>!/\b(?:width|height|depth|wide|is|was|dimensions|has|needs)\s*$/i.test(match[0])&&!/\b\d[\dx×.]*\s*(?:cm|mm|m)?$/i.test(match[0]));
    let scoped=segment;
    if(identifier) {
      const exact=labels.filter(match=>match[0].toLowerCase()===identifier);
      if(exact.length!==1)continue;
      const start=exact[0].index!;
      const end=labels.find(match=>match.index!>start)?.index;
      scoped=segment.slice(start,end);
    } else if(labels.length||itemCount>1)continue;
    const clean=scoped.replace(/\b\d+(?:\.\d+)?\s*[-–]\s*\d+(?:\.\d+)?\s*(?:cm|mm|m)\b/gi,"");
    const compound=clean.match(/\b(\d+(?:\.\d+)?)\s*[x×]\s*(\d+(?:\.\d+)?)\s*[x×]\s*(\d+(?:\.\d+)?)\s*(mm|cm|m)\b/i);
    const labelled=clean.match(/\b(?:width|wide|w)\s*(?:is\s*)?[:=]?\s*(\d+(?:\.\d+)?)\s*(mm|cm|m)\b/i)||
      clean.match(/\b(\d+(?:\.\d+)?)\s*(mm|cm|m)\s*(?:wide|width)\b/i);
    let value:number|undefined,unit:string|undefined;
    if(labelled){value=Number(labelled[1]);unit=labelled[2];}
    else if(compound) {
      const order=clean.match(/\b(height|width|depth|length|h|w|d|l)\s*[x×]\s*(height|width|depth|length|h|w|d|l)\s*[x×]\s*(height|width|depth|length|h|w|d|l)\b/i);
      const widthIndex=order?.slice(1).findIndex(token=>/^(width|w)$/i.test(token));
      if(widthIndex===undefined||widthIndex<0||order?.slice(1).filter(token=>/^(width|w)$/i.test(token)).length!==1)continue;
      value=Number(compound[widthIndex+1]);unit=compound[4];
    }
    if(value===undefined||!unit)continue;
    const cm=value*(unit.toLowerCase()==="mm"?0.1:unit.toLowerCase()==="m"?100:1);
    if(cm>0&&cm<10000)return {cm,source:scoped.trim()};
  }
}
