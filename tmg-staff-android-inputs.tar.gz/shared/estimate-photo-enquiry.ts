import { TMG_BUSINESS_PHONE } from "./whatsapp-handoff";

const serviceLabels: Record<string, string> = {
  install: "Installation / assembly",
  dismantle: "Dismantling",
  relocate: "Relocation",
  dispose: "Disposal",
  dismantle_dispose: "Dismantling and disposal",
};

export function estimatePhotoEnquiryMessage(
  services: readonly string[],
  serviceIntent = "",
): string {
  const labels = [...new Set(services)].map(service => serviceLabels[service]).filter(Boolean);
  const intent = serviceIntent.replace(/\s+/g, " ").trim().slice(0, 160);
  const relocation = services.includes("relocate");
  return [
    "Hi TMG Install, I'd like a quote from furniture photos or product links.",
    `Service: ${labels.length ? labels.join(" + ") : "Please help me choose the service."}`,
    ...(intent ? [`Work: ${intent}`] : []),
    "I'll share photos or product links and the quantity of each item.",
    relocation ? "Pickup and drop-off areas/postcodes:" : "Area/postcode:",
    "Preferred date (optional):",
    relocation ? "Lift/stairs access at each location:" : "Lift/stairs access:",
    "Please confirm the scope and price. Appointment dates and times need staff confirmation.",
  ].join("\n");
}

export function estimatePhotoEnquiryUrl(services: readonly string[], serviceIntent = ""): string {
  return `https://wa.me/${TMG_BUSINESS_PHONE}?text=${encodeURIComponent(
    estimatePhotoEnquiryMessage(services, serviceIntent),
  )}`;
}
