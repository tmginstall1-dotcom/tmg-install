import type {FirstFacts} from "./whatsappFirst";
/** Answer the immediate question without making claims about unseen files. */
export function directQuestionAnswer(text:string,facts:FirstFacts):string {
 const zh=facts.language==="zh";
 if(/(?:what|meaning|mean|difference).{0,40}(?:individual|sets?|pieces?)|(?:individual|sets?|pieces?).{0,30}(?:mean|difference)|套.{0,8}(?:意思|区别)|什么.{0,4}(?:套|件)/i.test(text))
   return zh?"一件是一个独立家具；一套是一组配套家具。请告诉我们每种家具的数量。":"A piece is one individual furniture item; a set is a group supplied together. We need the count of each furniture type.";
 if(/(?:can|did|do|have).{0,25}(?:see|read|receive|received|got).{0,20}(?:photo|picture|image)|(?:photo|picture).{0,20}(?:received|visible)|(?:看到|收到|看得清).{0,8}(?:照片|图片)/i.test(text)) {
   const photos=facts.evidence?.filter(e=>e.kind==="photo")||[];
   if(!photos.length&&!facts.photos?.length)return zh?"这里还没有可用的照片。请再上传一次，或提供型号和尺寸。":"There isn't an available photo here yet. Please upload it again, or share the model and dimensions.";
   if(!photos.some(e=>e.readable))return zh?"已收到照片，但还不能可靠辨认家具。请说明每张照片对应哪个项目或提供型号。":"I received the photos, but can't identify the furniture reliably yet. Please say which item each photo shows, or share its model.";
   return zh?"已收到可读取的照片。我们会按每张照片对应的项目核对，未确认的部分不会猜价。":"I received readable photo evidence. I'll use it for the matching item; unidentified parts still need clarification.";
 }
 return "";
}
