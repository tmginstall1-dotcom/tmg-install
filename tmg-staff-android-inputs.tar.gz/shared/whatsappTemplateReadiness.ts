import {exactQuotationProposal} from "./whatsappQuotationTemplates";
export function carriesCustomerQuoteLink(template: {
  components?: Array<{type?:string;text?:string;buttons?:Array<{type?:string;url?:string}>}>;
  bindings?: Record<string,string>;
}):boolean {
  return !!template.components?.some(component=>
    (["BODY","HEADER"].includes(component.type||"") &&
      Array.from(String(component.text||"").matchAll(/\{\{(\d+|[A-Za-z][A-Za-z0-9_]*)\}\}/g))
        .some(match=>template.bindings?.[`${component.type}:${match[1]}`]==="url")) ||
    (component.type==="BUTTONS"&&!!component.buttons?.some(button=>
      button.type==="URL"&&/^https:\/\/tmginstall\.com\/quotes\//.test(button.url||"")&&
      button.url?.endsWith("{{1}}"))));
}

export function eligibleQuoteTemplate(template:any, now=Date.now()):boolean {
  const verified=Date.parse(String(template?.verifiedAt||""));
  return template?.status==="APPROVED"&&template?.category==="UTILITY"&&template?.source==="meta"&&
    template?.purpose==="quote"&&Number.isFinite(verified)&&verified<=now&&now-verified<86400000&&
    exactQuotationProposal(template)&&template?.bindings?.["BODY:1"]==="referenceNo"&&template?.bindings?.["BODY:2"]==="url";
}
