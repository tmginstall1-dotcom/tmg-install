import type {FirstFacts} from "./whatsappFirst";

export const GENERIC_DISPOSAL_REVIEW = "Disposal: confirm old furniture versus cardboard/crates, quantities and visits";

/** A counted furniture-disposal caption can confirm already itemised scope.
 * This is not an identity classifier, catalogue match or approved price.
 * Unreadable photos and unsupported rates remain independent review gates.
 */
export function confirmsItemisedDisposal(text:string,facts:FirstFacts):boolean {
  if(/\b(?:also|additional|another|extra|cardboard|cartons?|crates?|visits?|trips?)\b|纸箱|木箱|另外|还有/i.test(text))return false;
  const count=text.match(/\b(?:this|these|those)\s+(one|two|three|four|\d+)\s+items?\s+(?:is|are)\s+for\s+(?:disposal|removal)\b/i);
  if(!count)return false;
  const words:Record<string,number>={one:1,two:2,three:3,four:4};
  const quantity=words[count[1].toLowerCase()]??Number(count[1]);
  const lines=(facts.items||[]).filter(l=>l.serviceType==="dispose"||l.serviceType==="dismantle_dispose");
  return quantity>0&&lines.length>0&&lines.every(l=>!!l.quantity&&!l.ambiguity)&&
    lines.reduce((n,l)=>n+l.quantity!,0)===quantity;
}
