// Owner-confirmed account setup only. This is NOT approval to export/upload any record.
export const VERIFIED_GOOGLE_OUTCOME_SETUP={
  customerId:"8190888513",
  accountLabel:"The Moving Guy Pte Ltd",
  accountSetupReviewed:true,
  complianceConfirmed:true,
  count:"ONE",clickWindowDays:90,primary:false,accountDefaultGoals:false,monetaryValue:false,
  actions:{
    qualified_enquiry:{resourceName:"customers/8190888513/conversionActions/7848846172",csvName:"TMG Qualified Enquiry"},
    booking_confirmed:{resourceName:"customers/8190888513/conversionActions/7848846175",csvName:"TMG Confirmed Job"},
  },
} as const;
