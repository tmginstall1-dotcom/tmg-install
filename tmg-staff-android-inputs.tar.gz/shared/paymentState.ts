import { depositPaidFallback } from "./pricing";
import { isReviewQuotation } from "./quotation-document-notes";

/** Receipt issuance needs actual ledger funds, not administrative closed/paid flags. */
export const hasCanonicalFullPayment=(q:any)=>quotePaymentSummary({...q,
  leadIntake:{...q?.leadIntake,settlementLedgerIncludesLegacy:true}}).settled;

/** Only persisted received-payment rows and legacy settlement stamps are money.
 * Pending uploads/claims/status labels are not clearance. Match storage's
 * current-version coordinator rule; legacy reconciled credit remains carried. */
export function quotePaymentSummary(quote: any) {
  // A priced component is evidence of work, not authority to collect a deposit.
  // Keep cleared credit/history, but never infer a debt or settlement from it.
  const pricingPending = isReviewQuotation(quote);
  const total = Math.max(0, Number(quote?.total) || 0);
  const coordinated = !!quote?.leadIntake?.coordinatorRelease;
  const ledgerPaid = (quote?.payments || []).reduce((sum: number, row: any) => {
    const eligible = coordinated
      ? row.quoteVersion === quote.version || quote.version === 1 && row.quoteVersion == null
      : row.quoteVersion !== 0;
    const amount = Number(row.amount);
    return sum + (eligible && Number.isFinite(amount) && (amount > 0 || row.method==="stripe_refund"&&amount<0) ? amount : 0);
  }, 0);
  const deposit = depositPaidFallback(total, quote?.depositAmount);
  const legacyDeposit = !coordinated && !quote?.leadIntake?.settlementLedgerIncludesLegacy && quote?.depositPaidAt
    ? Math.max(0, Number(quote.depositAmount) || (pricingPending?0:deposit)) : 0;
  const paid = coordinated||quote?.leadIntake?.settlementLedgerIncludesLegacy ? Math.max(0,ledgerPaid)
    : pricingPending ? ledgerPaid + legacyDeposit
    : Math.min(total, !coordinated && quote?.finalPaidAt ? total : ledgerPaid + legacyDeposit);
  const outstanding = pricingPending ? 0 : Math.max(0, Math.round((total - paid) * 100) / 100);
  const initialDue = pricingPending ? 0 : Math.max(0, Math.round((deposit - paid) * 100) / 100);
  const initialCollected = !pricingPending && deposit > 0 && initialDue <= 0.005;
  const settled = !pricingPending && total > 0 && outstanding <= 0.005;
  const status = pricingPending ? "pricing_pending" : settled ? "paid_in_full" : initialCollected ? "deposit_paid"
    : paid > 0 ? "partially_paid" : quote?.paymentStatus === "deposit_pending" ? "deposit_pending" : "unpaid";
  return { paid, outstanding, initialDue, initialCollected, settled, status, pricingPending };
}

export function initialPaymentCollected(
  paymentStatus: string | null | undefined,
  depositPaidAt: unknown,
): boolean {
  return Boolean(depositPaidAt)
    || paymentStatus === "deposit_paid"
    || paymentStatus === "paid_in_full";
}