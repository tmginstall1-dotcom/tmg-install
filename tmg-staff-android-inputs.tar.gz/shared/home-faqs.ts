export const HOME_FAQS = [
  {
    q: "How do I get a quote for furniture installation or dismantling in Singapore?",
    a: "Use the web form or WhatsApp us at +65 8088 0757 with photos, an item list and quantity, your location, preferred date and lift, stairs or loading access details. We review the scope and confirm the quote before work starts.",
  },
  {
    q: "Can you install office furniture and multi-seat workstations?",
    a: "Yes. Enquire about office workstations, desks, chairs, pedestals and meeting-room furniture. Share the number of seats, building access and loading arrangements; both one-room jobs and larger coordinated projects can be reviewed.",
  },
  {
    q: "Can you assemble Taobao, IKEA or other flat-pack furniture?",
    a: "Yes. We install Taobao, IKEA and other flat-pack furniture for home or office. Send photos of the boxes, item list and manuals if available so we can review the work.",
  },
  {
    q: "How much does furniture installation or dismantling cost in Singapore?",
    a: "Installation and dismantling labour prices come from the current item catalog and depend on the furniture and requested work. Use the itemised quote tool or send photos and an item list on WhatsApp. Mobilisation, access, transport and additional work are itemised where applicable; we confirm the full quote before work starts.",
  },
  {
    q: "Can you dismantle furniture for an office move or reinstatement?",
    a: "We can review furniture dismantling for office moves, reconfiguration or reinstatement-related furniture work. Share the item count, building access and required timing. This covers furniture only, not renovation, electrical, painting or other reinstatement trades. For a home move that also needs transport and reinstallation, ask about relocation support.",
  },
  {
    q: "Can I book dismantling without transport?",
    a: "Yes. Furniture dismantling can be enquired about on its own, for example before a move, replacement, storage or disposal. Select Dismantling in the quote form.",
  },
  {
    q: "Which areas of Singapore do you cover?",
    a: "Enquiries are welcome island-wide across Singapore, including HDB flats, condos, landed homes and commercial premises. Tell us about lift, stairs, loading-bay or other building access requirements when requesting a quote.",
  },
  {
    q: "Do you take home jobs with just one item?",
    a: "Yes. Home and single-item enquiries are welcome, including beds, wardrobes, desks and other furniture. Send a photo, item details and your location so we can assess the work.",
  },
  {
    q: "When do I pay?",
    a: "Follow the payment terms in your confirmed quotation; the balance is due after completion where applicable. Staff must separately confirm the appointment date and time. Paying a deposit or full payment alone does not confirm a booking.",
  },
];