export function accessEvidence(text:string) {
  const separator=/\b(?:to|another address|destination)\b/i.exec(text);
  const separated=/\b(?:from|pickup|collection)\b/i.test(text)&&!!separator;
  const destinationOnly=!separated&&/\b(?:destination|drop[- ]?off|delivery (?:address|floor))\b|目的地|送到/i.test(text)&&
    !/\b(?:pickup|pick up|collection|from)\b|取货/i.test(text);
  const parts=separated?[text.slice(0,separator!.index),text.slice(separator!.index+separator![0].length)]:
    destinationOnly?["",text]:[text,""];
  const read=(part:string)=>{
    const floor=part.match(/(?:floor|level)\s*(\d+)|(\d+)(?:st|nd|rd|th)\s*floor|(\d+)\s*楼/i);
    const conditional=/\b(?:if|as long as|not sure|don't know|do not know|might|maybe|whether)\b|不确定|不知道|如果/i.test(part);
    const hasLift=conditional?undefined:/\b(?:no|without)\s+(?:a\s+)?lift\b|\blift (?:is )?not needed\b|没有电梯|不需要电梯/i.test(part)?false:
      /\b(?:with|has|have)\s+(?:a\s+)?(?:suitable\s+)?lift\b|有电梯/i.test(part)?true:undefined;
    return {floor:floor?Number(floor[1]||floor[2]||floor[3]):/\bground floor\b|底楼/i.test(part)?0:undefined,hasLift};
  };
  return {separated,pickup:read(parts[0]),destination:read(parts[1])};
}
