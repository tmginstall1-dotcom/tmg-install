export const STORAGE_DESK_NAME = "Wardrobe / Cabinet with Attached Study Desk";
export const STORAGE_DESK_INSTALL_PRICE = 220;
export const STORAGE_DESK_INSTALL_SKU = "STORAGE-DESK-COMBO-INSTALL";

/** Connected storage + study furniture is not a wardrobe-only SKU. */
export function classifyIntegratedStorageDesk(item: {
  name?: string;
  type?: string;
  notes?: string;
  hasAttachedDesk?: boolean;
}): string | null {
  const name = String(item.name ?? item.type ?? "").trim();
  if (name.toLowerCase() === STORAGE_DESK_NAME.toLowerCase()) return STORAGE_DESK_NAME;
  const evidence = `${name} ${item.notes || ""}`;
  if (/\b(bed|bunk|loft|kitchen|vanity|entertainment|tv console)\b/i.test(name)) return null;
  if (!/\b(wardrobe|closet|cabinet|cupboard|storage tower)\b/i.test(evidence)) return null;
  const attached = /\b(?:attached|integrated|connected|built[- ]in)\s+(?:study\s+|computer\s+)?desk\b/i.test(evidence);
  return item.hasAttachedDesk === true || attached ? STORAGE_DESK_NAME : null;
}

export const STORAGE_DESK_VISION_GUIDE = `
CONNECTED STORAGE AND STUDY DESK:
- Inspect the ENTIRE unit, including its right-hand extension. A tall cupboard/wardrobe with open shelves and a physically attached study desk is "${STORAGE_DESK_NAME}", quantity 1.
- Do not price only its hinged doors as a standalone wardrobe, or split the attached desk and shelving into separate cheap items.
- Return hasAttachedDesk=true only when a study desk is physically connected to the cabinet/wardrobe. A separate desk standing nearby is not attached. Describe the connection in notes.
- Use this family for the freestanding storage-and-study combination, not kitchen worktops, vanity counters, bunk/loft beds, or large built-in full-wall systems. If the construction or scope is unclear, mark ambiguous=true.
- Use the exact catalog name when present; otherwise request review. Never invent prices or other service rates.
`;
