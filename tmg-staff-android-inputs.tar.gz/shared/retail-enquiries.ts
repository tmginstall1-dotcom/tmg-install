/** Internal enquiry housekeeping is deliberately separate from job/financial state. */
export type RetailOutcome = "declined" | "duplicate" | "dormant" | "review_backlog";
export type RetailDecision = {id:number;outcome:RetailOutcome|"restore";reason:string;canonicalQuoteId?:number};
export const reviewedProtectedIds = new Set([710,698,692,678,665,637,486,430,410,382,617,526,517,496,495,460,446,420,409,693,675,654,509,
  657,656,655,653,652,640,638,674,667,658,659,660,661,662,663,664,407,
  443,429,397,296,255,554,556,528,433,592]);
export const reviewedProjectIds = new Set([665,658,659,660,661,662,663,664,637,486,430,410,382]);
export const reviewedCleanupPlan:RetailDecision[]=[
  ...[[716,710],[699,698],[405,407]].map(([id,canonicalQuoteId])=>({id,canonicalQuoteId,outcome:"duplicate" as const,reason:"Owner-audited alias of retained canonical job; preserve all evidence and finances"})),
  ...[718,679,452,436,299].map(id=>({id,outcome:"declined" as const,reason:"Owner-audited explicit decline of this retail enquiry; not payment or completion"})),
  {id:630,outcome:"dormant",reason:"Owner-audited 8 October delivered/read request unanswered; recheck matching message, later activity and obligations"},
  ...[615,590,579,555,536,527,461,442,428,375,374,289,274,250,246,244,231,616,342,178]
    .map(id=>({id,outcome:"review_backlog" as const,reason:"Owner-reviewed uncertain older retail enquiry / validity needs review; not proven rejected, expired or dormant"})),
];
export function canonicalEnquiryPhone(value:string|null|undefined) {
  const n=(value||"").replace(/\D/g,"");
  return n.length===10&&n.startsWith("65")?n.slice(2):n;
}
export function enquiryDisposition(q:any):any {return q.leadIntake?.retailDisposition||null;}
export function isProjectEnquiry(q:any) {
  return reviewedProjectIds.has(q.id)||q.invoiceType==="commercial"||q.sourceChannel==="gogovan"||!!q.billingCompanyName||!!q.poNumber||
    !!q.commercialInvoiceSentAt||q.leadIntake?.billingMode&&q.leadIntake.billingMode!=="retail"||
    !!q.customerCompanyName||q.hasAccountBilling||q.leadIntake?.project===true||q.leadIntake?.commercial===true||
    /\b(project|commercial|corporate|account|invoice|b2b|enterprise)\b|\bnet\s*\d+|\bmonthly billing\b/i.test([q.leadIntake?.salesPath,q.leadIntake?.billingTerms,
      q.leadIntake?.paymentTerms,q.leadIntake?.customerType,q.leadIntake?.classification].filter(Boolean).join(" "));
}
export function operationalEnquiry(q:any) {
  return !!(q.hasPayments||q.hasAcceptedBaseline||q.termsAcceptedAt||q.termsAcceptedVersion||q.depositPaidAt||q.finalPaidAt||
    q.hasBooking||q.scheduledAt||q.assignedStaffId||q.assignedTeamId||
    ["booked","assigned","in_progress","at_pickup","in_transit","at_dropoff","completed","closed","final_paid","final_payment_requested","cancelled"].includes(q.status));
}
export function retailView(q:any) {
  if(operationalEnquiry(q))return "operations";
  if(isProjectEnquiry(q))return "project";
  const d=enquiryDisposition(q);
  if(q.archiveVisibilityOverridden)return "active";
  return d?d.outcome==="review_backlog"?"backlog":"archive":"active";
}
export function retailProtection(q:any) {
  const reasons:string[]=[];
  if(reviewedProtectedIds.has(q.id))reasons.push("Owner-protected record / awaiting our reply");
  if(isProjectEnquiry(q))reasons.push("Project, commercial, account invoice or operational mirror");
  if(q.termsAcceptedAt||q.termsAcceptedVersion||q.hasAcceptedBaseline)reasons.push("Accepted agreement");
  if(q.hasPayments||q.depositPaidAt||q.finalPaidAt||q.refundCompletedAt||q.refundApprovedAmount!=null)
    reasons.push("Payment/refund evidence");
  if(q.hasPendingCheckout||q.hasFinancialHold||q.paymentStatus&&q.paymentStatus!=="unpaid")
    reasons.push("Pending payment, payment claim or reconciliation requires review");
  if(q.hasDispute)reasons.push("Disputed record");
  if(q.scheduledAt||q.assignedStaffId||q.assignedTeamId||
    ["booked","assigned","in_progress","at_pickup","in_transit","at_dropoff","completed","closed","final_paid","final_payment_requested"].includes(q.status))
    reasons.push("Confirmed/assigned/performed work");
  if(q.hasBooking)reasons.push("Confirmed booking authorization");
  if(q.status==="cancelled")reasons.push("Historical administrative cancellation");
  return reasons;
}
export function dormantBlockers(q:any,at=new Date()) {
  const reasons=retailProtection(q);
  const lead=q.leadIntake||{},facts=lead.facts||{};
  if(q.validOffer)reasons.push("Current valid offer");
  if(q.pendingReschedule||q.hasScheduledFollowup||lead.schedulingRequest?.status==="pending_staff_confirmation"||
    facts.deferredUntil||lead.promisedFollowup||lead.pendingReschedule||
    /reschedul|postpon|follow.?up|will (?:reply|confirm|contact)|await(?:ing)? (?:our|office|staff)/i.test([q.notes,facts.specialNotes,lead.staffObligation].filter(Boolean).join(" ")))
    reasons.push("Promised follow-up, reschedule or awaiting staff");
  if(!q.lastMeaningfulAt||at.getTime()-Date.parse(q.lastMeaningfulAt)<14*86400000)
    reasons.push("Less than 14 days without meaningful activity");
  // Without evidence of whose turn it is, silence is not a safe automatic decision.
  if(!q.customerWaitingEvidence)reasons.push("No episode-bound delivered/read customer request with no later reply or staff obligation");
  return [...new Set(reasons)];
}
