// Singapore standard-wall labour rates, per piece. The pricing engine adds the
// existing $39.90 visit fee once per non-relocation job, not once per item.
// Benchmarks: gethandyman.sg (mirror/picture from $80 including transport),
// fixmove.sg (hanging labour from $40; visit minimum/other charges separate).
// Limits refer to BOTH longest side (diameter for round mirrors) AND weight.
// Oversized/heavier pieces, valuable art, damaged hanging hardware, tile/stone,
// glass or unsuitable partition walls need an individually confirmed scope.
export const WALL_HANGING_DEFINITIONS = [
  { name: "Wall Mirror (Small, up to 60cm longest side / 10kg)", skuBase: "WALL-MIRROR-SM-R61", install: 40, dismantle: 25, dispose: 25, dismantle_dispose: 40, volumeM3: "0.03" },
  { name: "Wall Mirror (Medium, up to 100cm longest side / 20kg)", skuBase: "WALL-MIRROR-MD-R61", install: 55, dismantle: 35, dispose: 35, dismantle_dispose: 55, volumeM3: "0.08" },
  { name: "Wall Mirror (Large, up to 180cm longest side / 30kg)", skuBase: "WALL-MIRROR-LG-R61", install: 85, dismantle: 50, dispose: 50, dismantle_dispose: 75, volumeM3: "0.15" },
  { name: "Picture Frame / Painting / Canvas Artwork (Small, up to 60cm longest side / 5kg)", skuBase: "WALL-ART-SM-R61", install: 25, dismantle: 15, dispose: 20, dismantle_dispose: 30, volumeM3: "0.02" },
  { name: "Picture Frame / Painting / Canvas Artwork (Medium, up to 100cm longest side / 10kg)", skuBase: "WALL-ART-MD-R61", install: 40, dismantle: 20, dispose: 25, dismantle_dispose: 40, volumeM3: "0.05" },
  { name: "Picture Frame / Painting / Canvas Artwork (Large, up to 180cm longest side / 20kg)", skuBase: "WALL-ART-LG-R61", install: 60, dismantle: 30, dispose: 35, dismantle_dispose: 55, volumeM3: "0.10" },
] as const;

export const WALL_HANGING_CATALOG_ROWS = WALL_HANGING_DEFINITIONS.flatMap(item => {
  const prices = {
    install: item.install,
    dismantle: item.dismantle,
    // Match the existing 40%-off dismantle-and-reinstall bundle; transport is
    // calculated separately by the central pricing engine.
    relocate: (item.install + item.dismantle) * 0.6,
    dispose: item.dispose,
    dismantle_dispose: item.dismantle_dispose,
  };
  return Object.entries(prices).map(([serviceType, price]) => ({
    name: item.name,
    sku: `${item.skuBase}-${serviceType.toUpperCase()}`,
    category: "Wall-Mounted — Mirrors & Wall Art",
    serviceType,
    basePrice: price.toFixed(2),
    volumeM3: item.volumeM3,
    active: true,
  }));
});