import { LEAD_INTENT_OPTIONS, type LeadIntentValue } from "./lead-intent";

export const FOCUSED_SERVICE_LANDINGS = [
  { slug: "office-furniture-installation-singapore", intent: "office_furniture_install", service: "install", site: "office" },
  { slug: "office-workstation-installation-singapore", intent: "office_workstation_install", service: "install", site: "office" },
  { slug: "furniture-dismantling-singapore", intent: "furniture_dismantling", service: "dismantle", site: "" },
  { slug: "taobao-furniture-installation-singapore", intent: "taobao_flatpack_install", service: "install", site: "" },
  { slug: "furniture-installation-singapore", intent: "", service: "install", site: "" },
  { slug: "wardrobe-dismantling-singapore", intent: "furniture_dismantling", service: "dismantle", site: "" },
] as const;

export function serviceEstimateHref(slug: string): string {
  const page = FOCUSED_SERVICE_LANDINGS.find(page => page.slug === slug);
  if (!page) return "/estimate";
  const params = new URLSearchParams({
    service: page.service, landing_page: `/services/${page.slug}`,
  });
  if (page.intent) params.set("intent", page.intent);
  if (page.site) params.set("site", page.site);
  return `/estimate?${params}`;
}

export function serviceCanonicalRedirect(slug: string, originalUrl: string): string {
  const page = FOCUSED_SERVICE_LANDINGS.find(page => page.slug === slug);
  if (!page) return "/services";
  const queryStart = originalUrl.indexOf("?");
  return `/services/${page.slug}${queryStart < 0 ? "" : originalUrl.slice(queryStart)}`;
}

/** Campaign context is advisory, never a trusted pricing or routing assertion. */
export function estimateLandingContext(search: string): {
  intent?: LeadIntentValue; siteType?: string; originatingServicePage?: string;
} {
  const params = new URLSearchParams(search);
  const intent = LEAD_INTENT_OPTIONS.find(option => option.value === params.get("intent"))?.value;
  const origin = params.get("landing_page");
  const page = FOCUSED_SERVICE_LANDINGS.find(page => `/services/${page.slug}` === origin);
  return {
    intent,
    siteType: params.get("site") === "office" || intent?.startsWith("office_") ? "office" : undefined,
    originatingServicePage: page ? `/services/${page.slug}` : undefined,
  };
}

export type ServiceLandingPricing = {
  rows: Array<{ label: string; min: number; max: number }>;
};
type CatalogPrice = { name: string; category?: string | null; serviceType: string; basePrice: string | number; active?: boolean | null };

/** Only active, positive catalog labour prices; no synthetic fallback or fees. */
export function serviceLandingPricing(slug: string, catalog: CatalogPrice[]): ServiceLandingPricing {
  const page = FOCUSED_SERVICE_LANDINGS.find(page => page.slug === slug);
  if (!page) return { rows: [] };
  const definitions: Array<[string, RegExp]> = page.slug === "wardrobe-dismantling-singapore"
    ? [["Wardrobes", /wardrobe|pax/i]]
    : page.slug === "furniture-installation-singapore"
    ? [["Wardrobes & storage", /wardrobe|cabinet|bookcase|shelving/i], ["Bed frames", /\bbed\b|bunk|loft/i], ["Desks & tables", /\bdesk\b|\btable\b/i]]
    : page.intent === "office_workstation_install"
    ? [["Workstations & cubicles", /workstation|cubicle/i], ["Office desks", /office.*desk|standing desk/i]]
    : page.intent === "office_furniture_install"
      ? [["Office desks & meeting tables", /office.*desk|standing desk|conference|meeting table/i], ["Workstations & cubicles", /workstation|cubicle/i], ["Office chairs", /office.*chair|ergonomic.*chair/i]]
      : page.intent === "furniture_dismantling"
        ? [["Workstations & office systems", /workstation|cubicle|office partition/i], ["Wardrobes & cabinets", /wardrobe|cabinet/i], ["Bed frames", /\bbed\b|bunk|loft/i]]
        : [["Taobao wardrobes & cabinets", /(?:taobao|flat.pack).*(?:wardrobe|cabinet)/i], ["Taobao beds & desks", /(?:taobao|flat.pack).*(?:bed|desk|table)/i]];
  const eligible = catalog.filter(item => item.active !== false && item.category !== "_internal" &&
    !/\bper (?:hole|point|metre|meter|screw|hinge|handle)\b/i.test(item.name) &&
    item.serviceType === page.service && Number.isFinite(Number(item.basePrice)) && Number(item.basePrice) > 0);
  return {
    rows: definitions.flatMap(([label, pattern]) => {
      const prices = eligible.filter(item => pattern.test(item.name)).map(item => Number(item.basePrice));
      return prices.length ? [{ label, min: Math.min(...prices), max: Math.max(...prices) }] : [];
    }),
  };
}