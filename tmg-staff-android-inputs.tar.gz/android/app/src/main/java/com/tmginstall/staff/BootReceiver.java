package com.tmginstall.staff;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

/**
 * Restarts the location service after device reboot or app update,
 * if tracking was active when the device was shut down.
 */
public class BootReceiver extends BroadcastReceiver {

    private static final String TAG = "TMGBootReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent == null ? "" : (intent.getAction() == null ? "" : intent.getAction());
        Log.d(TAG, "onReceive action=" + action);

        SharedPreferences prefs = context.getSharedPreferences(
            TMGLocationPlugin.PREFS, Context.MODE_PRIVATE);
        boolean wasTracking = prefs.getBoolean("tracking_active", false);
        int staffId         = prefs.getInt("staff_id", -1);

        if (!wasTracking || staffId < 0) {
            Log.d(TAG, "Not restarting — wasTracking=" + wasTracking + " staffId=" + staffId);
            return;
        }

        Log.d(TAG, "Restarting location service for staffId=" + staffId);
        Intent svcIntent = new Intent(context, TMGLocationService.class);
        svcIntent.putExtra("staff_id", staffId);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(svcIntent);
            } else {
                context.startService(svcIntent);
            }
        } catch (Exception e) {
            Log.w(TAG, "Could not start service: " + e.getMessage());
        }
    }
}
