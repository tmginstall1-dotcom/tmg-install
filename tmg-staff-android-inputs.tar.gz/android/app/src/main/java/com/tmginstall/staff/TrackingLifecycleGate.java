package com.tmginstall.staff;

/** Serializes stop against delayed location/HTTP callbacks, without Android APIs. */
final class TrackingLifecycleGate {
    private long generation=0;
    private boolean stopped=true;
    synchronized long begin(){stopped=false;return ++generation;}
    synchronized long token(){return generation;}
    synchronized void stop(){stopped=true;++generation;}
    synchronized boolean current(long token){return !stopped&&generation==token;}
    synchronized boolean run(long token,Runnable action){
        if(!current(token))return false;
        action.run();return true;
    }
}
